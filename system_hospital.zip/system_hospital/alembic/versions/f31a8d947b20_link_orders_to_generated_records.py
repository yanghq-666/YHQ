"""link medical orders to generated business records

Revision ID: f31a8d947b20
Revises: c8e27b1a4f02
Create Date: 2026-09-17
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "f31a8d947b20"
down_revision: Union[str, Sequence[str], None] = "c8e27b1a4f02"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    with op.batch_alter_table("prescriptions") as batch_op:
        batch_op.add_column(sa.Column("order_id", sa.Integer(), nullable=True))
        batch_op.create_foreign_key("fk_prescriptions_order_id", "medical_orders", ["order_id"], ["id"], ondelete="RESTRICT")
        batch_op.create_index("ix_prescriptions_order_id", ["order_id"], unique=True)
    with op.batch_alter_table("lab_reports") as batch_op:
        batch_op.add_column(sa.Column("order_id", sa.Integer(), nullable=True))
        batch_op.create_foreign_key("fk_lab_reports_order_id", "medical_orders", ["order_id"], ["id"], ondelete="RESTRICT")
        batch_op.create_index("ix_lab_reports_order_id", ["order_id"], unique=True)
    with op.batch_alter_table("examinations") as batch_op:
        batch_op.add_column(sa.Column("order_id", sa.Integer(), nullable=True))
        batch_op.create_foreign_key("fk_examinations_order_id", "medical_orders", ["order_id"], ["id"], ondelete="RESTRICT")
        batch_op.create_index("ix_examinations_order_id", ["order_id"], unique=True)


def downgrade() -> None:
    for table in ("examinations", "lab_reports", "prescriptions"):
        with op.batch_alter_table(table) as batch_op:
            batch_op.drop_index(f"ix_{table}_order_id")
            batch_op.drop_constraint(f"fk_{table}_order_id", type_="foreignkey")
            batch_op.drop_column("order_id")
