"""add lightweight input catalogs

Revision ID: c8e27b1a4f02
Revises: a7c41d92e630
Create Date: 2026-09-10
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "c8e27b1a4f02"
down_revision: Union[str, Sequence[str], None] = "a7c41d92e630"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _timestamps() -> tuple[sa.Column, sa.Column]:
    return (
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )


def upgrade() -> None:
    op.create_table(
        "drug_catalogs",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("drug_code", sa.String(50), nullable=False),
        sa.Column("drug_name", sa.String(255), nullable=False),
        sa.Column("generic_name", sa.String(255)),
        sa.Column("dosage_form", sa.String(100)),
        sa.Column("specification", sa.String(255)),
        sa.Column("unit", sa.String(50)),
        sa.Column("manufacturer", sa.String(255)),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
        *_timestamps(),
    )
    op.create_index(op.f("ix_drug_catalogs_drug_code"), "drug_catalogs", ["drug_code"], unique=True)
    op.create_index(op.f("ix_drug_catalogs_drug_name"), "drug_catalogs", ["drug_name"])
    op.create_index(op.f("ix_drug_catalogs_is_active"), "drug_catalogs", ["is_active"])

    op.create_table(
        "diagnosis_catalogs",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("diagnosis_code", sa.String(50), nullable=False),
        sa.Column("diagnosis_name", sa.String(255), nullable=False),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
        *_timestamps(),
    )
    op.create_index(op.f("ix_diagnosis_catalogs_diagnosis_code"), "diagnosis_catalogs", ["diagnosis_code"], unique=True)
    op.create_index(op.f("ix_diagnosis_catalogs_diagnosis_name"), "diagnosis_catalogs", ["diagnosis_name"])
    op.create_index(op.f("ix_diagnosis_catalogs_is_active"), "diagnosis_catalogs", ["is_active"])

    op.create_table(
        "lab_test_catalogs",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("test_code", sa.String(50), nullable=False),
        sa.Column("test_name", sa.String(255), nullable=False),
        sa.Column("unit", sa.String(50)),
        sa.Column("reference_range", sa.String(255)),
        sa.Column("result_type", sa.String(50), nullable=False, server_default="NUMERIC"),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
        *_timestamps(),
    )
    op.create_index(op.f("ix_lab_test_catalogs_test_code"), "lab_test_catalogs", ["test_code"], unique=True)
    op.create_index(op.f("ix_lab_test_catalogs_test_name"), "lab_test_catalogs", ["test_name"])
    op.create_index(op.f("ix_lab_test_catalogs_is_active"), "lab_test_catalogs", ["is_active"])

    with op.batch_alter_table("prescription_items") as batch_op:
        batch_op.add_column(sa.Column("drug_catalog_id", sa.Integer()))
        batch_op.add_column(sa.Column("dosage_form", sa.String(100)))
        batch_op.create_index(op.f("ix_prescription_items_drug_catalog_id"), ["drug_catalog_id"])
        batch_op.create_foreign_key(op.f("fk_prescription_items_drug_catalog_id_drug_catalogs"), "drug_catalogs", ["drug_catalog_id"], ["id"], ondelete="SET NULL")

    with op.batch_alter_table("diagnoses") as batch_op:
        batch_op.add_column(sa.Column("diagnosis_catalog_id", sa.Integer()))
        batch_op.create_index(op.f("ix_diagnoses_diagnosis_catalog_id"), ["diagnosis_catalog_id"])
        batch_op.create_foreign_key(op.f("fk_diagnoses_diagnosis_catalog_id_diagnosis_catalogs"), "diagnosis_catalogs", ["diagnosis_catalog_id"], ["id"], ondelete="SET NULL")

    with op.batch_alter_table("lab_reports") as batch_op:
        batch_op.add_column(sa.Column("lab_test_catalog_id", sa.Integer()))
        batch_op.create_index(op.f("ix_lab_reports_lab_test_catalog_id"), ["lab_test_catalog_id"])
        batch_op.create_foreign_key(op.f("fk_lab_reports_lab_test_catalog_id_lab_test_catalogs"), "lab_test_catalogs", ["lab_test_catalog_id"], ["id"], ondelete="SET NULL")

    with op.batch_alter_table("lab_results") as batch_op:
        batch_op.add_column(sa.Column("lab_test_catalog_id", sa.Integer()))
        batch_op.create_index(op.f("ix_lab_results_lab_test_catalog_id"), ["lab_test_catalog_id"])
        batch_op.create_foreign_key(op.f("fk_lab_results_lab_test_catalog_id_lab_test_catalogs"), "lab_test_catalogs", ["lab_test_catalog_id"], ["id"], ondelete="SET NULL")


def downgrade() -> None:
    for table, column, target in (
        ("lab_results", "lab_test_catalog_id", "lab_test_catalogs"),
        ("lab_reports", "lab_test_catalog_id", "lab_test_catalogs"),
        ("diagnoses", "diagnosis_catalog_id", "diagnosis_catalogs"),
        ("prescription_items", "drug_catalog_id", "drug_catalogs"),
    ):
        with op.batch_alter_table(table) as batch_op:
            batch_op.drop_constraint(op.f(f"fk_{table}_{column}_{target}"), type_="foreignkey")
            batch_op.drop_index(op.f(f"ix_{table}_{column}"))
            batch_op.drop_column(column)
    with op.batch_alter_table("prescription_items") as batch_op:
        batch_op.drop_column("dosage_form")
    op.drop_table("lab_test_catalogs")
    op.drop_table("diagnosis_catalogs")
    op.drop_table("drug_catalogs")
