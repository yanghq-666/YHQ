"""complete user account fields

Revision ID: 0002
Revises: 0001
Create Date: 2026-09-05 23:20:09.860019
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = '0002'
down_revision: Union[str, Sequence[str], None] = '0001'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    # Alembic 无法自动识别字段重命名，显式 rename 以保留已有姓名数据。
    with op.batch_alter_table("users") as batch_op:
        batch_op.alter_column(
            "full_name",
            new_column_name="real_name",
            existing_type=sa.String(length=100),
            existing_nullable=False,
        )
        batch_op.add_column(
            sa.Column(
                "is_active",
                sa.Boolean(),
                server_default=sa.true(),
                nullable=False,
            )
        )
        batch_op.add_column(
            sa.Column(
                "is_superuser",
                sa.Boolean(),
                server_default=sa.false(),
                nullable=False,
            )
        )
        batch_op.create_index(
            op.f("ix_users_is_active"), ["is_active"], unique=False
        )


def downgrade() -> None:
    """Downgrade schema."""
    with op.batch_alter_table("users") as batch_op:
        batch_op.drop_index(op.f("ix_users_is_active"))
        batch_op.drop_column("is_superuser")
        batch_op.drop_column("is_active")
        batch_op.alter_column(
            "real_name",
            new_column_name="full_name",
            existing_type=sa.String(length=100),
            existing_nullable=False,
        )
