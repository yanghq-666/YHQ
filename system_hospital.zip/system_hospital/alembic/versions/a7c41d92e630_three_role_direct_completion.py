"""three role direct completion and diagnosis number

Revision ID: a7c41d92e630
Revises: df13ee308384
Create Date: 2026-09-08
"""

from collections import defaultdict
from datetime import date, datetime, timezone
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "a7c41d92e630"
down_revision: Union[str, Sequence[str], None] = "df13ee308384"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _created_date(value: object) -> date:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if value:
        try:
            return datetime.fromisoformat(str(value).replace("Z", "+00:00")).date()
        except ValueError:
            pass
    return datetime.now(timezone.utc).date()


def upgrade() -> None:
    with op.batch_alter_table("medical_records") as batch_op:
        batch_op.add_column(sa.Column("completed_by", sa.Integer(), nullable=True))
        batch_op.add_column(
            sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True)
        )
        batch_op.create_foreign_key(
            op.f("fk_medical_records_completed_by_users"),
            "users",
            ["completed_by"],
            ["id"],
            ondelete="RESTRICT",
        )

    with op.batch_alter_table("diagnoses") as batch_op:
        batch_op.add_column(sa.Column("diagnosis_no", sa.String(24), nullable=True))

    bind = op.get_bind()
    rows = bind.execute(
        sa.text("SELECT id, created_at FROM diagnoses ORDER BY created_at, id")
    ).mappings()
    counters: dict[date, int] = defaultdict(int)
    for row in rows:
        sequence_date = _created_date(row["created_at"])
        counters[sequence_date] += 1
        diagnosis_no = f"DX{sequence_date:%Y%m%d}{counters[sequence_date]:06d}"
        bind.execute(
            sa.text(
                "UPDATE diagnoses SET diagnosis_no = :diagnosis_no WHERE id = :id"
            ),
            {"diagnosis_no": diagnosis_no, "id": row["id"]},
        )

    for sequence_date, current_value in counters.items():
        existing = bind.execute(
            sa.text(
                "SELECT current_value FROM business_sequences "
                "WHERE sequence_name = :name AND sequence_date = :sequence_date"
            ),
            {"name": "diagnosis", "sequence_date": sequence_date},
        ).scalar_one_or_none()
        if existing is None:
            bind.execute(
                sa.text(
                    "INSERT INTO business_sequences "
                    "(sequence_name, sequence_date, current_value, updated_at) "
                    "VALUES (:name, :sequence_date, :current_value, :updated_at)"
                ),
                {
                    "name": "diagnosis",
                    "sequence_date": sequence_date,
                    "current_value": current_value,
                    "updated_at": datetime.now(timezone.utc),
                },
            )
        elif existing < current_value:
            bind.execute(
                sa.text(
                    "UPDATE business_sequences SET current_value = :current_value "
                    "WHERE sequence_name = :name AND sequence_date = :sequence_date"
                ),
                {
                    "name": "diagnosis",
                    "sequence_date": sequence_date,
                    "current_value": current_value,
                },
            )

    with op.batch_alter_table("diagnoses") as batch_op:
        batch_op.alter_column(
            "diagnosis_no",
            existing_type=sa.String(24),
            nullable=False,
        )
        batch_op.create_index(
            op.f("ix_diagnoses_diagnosis_no"), ["diagnosis_no"], unique=True
        )


def downgrade() -> None:
    with op.batch_alter_table("diagnoses") as batch_op:
        batch_op.drop_index(op.f("ix_diagnoses_diagnosis_no"))
        batch_op.drop_column("diagnosis_no")

    with op.batch_alter_table("medical_records") as batch_op:
        batch_op.drop_constraint(
            op.f("fk_medical_records_completed_by_users"), type_="foreignkey"
        )
        batch_op.drop_column("completed_at")
        batch_op.drop_column("completed_by")
