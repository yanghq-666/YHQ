document.addEventListener("DOMContentLoaded", () => {
    const sidebar = document.getElementById("appSidebar");
    const backdrop = document.getElementById("sidebarBackdrop");
    const toggle = document.getElementById("sidebarToggle");

    const closeSidebar = () => {
        sidebar?.classList.remove("show");
        backdrop?.classList.remove("show");
    };

    toggle?.addEventListener("click", () => {
        sidebar?.classList.toggle("show");
        backdrop?.classList.toggle("show");
    });
    backdrop?.addEventListener("click", closeSidebar);

    document.querySelectorAll(".auto-dismiss").forEach((element) => {
        window.setTimeout(() => bootstrap.Alert.getOrCreateInstance(element).close(), 3500);
    });

    document.querySelectorAll("[data-confirm]").forEach((element) => {
        element.addEventListener("click", (event) => {
            if (!window.confirm(element.dataset.confirm || "确认执行此操作？")) {
                event.preventDefault();
            }
        });
    });

    document.querySelectorAll("form[data-confirm-form]").forEach((form) => {
        form.addEventListener("submit", (event) => {
            if (!window.confirm(form.dataset.confirmForm || "确认执行此操作？")) {
                event.preventDefault();
            }
        });
    });

    document.querySelectorAll("form").forEach((form) => {
        form.addEventListener("submit", (event) => {
            if (event.defaultPrevented || form.dataset.submitting === "true") {
                if (form.dataset.submitting === "true") event.preventDefault();
                return;
            }
            form.dataset.submitting = "true";
            form.querySelectorAll("button[type='submit']").forEach((button) => {
                button.disabled = true;
            });
        });
    });
});
