document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll("form[data-review-action]").forEach((form) => {
        form.addEventListener("submit", (event) => {
            if (event.defaultPrevented) return;
            form.querySelectorAll("button[type='submit']").forEach((button) => {
                button.textContent = button.dataset.loadingText || "处理中...";
            });
        });
    });
});
