(() => {
    const source = document.getElementById("statistics-data");
    if (!source || typeof echarts === "undefined") return;
    const allData = JSON.parse(source.textContent || "{}");
    const instances = [];
    document.querySelectorAll("[data-chart]").forEach((element) => {
        const rows = allData[element.dataset.chart] || [];
        const kind = element.dataset.kind;
        if (!rows.length) {
            element.classList.add("d-flex", "align-items-center", "justify-content-center", "text-secondary");
            element.textContent = "暂无统计数据";
            return;
        }
        const chart = echarts.init(element);
        let option;
        if (kind === "pie") {
            option = {tooltip: {trigger: "item"}, legend: {bottom: 0}, series: [{type: "pie", radius: ["38%", "68%"], data: rows, label: {formatter: "{b}: {c}"}}]};
        } else if (element.dataset.horizontal === "true") {
            option = {tooltip: {trigger: "axis"}, grid: {left: 90, right: 25, top: 15, bottom: 30}, xAxis: {type: "value", minInterval: 1}, yAxis: {type: "category", data: rows.map((item) => item.name)}, series: [{type: "bar", data: rows.map((item) => item.value), itemStyle: {color: "#19758e"}}]};
        } else {
            option = {tooltip: {trigger: "axis"}, grid: {left: 45, right: 20, top: 20, bottom: 45}, xAxis: {type: "category", data: rows.map((item) => item.name), axisLabel: {interval: 0, rotate: rows.length > 7 ? 25 : 0}}, yAxis: {type: "value", minInterval: 1}, series: [{type: kind, smooth: kind === "line", data: rows.map((item) => item.value), itemStyle: {color: "#19758e"}, areaStyle: kind === "line" ? {opacity: 0.12} : undefined}]};
        }
        chart.setOption(option);
        instances.push(chart);
    });
    window.addEventListener("resize", () => instances.forEach((chart) => chart.resize()));
})();
