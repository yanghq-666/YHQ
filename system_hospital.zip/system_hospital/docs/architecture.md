# 系统架构设计

## 1. 第一版范围

第一版只实现“管理员创建账号 → 患者建档 → 创建就诊 → 医生填写病历及诊疗信息 → 提交 → 上级医生审核 → 病案管理员归档 → 历史查询与版本追溯”的完整闭环。

医保、收费、挂号支付、药房库存和 PACS 等系统均不在本期范围内。架构采用单体模块化设计，避免过早拆分微服务，同时保留 REST API 和存储抽象，便于后续替换 Vue 3 前端、PostgreSQL 和 MinIO。

## 2. 系统模块关系

```mermaid
flowchart LR
    Auth[认证与 RBAC] --> User[用户/角色/权限]
    User --> Department[科室]
    User --> Patient[患者管理]
    Patient --> Encounter[就诊管理]
    Department --> Encounter
    User --> Encounter
    Encounter --> Record[病历管理]
    Record --> Diagnosis[诊断]
    Record --> Order[医嘱]
    Encounter --> Prescription[处方]
    Record --> Lab[检验报告/结果]
    Record --> Exam[检查报告]
    Record --> Attachment[附件]
    Record --> Version[病历版本]
    Record --> Review[病历审核]
    Review --> Archive[病历归档]
    Storage[本地/MinIO 存储适配器] --> Attachment
    Audit[审计日志] -.记录关键操作.-> Auth
    Audit -.记录关键操作.-> Patient
    Audit -.记录关键操作.-> Encounter
    Audit -.记录关键操作.-> Record
    Audit -.记录关键操作.-> Review
    Audit -.记录关键操作.-> Archive
```

## 3. 分层职责

- `api/routes`：HTTP 参数接收、依赖注入、认证授权入口和统一响应，不承载核心业务规则。
- `schemas`：Pydantic 输入输出校验，隔离数据库模型与外部接口。
- `services`：事务边界和业务规则；病历状态机、版本快照、审核、归档、审计都在此层编排。
- `repositories`：封装 SQLAlchemy 查询与持久化，避免路由直接拼装查询。
- `models`：实体、关系、唯一约束、索引和枚举映射。
- `core`：配置、数据库、安全、权限、异常与通用基础设施。

依赖方向固定为 `API → Service → Repository → Model/Database`。Service 可以调用审计与存储服务；Repository 不反向依赖 Service 或 API。

## 4. 核心业务状态机

就诊状态先由专用服务控制：

```mermaid
stateDiagram-v2
    [*] --> REGISTERED
    REGISTERED --> IN_PROGRESS: start_encounter
    IN_PROGRESS --> COMPLETED: complete_encounter
    REGISTERED --> CANCELLED: cancel_encounter
    COMPLETED --> [*]
    CANCELLED --> [*]
```

就诊状态不接受通用更新接口直接写入。住院就诊完成前必须填写出院时间，
`COMPLETED` 和 `CANCELLED` 为终态，默认禁止继续修改。

病历状态枚举和状态机边界如下；当前阶段仅开放创建 `DRAFT` 和
`DRAFT/REJECTED → SUBMITTED`，审核与归档转换留待后续阶段：

```mermaid
stateDiagram-v2
    [*] --> DRAFT
    DRAFT --> SUBMITTED: submit_record
    REJECTED --> SUBMITTED: 修改后 submit_record
    SUBMITTED --> REVIEWING: start_review
    REVIEWING --> APPROVED: approve_record
    REVIEWING --> REJECTED: reject_record（必须填写原因）
    APPROVED --> ARCHIVED: archive_record
    ARCHIVED --> [*]
```

状态字段不接受通用更新接口直接写入。当前提交服务在同一数据库事务中完成
完整性校验、提交前版本快照、状态修改和审计日志；后续审核与归档服务继续复用
这一事务边界。`SUBMITTED` 默认锁定正文，`ARCHIVED` 数据只读且不允许物理删除。

## 5. 关键设计决定

- `Patient`、`Encounter`、`MedicalRecord` 分层建模；患者与病历不直接绑定。
- 就诊号由按日期独立的 `EncounterSequence` 原子递增生成，格式为
  `E + YYYYMMDD + 6 位流水号`，并由唯一约束处理最终冲突。
- Encounter 访问由权限依赖和服务层数据范围共同控制；普通医生限本人或本科室，
  上级医生和护士限本科室，管理员拥有跨科室管理能力。
- 一次就诊第一版对应至多一份主病历，`medical_record.encounter_id` 使用唯一约束。
- 病历号由按日期独立的 `MedicalRecordSequence` 原子递增生成，格式为
  `MR + YYYYMMDD + 6 位流水号`，并由唯一索引处理最终冲突。
- 病历读写同时经过 RBAC 和 `MedicalRecordAccessPolicy`；临床角色按负责医生、
  创建人和科室限定范围，病案管理员只有查看权限。
- 审核开始使用条件 UPDATE 原子取得 `current_reviewer_id` 锁；审核人不能自审，
  上级医生限本科室，管理员可跨科室，批准或退回后释放锁。
- 每个 `RecordReview` 追加保存动作、审核人、起止状态、提交版本和审核轮次；
  批准时将准确版本写入 `approved_version`，供下一阶段归档使用。
- 诊断和医嘱同时保存 `encounter_id` 与 `record_id`，便于就诊聚合查询，并通过业务层保证二者属于同一链路。
- 同一病历、同一诊断类型的主诊断由 `DiagnosisService` 自动替换，避免出现多个
  PRELIMINARY 或 FINAL 主诊断。
- 医嘱和处方号共用 `BusinessSequence` 与 `SequenceService`，按业务名和日期隔离
  原子流水，分别生成 MO/RX 编号。
- 处方及初始处方项目在单一事务中创建；处方签发、取消和医嘱状态均通过专用
  Service 转换，通用 PATCH 不接受状态字段。
- 每次提交前写入不可覆盖的 `MedicalRecordVersion` JSON 快照，版本从 1 递增；
  快照包含病历正文、诊断、医嘱、处方及项目、检验结果、检查结果和附件元数据；审计只保存变化字段名，避免复制
  完整敏感正文。
- `RecordReview` 采用追加式记录，保留每轮审核意见。
- `AuditLog` 只提供新增和查询能力；患者身份证、密码、令牌及附件正文不写普通日志。
- 附件表只保存元数据与对象键，文件内容由 `StorageService` 的本地或 MinIO 实现管理。
- 检验和检查各自拥有独立 AccessPolicy；病历提交后仍允许技术人员回报结果，
  不使用主病历正文的可编辑状态作为结果录入条件。
