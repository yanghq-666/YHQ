# 数据库实体关系设计

## 1. ER 关系

```mermaid
erDiagram
    DEPARTMENT ||--o{ USER : contains
    USER }o--o{ ROLE : user_roles
    ROLE }o--o{ PERMISSION : role_permissions
    PATIENT_SEQUENCE ||--o{ PATIENT : generates_number
    PATIENT ||--o{ ENCOUNTER : has
    ENCOUNTER_SEQUENCE ||--o{ ENCOUNTER : generates_number
    USER ||--o{ ENCOUNTER : attends
    DEPARTMENT ||--o{ ENCOUNTER : receives
    ENCOUNTER ||--o| MEDICAL_RECORD : owns
    MEDICAL_RECORD_SEQUENCE ||--o{ MEDICAL_RECORD : generates_number
    MEDICAL_RECORD ||--o{ MEDICAL_RECORD_VERSION : snapshots
    MEDICAL_RECORD ||--o{ RECORD_REVIEW : reviews
    ENCOUNTER ||--o{ DIAGNOSIS : diagnoses
    MEDICAL_RECORD ||--o{ DIAGNOSIS : documents
    ENCOUNTER ||--o{ MEDICAL_ORDER : orders
    MEDICAL_RECORD ||--o{ MEDICAL_ORDER : documents
    BUSINESS_SEQUENCE ||--o{ MEDICAL_ORDER : generates_number
    ENCOUNTER ||--o{ PRESCRIPTION : prescriptions
    MEDICAL_RECORD ||--o{ PRESCRIPTION : documents
    BUSINESS_SEQUENCE ||--o{ PRESCRIPTION : generates_number
    PRESCRIPTION ||--|{ PRESCRIPTION_ITEM : contains
    ENCOUNTER ||--o{ LAB_REPORT : produces
    PATIENT ||--o{ LAB_REPORT : owns
    MEDICAL_RECORD ||--o{ LAB_REPORT : documents
    LAB_REPORT ||--o{ LAB_RESULT : contains
    ENCOUNTER ||--o{ EXAMINATION : produces
    PATIENT ||--o{ EXAMINATION : owns
    MEDICAL_RECORD ||--o{ EXAMINATION : documents
    MEDICAL_RECORD ||--o{ ATTACHMENT : has
    LAB_REPORT ||--o{ ATTACHMENT : files
    EXAMINATION ||--o{ ATTACHMENT : files
    USER ||--o{ AUDIT_LOG : performs
```

## 2. 核心实体与约束

| 实体 | 关键关系与约束 |
| --- | --- |
| `users` | `username` 唯一；可归属科室；密码只保存哈希；通过中间表关联多个角色 |
| `roles` / `permissions` | `code` 唯一；分别通过 `user_roles`、`role_permissions` 建立多对多关系 |
| `departments` | `department_code` 唯一；状态字段控制停用，已有业务数据不级联删除 |
| `patients` | `patient_no` 唯一且自动生成；`id_card` 建唯一索引（允许空值）；采用 `deleted_at` 软删除 |
| `patient_sequences` | 以年份为主键原子递增，生成 `P + 年份 + 6 位流水号`；唯一索引二次兜底 |
| `encounter_sequences` | 以日期为主键原子递增，生成 `E + YYYYMMDD + 6 位流水号`；唯一索引二次兜底 |
| `encounters` | `encounter_no` 唯一；外键关联患者、医生、科室和创建人；类型与状态使用枚举；采用 `deleted_at` 软删除 |
| `medical_record_sequences` | 以日期为主键原子递增，生成 `MR + YYYYMMDD + 6 位流水号` |
| `medical_records` | `record_no` 和 `encounter_id` 唯一；正文使用 Text；提交/审核/归档用户与时间均预留；状态仅由专用服务改变 |
| `medical_record_versions` | `(record_id, version)` 联合唯一；`snapshot_data` 使用 JSON/JSONB 兼容类型；只新增不覆盖 |
| `business_sequences` | `(sequence_name, sequence_date)` 联合主键；为 MO/RX 提供互相隔离的每日原子流水 |
| `record_reviews` | 提交、开始审核、通过、退回和重提均追加记录；保存版本、轮次和状态转换，不提供修改删除接口 |
| `diagnoses` | 同时关联就诊与病历；保留 ICD 编码；类型和主诊断由 Service 控制；采用软删除 |
| `medical_orders` | `order_no` 唯一；同时关联就诊与病历；状态通过专用方法改变；采用软删除 |
| `prescriptions` | `prescription_no` 唯一；关联就诊、病历和开方医生；保存签发/取消状态及取消信息 |
| `prescription_items` | 从属处方；保存剂量、频次、途径、疗程、数量和用法；采用软删除 |
| `lab_reports` | 同时关联患者、就诊和病历；报告号唯一；状态只经 Service 流转；采用软删除 |
| `lab_results` | 从属检验报告；保存项目值、单位、参考范围和受控异常标记 |
| `examinations` | 同时关联患者、就诊和病历；检查号唯一；保存类型、所见和结论；采用软删除 |
| `attachments` | 可关联病历、检验或检查；保存名称、MIME、大小、SHA-256、对象键和上传者；不保存 BLOB |
| `audit_logs` | 追加式写入；用户可空以记录登录失败；旧值和新值使用脱敏 JSON |

## 3. 索引计划

- 患者：`patient_no` 唯一索引，`name` 普通索引，`id_card` 唯一索引。
- 就诊：`encounter_no` 唯一索引，`patient_id`、`doctor_id`、`department_id`、
  `visit_time`、`status`、`encounter_type` 索引，以及患者/医生/科室分别与
  `visit_time` 组成的组合索引。
- 病历：`record_no`、`encounter_id` 唯一索引，以及 `status`、`created_by`、
  `created_at`、`updated_at`、`deleted_at` 索引。
- 病历版本：`record_id`、`created_at` 索引，`(record_id, version)` 联合唯一约束。
- 诊断：`record_id`、`encounter_id`、`diagnosis_type`、`diagnosis_code`、
  `is_primary`、`deleted_at` 索引。
- 医嘱：`order_no` 唯一索引，以及 `record_id`、`encounter_id`、`order_type`、
  `status`、`created_at`、`deleted_at` 索引。
- 处方：`prescription_no` 唯一索引，以及 `record_id`、`encounter_id`、
  `doctor_id`、`status`、`created_at`、`deleted_at` 索引；处方项目按
  `prescription_id`、`sort_order` 和 `deleted_at` 建索引。
- 检验：`report_no` 唯一索引，以及 `patient_id`、`encounter_id`、`record_id`、
  `status`、`reported_at` 索引；结果按 `lab_report_id`、`item_code`、异常标记索引。
- 检查：`examination_no` 唯一索引，以及患者、就诊、病历、类型、状态和报告时间索引。
- 附件：患者、就诊、病历、检验、检查、文件哈希、创建时间和删除时间索引；对象键唯一。
- 审计：`user_id`、`target_id`、`created_at` 索引，并预留 `(module, target_type, target_id)` 组合索引。

外键默认使用限制删除（`RESTRICT`/`NO ACTION`）；处方明细等严格从属数据是否级联，仅在模型和迁移阶段逐项明确。病历、版本、审核、审计及归档相关记录不提供物理删除接口。

## 4. SQLite 与 PostgreSQL 兼容策略

- 开发环境使用 SQLite，生产环境通过 `DATABASE_URL` 切换为 PostgreSQL。
- 不使用 SQLite 专有 SQL；迁移全部由 Alembic 管理。
- JSON 快照在模型层使用 SQLAlchemy `JSON`，PostgreSQL 迁移时可无损调整为 `JSONB`。
- 编号生成由服务层统一实现，不依赖数据库自增值拼接，避免并发重复。
- 时间统一保存带时区的 UTC 时间，展示层再转换为本地时区。
