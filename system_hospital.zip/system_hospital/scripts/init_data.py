"""初始化角色、权限、科室和管理员账号。"""

from app.core.config import get_settings
from app.core.database import SessionLocal
from app.services.bootstrap_service import (
    initialize_demo_accounts,
    initialize_system_data,
)


def main() -> None:
    settings = get_settings()
    if settings.admin_password is None:
        raise SystemExit(
            "缺少 INITIAL_ADMIN_PASSWORD，请先在 .env 中配置管理员初始密码"
        )

    with SessionLocal() as db:
        result = initialize_system_data(
            db,
            admin_username=settings.admin_username,
            admin_password=settings.admin_password.get_secret_value(),
            admin_real_name=settings.admin_real_name,
        )
        demo_count = 0
        if settings.demo_account_password is not None:
            demo_count = initialize_demo_accounts(
                db,
                password=settings.demo_account_password.get_secret_value(),
            )
    print(
        "初始化完成："
        f"{result['roles']} 个角色，"
        f"{result['permissions']} 个权限，"
        f"{result['departments']} 个科室，"
        f"管理员 ID={result['admin_user_id']}，"
        f"{demo_count} 个演示账号"
    )


if __name__ == "__main__":
    main()
