"""检验报告及结构化结果明细。"""

from datetime import datetime

from sqlalchemy import DateTime, Enum as SqlEnum, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base
from app.models.base import TimestampMixin
from app.models.enums import AbnormalFlag, LabReportStatus
from app.models.catalog import LabTestCatalog


class LabReport(TimestampMixin, Base):
    __tablename__ = "lab_reports"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    report_no: Mapped[str] = mapped_column(String(24), unique=True, index=True, nullable=False)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id", ondelete="RESTRICT"), index=True, nullable=False)
    encounter_id: Mapped[int] = mapped_column(ForeignKey("encounters.id", ondelete="RESTRICT"), index=True, nullable=False)
    record_id: Mapped[int] = mapped_column(ForeignKey("medical_records.id", ondelete="RESTRICT"), index=True, nullable=False)
    order_id: Mapped[int | None] = mapped_column(ForeignKey("medical_orders.id", ondelete="RESTRICT"), unique=True, index=True)
    lab_test_catalog_id: Mapped[int | None] = mapped_column(ForeignKey("lab_test_catalogs.id", ondelete="SET NULL"), index=True)
    report_name: Mapped[str] = mapped_column(String(255), nullable=False)
    report_type: Mapped[str] = mapped_column(String(100), index=True, nullable=False)
    specimen_type: Mapped[str | None] = mapped_column(String(100))
    status: Mapped[LabReportStatus] = mapped_column(SqlEnum(LabReportStatus, name="lab_report_status", native_enum=False, create_constraint=True, validate_strings=True), default=LabReportStatus.PENDING, index=True, nullable=False)
    result_summary: Mapped[str | None] = mapped_column(Text)
    conclusion: Mapped[str | None] = mapped_column(Text)
    requested_by: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"), nullable=False)
    performed_by: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))
    reviewed_by: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))
    collected_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    reported_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    results: Mapped[list["LabResult"]] = relationship(back_populates="lab_report", order_by="LabResult.sort_order, LabResult.id")
    lab_test_catalog: Mapped[LabTestCatalog | None] = relationship()


class LabResult(TimestampMixin, Base):
    __tablename__ = "lab_results"
    __table_args__ = (Index("ix_lab_results_lab_report_sort", "lab_report_id", "sort_order"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    lab_report_id: Mapped[int] = mapped_column(ForeignKey("lab_reports.id", ondelete="RESTRICT"), index=True, nullable=False)
    lab_test_catalog_id: Mapped[int | None] = mapped_column(ForeignKey("lab_test_catalogs.id", ondelete="SET NULL"), index=True)
    item_code: Mapped[str | None] = mapped_column(String(50), index=True)
    item_name: Mapped[str] = mapped_column(String(255), nullable=False)
    result_value: Mapped[str | None] = mapped_column(String(255))
    result_text: Mapped[str | None] = mapped_column(Text)
    unit: Mapped[str | None] = mapped_column(String(50))
    reference_range: Mapped[str | None] = mapped_column(String(255))
    abnormal_flag: Mapped[AbnormalFlag] = mapped_column(SqlEnum(AbnormalFlag, name="abnormal_flag", native_enum=False, create_constraint=True, validate_strings=True), default=AbnormalFlag.UNKNOWN, index=True, nullable=False)
    sort_order: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    remark: Mapped[str | None] = mapped_column(Text)

    lab_report: Mapped[LabReport] = relationship(back_populates="results")
    lab_test_catalog: Mapped[LabTestCatalog | None] = relationship()
