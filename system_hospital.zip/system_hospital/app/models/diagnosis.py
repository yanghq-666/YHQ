"""诊断模型。"""

from datetime import datetime

from sqlalchemy import Boolean, DateTime, Enum as SqlEnum
from sqlalchemy import ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base
from app.models.base import TimestampMixin
from app.models.encounter import Encounter
from app.models.enums import DiagnosisType
from app.models.medical_record import MedicalRecord
from app.models.user import User
from app.models.catalog import DiagnosisCatalog


class Diagnosis(TimestampMixin, Base):
    __tablename__ = "diagnoses"
    __table_args__ = (Index("ix_diagnoses_deleted_at", "deleted_at"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    encounter_id: Mapped[int] = mapped_column(
        ForeignKey("encounters.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    record_id: Mapped[int] = mapped_column(
        ForeignKey("medical_records.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    diagnosis_catalog_id: Mapped[int | None] = mapped_column(
        ForeignKey("diagnosis_catalogs.id", ondelete="SET NULL"), index=True
    )
    diagnosis_no: Mapped[str] = mapped_column(
        String(24), unique=True, index=True, nullable=False
    )
    diagnosis_name: Mapped[str] = mapped_column(String(255), nullable=False)
    # 标准疾病分类编码（如 ICD-10），与系统内部 diagnosis_no 分开保存。
    diagnosis_code: Mapped[str | None] = mapped_column(String(50), index=True)
    diagnosis_type: Mapped[DiagnosisType] = mapped_column(
        SqlEnum(
            DiagnosisType,
            name="diagnosis_type",
            native_enum=False,
            create_constraint=True,
            validate_strings=True,
        ),
        index=True,
        nullable=False,
    )
    description: Mapped[str | None] = mapped_column(Text)
    sort_order: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    is_primary: Mapped[bool] = mapped_column(
        Boolean, default=False, index=True, nullable=False
    )
    created_by: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), nullable=False
    )
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    encounter: Mapped[Encounter] = relationship()
    record: Mapped[MedicalRecord] = relationship()
    creator: Mapped[User] = relationship()
    diagnosis_catalog: Mapped[DiagnosisCatalog | None] = relationship()

    @property
    def created_by_name(self) -> str:
        return self.creator.real_name
