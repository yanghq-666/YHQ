"""当前阶段使用的数据库枚举。"""

from enum import Enum


class UserStatus(str, Enum):
    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"
    LOCKED = "LOCKED"


class DepartmentStatus(str, Enum):
    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"


class Gender(str, Enum):
    MALE = "MALE"
    FEMALE = "FEMALE"
    OTHER = "OTHER"
    UNKNOWN = "UNKNOWN"


class BloodType(str, Enum):
    A = "A"
    B = "B"
    AB = "AB"
    O = "O"
    UNKNOWN = "UNKNOWN"


class EncounterType(str, Enum):
    OUTPATIENT = "OUTPATIENT"
    INPATIENT = "INPATIENT"
    EMERGENCY = "EMERGENCY"


class EncounterStatus(str, Enum):
    REGISTERED = "REGISTERED"
    IN_PROGRESS = "IN_PROGRESS"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"


class MedicalRecordStatus(str, Enum):
    DRAFT = "DRAFT"
    SUBMITTED = "SUBMITTED"
    REVIEWING = "REVIEWING"
    REJECTED = "REJECTED"
    APPROVED = "APPROVED"
    ARCHIVED = "ARCHIVED"


class DiagnosisType(str, Enum):
    PRELIMINARY = "PRELIMINARY"
    FINAL = "FINAL"


class MedicalOrderType(str, Enum):
    MEDICATION = "MEDICATION"
    LAB = "LAB"
    EXAMINATION = "EXAMINATION"
    TREATMENT = "TREATMENT"
    NURSING = "NURSING"
    OTHER = "OTHER"


class MedicalOrderStatus(str, Enum):
    ACTIVE = "ACTIVE"
    STOPPED = "STOPPED"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"


class PrescriptionType(str, Enum):
    OUTPATIENT = "OUTPATIENT"
    INPATIENT = "INPATIENT"
    DISCHARGE = "DISCHARGE"
    OTHER = "OTHER"


class PrescriptionStatus(str, Enum):
    DRAFT = "DRAFT"
    ISSUED = "ISSUED"
    CANCELLED = "CANCELLED"


class LabReportStatus(str, Enum):
    PENDING = "PENDING"
    IN_PROGRESS = "IN_PROGRESS"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"


class AbnormalFlag(str, Enum):
    NORMAL = "NORMAL"
    HIGH = "HIGH"
    LOW = "LOW"
    CRITICAL = "CRITICAL"
    ABNORMAL = "ABNORMAL"
    UNKNOWN = "UNKNOWN"


class ExaminationType(str, Enum):
    XRAY = "XRAY"
    CT = "CT"
    MRI = "MRI"
    ULTRASOUND = "ULTRASOUND"
    ECG = "ECG"
    ENDOSCOPY = "ENDOSCOPY"
    OTHER = "OTHER"


class ExaminationStatus(str, Enum):
    PENDING = "PENDING"
    IN_PROGRESS = "IN_PROGRESS"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"


class AttachmentCategory(str, Enum):
    MEDICAL_RECORD = "MEDICAL_RECORD"
    LAB_REPORT = "LAB_REPORT"
    EXAMINATION = "EXAMINATION"
    IMAGE = "IMAGE"
    PDF = "PDF"
    OTHER = "OTHER"


class StorageProvider(str, Enum):
    LOCAL = "local"
    MINIO = "minio"


class ReviewAction(str, Enum):
    SUBMIT = "SUBMIT"
    START_REVIEW = "START_REVIEW"
    REJECT = "REJECT"
    RESUBMIT = "RESUBMIT"
    APPROVE = "APPROVE"
