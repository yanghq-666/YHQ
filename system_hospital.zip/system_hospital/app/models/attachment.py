"""只保存元数据的通用病历附件。"""

from datetime import datetime

from sqlalchemy import BigInteger, DateTime, Enum as SqlEnum, ForeignKey, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.models.enums import AttachmentCategory, StorageProvider


class Attachment(Base):
    __tablename__ = "attachments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id", ondelete="RESTRICT"), index=True, nullable=False)
    encounter_id: Mapped[int] = mapped_column(ForeignKey("encounters.id", ondelete="RESTRICT"), index=True, nullable=False)
    record_id: Mapped[int] = mapped_column(ForeignKey("medical_records.id", ondelete="RESTRICT"), index=True, nullable=False)
    lab_report_id: Mapped[int | None] = mapped_column(ForeignKey("lab_reports.id", ondelete="RESTRICT"), index=True)
    examination_id: Mapped[int | None] = mapped_column(ForeignKey("examinations.id", ondelete="RESTRICT"), index=True)
    category: Mapped[AttachmentCategory] = mapped_column(SqlEnum(AttachmentCategory, name="attachment_category", native_enum=False, create_constraint=True, validate_strings=True), nullable=False)
    original_name: Mapped[str] = mapped_column(String(255), nullable=False)
    storage_name: Mapped[str] = mapped_column(String(255), nullable=False)
    storage_provider: Mapped[StorageProvider] = mapped_column(SqlEnum(StorageProvider, name="storage_provider", native_enum=False, create_constraint=True, validate_strings=True), nullable=False)
    object_key: Mapped[str] = mapped_column(String(500), unique=True, nullable=False)
    mime_type: Mapped[str] = mapped_column(String(100), nullable=False)
    file_extension: Mapped[str] = mapped_column(String(20), nullable=False)
    file_size: Mapped[int] = mapped_column(BigInteger, nullable=False)
    file_hash: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    uploaded_by: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False, index=True)
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
