"""患者与年度编号流水模型。"""

from datetime import date, datetime
from typing import TYPE_CHECKING

from sqlalchemy import Date, DateTime, Enum as SqlEnum
from sqlalchemy import Index, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base
from app.models.base import TimestampMixin
from app.models.enums import BloodType, Gender

if TYPE_CHECKING:
    from app.models.encounter import Encounter


class Patient(TimestampMixin, Base):
    __tablename__ = "patients"
    __table_args__ = (
        Index("ix_patients_created_at", "created_at"),
        Index("ix_patients_deleted_at", "deleted_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    patient_no: Mapped[str] = mapped_column(
        String(20), unique=True, index=True, nullable=False
    )
    name: Mapped[str] = mapped_column(String(100), index=True, nullable=False)
    gender: Mapped[Gender] = mapped_column(
        SqlEnum(
            Gender,
            name="patient_gender",
            native_enum=False,
            create_constraint=True,
            validate_strings=True,
        ),
        default=Gender.UNKNOWN,
        nullable=False,
    )
    birthday: Mapped[date | None] = mapped_column(Date)
    id_card: Mapped[str | None] = mapped_column(
        String(32), unique=True, index=True
    )
    phone: Mapped[str | None] = mapped_column(String(30), index=True)
    address: Mapped[str | None] = mapped_column(String(500))
    blood_type: Mapped[BloodType] = mapped_column(
        SqlEnum(
            BloodType,
            name="patient_blood_type",
            native_enum=False,
            create_constraint=True,
            validate_strings=True,
        ),
        default=BloodType.UNKNOWN,
        nullable=False,
    )
    allergy_history: Mapped[str | None] = mapped_column(Text)
    emergency_contact: Mapped[str | None] = mapped_column(String(100))
    emergency_phone: Mapped[str | None] = mapped_column(String(30))
    remark: Mapped[str | None] = mapped_column(Text)
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    encounters: Mapped[list["Encounter"]] = relationship(back_populates="patient")


class PatientSequence(Base):
    """年度患者流水；每年独立从 1 开始。"""

    __tablename__ = "patient_sequences"

    year: Mapped[int] = mapped_column(Integer, primary_key=True)
    current_value: Mapped[int] = mapped_column(Integer, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
