"""科室模型。"""

from typing import TYPE_CHECKING

from sqlalchemy import Enum as SqlEnum
from sqlalchemy import Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base
from app.models.base import TimestampMixin
from app.models.enums import DepartmentStatus

if TYPE_CHECKING:
    from app.models.encounter import Encounter
    from app.models.user import User


class Department(TimestampMixin, Base):
    __tablename__ = "departments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    department_code: Mapped[str] = mapped_column(
        String(50), unique=True, index=True, nullable=False
    )
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    status: Mapped[DepartmentStatus] = mapped_column(
        SqlEnum(
            DepartmentStatus,
            name="department_status",
            native_enum=False,
            create_constraint=True,
            validate_strings=True,
        ),
        default=DepartmentStatus.ACTIVE,
        nullable=False,
        index=True,
    )

    users: Mapped[list["User"]] = relationship(back_populates="department")
    encounters: Mapped[list["Encounter"]] = relationship(
        back_populates="department"
    )
