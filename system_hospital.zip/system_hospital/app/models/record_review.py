"""不可修改、不可删除的病历审核时间线记录。"""

from datetime import datetime

from sqlalchemy import DateTime, Enum as SqlEnum, ForeignKey, Index, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base
from app.models.enums import MedicalRecordStatus, ReviewAction


class RecordReview(Base):
    __tablename__ = "record_reviews"
    __table_args__ = (
        Index("ix_record_reviews_record_created", "record_id", "created_at"),
        Index("ix_record_reviews_reviewer_created", "reviewer_id", "created_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    record_id: Mapped[int] = mapped_column(
        ForeignKey("medical_records.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    reviewer_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    action: Mapped[ReviewAction] = mapped_column(
        SqlEnum(
            ReviewAction,
            name="review_action",
            native_enum=False,
            create_constraint=True,
            validate_strings=True,
        ),
        index=True,
        nullable=False,
    )
    comment: Mapped[str | None] = mapped_column(Text)
    from_status: Mapped[MedicalRecordStatus] = mapped_column(
        SqlEnum(
            MedicalRecordStatus,
            name="review_from_status",
            native_enum=False,
            create_constraint=True,
            validate_strings=True,
        ),
        nullable=False,
    )
    to_status: Mapped[MedicalRecordStatus] = mapped_column(
        SqlEnum(
            MedicalRecordStatus,
            name="review_to_status",
            native_enum=False,
            create_constraint=True,
            validate_strings=True,
        ),
        nullable=False,
    )
    record_version: Mapped[int] = mapped_column(Integer, nullable=False)
    review_round: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    record = relationship("MedicalRecord", back_populates="reviews")
    reviewer = relationship("User")
