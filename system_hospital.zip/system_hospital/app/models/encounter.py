"""就诊及每日编号流水模型。"""

from datetime import date, datetime
from typing import TYPE_CHECKING

from sqlalchemy import Date, DateTime, Enum as SqlEnum
from sqlalchemy import ForeignKey, Index, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base
from app.models.base import TimestampMixin
from app.models.department import Department
from app.models.enums import EncounterStatus, EncounterType
from app.models.patient import Patient
from app.models.user import User

if TYPE_CHECKING:
    from app.models.medical_record import MedicalRecord


class Encounter(TimestampMixin, Base):
    __tablename__ = "encounters"
    __table_args__ = (
        Index("ix_encounters_deleted_at", "deleted_at"),
        Index("ix_encounters_patient_visit_time", "patient_id", "visit_time"),
        Index(
            "ix_encounters_department_visit_time",
            "department_id",
            "visit_time",
        ),
        Index("ix_encounters_doctor_visit_time", "doctor_id", "visit_time"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    encounter_no: Mapped[str] = mapped_column(
        String(24), unique=True, index=True, nullable=False
    )
    patient_id: Mapped[int] = mapped_column(
        ForeignKey("patients.id", ondelete="RESTRICT"), index=True, nullable=False
    )
    doctor_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), index=True, nullable=False
    )
    department_id: Mapped[int] = mapped_column(
        ForeignKey("departments.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    encounter_type: Mapped[EncounterType] = mapped_column(
        SqlEnum(
            EncounterType,
            name="encounter_type",
            native_enum=False,
            create_constraint=True,
            validate_strings=True,
        ),
        index=True,
        nullable=False,
    )
    visit_time: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), index=True, nullable=False
    )
    status: Mapped[EncounterStatus] = mapped_column(
        SqlEnum(
            EncounterStatus,
            name="encounter_status",
            native_enum=False,
            create_constraint=True,
            validate_strings=True,
        ),
        default=EncounterStatus.REGISTERED,
        index=True,
        nullable=False,
    )
    chief_complaint: Mapped[str | None] = mapped_column(Text)
    admission_time: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    discharge_time: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    room_no: Mapped[str | None] = mapped_column(String(50))
    bed_no: Mapped[str | None] = mapped_column(String(50))
    remark: Mapped[str | None] = mapped_column(Text)
    created_by: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), index=True, nullable=False
    )
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    patient: Mapped[Patient] = relationship(back_populates="encounters")
    doctor: Mapped[User] = relationship(
        back_populates="encounters_as_doctor", foreign_keys=[doctor_id]
    )
    department: Mapped[Department] = relationship(back_populates="encounters")
    created_by_user: Mapped[User] = relationship(
        back_populates="encounters_created", foreign_keys=[created_by]
    )
    medical_record: Mapped["MedicalRecord | None"] = relationship(
        back_populates="encounter", uselist=False
    )


class EncounterSequence(Base):
    """每日就诊流水；每个自然日独立从 1 开始。"""

    __tablename__ = "encounter_sequences"

    sequence_date: Mapped[date] = mapped_column(Date, primary_key=True)
    current_value: Mapped[int] = mapped_column(Integer, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
