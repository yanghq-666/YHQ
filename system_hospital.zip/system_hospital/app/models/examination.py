"""影像及其他检查报告。"""

from datetime import datetime

from sqlalchemy import DateTime, Enum as SqlEnum, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.models.base import TimestampMixin
from app.models.enums import ExaminationStatus, ExaminationType


class Examination(TimestampMixin, Base):
    __tablename__ = "examinations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    examination_no: Mapped[str] = mapped_column(String(24), unique=True, index=True, nullable=False)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id", ondelete="RESTRICT"), index=True, nullable=False)
    encounter_id: Mapped[int] = mapped_column(ForeignKey("encounters.id", ondelete="RESTRICT"), index=True, nullable=False)
    record_id: Mapped[int] = mapped_column(ForeignKey("medical_records.id", ondelete="RESTRICT"), index=True, nullable=False)
    order_id: Mapped[int | None] = mapped_column(ForeignKey("medical_orders.id", ondelete="RESTRICT"), unique=True, index=True)
    examination_type: Mapped[ExaminationType] = mapped_column(SqlEnum(ExaminationType, name="examination_type", native_enum=False, create_constraint=True, validate_strings=True), index=True, nullable=False)
    examination_name: Mapped[str] = mapped_column(String(255), nullable=False)
    body_part: Mapped[str | None] = mapped_column(String(255))
    clinical_indication: Mapped[str | None] = mapped_column(Text)
    findings: Mapped[str | None] = mapped_column(Text)
    conclusion: Mapped[str | None] = mapped_column(Text)
    status: Mapped[ExaminationStatus] = mapped_column(SqlEnum(ExaminationStatus, name="examination_status", native_enum=False, create_constraint=True, validate_strings=True), default=ExaminationStatus.PENDING, index=True, nullable=False)
    requested_by: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"), nullable=False)
    performed_by: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))
    performed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    reported_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
