"""处方及处方项目模型。"""

from datetime import datetime
from decimal import Decimal

from sqlalchemy import DateTime, Enum as SqlEnum
from sqlalchemy import ForeignKey, Index, Integer, Numeric, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base
from app.models.base import TimestampMixin
from app.models.encounter import Encounter
from app.models.enums import PrescriptionStatus, PrescriptionType
from app.models.medical_record import MedicalRecord
from app.models.user import User
from app.models.catalog import DrugCatalog


class Prescription(TimestampMixin, Base):
    __tablename__ = "prescriptions"
    __table_args__ = (
        Index("ix_prescriptions_created_at", "created_at"),
        Index("ix_prescriptions_deleted_at", "deleted_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    prescription_no: Mapped[str] = mapped_column(
        String(24), unique=True, index=True, nullable=False
    )
    encounter_id: Mapped[int] = mapped_column(
        ForeignKey("encounters.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    record_id: Mapped[int] = mapped_column(
        ForeignKey("medical_records.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    order_id: Mapped[int | None] = mapped_column(
        ForeignKey("medical_orders.id", ondelete="RESTRICT"),
        unique=True,
        index=True,
    )
    doctor_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    prescription_type: Mapped[PrescriptionType] = mapped_column(
        SqlEnum(
            PrescriptionType,
            name="prescription_type",
            native_enum=False,
            create_constraint=True,
            validate_strings=True,
        ),
        nullable=False,
    )
    status: Mapped[PrescriptionStatus] = mapped_column(
        SqlEnum(
            PrescriptionStatus,
            name="prescription_status",
            native_enum=False,
            create_constraint=True,
            validate_strings=True,
        ),
        default=PrescriptionStatus.DRAFT,
        index=True,
        nullable=False,
    )
    notes: Mapped[str | None] = mapped_column(Text)
    cancelled_by: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT")
    )
    cancelled_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    cancel_reason: Mapped[str | None] = mapped_column(String(500))
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    encounter: Mapped[Encounter] = relationship()
    record: Mapped[MedicalRecord] = relationship()
    doctor: Mapped[User] = relationship(foreign_keys=[doctor_id])
    canceller: Mapped[User | None] = relationship(foreign_keys=[cancelled_by])
    items: Mapped[list["PrescriptionItem"]] = relationship(
        back_populates="prescription",
        order_by="PrescriptionItem.sort_order, PrescriptionItem.id",
    )


class PrescriptionItem(TimestampMixin, Base):
    __tablename__ = "prescription_items"
    __table_args__ = (Index("ix_prescription_items_deleted_at", "deleted_at"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    prescription_id: Mapped[int] = mapped_column(
        ForeignKey("prescriptions.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    drug_catalog_id: Mapped[int | None] = mapped_column(
        ForeignKey("drug_catalogs.id", ondelete="SET NULL"), index=True
    )
    drug_name: Mapped[str] = mapped_column(String(255), nullable=False)
    generic_name: Mapped[str | None] = mapped_column(String(255))
    dosage_form: Mapped[str | None] = mapped_column(String(100))
    specification: Mapped[str | None] = mapped_column(String(255))
    dosage: Mapped[str | None] = mapped_column(String(100))
    dosage_unit: Mapped[str | None] = mapped_column(String(50))
    frequency: Mapped[str | None] = mapped_column(String(100))
    route: Mapped[str | None] = mapped_column(String(100))
    duration: Mapped[int | None] = mapped_column(Integer)
    duration_unit: Mapped[str | None] = mapped_column(String(50))
    quantity: Mapped[Decimal | None] = mapped_column(Numeric(12, 3))
    quantity_unit: Mapped[str | None] = mapped_column(String(50))
    usage_instruction: Mapped[str | None] = mapped_column(Text)
    remark: Mapped[str | None] = mapped_column(Text)
    sort_order: Mapped[int] = mapped_column(Integer, default=0, index=True, nullable=False)
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    prescription: Mapped[Prescription] = relationship(back_populates="items")
    drug_catalog: Mapped[DrugCatalog | None] = relationship()
