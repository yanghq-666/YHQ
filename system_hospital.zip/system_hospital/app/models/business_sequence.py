"""多个业务编号共用的每日流水模型。"""

from datetime import date, datetime

from sqlalchemy import Date, DateTime, Integer, String, func
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class BusinessSequence(Base):
    __tablename__ = "business_sequences"

    sequence_name: Mapped[str] = mapped_column(
        String(50), primary_key=True
    )
    sequence_date: Mapped[date] = mapped_column(Date, primary_key=True)
    current_value: Mapped[int] = mapped_column(Integer, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
