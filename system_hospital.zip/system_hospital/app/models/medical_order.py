"""医嘱模型。"""

from datetime import datetime

from sqlalchemy import DateTime, Enum as SqlEnum
from sqlalchemy import ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base
from app.models.base import TimestampMixin
from app.models.encounter import Encounter
from app.models.enums import MedicalOrderStatus, MedicalOrderType
from app.models.medical_record import MedicalRecord
from app.models.user import User


class MedicalOrder(TimestampMixin, Base):
    __tablename__ = "medical_orders"
    __table_args__ = (
        Index("ix_medical_orders_created_at", "created_at"),
        Index("ix_medical_orders_deleted_at", "deleted_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    order_no: Mapped[str] = mapped_column(
        String(24), unique=True, index=True, nullable=False
    )
    encounter_id: Mapped[int] = mapped_column(
        ForeignKey("encounters.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    record_id: Mapped[int] = mapped_column(
        ForeignKey("medical_records.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    order_type: Mapped[MedicalOrderType] = mapped_column(
        SqlEnum(
            MedicalOrderType,
            name="medical_order_type",
            native_enum=False,
            create_constraint=True,
            validate_strings=True,
        ),
        index=True,
        nullable=False,
    )
    order_content: Mapped[str] = mapped_column(Text, nullable=False)
    dosage: Mapped[str | None] = mapped_column(String(100))
    dosage_unit: Mapped[str | None] = mapped_column(String(50))
    frequency: Mapped[str | None] = mapped_column(String(100))
    route: Mapped[str | None] = mapped_column(String(100))
    start_time: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    end_time: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    status: Mapped[MedicalOrderStatus] = mapped_column(
        SqlEnum(
            MedicalOrderStatus,
            name="medical_order_status",
            native_enum=False,
            create_constraint=True,
            validate_strings=True,
        ),
        default=MedicalOrderStatus.ACTIVE,
        index=True,
        nullable=False,
    )
    remark: Mapped[str | None] = mapped_column(Text)
    created_by: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), nullable=False
    )
    stopped_by: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT")
    )
    stopped_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    encounter: Mapped[Encounter] = relationship()
    record: Mapped[MedicalRecord] = relationship()
    creator: Mapped[User] = relationship(foreign_keys=[created_by])
    stopper: Mapped[User | None] = relationship(foreign_keys=[stopped_by])
