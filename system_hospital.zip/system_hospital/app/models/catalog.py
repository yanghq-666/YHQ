"""轻量药品、疾病和检验项目字典。"""

from sqlalchemy import Boolean, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.models.base import TimestampMixin


class DrugCatalog(TimestampMixin, Base):
    __tablename__ = "drug_catalogs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    drug_code: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    drug_name: Mapped[str] = mapped_column(String(255), index=True)
    generic_name: Mapped[str | None] = mapped_column(String(255))
    dosage_form: Mapped[str | None] = mapped_column(String(100))
    specification: Mapped[str | None] = mapped_column(String(255))
    unit: Mapped[str | None] = mapped_column(String(50))
    manufacturer: Mapped[str | None] = mapped_column(String(255))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)


class LabTestCatalog(TimestampMixin, Base):
    __tablename__ = "lab_test_catalogs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    test_code: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    test_name: Mapped[str] = mapped_column(String(255), index=True)
    unit: Mapped[str | None] = mapped_column(String(50))
    reference_range: Mapped[str | None] = mapped_column(String(255))
    result_type: Mapped[str] = mapped_column(String(50), default="NUMERIC")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)


class DiagnosisCatalog(TimestampMixin, Base):
    __tablename__ = "diagnosis_catalogs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    diagnosis_code: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    diagnosis_name: Mapped[str] = mapped_column(String(255), index=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
