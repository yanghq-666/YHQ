"""主病历、版本快照及每日编号流水模型。"""

from datetime import date, datetime
from typing import Any

from sqlalchemy import JSON, Date, DateTime, Enum as SqlEnum
from sqlalchemy import ForeignKey, Index, Integer, String, Text, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base
from app.models.base import TimestampMixin
from app.models.encounter import Encounter
from app.models.enums import MedicalRecordStatus
from app.models.user import User


class MedicalRecord(TimestampMixin, Base):
    """一次就诊对应的一份主病历。"""

    __tablename__ = "medical_records"
    __table_args__ = (
        Index("ix_medical_records_created_at", "created_at"),
        Index("ix_medical_records_updated_at", "updated_at"),
        Index("ix_medical_records_deleted_at", "deleted_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    record_no: Mapped[str] = mapped_column(
        String(24), unique=True, index=True, nullable=False
    )
    encounter_id: Mapped[int] = mapped_column(
        ForeignKey("encounters.id", ondelete="RESTRICT"),
        unique=True,
        index=True,
        nullable=False,
    )
    chief_complaint: Mapped[str | None] = mapped_column(Text)
    present_illness: Mapped[str | None] = mapped_column(Text)
    past_history: Mapped[str | None] = mapped_column(Text)
    personal_history: Mapped[str | None] = mapped_column(Text)
    family_history: Mapped[str | None] = mapped_column(Text)
    allergy_history: Mapped[str | None] = mapped_column(Text)
    physical_exam: Mapped[str | None] = mapped_column(Text)
    auxiliary_exam: Mapped[str | None] = mapped_column(Text)
    diagnosis_summary: Mapped[str | None] = mapped_column(Text)
    treatment_plan: Mapped[str | None] = mapped_column(Text)
    doctor_notes: Mapped[str | None] = mapped_column(Text)
    status: Mapped[MedicalRecordStatus] = mapped_column(
        SqlEnum(
            MedicalRecordStatus,
            name="medical_record_status",
            native_enum=False,
            create_constraint=True,
            validate_strings=True,
        ),
        default=MedicalRecordStatus.DRAFT,
        index=True,
        nullable=False,
    )
    created_by: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), index=True, nullable=False
    )
    updated_by: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), nullable=False
    )
    submitted_by: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT")
    )
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    reviewed_by: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT")
    )
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    current_reviewer_id: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), index=True
    )
    approved_version: Mapped[int | None] = mapped_column(Integer)
    completed_by: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT")
    )
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    archived_by: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT")
    )
    archived_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    encounter: Mapped[Encounter] = relationship(back_populates="medical_record")
    creator: Mapped[User] = relationship(foreign_keys=[created_by])
    updater: Mapped[User] = relationship(foreign_keys=[updated_by])
    submitter: Mapped[User | None] = relationship(foreign_keys=[submitted_by])
    reviewer: Mapped[User | None] = relationship(foreign_keys=[reviewed_by])
    current_reviewer: Mapped[User | None] = relationship(
        foreign_keys=[current_reviewer_id]
    )
    completer: Mapped[User | None] = relationship(foreign_keys=[completed_by])
    archiver: Mapped[User | None] = relationship(foreign_keys=[archived_by])
    versions: Mapped[list["MedicalRecordVersion"]] = relationship(
        back_populates="record",
        order_by="MedicalRecordVersion.version",
    )
    reviews: Mapped[list["RecordReview"]] = relationship(
        back_populates="record",
        order_by="RecordReview.created_at, RecordReview.id",
    )


class MedicalRecordVersion(Base):
    """病历不可覆盖的 JSON 版本快照。"""

    __tablename__ = "medical_record_versions"
    __table_args__ = (
        UniqueConstraint(
            "record_id", "version", name="uq_medical_record_versions_record_version"
        ),
        Index("ix_medical_record_versions_created_at", "created_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    record_id: Mapped[int] = mapped_column(
        ForeignKey("medical_records.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    snapshot_data: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False)
    change_reason: Mapped[str] = mapped_column(String(500), nullable=False)
    created_by: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), nullable=False
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    record: Mapped[MedicalRecord] = relationship(back_populates="versions")
    creator: Mapped[User] = relationship(foreign_keys=[created_by])


class MedicalRecordSequence(Base):
    """每日病历流水；每个自然日独立从 1 开始。"""

    __tablename__ = "medical_record_sequences"

    sequence_date: Mapped[date] = mapped_column(Date, primary_key=True)
    current_value: Mapped[int] = mapped_column(Integer, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
