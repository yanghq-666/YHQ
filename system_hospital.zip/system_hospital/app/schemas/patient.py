"""患者输入、查询和安全输出模型。"""

import re
from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.models.enums import BloodType, Gender

ID_CARD_PATTERN = re.compile(r"^(?:\d{15}|\d{17}[0-9X])$")
PHONE_PATTERN = re.compile(r"^\+?[0-9][0-9 -]{5,19}$")


def _normalize_optional(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = value.strip()
    return normalized or None


class PatientCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1, max_length=100)
    gender: Gender = Gender.UNKNOWN
    birthday: date | None = None
    id_card: str | None = Field(default=None, max_length=32)
    phone: str | None = Field(default=None, max_length=30)
    address: str | None = Field(default=None, max_length=500)
    blood_type: BloodType = BloodType.UNKNOWN
    allergy_history: str | None = Field(default=None, max_length=5000)
    emergency_contact: str | None = Field(default=None, max_length=100)
    emergency_phone: str | None = Field(default=None, max_length=30)
    remark: str | None = Field(default=None, max_length=5000)

    @field_validator("name")
    @classmethod
    def validate_name(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("患者姓名不能为空")
        return normalized

    @field_validator("birthday")
    @classmethod
    def validate_birthday(cls, value: date | None) -> date | None:
        if value is not None and value > date.today():
            raise ValueError("出生日期不能晚于今天")
        return value

    @field_validator("id_card")
    @classmethod
    def validate_id_card(cls, value: str | None) -> str | None:
        normalized = _normalize_optional(value)
        if normalized is None:
            return None
        normalized = normalized.upper()
        if not ID_CARD_PATTERN.fullmatch(normalized):
            raise ValueError("身份证号格式不正确")
        return normalized

    @field_validator("phone", "emergency_phone")
    @classmethod
    def validate_phone(cls, value: str | None) -> str | None:
        normalized = _normalize_optional(value)
        if normalized is not None and not PHONE_PATTERN.fullmatch(normalized):
            raise ValueError("电话号码格式不正确")
        return normalized

    @field_validator(
        "address",
        "allergy_history",
        "emergency_contact",
        "remark",
    )
    @classmethod
    def normalize_optional_text(cls, value: str | None) -> str | None:
        return _normalize_optional(value)


class PatientUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str | None = Field(default=None, min_length=1, max_length=100)
    gender: Gender | None = None
    birthday: date | None = None
    id_card: str | None = Field(default=None, max_length=32)
    phone: str | None = Field(default=None, max_length=30)
    address: str | None = Field(default=None, max_length=500)
    blood_type: BloodType | None = None
    allergy_history: str | None = Field(default=None, max_length=5000)
    emergency_contact: str | None = Field(default=None, max_length=100)
    emergency_phone: str | None = Field(default=None, max_length=30)
    remark: str | None = Field(default=None, max_length=5000)

    @field_validator("name")
    @classmethod
    def validate_name(cls, value: str | None) -> str | None:
        if value is None:
            return None
        normalized = value.strip()
        if not normalized:
            raise ValueError("患者姓名不能为空")
        return normalized

    @field_validator("birthday")
    @classmethod
    def validate_birthday(cls, value: date | None) -> date | None:
        if value is not None and value > date.today():
            raise ValueError("出生日期不能晚于今天")
        return value

    @field_validator("id_card")
    @classmethod
    def validate_id_card(cls, value: str | None) -> str | None:
        normalized = _normalize_optional(value)
        if normalized is None:
            return None
        normalized = normalized.upper()
        if not ID_CARD_PATTERN.fullmatch(normalized):
            raise ValueError("身份证号格式不正确")
        return normalized

    @field_validator("phone", "emergency_phone")
    @classmethod
    def validate_phone(cls, value: str | None) -> str | None:
        normalized = _normalize_optional(value)
        if normalized is not None and not PHONE_PATTERN.fullmatch(normalized):
            raise ValueError("电话号码格式不正确")
        return normalized

    @field_validator(
        "address",
        "allergy_history",
        "emergency_contact",
        "remark",
    )
    @classmethod
    def normalize_optional_text(cls, value: str | None) -> str | None:
        return _normalize_optional(value)


class PatientSearchParams(BaseModel):
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=20, ge=1, le=100)
    keyword: str | None = Field(default=None, max_length=100)
    patient_no: str | None = Field(default=None, max_length=20)
    name: str | None = Field(default=None, max_length=100)
    phone: str | None = Field(default=None, max_length=30)
    id_card: str | None = Field(default=None, max_length=32)
    gender: Gender | None = None
    blood_type: BloodType | None = None


class PatientRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    patient_no: str
    name: str
    gender: Gender
    birthday: date | None
    id_card: str | None
    phone: str | None
    address: str | None
    blood_type: BloodType
    allergy_history: str | None
    emergency_contact: str | None
    emergency_phone: str | None
    remark: str | None
    created_at: datetime
    updated_at: datetime


class PatientListItem(PatientRead):
    pass


class PatientDetail(PatientRead):
    pass

