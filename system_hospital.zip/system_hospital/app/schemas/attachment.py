"""附件元数据输出模型。"""

from datetime import datetime

from pydantic import BaseModel, ConfigDict

from app.models.enums import AttachmentCategory, StorageProvider


class AttachmentRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    patient_id: int
    encounter_id: int
    record_id: int
    lab_report_id: int | None
    examination_id: int | None
    category: AttachmentCategory
    original_name: str
    storage_name: str
    storage_provider: StorageProvider
    object_key: str
    mime_type: str
    file_extension: str
    file_size: int
    file_hash: str
    description: str | None
    uploaded_by: int
    created_at: datetime


class AttachmentUploadResponse(AttachmentRead):
    pass
