"""统计分析 API 输出模型。"""

from pydantic import BaseModel


class StatisticPoint(BaseModel):
    name: str
    value: int


class StatisticsSummary(BaseModel):
    patients: int
    users: int
    doctors: int
    encounters_today: int
    medical_records: int
    draft_records: int
    completed_records: int
