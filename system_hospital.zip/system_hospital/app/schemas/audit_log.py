"""审计日志只读查询模型。"""

from datetime import date, datetime

from pydantic import BaseModel, Field, model_validator


class AuditLogSearchParams(BaseModel):
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=20, ge=1, le=100)
    user: str | None = Field(default=None, max_length=100)
    action: str | None = Field(default=None, max_length=100)
    start_date: date | None = None
    end_date: date | None = None

    @model_validator(mode="after")
    def validate_dates(self) -> "AuditLogSearchParams":
        if self.start_date and self.end_date and self.start_date > self.end_date:
            raise ValueError("开始日期不能晚于结束日期")
        return self


class AuditLogListItem(BaseModel):
    id: int
    user_id: int | None
    username: str | None
    real_name: str | None
    action: str
    module: str
    target_type: str
    target_id: int | None
    request_method: str | None
    request_path: str | None
    ip_address: str | None
    created_at: datetime
