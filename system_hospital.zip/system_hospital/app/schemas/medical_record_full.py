"""供后续审核页面使用的完整病历聚合结构。"""

from pydantic import BaseModel

from app.schemas.attachment import AttachmentRead
from app.schemas.diagnosis import DiagnosisRead
from app.schemas.examination import ExaminationRead
from app.schemas.lab_report import LabReportDetail
from app.schemas.medical_order import MedicalOrderRead
from app.schemas.medical_record import (
    MedicalRecordDetail,
    MedicalRecordEncounterBrief,
    MedicalRecordPatientBrief,
    MedicalRecordVersionRead,
)
from app.schemas.prescription import PrescriptionDetail
from app.schemas.record_review import RecordReviewRead


class MedicalRecordFull(BaseModel):
    patient: MedicalRecordPatientBrief
    encounter: MedicalRecordEncounterBrief
    medical_record: MedicalRecordDetail
    diagnoses: list[DiagnosisRead]
    medical_orders: list[MedicalOrderRead]
    prescriptions: list[PrescriptionDetail]
    lab_reports: list[LabReportDetail]
    examinations: list[ExaminationRead]
    attachments: list[AttachmentRead]
    versions: list[MedicalRecordVersionRead]
    review_history: list[RecordReviewRead]
