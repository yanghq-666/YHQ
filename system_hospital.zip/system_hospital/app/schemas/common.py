"""通用 API 响应结构。"""

from typing import Generic, TypeVar

from pydantic import BaseModel

DataT = TypeVar("DataT")


class ApiResponse(BaseModel, Generic[DataT]):
    success: bool = True
    code: int = 200
    message: str = "操作成功"
    data: DataT


class PageData(BaseModel, Generic[DataT]):
    items: list[DataT]
    page: int
    page_size: int
    total: int
    pages: int
