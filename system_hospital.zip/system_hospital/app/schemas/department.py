"""科室输入输出模型。"""

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.models.enums import DepartmentStatus


class DepartmentBrief(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    department_code: str
    name: str


class DepartmentCreate(BaseModel):
    department_code: str = Field(min_length=1, max_length=50)
    name: str = Field(min_length=1, max_length=100)
    description: str | None = Field(default=None, max_length=1000)
    status: DepartmentStatus = DepartmentStatus.ACTIVE

    @field_validator("department_code", "name")
    @classmethod
    def validate_required_text(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("不能为空")
        return value


class DepartmentUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=100)
    description: str | None = Field(default=None, max_length=1000)
    status: DepartmentStatus | None = None

    @field_validator("name")
    @classmethod
    def validate_name(cls, value: str | None) -> str | None:
        if value is not None and not value.strip():
            raise ValueError("科室名称不能为空")
        return value


class DepartmentResponse(DepartmentBrief):
    description: str | None
    status: DepartmentStatus
    created_at: datetime
    updated_at: datetime
