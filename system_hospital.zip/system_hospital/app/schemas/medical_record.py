"""病历输入、查询、详情、提交和版本输出模型。"""

from datetime import date, datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from app.models.enums import EncounterStatus, EncounterType, Gender, MedicalRecordStatus

CONTENT_FIELDS = (
    "chief_complaint",
    "present_illness",
    "past_history",
    "personal_history",
    "family_history",
    "allergy_history",
    "physical_exam",
    "auxiliary_exam",
    "diagnosis_summary",
    "treatment_plan",
    "doctor_notes",
)


def _normalize_text(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = value.strip()
    return normalized or None


class MedicalRecordContent(BaseModel):
    chief_complaint: str | None = Field(default=None, max_length=20_000)
    present_illness: str | None = Field(default=None, max_length=20_000)
    past_history: str | None = Field(default=None, max_length=20_000)
    personal_history: str | None = Field(default=None, max_length=20_000)
    family_history: str | None = Field(default=None, max_length=20_000)
    allergy_history: str | None = Field(default=None, max_length=20_000)
    physical_exam: str | None = Field(default=None, max_length=20_000)
    auxiliary_exam: str | None = Field(default=None, max_length=20_000)
    diagnosis_summary: str | None = Field(default=None, max_length=20_000)
    treatment_plan: str | None = Field(default=None, max_length=20_000)
    doctor_notes: str | None = Field(default=None, max_length=20_000)

    @field_validator(*CONTENT_FIELDS)
    @classmethod
    def normalize_content(cls, value: str | None) -> str | None:
        return _normalize_text(value)


class MedicalRecordCreate(MedicalRecordContent):
    model_config = ConfigDict(extra="forbid")


class MedicalRecordUpdate(MedicalRecordContent):
    model_config = ConfigDict(extra="forbid")


class MedicalRecordSearchParams(BaseModel):
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=20, ge=1, le=100)
    keyword: str | None = Field(default=None, max_length=100)
    record_no: str | None = Field(default=None, max_length=24)
    patient_id: int | None = Field(default=None, gt=0)
    patient_name: str | None = Field(default=None, max_length=100)
    doctor_id: int | None = Field(default=None, gt=0)
    department_id: int | None = Field(default=None, gt=0)
    encounter_id: int | None = Field(default=None, gt=0)
    status: MedicalRecordStatus | None = None
    start_date: date | None = None
    end_date: date | None = None

    @model_validator(mode="after")
    def validate_date_range(self) -> "MedicalRecordSearchParams":
        if self.start_date and self.end_date and self.start_date > self.end_date:
            raise ValueError("开始日期不能晚于结束日期")
        return self


class MyMedicalRecordSearchParams(BaseModel):
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=20, ge=1, le=100)
    keyword: str | None = Field(default=None, max_length=100)
    status: MedicalRecordStatus | None = None
    start_date: date | None = None
    end_date: date | None = None

    @model_validator(mode="after")
    def validate_date_range(self) -> "MyMedicalRecordSearchParams":
        if self.start_date and self.end_date and self.start_date > self.end_date:
            raise ValueError("开始日期不能晚于结束日期")
        return self


class MedicalRecordPatientBrief(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    patient_no: str
    name: str
    gender: Gender
    birthday: date | None


class MedicalRecordDoctorBrief(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    real_name: str
    employee_no: str | None


class MedicalRecordDepartmentBrief(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str


class MedicalRecordEncounterBrief(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    encounter_no: str
    encounter_type: EncounterType
    visit_time: datetime
    status: EncounterStatus
    patient: MedicalRecordPatientBrief
    doctor: MedicalRecordDoctorBrief
    department: MedicalRecordDepartmentBrief


class MedicalRecordRead(MedicalRecordContent):
    model_config = ConfigDict(from_attributes=True)

    id: int
    record_no: str
    encounter_id: int
    status: MedicalRecordStatus
    created_by: int
    updated_by: int
    submitted_by: int | None
    submitted_at: datetime | None
    reviewed_by: int | None
    reviewed_at: datetime | None
    current_reviewer_id: int | None
    approved_version: int | None
    completed_by: int | None
    completed_at: datetime | None
    archived_by: int | None
    archived_at: datetime | None
    created_at: datetime
    updated_at: datetime


class MedicalRecordListItem(MedicalRecordRead):
    encounter: MedicalRecordEncounterBrief


class MedicalRecordDetail(MedicalRecordListItem):
    pass


class MedicalRecordSubmitResponse(BaseModel):
    id: int
    record_no: str
    old_status: MedicalRecordStatus
    status: MedicalRecordStatus
    submitted_by: int
    submitted_at: datetime
    version: int


class MedicalRecordCompleteResponse(BaseModel):
    id: int
    record_no: str
    old_status: MedicalRecordStatus
    status: MedicalRecordStatus
    completed_by: int
    completed_at: datetime
    version: int


class MedicalRecordArchiveResponse(BaseModel):
    id: int
    record_no: str
    old_status: MedicalRecordStatus
    status: MedicalRecordStatus
    archived_by: int
    archived_at: datetime


class MedicalRecordVersionRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    record_id: int
    version: int
    snapshot_data: dict[str, Any]
    change_reason: str
    created_by: int
    created_at: datetime
