"""检验报告输入输出模型。"""

from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from app.models.enums import AbnormalFlag, LabReportStatus


def _required(value: str) -> str:
    value = value.strip()
    if not value:
        raise ValueError("不能为空")
    return value


class LabReportCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    lab_test_catalog_id: int | None = Field(default=None, gt=0)
    report_name: str = Field(max_length=255)
    report_type: str = Field(max_length=100)
    specimen_type: str | None = Field(default=None, max_length=100)
    collected_at: datetime | None = None

    _names = field_validator("report_name", "report_type")(_required)


class LabReportUpdate(BaseModel):
    """预留的非状态字段更新结构；状态只能走专用状态机方法。"""

    model_config = ConfigDict(extra="forbid")
    report_name: str | None = Field(default=None, max_length=255)
    report_type: str | None = Field(default=None, max_length=100)
    specimen_type: str | None = Field(default=None, max_length=100)
    collected_at: datetime | None = None


class LabResultCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    lab_test_catalog_id: int | None = Field(default=None, gt=0)
    item_code: str | None = Field(default=None, max_length=50)
    item_name: str = Field(max_length=255)
    result_value: str | None = Field(default=None, max_length=255)
    result_text: str | None = Field(default=None, max_length=20_000)
    unit: str | None = Field(default=None, max_length=50)
    reference_range: str | None = Field(default=None, max_length=255)
    abnormal_flag: AbnormalFlag = AbnormalFlag.UNKNOWN
    sort_order: int = Field(default=0, ge=0)
    remark: str | None = Field(default=None, max_length=2_000)

    _item_name = field_validator("item_name")(_required)

    @model_validator(mode="after")
    def validate_result(self) -> "LabResultCreate":
        if not (self.result_value or self.result_text):
            raise ValueError("result_value 和 result_text 至少填写一项")
        return self


class LabResultsBatchCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    results: list[LabResultCreate] = Field(min_length=1, max_length=500)


class LabResultUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    lab_test_catalog_id: int | None = Field(default=None, gt=0)
    item_code: str | None = Field(default=None, max_length=50)
    item_name: str | None = Field(default=None, max_length=255)
    result_value: str | None = Field(default=None, max_length=255)
    result_text: str | None = Field(default=None, max_length=20_000)
    unit: str | None = Field(default=None, max_length=50)
    reference_range: str | None = Field(default=None, max_length=255)
    abnormal_flag: AbnormalFlag | None = None
    sort_order: int | None = Field(default=None, ge=0)
    remark: str | None = Field(default=None, max_length=2_000)

    @field_validator("item_name")
    @classmethod
    def validate_item_name(cls, value: str | None) -> str | None:
        if value is None:
            raise ValueError("item_name 不能设为空")
        return _required(value)


class LabReportComplete(BaseModel):
    model_config = ConfigDict(extra="forbid")
    result_summary: str = Field(max_length=20_000)
    conclusion: str = Field(max_length=20_000)

    _texts = field_validator("result_summary", "conclusion")(_required)


class LabReportCancel(BaseModel):
    model_config = ConfigDict(extra="forbid")
    reason: str = Field(min_length=1, max_length=500)


class LabReportFilter(BaseModel):
    status: LabReportStatus | None = None
    report_type: str | None = Field(default=None, max_length=100)
    start_date: date | None = None
    end_date: date | None = None

    @model_validator(mode="after")
    def validate_dates(self) -> "LabReportFilter":
        if self.start_date and self.end_date and self.start_date > self.end_date:
            raise ValueError("开始日期不能晚于结束日期")
        return self


class LabResultRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    lab_report_id: int
    lab_test_catalog_id: int | None
    item_code: str | None
    item_name: str
    result_value: str | None
    result_text: str | None
    unit: str | None
    reference_range: str | None
    abnormal_flag: AbnormalFlag
    sort_order: int
    remark: str | None
    created_at: datetime
    updated_at: datetime


class LabReportRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    report_no: str
    patient_id: int
    encounter_id: int
    record_id: int
    order_id: int | None
    lab_test_catalog_id: int | None
    report_name: str
    report_type: str
    specimen_type: str | None
    status: LabReportStatus
    result_summary: str | None
    conclusion: str | None
    requested_by: int
    performed_by: int | None
    reviewed_by: int | None
    collected_at: datetime | None
    reported_at: datetime | None
    created_at: datetime
    updated_at: datetime


class LabReportDetail(LabReportRead):
    results: list[LabResultRead]
    lab_test_catalog_id: int | None = Field(default=None, gt=0)
