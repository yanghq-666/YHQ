"""角色与权限输出模型。"""

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class RolePermissionAssign(BaseModel):
    permission_ids: list[int] = Field(default_factory=list)


class PermissionResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    code: str
    name: str
    module: str
    description: str | None
    created_at: datetime


class RoleResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    code: str
    name: str
    description: str | None
    created_at: datetime
    updated_at: datetime
    permissions: list[str]
