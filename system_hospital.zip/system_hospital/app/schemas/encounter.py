"""就诊输入、查询和输出模型。"""

from datetime import date, datetime, timezone
from zoneinfo import ZoneInfo

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from app.models.enums import EncounterStatus, EncounterType, Gender

LOCAL_TIMEZONE = ZoneInfo("Asia/Shanghai")


def _to_utc(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=LOCAL_TIMEZONE)
    return value.astimezone(timezone.utc)


class EncounterCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    patient_id: int = Field(gt=0)
    doctor_id: int = Field(gt=0)
    department_id: int = Field(gt=0)
    encounter_type: EncounterType
    visit_time: datetime
    chief_complaint: str | None = Field(default=None, max_length=5000)
    admission_time: datetime | None = None
    discharge_time: datetime | None = None
    room_no: str | None = Field(default=None, max_length=50)
    bed_no: str | None = Field(default=None, max_length=50)
    remark: str | None = Field(default=None, max_length=5000)

    @field_validator("visit_time", "admission_time", "discharge_time")
    @classmethod
    def normalize_time(cls, value: datetime | None) -> datetime | None:
        return _to_utc(value)

    @model_validator(mode="after")
    def validate_inpatient_times(self) -> "EncounterCreate":
        if (
            self.admission_time
            and self.discharge_time
            and self.admission_time > self.discharge_time
        ):
            raise ValueError("入院时间不能晚于出院时间")
        return self


class EncounterUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    doctor_id: int | None = Field(default=None, gt=0)
    department_id: int | None = Field(default=None, gt=0)
    visit_time: datetime | None = None
    chief_complaint: str | None = Field(default=None, max_length=5000)
    admission_time: datetime | None = None
    discharge_time: datetime | None = None
    room_no: str | None = Field(default=None, max_length=50)
    bed_no: str | None = Field(default=None, max_length=50)
    remark: str | None = Field(default=None, max_length=5000)

    @field_validator("visit_time", "admission_time", "discharge_time")
    @classmethod
    def normalize_time(cls, value: datetime | None) -> datetime | None:
        return _to_utc(value)


class EncounterSearchParams(BaseModel):
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=20, ge=1, le=100)
    keyword: str | None = Field(default=None, max_length=100)
    encounter_no: str | None = Field(default=None, max_length=24)
    patient_id: int | None = Field(default=None, gt=0)
    patient_name: str | None = Field(default=None, max_length=100)
    doctor_id: int | None = Field(default=None, gt=0)
    department_id: int | None = Field(default=None, gt=0)
    encounter_type: EncounterType | None = None
    status: EncounterStatus | None = None
    start_date: date | None = None
    end_date: date | None = None

    @model_validator(mode="after")
    def validate_date_range(self) -> "EncounterSearchParams":
        if self.start_date and self.end_date and self.start_date > self.end_date:
            raise ValueError("开始日期不能晚于结束日期")
        return self


class EncounterPatientBrief(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    patient_no: str
    name: str
    gender: Gender
    birthday: date | None
    allergy_history: str | None


class EncounterDoctorBrief(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    real_name: str
    employee_no: str | None


class EncounterDepartmentBrief(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str


class EncounterRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    encounter_no: str
    patient_id: int
    doctor_id: int
    department_id: int
    encounter_type: EncounterType
    visit_time: datetime
    status: EncounterStatus
    chief_complaint: str | None
    admission_time: datetime | None
    discharge_time: datetime | None
    room_no: str | None
    bed_no: str | None
    remark: str | None
    created_by: int
    created_at: datetime
    updated_at: datetime


class EncounterListItem(EncounterRead):
    patient: EncounterPatientBrief
    doctor: EncounterDoctorBrief
    department: EncounterDepartmentBrief


class EncounterDetail(EncounterListItem):
    pass


class EncounterStatusResponse(BaseModel):
    id: int
    encounter_no: str
    old_status: EncounterStatus
    status: EncounterStatus
