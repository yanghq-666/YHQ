"""处方、项目与状态操作数据模型。"""

from datetime import datetime
from decimal import Decimal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.models.enums import PrescriptionStatus, PrescriptionType


class PrescriptionItemCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    drug_catalog_id: int | None = Field(default=None, gt=0)
    drug_name: str = Field(min_length=1, max_length=255)
    generic_name: str | None = Field(default=None, max_length=255)
    dosage_form: str | None = Field(default=None, max_length=100)
    specification: str | None = Field(default=None, max_length=255)
    dosage: str | None = Field(default=None, max_length=100)
    dosage_unit: str | None = Field(default=None, max_length=50)
    frequency: str | None = Field(default=None, max_length=100)
    route: str | None = Field(default=None, max_length=100)
    duration: int | None = Field(default=None, gt=0)
    duration_unit: str | None = Field(default=None, max_length=50)
    quantity: Decimal | None = Field(default=None, gt=0, max_digits=12, decimal_places=3)
    quantity_unit: str | None = Field(default=None, max_length=50)
    usage_instruction: str | None = Field(default=None, max_length=5000)
    remark: str | None = Field(default=None, max_length=5000)
    sort_order: int = Field(default=0, ge=0)

    @field_validator("drug_name")
    @classmethod
    def normalize_drug_name(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("药品名称不能为空")
        return normalized


class PrescriptionItemUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    drug_catalog_id: int | None = Field(default=None, gt=0)
    drug_name: str | None = Field(default=None, min_length=1, max_length=255)
    generic_name: str | None = Field(default=None, max_length=255)
    dosage_form: str | None = Field(default=None, max_length=100)
    specification: str | None = Field(default=None, max_length=255)
    dosage: str | None = Field(default=None, max_length=100)
    dosage_unit: str | None = Field(default=None, max_length=50)
    frequency: str | None = Field(default=None, max_length=100)
    route: str | None = Field(default=None, max_length=100)
    duration: int | None = Field(default=None, gt=0)
    duration_unit: str | None = Field(default=None, max_length=50)
    quantity: Decimal | None = Field(default=None, gt=0, max_digits=12, decimal_places=3)
    quantity_unit: str | None = Field(default=None, max_length=50)
    usage_instruction: str | None = Field(default=None, max_length=5000)
    remark: str | None = Field(default=None, max_length=5000)
    sort_order: int | None = Field(default=None, ge=0)

    @field_validator("drug_name")
    @classmethod
    def normalize_drug_name(cls, value: str | None) -> str | None:
        if value is None:
            return None
        normalized = value.strip()
        if not normalized:
            raise ValueError("药品名称不能为空")
        return normalized


class PrescriptionCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    prescription_type: PrescriptionType | None = None
    notes: str | None = Field(default=None, max_length=5000)
    items: list[PrescriptionItemCreate] = Field(default_factory=list, max_length=100)


class PrescriptionUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    prescription_type: PrescriptionType | None = None
    notes: str | None = Field(default=None, max_length=5000)


class PrescriptionCancelRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    reason: str = Field(min_length=1, max_length=500)

    @field_validator("reason")
    @classmethod
    def normalize_reason(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("取消原因不能为空")
        return normalized


class PrescriptionItemRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    prescription_id: int
    drug_catalog_id: int | None
    drug_name: str
    generic_name: str | None
    dosage_form: str | None
    specification: str | None
    dosage: str | None
    dosage_unit: str | None
    frequency: str | None
    route: str | None
    duration: int | None
    duration_unit: str | None
    quantity: Decimal | None
    quantity_unit: str | None
    usage_instruction: str | None
    remark: str | None
    sort_order: int
    created_at: datetime
    updated_at: datetime


class PrescriptionRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    prescription_no: str
    encounter_id: int
    record_id: int
    order_id: int | None
    doctor_id: int
    prescription_type: PrescriptionType
    status: PrescriptionStatus
    notes: str | None
    cancelled_by: int | None
    cancelled_at: datetime | None
    cancel_reason: str | None
    created_at: datetime
    updated_at: datetime


class PrescriptionListItem(PrescriptionRead):
    item_count: int


class PrescriptionDetail(PrescriptionRead):
    items: list[PrescriptionItemRead]


class PrescriptionStatusResponse(BaseModel):
    id: int
    prescription_no: str
    old_status: PrescriptionStatus
    status: PrescriptionStatus
    cancelled_by: int | None = None
    cancelled_at: datetime | None = None
    cancel_reason: str | None = None
