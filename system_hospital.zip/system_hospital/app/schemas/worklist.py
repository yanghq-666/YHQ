"""检验、检查与附件全局工作列表模型。"""

from datetime import date, datetime

from pydantic import BaseModel, Field, model_validator

from app.models.enums import (
    AttachmentCategory,
    ExaminationStatus,
    ExaminationType,
    LabReportStatus,
)


class _DateRangeParams(BaseModel):
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=20, ge=1, le=100)
    keyword: str | None = Field(default=None, max_length=100)
    start_date: date | None = None
    end_date: date | None = None

    @model_validator(mode="after")
    def validate_dates(self):
        if self.start_date and self.end_date and self.start_date > self.end_date:
            raise ValueError("开始日期不能晚于结束日期")
        return self


class LabWorklistParams(_DateRangeParams):
    status: LabReportStatus | None = None


class ExaminationWorklistParams(_DateRangeParams):
    status: ExaminationStatus | None = None
    examination_type: ExaminationType | None = None


class AttachmentWorklistParams(_DateRangeParams):
    category: AttachmentCategory | None = None


class LabWorklistItem(BaseModel):
    id: int
    report_no: str
    report_name: str
    specimen_type: str | None
    status: LabReportStatus
    patient_name: str
    patient_no: str
    encounter_no: str
    record_no: str
    requested_by_name: str
    reported_at: datetime | None
    created_at: datetime


class ExaminationWorklistItem(BaseModel):
    id: int
    examination_no: str
    examination_type: ExaminationType
    examination_name: str
    body_part: str | None
    status: ExaminationStatus
    patient_name: str
    patient_no: str
    encounter_no: str
    record_no: str
    requested_by_name: str
    reported_at: datetime | None
    created_at: datetime


class AttachmentWorklistItem(BaseModel):
    id: int
    original_name: str
    mime_type: str
    file_size: int
    category: AttachmentCategory
    patient_name: str
    patient_no: str
    encounter_no: str
    record_no: str
    uploaded_by_name: str
    created_at: datetime
