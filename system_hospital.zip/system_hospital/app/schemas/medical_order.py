"""医嘱输入、筛选、输出和状态响应模型。"""

from datetime import datetime, timezone
from decimal import Decimal
from zoneinfo import ZoneInfo

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from app.models.enums import ExaminationType, MedicalOrderStatus, MedicalOrderType

LOCAL_TIMEZONE = ZoneInfo("Asia/Shanghai")


def _to_utc(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=LOCAL_TIMEZONE)
    return value.astimezone(timezone.utc)


class MedicalOrderCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    order_type: MedicalOrderType
    order_content: str = Field(min_length=1, max_length=20_000)
    dosage: str | None = Field(default=None, max_length=100)
    dosage_unit: str | None = Field(default=None, max_length=50)
    frequency: str | None = Field(default=None, max_length=100)
    route: str | None = Field(default=None, max_length=100)
    start_time: datetime | None = None
    end_time: datetime | None = None
    remark: str | None = Field(default=None, max_length=5000)
    drug_catalog_id: int | None = Field(default=None, gt=0)
    duration: int | None = Field(default=None, gt=0)
    duration_unit: str | None = Field(default=None, max_length=50)
    quantity: Decimal | None = Field(default=None, gt=0, max_digits=12, decimal_places=3)
    quantity_unit: str | None = Field(default=None, max_length=50)
    lab_test_catalog_id: int | None = Field(default=None, gt=0)
    lab_report_type: str | None = Field(default=None, max_length=100)
    specimen_type: str | None = Field(default=None, max_length=100)
    examination_type: ExaminationType | None = None
    body_part: str | None = Field(default=None, max_length=255)

    @field_validator("order_content")
    @classmethod
    def normalize_content(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("医嘱内容不能为空")
        return normalized

    @field_validator("start_time", "end_time")
    @classmethod
    def normalize_time(cls, value: datetime | None) -> datetime | None:
        return _to_utc(value)

    @model_validator(mode="after")
    def validate_times(self) -> "MedicalOrderCreate":
        if self.start_time and self.end_time and self.start_time > self.end_time:
            raise ValueError("医嘱开始时间不能晚于结束时间")
        if self.order_type == MedicalOrderType.MEDICATION:
            required = {
                "药品": self.drug_catalog_id,
                "单次剂量": self.dosage,
                "频次": self.frequency,
                "给药途径": self.route,
                "疗程": self.duration,
                "数量": self.quantity,
            }
            missing = [label for label, value in required.items() if value in (None, "")]
            if missing:
                raise ValueError(f"药物医嘱缺少：{'、'.join(missing)}")
        elif self.order_type == MedicalOrderType.LAB and not self.lab_report_type:
            raise ValueError("请选择检验类型")
        elif (
            self.order_type == MedicalOrderType.EXAMINATION
            and self.examination_type is None
        ):
            raise ValueError("请选择检查类型")
        return self


class MedicalOrderUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    order_type: MedicalOrderType | None = None
    order_content: str | None = Field(default=None, min_length=1, max_length=20_000)
    dosage: str | None = Field(default=None, max_length=100)
    dosage_unit: str | None = Field(default=None, max_length=50)
    frequency: str | None = Field(default=None, max_length=100)
    route: str | None = Field(default=None, max_length=100)
    start_time: datetime | None = None
    end_time: datetime | None = None
    remark: str | None = Field(default=None, max_length=5000)
    drug_catalog_id: int | None = Field(default=None, gt=0)
    duration: int | None = Field(default=None, gt=0)
    duration_unit: str | None = Field(default=None, max_length=50)
    quantity: Decimal | None = Field(default=None, gt=0, max_digits=12, decimal_places=3)
    quantity_unit: str | None = Field(default=None, max_length=50)
    lab_test_catalog_id: int | None = Field(default=None, gt=0)
    lab_report_type: str | None = Field(default=None, max_length=100)
    specimen_type: str | None = Field(default=None, max_length=100)
    examination_type: ExaminationType | None = None
    body_part: str | None = Field(default=None, max_length=255)

    @field_validator("order_content")
    @classmethod
    def normalize_content(cls, value: str | None) -> str | None:
        if value is None:
            return None
        normalized = value.strip()
        if not normalized:
            raise ValueError("医嘱内容不能为空")
        return normalized

    @field_validator("start_time", "end_time")
    @classmethod
    def normalize_time(cls, value: datetime | None) -> datetime | None:
        return _to_utc(value)


class MedicalOrderFilter(BaseModel):
    order_type: MedicalOrderType | None = None
    status: MedicalOrderStatus | None = None


class MedicalOrderRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    order_no: str
    encounter_id: int
    record_id: int
    order_type: MedicalOrderType
    order_content: str
    dosage: str | None
    dosage_unit: str | None
    frequency: str | None
    route: str | None
    start_time: datetime | None
    end_time: datetime | None
    status: MedicalOrderStatus
    remark: str | None
    created_by: int
    stopped_by: int | None
    stopped_at: datetime | None
    created_at: datetime
    updated_at: datetime


class MedicalOrderStatusResponse(BaseModel):
    id: int
    order_no: str
    old_status: MedicalOrderStatus
    status: MedicalOrderStatus
    stopped_by: int | None = None
    stopped_at: datetime | None = None
