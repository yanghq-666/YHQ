"""检查报告输入输出模型。"""

from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from app.models.enums import ExaminationStatus, ExaminationType


def _required(value: str) -> str:
    value = value.strip()
    if not value:
        raise ValueError("不能为空")
    return value


class ExaminationCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    examination_type: ExaminationType
    examination_name: str = Field(max_length=255)
    body_part: str | None = Field(default=None, max_length=255)
    clinical_indication: str | None = Field(default=None, max_length=20_000)

    _name = field_validator("examination_name")(_required)


class ExaminationUpdate(BaseModel):
    """预留的非状态字段更新结构；状态只能走专用状态机方法。"""

    model_config = ConfigDict(extra="forbid")
    examination_name: str | None = Field(default=None, max_length=255)
    body_part: str | None = Field(default=None, max_length=255)
    clinical_indication: str | None = Field(default=None, max_length=20_000)


class ExaminationComplete(BaseModel):
    model_config = ConfigDict(extra="forbid")
    findings: str = Field(max_length=20_000)
    conclusion: str = Field(max_length=20_000)

    _texts = field_validator("findings", "conclusion")(_required)


class ExaminationCancel(BaseModel):
    model_config = ConfigDict(extra="forbid")
    reason: str = Field(min_length=1, max_length=500)


class ExaminationFilter(BaseModel):
    examination_type: ExaminationType | None = None
    status: ExaminationStatus | None = None
    start_date: date | None = None
    end_date: date | None = None

    @model_validator(mode="after")
    def validate_dates(self) -> "ExaminationFilter":
        if self.start_date and self.end_date and self.start_date > self.end_date:
            raise ValueError("开始日期不能晚于结束日期")
        return self


class ExaminationRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    examination_no: str
    patient_id: int
    encounter_id: int
    record_id: int
    order_id: int | None
    examination_type: ExaminationType
    examination_name: str
    body_part: str | None
    clinical_indication: str | None
    findings: str | None
    conclusion: str | None
    status: ExaminationStatus
    requested_by: int
    performed_by: int | None
    performed_at: datetime | None
    reported_at: datetime | None
    created_at: datetime
    updated_at: datetime
