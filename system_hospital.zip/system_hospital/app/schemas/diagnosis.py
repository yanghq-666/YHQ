"""诊断输入与输出模型。"""

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.models.enums import DiagnosisType


class DiagnosisCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    diagnosis_catalog_id: int | None = Field(default=None, gt=0)
    diagnosis_name: str = Field(min_length=1, max_length=255)
    diagnosis_code: str | None = Field(default=None, max_length=50)
    diagnosis_type: DiagnosisType = DiagnosisType.PRELIMINARY
    description: str | None = Field(default=None, max_length=5000)
    sort_order: int = Field(default=0, ge=0)
    is_primary: bool = False

    @field_validator("diagnosis_name")
    @classmethod
    def normalize_name(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("诊断名称不能为空")
        return normalized


class DiagnosisUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    diagnosis_catalog_id: int | None = Field(default=None, gt=0)
    diagnosis_name: str | None = Field(default=None, min_length=1, max_length=255)
    diagnosis_code: str | None = Field(default=None, max_length=50)
    diagnosis_type: DiagnosisType | None = None
    description: str | None = Field(default=None, max_length=5000)
    sort_order: int | None = Field(default=None, ge=0)
    is_primary: bool | None = None

    @field_validator("diagnosis_name")
    @classmethod
    def normalize_name(cls, value: str | None) -> str | None:
        if value is None:
            return None
        normalized = value.strip()
        if not normalized:
            raise ValueError("诊断名称不能为空")
        return normalized


class DiagnosisRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    encounter_id: int
    record_id: int
    diagnosis_catalog_id: int | None
    diagnosis_no: str
    diagnosis_name: str
    diagnosis_code: str | None
    diagnosis_type: DiagnosisType
    description: str | None
    sort_order: int
    is_primary: bool
    created_by: int
    created_by_name: str
    created_at: datetime
    updated_at: datetime
