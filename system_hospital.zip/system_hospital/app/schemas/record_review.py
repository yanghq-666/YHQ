"""病历审核请求、时间线和任务列表模型。"""

from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from app.models.enums import MedicalRecordStatus, ReviewAction
from app.schemas.medical_record import (
    MedicalRecordDepartmentBrief,
    MedicalRecordDoctorBrief,
    MedicalRecordPatientBrief,
)


class MedicalRecordResubmitRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    change_reason: str | None = Field(default=None, max_length=500)


class RecordReviewApproveRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    comment: str | None = Field(default=None, max_length=2_000)


class RecordReviewRejectRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    comment: str = Field(min_length=5, max_length=2_000)

    @field_validator("comment")
    @classmethod
    def validate_comment(cls, value: str) -> str:
        value = value.strip()
        if len(value) < 5:
            raise ValueError("退回原因至少需要 5 个字符")
        return value


class ReviewerBrief(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    real_name: str
    employee_no: str | None


class RecordReviewRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    record_id: int
    reviewer_id: int
    action: ReviewAction
    comment: str | None
    from_status: MedicalRecordStatus
    to_status: MedicalRecordStatus
    record_version: int
    review_round: int
    created_at: datetime
    reviewer: ReviewerBrief


class ReviewHistoryRead(RecordReviewRead):
    pass


class RecordReviewStartResponse(BaseModel):
    record_id: int
    status: MedicalRecordStatus
    current_reviewer_id: int
    record_version: int
    review_round: int


class RecordReviewDecisionResponse(BaseModel):
    record_id: int
    status: MedicalRecordStatus
    reviewed_by: int | None
    reviewed_at: datetime | None
    approved_version: int | None


class PendingReviewListItem(BaseModel):
    record_id: int
    record_no: str
    patient: MedicalRecordPatientBrief
    encounter_no: str
    department: MedicalRecordDepartmentBrief
    doctor: MedicalRecordDoctorBrief
    submitted_at: datetime
    status: MedicalRecordStatus
    current_version: int
    current_reviewer_id: int | None


class PendingReviewSearchParams(BaseModel):
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=20, ge=1, le=100)
    status: MedicalRecordStatus = MedicalRecordStatus.SUBMITTED
    patient_name: str | None = Field(default=None, max_length=100)
    record_no: str | None = Field(default=None, max_length=24)
    department_name: str | None = Field(default=None, max_length=100)
    doctor_name: str | None = Field(default=None, max_length=100)
    start_date: date | None = None
    end_date: date | None = None

    @field_validator("status")
    @classmethod
    def validate_status(cls, value: MedicalRecordStatus) -> MedicalRecordStatus:
        if value not in {MedicalRecordStatus.SUBMITTED, MedicalRecordStatus.REVIEWING}:
            raise ValueError("待审核列表只支持 SUBMITTED 或 REVIEWING")
        return value

    @model_validator(mode="after")
    def validate_dates(self) -> "PendingReviewSearchParams":
        if self.start_date and self.end_date and self.start_date > self.end_date:
            raise ValueError("开始日期不能晚于结束日期")
        return self


class MyReviewSearchParams(BaseModel):
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=20, ge=1, le=100)
    status: MedicalRecordStatus | None = None
    action: ReviewAction | None = None
    start_date: date | None = None
    end_date: date | None = None

    @model_validator(mode="after")
    def validate_dates(self) -> "MyReviewSearchParams":
        if self.start_date and self.end_date and self.start_date > self.end_date:
            raise ValueError("开始日期不能晚于结束日期")
        return self


class ReviewTaskListItem(RecordReviewRead):
    record_no: str
    status: MedicalRecordStatus
