"""管理员用户接口的数据模型。"""

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.models.enums import UserStatus
from app.schemas.department import DepartmentBrief


class UserCreate(BaseModel):
    username: str = Field(min_length=1, max_length=50)
    password: str = Field(min_length=8, max_length=72)
    real_name: str = Field(min_length=1, max_length=100)
    employee_no: str | None = Field(default=None, max_length=50)
    email: str | None = Field(default=None, max_length=255)
    phone: str | None = Field(default=None, max_length=30)
    department_id: int | None = None
    role_ids: list[int] = Field(default_factory=list)
    is_active: bool = True
    is_superuser: bool = False

    @field_validator("username", "real_name")
    @classmethod
    def validate_required_text(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("不能为空")
        return value

    @field_validator("password")
    @classmethod
    def validate_bcrypt_password_length(cls, value: str) -> str:
        if len(value.encode("utf-8")) > 72:
            raise ValueError("密码不能超过 72 个字节")
        return value


class UserUpdate(BaseModel):
    password: str | None = Field(default=None, min_length=8, max_length=72)
    real_name: str | None = Field(default=None, min_length=1, max_length=100)
    employee_no: str | None = Field(default=None, max_length=50)
    email: str | None = Field(default=None, max_length=255)
    phone: str | None = Field(default=None, max_length=30)
    department_id: int | None = None
    is_active: bool | None = None
    is_superuser: bool | None = None

    @field_validator("real_name")
    @classmethod
    def validate_real_name(cls, value: str | None) -> str | None:
        if value is not None and not value.strip():
            raise ValueError("真实姓名不能为空")
        return value

    @field_validator("password")
    @classmethod
    def validate_password(cls, value: str | None) -> str | None:
        if value is not None and len(value.encode("utf-8")) > 72:
            raise ValueError("密码不能超过 72 个字节")
        return value


class UserRoleAssign(BaseModel):
    role_ids: list[int]


class UserPasswordReset(BaseModel):
    password: str = Field(min_length=8, max_length=72)

    @field_validator("password")
    @classmethod
    def validate_password(cls, value: str) -> str:
        if len(value.encode("utf-8")) > 72:
            raise ValueError("密码不能超过 72 个字节")
        return value


class UserResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    username: str
    real_name: str
    employee_no: str | None
    email: str | None
    phone: str | None
    department_id: int | None
    department: DepartmentBrief | None
    status: UserStatus
    is_active: bool
    is_superuser: bool
    last_login_at: datetime | None
    created_at: datetime
    updated_at: datetime
    roles: list[str]
    permissions: list[str]
