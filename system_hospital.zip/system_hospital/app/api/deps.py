"""API 认证与数据库依赖。"""

from typing import Annotated

from fastapi import Depends
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.config import get_settings
from app.core.exceptions import AuthenticationError, PermissionDeniedError
from app.core.security import decode_access_token
from app.models.enums import UserStatus
from app.models.user import User
from app.repositories.user_repository import UserRepository
from app.services.storage_service import StorageService, build_storage_service

bearer_scheme = HTTPBearer(auto_error=False)
DatabaseSession = Annotated[Session, Depends(get_db)]


def get_storage_service() -> StorageService:
    return build_storage_service(get_settings())


Storage = Annotated[StorageService, Depends(get_storage_service)]


def get_current_user(
    credentials: Annotated[
        HTTPAuthorizationCredentials | None, Depends(bearer_scheme)
    ],
    db: DatabaseSession,
) -> User:
    if credentials is None or credentials.scheme.lower() != "bearer":
        raise AuthenticationError("请先登录")

    return resolve_current_user(credentials.credentials, db)


def resolve_current_user(token: str, db: Session) -> User:
    """统一解析 JWT 并加载用户，供 API Bearer 与 Web Cookie 共同复用。"""

    payload = decode_access_token(token)
    try:
        user_id = int(payload["sub"])
    except (KeyError, TypeError, ValueError) as exc:
        raise AuthenticationError("登录凭证无效") from exc

    user = UserRepository(db).get_by_id(user_id)
    if user is None:
        raise AuthenticationError("用户不存在或登录凭证无效")
    if user.status != UserStatus.ACTIVE or not user.is_active:
        raise PermissionDeniedError("账号已被禁用")
    return user


CurrentUser = Annotated[User, Depends(get_current_user)]
