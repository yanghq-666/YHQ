"""检查报告 REST API。"""

from typing import Annotated

from fastapi import APIRouter, Depends, Request, status

from app.api.deps import DatabaseSession
from app.core.permissions import require_permission
from app.models.user import User
from app.schemas.common import ApiResponse
from app.schemas.examination import ExaminationCancel, ExaminationComplete, ExaminationCreate, ExaminationFilter, ExaminationRead
from app.services.audit_service import AuditContext
from app.services.examination_service import ExaminationService

router = APIRouter(tags=["Examinations"])
Viewer = Annotated[User, Depends(require_permission("examination:view"))]
Creator = Annotated[User, Depends(require_permission("examination:create"))]
Editor = Annotated[User, Depends(require_permission("examination:update"))]
Completer = Annotated[User, Depends(require_permission("examination:complete"))]


def _context(request: Request) -> AuditContext:
    return AuditContext(request.method, request.url.path, request.client.host if request.client else None)


@router.post("/api/medical-records/{record_id}/examinations", response_model=ApiResponse[ExaminationRead], status_code=status.HTTP_201_CREATED)
def create_examination(record_id: int, payload: ExaminationCreate, request: Request, current_user: Creator, db: DatabaseSession):
    return ApiResponse(code=201, message="检查创建成功", data=ExaminationService(db).create_examination(record_id, payload, operator=current_user, audit_context=_context(request)))


@router.get("/api/medical-records/{record_id}/examinations", response_model=ApiResponse[list[ExaminationRead]])
def list_examinations(record_id: int, current_user: Viewer, db: DatabaseSession, params: Annotated[ExaminationFilter, Depends()]):
    return ApiResponse(data=ExaminationService(db).list_examinations(record_id, params, operator=current_user))


@router.get("/api/examinations/{examination_id}", response_model=ApiResponse[ExaminationRead])
def get_examination(examination_id: int, current_user: Viewer, db: DatabaseSession):
    return ApiResponse(data=ExaminationService(db).get_examination(examination_id, operator=current_user))


@router.post("/api/examinations/{examination_id}/start", response_model=ApiResponse[ExaminationRead])
def start_examination(examination_id: int, request: Request, current_user: Editor, db: DatabaseSession):
    return ApiResponse(message="检查已开始", data=ExaminationService(db).start_examination(examination_id, operator=current_user, audit_context=_context(request)))


@router.post("/api/examinations/{examination_id}/complete", response_model=ApiResponse[ExaminationRead])
def complete_examination(examination_id: int, payload: ExaminationComplete, request: Request, current_user: Completer, db: DatabaseSession):
    return ApiResponse(message="检查已完成", data=ExaminationService(db).complete_examination(examination_id, payload, operator=current_user, audit_context=_context(request)))


@router.post("/api/examinations/{examination_id}/cancel", response_model=ApiResponse[ExaminationRead])
def cancel_examination(examination_id: int, payload: ExaminationCancel, request: Request, current_user: Editor, db: DatabaseSession):
    return ApiResponse(message="检查已取消", data=ExaminationService(db).cancel_examination(examination_id, payload, operator=current_user, audit_context=_context(request)))
