"""患者管理 REST API。"""

from typing import Annotated

from fastapi import APIRouter, Depends, Request, status

from app.api.deps import DatabaseSession
from app.core.permissions import require_permission
from app.models.user import User
from app.schemas.common import ApiResponse, PageData
from app.schemas.patient import (
    PatientCreate,
    PatientDetail,
    PatientListItem,
    PatientSearchParams,
    PatientUpdate,
)
from app.services.audit_service import AuditContext
from app.services.patient_service import PatientService

router = APIRouter(prefix="/api/patients", tags=["Patients"])

PatientViewer = Annotated[User, Depends(require_permission("patient:view"))]
PatientCreator = Annotated[User, Depends(require_permission("patient:create"))]
PatientEditor = Annotated[User, Depends(require_permission("patient:update"))]
PatientRestorer = Annotated[User, Depends(require_permission("admin:user"))]


def _audit_context(request: Request) -> AuditContext:
    return AuditContext(
        request_method=request.method,
        request_path=request.url.path,
        ip_address=request.client.host if request.client else None,
    )


@router.post(
    "",
    response_model=ApiResponse[PatientDetail],
    status_code=status.HTTP_201_CREATED,
    summary="创建患者档案",
    description="需要 patient:create 权限；患者编号由系统自动生成。",
)
def create_patient(
    payload: PatientCreate,
    request: Request,
    current_user: PatientCreator,
    db: DatabaseSession,
) -> ApiResponse[PatientDetail]:
    patient = PatientService(db).create_patient(
        payload,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(
        code=status.HTTP_201_CREATED,
        message="患者建档成功",
        data=patient,
    )


@router.get(
    "",
    response_model=ApiResponse[PageData[PatientListItem]],
    summary="分页查询患者",
    description=(
        "需要 patient:view 权限；支持 keyword、编号、姓名、电话、身份证、"
        "性别和血型筛选。非管理员的身份证及电话会脱敏。"
    ),
)
def list_patients(
    current_user: PatientViewer,
    db: DatabaseSession,
    params: Annotated[PatientSearchParams, Depends()],
) -> ApiResponse[PageData[PatientListItem]]:
    return ApiResponse(
        data=PatientService(db).list_patients(params, operator=current_user)
    )


@router.get(
    "/{patient_id}",
    response_model=ApiResponse[PatientDetail],
    summary="获取患者详情",
    description="需要 patient:view 权限；不存在或已软删除时返回 404。",
)
def get_patient(
    patient_id: int,
    current_user: PatientViewer,
    db: DatabaseSession,
) -> ApiResponse[PatientDetail]:
    return ApiResponse(
        data=PatientService(db).get_patient_detail(
            patient_id, operator=current_user
        )
    )


@router.put(
    "/{patient_id}",
    response_model=ApiResponse[PatientDetail],
    summary="修改患者档案",
    description=(
        "需要 patient:update 权限；patient_no、id 和创建时间不可修改。"
    ),
)
def update_patient(
    patient_id: int,
    payload: PatientUpdate,
    request: Request,
    current_user: PatientEditor,
    db: DatabaseSession,
) -> ApiResponse[PatientDetail]:
    patient = PatientService(db).update_patient(
        patient_id,
        payload,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(message="患者信息更新成功", data=patient)


@router.delete(
    "/{patient_id}",
    response_model=ApiResponse[None],
    summary="软删除患者档案",
    description="需要 patient:update 权限；只写入 deleted_at，不物理删除。",
)
def delete_patient(
    patient_id: int,
    request: Request,
    current_user: PatientEditor,
    db: DatabaseSession,
) -> ApiResponse[None]:
    PatientService(db).delete_patient(
        patient_id,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(message="患者已删除", data=None)


@router.post(
    "/{patient_id}/restore",
    response_model=ApiResponse[PatientDetail],
    summary="恢复患者档案",
    description="仅拥有 admin:user 权限的管理员可以恢复软删除患者。",
)
def restore_patient(
    patient_id: int,
    request: Request,
    current_user: PatientRestorer,
    db: DatabaseSession,
) -> ApiResponse[PatientDetail]:
    patient = PatientService(db).restore_patient(
        patient_id,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(message="患者已恢复", data=patient)

