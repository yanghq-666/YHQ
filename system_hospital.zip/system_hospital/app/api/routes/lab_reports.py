"""检验报告与结果 REST API。"""

from typing import Annotated

from fastapi import APIRouter, Depends, Request, status

from app.api.deps import DatabaseSession
from app.core.permissions import require_permission
from app.models.user import User
from app.schemas.common import ApiResponse
from app.schemas.lab_report import LabReportCancel, LabReportComplete, LabReportCreate, LabReportDetail, LabReportFilter, LabResultRead, LabResultsBatchCreate, LabResultUpdate
from app.services.audit_service import AuditContext
from app.services.lab_report_service import LabReportService

router = APIRouter(tags=["Lab Reports"])
LabViewer = Annotated[User, Depends(require_permission("lab:view"))]
LabCreator = Annotated[User, Depends(require_permission("lab:create"))]
LabEditor = Annotated[User, Depends(require_permission("lab:update"))]
LabCompleter = Annotated[User, Depends(require_permission("lab:complete"))]


def _context(request: Request) -> AuditContext:
    return AuditContext(request.method, request.url.path, request.client.host if request.client else None)


@router.post("/api/medical-records/{record_id}/lab-reports", response_model=ApiResponse[LabReportDetail], status_code=status.HTTP_201_CREATED)
def create_lab_report(record_id: int, payload: LabReportCreate, request: Request, current_user: LabCreator, db: DatabaseSession):
    return ApiResponse(code=201, message="检验报告创建成功", data=LabReportService(db).create_report(record_id, payload, operator=current_user, audit_context=_context(request)))


@router.get("/api/medical-records/{record_id}/lab-reports", response_model=ApiResponse[list[LabReportDetail]])
def list_lab_reports(record_id: int, current_user: LabViewer, db: DatabaseSession, params: Annotated[LabReportFilter, Depends()]):
    return ApiResponse(data=LabReportService(db).list_reports(record_id, params, operator=current_user))


@router.get("/api/lab-reports/{report_id}", response_model=ApiResponse[LabReportDetail])
def get_lab_report(report_id: int, current_user: LabViewer, db: DatabaseSession):
    return ApiResponse(data=LabReportService(db).get_report(report_id, operator=current_user))


@router.post("/api/lab-reports/{report_id}/start", response_model=ApiResponse[LabReportDetail])
def start_lab_report(report_id: int, request: Request, current_user: LabEditor, db: DatabaseSession):
    return ApiResponse(message="检验报告已开始处理", data=LabReportService(db).start_report(report_id, operator=current_user, audit_context=_context(request)))


@router.post("/api/lab-reports/{report_id}/results", response_model=ApiResponse[list[LabResultRead]], status_code=status.HTTP_201_CREATED)
def add_lab_results(report_id: int, payload: LabResultsBatchCreate, request: Request, current_user: LabEditor, db: DatabaseSession):
    return ApiResponse(code=201, message="检验结果添加成功", data=LabReportService(db).add_results(report_id, payload, operator=current_user, audit_context=_context(request)))


@router.patch("/api/lab-results/{result_id}", response_model=ApiResponse[LabResultRead])
def update_lab_result(result_id: int, payload: LabResultUpdate, request: Request, current_user: LabEditor, db: DatabaseSession):
    return ApiResponse(message="检验结果更新成功", data=LabReportService(db).update_result(result_id, payload, operator=current_user, audit_context=_context(request)))


@router.post("/api/lab-reports/{report_id}/complete", response_model=ApiResponse[LabReportDetail])
def complete_lab_report(report_id: int, payload: LabReportComplete, request: Request, current_user: LabCompleter, db: DatabaseSession):
    return ApiResponse(message="检验报告已完成", data=LabReportService(db).complete_report(report_id, payload, operator=current_user, audit_context=_context(request)))


@router.post("/api/lab-reports/{report_id}/cancel", response_model=ApiResponse[LabReportDetail])
def cancel_lab_report(report_id: int, payload: LabReportCancel, request: Request, current_user: LabEditor, db: DatabaseSession):
    return ApiResponse(message="检验报告已取消", data=LabReportService(db).cancel_report(report_id, payload, operator=current_user, audit_context=_context(request)))
