"""医嘱 REST API。"""

from typing import Annotated

from fastapi import APIRouter, Depends, Request, status

from app.api.deps import DatabaseSession
from app.core.permissions import require_permission
from app.models.user import User
from app.schemas.common import ApiResponse
from app.schemas.medical_order import (
    MedicalOrderCreate,
    MedicalOrderFilter,
    MedicalOrderRead,
    MedicalOrderStatusResponse,
    MedicalOrderUpdate,
)
from app.services.audit_service import AuditContext
from app.services.medical_order_service import MedicalOrderService

router = APIRouter(tags=["Medical Orders"])
OrderCreator = Annotated[User, Depends(require_permission("order:create"))]
OrderEditor = Annotated[User, Depends(require_permission("order:update"))]
RecordViewer = Annotated[User, Depends(require_permission("record:view"))]


def _audit_context(request: Request) -> AuditContext:
    return AuditContext(
        request_method=request.method,
        request_path=request.url.path,
        ip_address=request.client.host if request.client else None,
    )


@router.post(
    "/api/medical-records/{record_id}/orders",
    response_model=ApiResponse[MedicalOrderRead],
    status_code=status.HTTP_201_CREATED,
    summary="新增医嘱",
)
def create_order(
    record_id: int,
    payload: MedicalOrderCreate,
    request: Request,
    current_user: OrderCreator,
    db: DatabaseSession,
) -> ApiResponse[MedicalOrderRead]:
    result = MedicalOrderService(db).create_order(
        record_id,
        payload,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(code=201, message="医嘱创建成功", data=result)


@router.get(
    "/api/medical-records/{record_id}/orders",
    response_model=ApiResponse[list[MedicalOrderRead]],
    summary="查询病历医嘱",
)
def list_orders(
    record_id: int,
    current_user: RecordViewer,
    db: DatabaseSession,
    filters: Annotated[MedicalOrderFilter, Depends()],
) -> ApiResponse[list[MedicalOrderRead]]:
    return ApiResponse(
        data=MedicalOrderService(db).list_orders(
            record_id, filters, operator=current_user
        )
    )


@router.patch(
    "/api/orders/{order_id}",
    response_model=ApiResponse[MedicalOrderRead],
    summary="修改生效中医嘱",
)
def update_order(
    order_id: int,
    payload: MedicalOrderUpdate,
    request: Request,
    current_user: OrderEditor,
    db: DatabaseSession,
) -> ApiResponse[MedicalOrderRead]:
    result = MedicalOrderService(db).update_order(
        order_id,
        payload,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(message="医嘱更新成功", data=result)


@router.post(
    "/api/orders/{order_id}/stop",
    response_model=ApiResponse[MedicalOrderStatusResponse],
    summary="停止医嘱",
)
def stop_order(
    order_id: int,
    request: Request,
    current_user: OrderEditor,
    db: DatabaseSession,
) -> ApiResponse[MedicalOrderStatusResponse]:
    result = MedicalOrderService(db).stop_order(
        order_id,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(message="医嘱已停止", data=result)


@router.post(
    "/api/orders/{order_id}/complete",
    response_model=ApiResponse[MedicalOrderStatusResponse],
    summary="完成医嘱",
)
def complete_order(
    order_id: int,
    request: Request,
    current_user: OrderEditor,
    db: DatabaseSession,
) -> ApiResponse[MedicalOrderStatusResponse]:
    result = MedicalOrderService(db).complete_order(
        order_id,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(message="医嘱已完成", data=result)


@router.delete(
    "/api/orders/{order_id}",
    response_model=ApiResponse[None],
    summary="软删除生效中医嘱",
)
def delete_order(
    order_id: int,
    request: Request,
    current_user: OrderEditor,
    db: DatabaseSession,
) -> ApiResponse[None]:
    MedicalOrderService(db).delete_order(
        order_id,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(message="医嘱已删除", data=None)
