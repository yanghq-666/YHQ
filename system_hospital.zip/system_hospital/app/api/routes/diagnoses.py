"""诊断 REST API。"""

from typing import Annotated

from fastapi import APIRouter, Depends, Request, status

from app.api.deps import DatabaseSession
from app.core.permissions import require_permission
from app.models.user import User
from app.schemas.common import ApiResponse
from app.schemas.diagnosis import DiagnosisCreate, DiagnosisRead, DiagnosisUpdate
from app.services.audit_service import AuditContext
from app.services.diagnosis_service import DiagnosisService

router = APIRouter(tags=["Diagnoses"])
DiagnosisCreator = Annotated[
    User, Depends(require_permission("diagnosis:create"))
]
DiagnosisEditor = Annotated[
    User, Depends(require_permission("diagnosis:update"))
]
RecordViewer = Annotated[User, Depends(require_permission("record:view"))]


def _audit_context(request: Request) -> AuditContext:
    return AuditContext(
        request_method=request.method,
        request_path=request.url.path,
        ip_address=request.client.host if request.client else None,
    )


@router.post(
    "/api/medical-records/{record_id}/diagnoses",
    response_model=ApiResponse[DiagnosisRead],
    status_code=status.HTTP_201_CREATED,
    summary="新增诊断",
)
def create_diagnosis(
    record_id: int,
    payload: DiagnosisCreate,
    request: Request,
    current_user: DiagnosisCreator,
    db: DatabaseSession,
) -> ApiResponse[DiagnosisRead]:
    result = DiagnosisService(db).create_diagnosis(
        record_id,
        payload,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(code=201, message="诊断创建成功", data=result)


@router.get(
    "/api/medical-records/{record_id}/diagnoses",
    response_model=ApiResponse[list[DiagnosisRead]],
    summary="查询病历诊断",
)
def list_diagnoses(
    record_id: int,
    current_user: RecordViewer,
    db: DatabaseSession,
) -> ApiResponse[list[DiagnosisRead]]:
    return ApiResponse(
        data=DiagnosisService(db).list_diagnoses(
            record_id, operator=current_user
        )
    )


@router.patch(
    "/api/diagnoses/{diagnosis_id}",
    response_model=ApiResponse[DiagnosisRead],
    summary="修改诊断",
)
def update_diagnosis(
    diagnosis_id: int,
    payload: DiagnosisUpdate,
    request: Request,
    current_user: DiagnosisEditor,
    db: DatabaseSession,
) -> ApiResponse[DiagnosisRead]:
    result = DiagnosisService(db).update_diagnosis(
        diagnosis_id,
        payload,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(message="诊断更新成功", data=result)


@router.delete(
    "/api/diagnoses/{diagnosis_id}",
    response_model=ApiResponse[None],
    summary="软删除诊断",
)
def delete_diagnosis(
    diagnosis_id: int,
    request: Request,
    current_user: DiagnosisEditor,
    db: DatabaseSession,
) -> ApiResponse[None]:
    DiagnosisService(db).delete_diagnosis(
        diagnosis_id,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(message="诊断已删除", data=None)
