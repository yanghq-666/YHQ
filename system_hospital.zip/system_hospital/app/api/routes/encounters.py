"""就诊管理 REST API。"""

from typing import Annotated

from fastapi import APIRouter, Depends, Request, status

from app.api.deps import DatabaseSession
from app.core.permissions import require_permission
from app.models.user import User
from app.schemas.common import ApiResponse, PageData
from app.schemas.encounter import (
    EncounterCreate,
    EncounterDetail,
    EncounterListItem,
    EncounterSearchParams,
    EncounterStatusResponse,
    EncounterUpdate,
)
from app.services.audit_service import AuditContext
from app.services.encounter_service import EncounterService

router = APIRouter(prefix="/api/encounters", tags=["Encounters"])
patient_history_router = APIRouter(prefix="/api/patients", tags=["Encounters"])

EncounterViewer = Annotated[
    User, Depends(require_permission("encounter:view"))
]
EncounterCreator = Annotated[
    User, Depends(require_permission("encounter:create"))
]
EncounterEditor = Annotated[
    User, Depends(require_permission("encounter:update"))
]


def _audit_context(request: Request) -> AuditContext:
    return AuditContext(
        request_method=request.method,
        request_path=request.url.path,
        ip_address=request.client.host if request.client else None,
    )


@router.post(
    "",
    response_model=ApiResponse[EncounterDetail],
    status_code=status.HTTP_201_CREATED,
    summary="创建就诊",
    description=(
        "需要 encounter:create；校验患者、医生角色、科室后自动生成就诊编号。"
    ),
)
def create_encounter(
    payload: EncounterCreate,
    request: Request,
    current_user: EncounterCreator,
    db: DatabaseSession,
) -> ApiResponse[EncounterDetail]:
    encounter = EncounterService(db).create_encounter(
        payload,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(
        code=status.HTTP_201_CREATED,
        message="就诊创建成功",
        data=encounter,
    )


@router.get(
    "",
    response_model=ApiResponse[PageData[EncounterListItem]],
    summary="分页查询就诊",
    description="需要 encounter:view；查询结果由 EncounterAccessPolicy 限定数据范围。",
)
def list_encounters(
    current_user: EncounterViewer,
    db: DatabaseSession,
    params: Annotated[EncounterSearchParams, Depends()],
) -> ApiResponse[PageData[EncounterListItem]]:
    return ApiResponse(
        data=EncounterService(db).list_encounters(params, operator=current_user)
    )


@patient_history_router.get(
    "/{patient_id}/encounters",
    response_model=ApiResponse[list[EncounterListItem]],
    summary="查询患者就诊历史",
    description="需要 encounter:view；返回未删除就诊并按 visit_time 倒序。",
)
def list_patient_encounters(
    patient_id: int,
    current_user: EncounterViewer,
    db: DatabaseSession,
) -> ApiResponse[list[EncounterListItem]]:
    return ApiResponse(
        data=EncounterService(db).list_by_patient(
            patient_id, operator=current_user
        )
    )


@router.get(
    "/{encounter_id}",
    response_model=ApiResponse[EncounterDetail],
    summary="获取就诊详情",
    description="需要 encounter:view；返回患者、医生和科室简要信息。",
)
def get_encounter(
    encounter_id: int,
    current_user: EncounterViewer,
    db: DatabaseSession,
) -> ApiResponse[EncounterDetail]:
    return ApiResponse(
        data=EncounterService(db).get_encounter_detail(
            encounter_id, operator=current_user
        )
    )


@router.patch(
    "/{encounter_id}",
    response_model=ApiResponse[EncounterDetail],
    summary="修改就诊",
    description="需要 encounter:update；编号、患者、创建人和状态不可直接修改。",
)
def update_encounter(
    encounter_id: int,
    payload: EncounterUpdate,
    request: Request,
    current_user: EncounterEditor,
    db: DatabaseSession,
) -> ApiResponse[EncounterDetail]:
    encounter = EncounterService(db).update_encounter(
        encounter_id,
        payload,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(message="就诊更新成功", data=encounter)


@router.post(
    "/{encounter_id}/start",
    response_model=ApiResponse[EncounterStatusResponse],
    summary="开始就诊",
    description="需要 encounter:update；仅允许 REGISTERED → IN_PROGRESS。",
)
def start_encounter(
    encounter_id: int,
    request: Request,
    current_user: EncounterEditor,
    db: DatabaseSession,
) -> ApiResponse[EncounterStatusResponse]:
    result = EncounterService(db).start_encounter(
        encounter_id,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(message="就诊已开始", data=result)


@router.post(
    "/{encounter_id}/complete",
    response_model=ApiResponse[EncounterStatusResponse],
    summary="完成就诊",
    description="需要 encounter:update；仅允许 IN_PROGRESS → COMPLETED。",
)
def complete_encounter(
    encounter_id: int,
    request: Request,
    current_user: EncounterEditor,
    db: DatabaseSession,
) -> ApiResponse[EncounterStatusResponse]:
    result = EncounterService(db).complete_encounter(
        encounter_id,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(message="就诊已完成", data=result)


@router.post(
    "/{encounter_id}/cancel",
    response_model=ApiResponse[EncounterStatusResponse],
    summary="取消就诊",
    description="需要 encounter:update；仅允许 REGISTERED → CANCELLED。",
)
def cancel_encounter(
    encounter_id: int,
    request: Request,
    current_user: EncounterEditor,
    db: DatabaseSession,
) -> ApiResponse[EncounterStatusResponse]:
    result = EncounterService(db).cancel_encounter(
        encounter_id,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(message="就诊已取消", data=result)


@router.delete(
    "/{encounter_id}",
    response_model=ApiResponse[None],
    summary="软删除就诊",
    description="需要 encounter:update；已完成或已有病历的就诊禁止删除。",
)
def delete_encounter(
    encounter_id: int,
    request: Request,
    current_user: EncounterEditor,
    db: DatabaseSession,
) -> ApiResponse[None]:
    EncounterService(db).delete_encounter(
        encounter_id,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(message="就诊已删除", data=None)

