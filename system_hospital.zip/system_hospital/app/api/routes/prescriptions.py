"""处方、处方项目、签发与取消 REST API。"""

from typing import Annotated

from fastapi import APIRouter, Depends, Request, status

from app.api.deps import DatabaseSession
from app.core.permissions import require_permission
from app.models.user import User
from app.schemas.common import ApiResponse
from app.schemas.prescription import (
    PrescriptionCancelRequest,
    PrescriptionCreate,
    PrescriptionDetail,
    PrescriptionItemCreate,
    PrescriptionItemRead,
    PrescriptionItemUpdate,
    PrescriptionListItem,
    PrescriptionStatusResponse,
    PrescriptionUpdate,
)
from app.services.audit_service import AuditContext
from app.services.prescription_service import PrescriptionService

router = APIRouter(tags=["Prescriptions"])
PrescriptionCreator = Annotated[
    User, Depends(require_permission("prescription:create"))
]
PrescriptionEditor = Annotated[
    User, Depends(require_permission("prescription:update"))
]
RecordViewer = Annotated[User, Depends(require_permission("record:view"))]


def _audit_context(request: Request) -> AuditContext:
    return AuditContext(
        request_method=request.method,
        request_path=request.url.path,
        ip_address=request.client.host if request.client else None,
    )


@router.post(
    "/api/medical-records/{record_id}/prescriptions",
    response_model=ApiResponse[PrescriptionDetail],
    status_code=status.HTTP_201_CREATED,
    summary="创建处方及项目",
)
def create_prescription(
    record_id: int,
    payload: PrescriptionCreate,
    request: Request,
    current_user: PrescriptionCreator,
    db: DatabaseSession,
) -> ApiResponse[PrescriptionDetail]:
    result = PrescriptionService(db).create_prescription(
        record_id,
        payload,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(code=201, message="处方创建成功", data=result)


@router.get(
    "/api/medical-records/{record_id}/prescriptions",
    response_model=ApiResponse[list[PrescriptionListItem]],
    summary="查询病历处方",
)
def list_prescriptions(
    record_id: int,
    current_user: RecordViewer,
    db: DatabaseSession,
) -> ApiResponse[list[PrescriptionListItem]]:
    return ApiResponse(
        data=PrescriptionService(db).list_prescriptions(
            record_id, operator=current_user
        )
    )


@router.get(
    "/api/prescriptions/{prescription_id}",
    response_model=ApiResponse[PrescriptionDetail],
    summary="获取处方及有效项目详情",
)
def get_prescription(
    prescription_id: int,
    current_user: RecordViewer,
    db: DatabaseSession,
) -> ApiResponse[PrescriptionDetail]:
    return ApiResponse(
        data=PrescriptionService(db).get_prescription_detail(
            prescription_id, operator=current_user
        )
    )


@router.patch(
    "/api/prescriptions/{prescription_id}",
    response_model=ApiResponse[PrescriptionDetail],
    summary="修改草稿处方",
)
def update_prescription(
    prescription_id: int,
    payload: PrescriptionUpdate,
    request: Request,
    current_user: PrescriptionEditor,
    db: DatabaseSession,
) -> ApiResponse[PrescriptionDetail]:
    result = PrescriptionService(db).update_prescription(
        prescription_id,
        payload,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(message="处方更新成功", data=result)


@router.post(
    "/api/prescriptions/{prescription_id}/items",
    response_model=ApiResponse[PrescriptionItemRead],
    status_code=status.HTTP_201_CREATED,
    summary="添加处方项目",
)
def add_prescription_item(
    prescription_id: int,
    payload: PrescriptionItemCreate,
    request: Request,
    current_user: PrescriptionEditor,
    db: DatabaseSession,
) -> ApiResponse[PrescriptionItemRead]:
    result = PrescriptionService(db).add_item(
        prescription_id,
        payload,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(code=201, message="处方项目创建成功", data=result)


@router.patch(
    "/api/prescription-items/{item_id}",
    response_model=ApiResponse[PrescriptionItemRead],
    summary="修改处方项目",
)
def update_prescription_item(
    item_id: int,
    payload: PrescriptionItemUpdate,
    request: Request,
    current_user: PrescriptionEditor,
    db: DatabaseSession,
) -> ApiResponse[PrescriptionItemRead]:
    result = PrescriptionService(db).update_item(
        item_id,
        payload,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(message="处方项目更新成功", data=result)


@router.delete(
    "/api/prescription-items/{item_id}",
    response_model=ApiResponse[None],
    summary="软删除处方项目",
)
def delete_prescription_item(
    item_id: int,
    request: Request,
    current_user: PrescriptionEditor,
    db: DatabaseSession,
) -> ApiResponse[None]:
    PrescriptionService(db).remove_item(
        item_id,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(message="处方项目已删除", data=None)


@router.post(
    "/api/prescriptions/{prescription_id}/issue",
    response_model=ApiResponse[PrescriptionStatusResponse],
    summary="签发处方",
)
def issue_prescription(
    prescription_id: int,
    request: Request,
    current_user: PrescriptionEditor,
    db: DatabaseSession,
) -> ApiResponse[PrescriptionStatusResponse]:
    result = PrescriptionService(db).issue_prescription(
        prescription_id,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(message="处方签发成功", data=result)


@router.post(
    "/api/prescriptions/{prescription_id}/cancel",
    response_model=ApiResponse[PrescriptionStatusResponse],
    summary="取消处方",
)
def cancel_prescription(
    prescription_id: int,
    payload: PrescriptionCancelRequest,
    request: Request,
    current_user: PrescriptionEditor,
    db: DatabaseSession,
) -> ApiResponse[PrescriptionStatusResponse]:
    result = PrescriptionService(db).cancel_prescription(
        prescription_id,
        payload,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(message="处方已取消", data=result)
