"""主病历、提交和版本历史 REST API。"""

from typing import Annotated

from fastapi import APIRouter, Depends, Request, status

from app.api.deps import DatabaseSession
from app.core.permissions import require_permission
from app.models.enums import MedicalRecordStatus
from app.models.user import User
from app.schemas.common import ApiResponse, PageData
from app.schemas.medical_record import (
    MedicalRecordCreate,
    MedicalRecordArchiveResponse,
    MedicalRecordCompleteResponse,
    MedicalRecordDetail,
    MedicalRecordListItem,
    MedicalRecordSearchParams,
    MedicalRecordUpdate,
    MedicalRecordVersionRead,
    MyMedicalRecordSearchParams,
)
from app.schemas.medical_record_full import MedicalRecordFull
from app.services.audit_service import AuditContext
from app.services.medical_record_service import MedicalRecordService

router = APIRouter(prefix="/api/medical-records", tags=["Medical Records"])
encounter_record_router = APIRouter(
    prefix="/api/encounters", tags=["Medical Records"]
)

RecordViewer = Annotated[User, Depends(require_permission("record:view"))]
RecordCreator = Annotated[User, Depends(require_permission("record:create"))]
RecordEditor = Annotated[User, Depends(require_permission("record:update"))]
RecordSubmitter = Annotated[User, Depends(require_permission("record:submit"))]
RecordArchiver = Annotated[User, Depends(require_permission("record:archive"))]


def _audit_context(request: Request) -> AuditContext:
    return AuditContext(
        request_method=request.method,
        request_path=request.url.path,
        ip_address=request.client.host if request.client else None,
    )


@encounter_record_router.post(
    "/{encounter_id}/medical-record",
    response_model=ApiResponse[MedicalRecordDetail],
    status_code=status.HTTP_201_CREATED,
    summary="为就诊创建主病历",
    description="需要 record:create；一个就诊只能创建一份主病历。",
)
def create_medical_record(
    encounter_id: int,
    payload: MedicalRecordCreate,
    request: Request,
    current_user: RecordCreator,
    db: DatabaseSession,
) -> ApiResponse[MedicalRecordDetail]:
    result = MedicalRecordService(db).create_record(
        encounter_id,
        payload,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(
        code=status.HTTP_201_CREATED,
        message="病历草稿创建成功",
        data=result,
    )


@encounter_record_router.get(
    "/{encounter_id}/medical-record",
    response_model=ApiResponse[MedicalRecordDetail],
    summary="通过就诊获取主病历",
    description="需要 record:view；无主病历时返回 404。",
)
def get_encounter_medical_record(
    encounter_id: int,
    current_user: RecordViewer,
    db: DatabaseSession,
) -> ApiResponse[MedicalRecordDetail]:
    return ApiResponse(
        data=MedicalRecordService(db).get_by_encounter(
            encounter_id, operator=current_user
        )
    )


@router.get(
    "",
    response_model=ApiResponse[PageData[MedicalRecordListItem]],
    summary="分页查询病历",
    description="需要 record:view；结果同时受角色和就诊数据范围限制。",
)
def list_medical_records(
    current_user: RecordViewer,
    db: DatabaseSession,
    params: Annotated[MedicalRecordSearchParams, Depends()],
) -> ApiResponse[PageData[MedicalRecordListItem]]:
    return ApiResponse(
        data=MedicalRecordService(db).list_records(
            params, operator=current_user
        )
    )


@router.get(
    "/my",
    response_model=ApiResponse[PageData[MedicalRecordListItem]],
    summary="查询我的病历",
    description="返回当前用户创建或当前用户负责就诊的病历。",
)
def list_my_medical_records(
    current_user: RecordViewer,
    db: DatabaseSession,
    params: Annotated[MyMedicalRecordSearchParams, Depends()],
) -> ApiResponse[PageData[MedicalRecordListItem]]:
    return ApiResponse(
        data=MedicalRecordService(db).list_my_records(
            params, operator=current_user
        )
    )


@router.get(
    "/my/drafts",
    response_model=ApiResponse[PageData[MedicalRecordListItem]],
    summary="查询我的草稿病历",
)
def list_my_draft_medical_records(
    current_user: RecordViewer,
    db: DatabaseSession,
    params: Annotated[MyMedicalRecordSearchParams, Depends()],
) -> ApiResponse[PageData[MedicalRecordListItem]]:
    draft_params = params.model_copy(
        update={"status": MedicalRecordStatus.DRAFT}
    )
    return ApiResponse(
        data=MedicalRecordService(db).list_my_records(
            draft_params, operator=current_user
        )
    )


@router.get(
    "/{record_id}/full",
    response_model=ApiResponse[MedicalRecordFull],
    summary="获取完整聚合病历",
)
def get_full_medical_record(
    record_id: int,
    current_user: RecordViewer,
    db: DatabaseSession,
) -> ApiResponse[MedicalRecordFull]:
    return ApiResponse(
        data=MedicalRecordService(db).get_full_record(
            record_id, operator=current_user
        )
    )


@router.get(
    "/{record_id}",
    response_model=ApiResponse[MedicalRecordDetail],
    summary="获取病历详情",
)
def get_medical_record(
    record_id: int,
    current_user: RecordViewer,
    db: DatabaseSession,
) -> ApiResponse[MedicalRecordDetail]:
    return ApiResponse(
        data=MedicalRecordService(db).get_record_detail(
            record_id, operator=current_user
        )
    )


@router.patch(
    "/{record_id}",
    response_model=ApiResponse[MedicalRecordDetail],
    summary="部分修改病历草稿",
    description="需要 record:update；当前业务仅 DRAFT 可修改，系统字段不可传入。",
)
def update_medical_record(
    record_id: int,
    payload: MedicalRecordUpdate,
    request: Request,
    current_user: RecordEditor,
    db: DatabaseSession,
) -> ApiResponse[MedicalRecordDetail]:
    result = MedicalRecordService(db).update_record(
        record_id,
        payload,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(message="病历草稿更新成功", data=result)


@router.post(
    "/{record_id}/complete",
    response_model=ApiResponse[MedicalRecordCompleteResponse],
    summary="完成病历",
    description="需要 record:submit；校验完整性并生成版本，DRAFT 直接转为 APPROVED。",
)
def complete_medical_record(
    record_id: int,
    request: Request,
    current_user: RecordSubmitter,
    db: DatabaseSession,
) -> ApiResponse[MedicalRecordCompleteResponse]:
    result = MedicalRecordService(db).complete_record(
        record_id,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(message="病历已完成并转为只读", data=result)


@router.post(
    "/{record_id}/submit",
    response_model=ApiResponse[MedicalRecordCompleteResponse],
    include_in_schema=False,
)
def legacy_submit_medical_record(
    record_id: int,
    request: Request,
    current_user: RecordSubmitter,
    db: DatabaseSession,
) -> ApiResponse[MedicalRecordCompleteResponse]:
    """兼容旧地址；不再产生待审核状态。"""
    result = MedicalRecordService(db).complete_record(
        record_id,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(message="审核流程已停用，病历已直接完成", data=result)


@router.delete(
    "/{record_id}",
    response_model=ApiResponse[None],
    summary="软删除病历草稿",
    description="需要 record:update；只有 DRAFT 状态允许软删除。",
)
def delete_medical_record(
    record_id: int,
    request: Request,
    current_user: RecordEditor,
    db: DatabaseSession,
) -> ApiResponse[None]:
    MedicalRecordService(db).delete_draft(
        record_id,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(message="病历草稿已删除", data=None)


@router.post(
    "/{record_id}/archive",
    response_model=ApiResponse[MedicalRecordArchiveResponse],
    summary="归档已审核通过病历",
    description="需要 record:archive；仅 APPROVED 状态可转换为 ARCHIVED。",
)
def archive_medical_record(
    record_id: int,
    request: Request,
    current_user: RecordArchiver,
    db: DatabaseSession,
) -> ApiResponse[MedicalRecordArchiveResponse]:
    result = MedicalRecordService(db).archive_record(
        record_id,
        operator=current_user,
        audit_context=_audit_context(request),
    )
    return ApiResponse(message="病历归档成功", data=result)


@router.get(
    "/{record_id}/versions",
    response_model=ApiResponse[list[MedicalRecordVersionRead]],
    summary="查询病历版本",
)
def list_medical_record_versions(
    record_id: int,
    current_user: RecordViewer,
    db: DatabaseSession,
) -> ApiResponse[list[MedicalRecordVersionRead]]:
    return ApiResponse(
        data=MedicalRecordService(db).list_versions(
            record_id, operator=current_user
        )
    )


@router.get(
    "/{record_id}/versions/{version}",
    response_model=ApiResponse[MedicalRecordVersionRead],
    summary="获取指定病历版本",
)
def get_medical_record_version(
    record_id: int,
    version: int,
    current_user: RecordViewer,
    db: DatabaseSession,
) -> ApiResponse[MedicalRecordVersionRead]:
    return ApiResponse(
        data=MedicalRecordService(db).get_version(
            record_id, version, operator=current_user
        )
    )
