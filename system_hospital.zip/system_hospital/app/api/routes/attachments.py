"""受权限保护的附件上传、元数据、预览、下载与软删除 API。"""

from typing import Annotated

from fastapi import APIRouter, Depends, File, Form, Request, UploadFile, status
from fastapi.responses import Response

from app.api.deps import DatabaseSession, Storage
from app.core.config import get_settings
from app.core.permissions import require_permission
from app.models.enums import AttachmentCategory
from app.models.user import User
from app.schemas.attachment import AttachmentRead, AttachmentUploadResponse
from app.schemas.common import ApiResponse
from app.services.attachment_service import AttachmentService
from app.services.audit_service import AuditContext

router = APIRouter(tags=["Attachments"])
Uploader = Annotated[User, Depends(require_permission("attachment:upload"))]
Viewer = Annotated[User, Depends(require_permission("attachment:view"))]


def _context(request: Request) -> AuditContext:
    return AuditContext(request.method, request.url.path, request.client.host if request.client else None)


def _service(db: DatabaseSession, storage: Storage) -> AttachmentService:
    return AttachmentService(db, storage, max_upload_size_mb=get_settings().max_upload_size_mb)


@router.post("/api/medical-records/{record_id}/attachments", response_model=ApiResponse[AttachmentUploadResponse], status_code=status.HTTP_201_CREATED)
def upload_attachment(record_id: int, request: Request, current_user: Uploader, db: DatabaseSession, storage: Storage, file: Annotated[UploadFile, File()], category: Annotated[AttachmentCategory, Form()] = AttachmentCategory.MEDICAL_RECORD, description: Annotated[str | None, Form(max_length=2000)] = None, lab_report_id: Annotated[int | None, Form(gt=0)] = None, examination_id: Annotated[int | None, Form(gt=0)] = None):
    data = _service(db, storage).upload(record_id, file, category=category, description=description, lab_report_id=lab_report_id, examination_id=examination_id, operator=current_user, audit_context=_context(request))
    return ApiResponse(code=201, message="附件上传成功", data=data)


@router.get("/api/attachments/{attachment_id}", response_model=ApiResponse[AttachmentRead])
def get_attachment(attachment_id: int, current_user: Viewer, db: DatabaseSession, storage: Storage):
    return ApiResponse(data=_service(db, storage).get_attachment(attachment_id, operator=current_user))


@router.get("/api/attachments/{attachment_id}/download", response_class=Response)
def download_attachment(attachment_id: int, request: Request, current_user: Viewer, db: DatabaseSession, storage: Storage):
    return _service(db, storage).get_content(attachment_id, operator=current_user, audit_context=_context(request), inline=False)


@router.get("/api/attachments/{attachment_id}/content", response_class=Response)
def view_attachment(attachment_id: int, request: Request, current_user: Viewer, db: DatabaseSession, storage: Storage):
    return _service(db, storage).get_content(attachment_id, operator=current_user, audit_context=_context(request), inline=True)


@router.delete("/api/attachments/{attachment_id}", response_model=ApiResponse[None])
def delete_attachment(attachment_id: int, request: Request, current_user: Uploader, db: DatabaseSession, storage: Storage):
    _service(db, storage).delete_attachment(attachment_id, operator=current_user, audit_context=_context(request))
    return ApiResponse(message="附件已软删除", data=None)
