"""登录和当前用户接口。"""

from fastapi import APIRouter

from app.api.deps import CurrentUser, DatabaseSession
from app.core.config import get_settings
from app.core.security import create_access_token
from app.repositories.user_repository import UserRepository
from app.schemas.auth import LoginRequest, TokenResponse
from app.schemas.common import ApiResponse
from app.services.auth_service import AuthService
from app.schemas.user import UserResponse
from app.services.user_service import UserService

router = APIRouter(prefix="/api/auth", tags=["认证"])


@router.post("/login", response_model=ApiResponse[TokenResponse])
def login(payload: LoginRequest, db: DatabaseSession) -> ApiResponse[TokenResponse]:
    settings = get_settings()
    repository = UserRepository(db)
    user = AuthService(repository).authenticate(payload.username, payload.password)
    access_token = create_access_token(user.id, user.username, settings=settings)
    user_response = UserService(db).to_response(user)
    return ApiResponse(
        message="登录成功",
        data=TokenResponse(
            access_token=access_token,
            expires_in=settings.access_token_expire_minutes * 60,
            user=user_response,
        ),
    )


@router.get("/me", response_model=ApiResponse[UserResponse])
def get_me(
    current_user: CurrentUser, db: DatabaseSession
) -> ApiResponse[UserResponse]:
    return ApiResponse(data=UserService(db).to_response(current_user))
