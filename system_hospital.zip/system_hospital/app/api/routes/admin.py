"""基础用户、角色、权限与科室管理接口。"""

from typing import Annotated

from fastapi import APIRouter, Depends, Query, status

from app.api.deps import DatabaseSession
from app.core.permissions import require_permission
from app.models.user import User
from app.schemas.common import ApiResponse
from app.schemas.department import DepartmentCreate, DepartmentResponse, DepartmentUpdate
from app.schemas.role import PermissionResponse, RolePermissionAssign, RoleResponse
from app.schemas.user import (
    UserCreate,
    UserPasswordReset,
    UserResponse,
    UserRoleAssign,
    UserUpdate,
)
from app.services.admin_service import AdminService
from app.services.user_service import UserService

router = APIRouter(prefix="/api/admin", tags=["系统管理"])

AdminUserPermission = Annotated[
    User, Depends(require_permission("admin:user"))
]
AdminRolePermission = Annotated[
    User, Depends(require_permission("admin:role"))
]
AdminDepartmentPermission = Annotated[
    User, Depends(require_permission("admin:department"))
]


@router.get("/users", response_model=ApiResponse[list[UserResponse]])
def list_users(
    _current_user: AdminUserPermission,
    db: DatabaseSession,
    offset: int = Query(default=0, ge=0),
    limit: int = Query(default=100, ge=1, le=200),
) -> ApiResponse[list[UserResponse]]:
    return ApiResponse(
        data=UserService(db).list_users(offset=offset, limit=limit)
    )


@router.post(
    "/users",
    response_model=ApiResponse[UserResponse],
    status_code=status.HTTP_201_CREATED,
)
def create_user(
    payload: UserCreate,
    _current_user: AdminUserPermission,
    db: DatabaseSession,
) -> ApiResponse[UserResponse]:
    service = UserService(db)
    user = service.create_user(payload)
    return ApiResponse(
        code=status.HTTP_201_CREATED,
        message="用户创建成功",
        data=service.to_response(user),
    )


@router.get("/users/{user_id}", response_model=ApiResponse[UserResponse])
def get_user(
    user_id: int,
    _current_user: AdminUserPermission,
    db: DatabaseSession,
) -> ApiResponse[UserResponse]:
    service = UserService(db)
    return ApiResponse(data=service.to_response(service.get_user(user_id)))


@router.put("/users/{user_id}", response_model=ApiResponse[UserResponse])
def update_user(
    user_id: int,
    payload: UserUpdate,
    _current_user: AdminUserPermission,
    db: DatabaseSession,
) -> ApiResponse[UserResponse]:
    service = UserService(db)
    user = service.update_user(user_id, payload)
    return ApiResponse(message="用户更新成功", data=service.to_response(user))


@router.post(
    "/users/{user_id}/roles",
    response_model=ApiResponse[UserResponse],
)
def assign_user_roles(
    user_id: int,
    payload: UserRoleAssign,
    _current_user: AdminUserPermission,
    db: DatabaseSession,
) -> ApiResponse[UserResponse]:
    service = UserService(db)
    user = service.assign_roles(user_id, payload.role_ids)
    return ApiResponse(message="角色分配成功", data=service.to_response(user))


@router.post("/users/{user_id}/reset-password", response_model=ApiResponse[UserResponse])
def reset_user_password(
    user_id: int,
    payload: UserPasswordReset,
    _current_user: AdminUserPermission,
    db: DatabaseSession,
) -> ApiResponse[UserResponse]:
    service = UserService(db)
    user = service.update_user(user_id, UserUpdate(password=payload.password))
    return ApiResponse(message="密码重置成功", data=service.to_response(user))


@router.get("/roles", response_model=ApiResponse[list[RoleResponse]])
def list_roles(
    _current_user: AdminRolePermission,
    db: DatabaseSession,
) -> ApiResponse[list[RoleResponse]]:
    return ApiResponse(data=AdminService(db).list_roles())


@router.get(
    "/permissions", response_model=ApiResponse[list[PermissionResponse]]
)
def list_permissions(
    _current_user: AdminRolePermission,
    db: DatabaseSession,
) -> ApiResponse[list[PermissionResponse]]:
    return ApiResponse(data=AdminService(db).list_permissions())


@router.put(
    "/roles/{role_id}/permissions",
    response_model=ApiResponse[RoleResponse],
)
def assign_role_permissions(
    role_id: int,
    payload: RolePermissionAssign,
    _current_user: AdminRolePermission,
    db: DatabaseSession,
) -> ApiResponse[RoleResponse]:
    result = AdminService(db).assign_role_permissions(
        role_id, payload.permission_ids
    )
    return ApiResponse(message="角色权限保存成功", data=result)


@router.get(
    "/departments", response_model=ApiResponse[list[DepartmentResponse]]
)
def list_departments(
    _current_user: AdminDepartmentPermission,
    db: DatabaseSession,
) -> ApiResponse[list[DepartmentResponse]]:
    return ApiResponse(data=AdminService(db).list_departments())


@router.post(
    "/departments",
    response_model=ApiResponse[DepartmentResponse],
    status_code=status.HTTP_201_CREATED,
)
def create_department(
    payload: DepartmentCreate,
    _current_user: AdminDepartmentPermission,
    db: DatabaseSession,
) -> ApiResponse[DepartmentResponse]:
    department = AdminService(db).create_department(payload)
    return ApiResponse(
        code=status.HTTP_201_CREATED,
        message="科室创建成功",
        data=DepartmentResponse.model_validate(department),
    )


@router.put(
    "/departments/{department_id}",
    response_model=ApiResponse[DepartmentResponse],
)
def update_department(
    department_id: int,
    payload: DepartmentUpdate,
    _current_user: AdminDepartmentPermission,
    db: DatabaseSession,
) -> ApiResponse[DepartmentResponse]:
    department = AdminService(db).update_department(department_id, payload)
    return ApiResponse(
        message="科室更新成功",
        data=DepartmentResponse.model_validate(department),
    )
