"""面向当前后台及后续 Vue 的统计分析 API。"""

from typing import Annotated

from fastapi import APIRouter, Depends

from app.api.deps import DatabaseSession
from app.core.permissions import require_permission
from app.models.user import User
from app.schemas.common import ApiResponse
from app.schemas.statistics import StatisticPoint, StatisticsSummary
from app.services.statistics_service import StatisticsService

router = APIRouter(prefix="/api/statistics", tags=["Statistics"])
StatisticsViewer = Annotated[User, Depends(require_permission("audit:view"))]


@router.get("/summary", response_model=ApiResponse[StatisticsSummary])
def summary(_user: StatisticsViewer, db: DatabaseSession):
    return ApiResponse(data=StatisticsService(db).summary())


@router.get("/patients/monthly", response_model=ApiResponse[list[StatisticPoint]])
def patients_monthly(_user: StatisticsViewer, db: DatabaseSession):
    return ApiResponse(data=StatisticsService(db).patients_monthly())


@router.get("/encounters/daily", response_model=ApiResponse[list[StatisticPoint]])
def encounters_daily(_user: StatisticsViewer, db: DatabaseSession):
    return ApiResponse(data=StatisticsService(db).encounters_daily())


@router.get("/encounters/types", response_model=ApiResponse[list[StatisticPoint]])
def encounter_types(_user: StatisticsViewer, db: DatabaseSession):
    return ApiResponse(data=StatisticsService(db).encounter_types())


@router.get("/departments", response_model=ApiResponse[list[StatisticPoint]])
def departments(_user: StatisticsViewer, db: DatabaseSession):
    return ApiResponse(data=StatisticsService(db).departments())


@router.get("/records/status", response_model=ApiResponse[list[StatisticPoint]])
def record_statuses(_user: StatisticsViewer, db: DatabaseSession):
    return ApiResponse(data=StatisticsService(db).record_statuses())


@router.get("/diagnoses/top", response_model=ApiResponse[list[StatisticPoint]])
def top_diagnoses(_user: StatisticsViewer, db: DatabaseSession):
    return ApiResponse(data=StatisticsService(db).top_diagnoses())
