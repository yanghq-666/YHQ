"""服务健康检查。"""

from fastapi import APIRouter

router = APIRouter(tags=["系统"])


@router.get("/health", summary="健康检查")
def health_check() -> dict[str, str]:
    """供部署平台和反向代理检查进程是否存活。"""
    return {"status": "ok"}

