"""病历审核任务、审核锁和审核时间线 REST API。"""

from typing import Annotated, Any

from fastapi import APIRouter, Depends, Request

from app.api.deps import DatabaseSession
from app.core.permissions import require_permission
from app.models.enums import MedicalRecordStatus
from app.models.user import User
from app.schemas.common import ApiResponse, PageData
from app.schemas.medical_record import MedicalRecordListItem, MyMedicalRecordSearchParams
from app.schemas.record_review import (
    MyReviewSearchParams,
    PendingReviewListItem,
    PendingReviewSearchParams,
    RecordReviewApproveRequest,
    RecordReviewDecisionResponse,
    RecordReviewRead,
    RecordReviewRejectRequest,
    RecordReviewStartResponse,
    ReviewTaskListItem,
    ReviewHistoryRead,
)
from app.services.audit_service import AuditContext
from app.services.medical_record_service import MedicalRecordService
from app.services.review_service import ReviewService

router = APIRouter(
    prefix="/api/medical-records",
    tags=["Medical Record Reviews"],
    responses={
        401: {"description": "未登录或登录凭证无效"},
        403: {"description": "角色、权限或科室数据范围不允许"},
        404: {"description": "病历、版本或审核记录不存在"},
        409: {"description": "病历状态或审核锁冲突"},
        422: {"description": "请求参数或审核意见校验失败"},
    },
)
Reviewer = Annotated[User, Depends(require_permission("record:review"))]
RecordViewer = Annotated[User, Depends(require_permission("record:view"))]


def _audit_context(request: Request) -> AuditContext:
    return AuditContext(
        request_method=request.method,
        request_path=request.url.path,
        ip_address=request.client.host if request.client else None,
    )


@router.get(
    "/pending-review",
    response_model=ApiResponse[PageData[PendingReviewListItem]],
    summary="查询待审核病历",
    description="仅上级医生或管理员；默认返回最新提交在前的 SUBMITTED 病历。",
)
def list_pending_review(
    current_user: Reviewer,
    db: DatabaseSession,
    params: Annotated[PendingReviewSearchParams, Depends()],
) -> ApiResponse[PageData[PendingReviewListItem]]:
    return ApiResponse(
        data=ReviewService(db).list_pending(params, operator=current_user)
    )


@router.get(
    "/my-reviews",
    response_model=ApiResponse[PageData[ReviewTaskListItem]],
    summary="查询我的审核记录",
)
def list_my_reviews(
    current_user: Reviewer,
    db: DatabaseSession,
    params: Annotated[MyReviewSearchParams, Depends()],
) -> ApiResponse[PageData[ReviewTaskListItem]]:
    return ApiResponse(
        data=ReviewService(db).list_my_reviews(params, operator=current_user)
    )


@router.get(
    "/my/rejected",
    response_model=ApiResponse[PageData[MedicalRecordListItem]],
    summary="查询我的退回病历",
)
def list_my_rejected(
    current_user: RecordViewer,
    db: DatabaseSession,
    params: Annotated[MyMedicalRecordSearchParams, Depends()],
) -> ApiResponse[PageData[MedicalRecordListItem]]:
    rejected = params.model_copy(
        update={"status": MedicalRecordStatus.REJECTED}
    )
    return ApiResponse(
        data=MedicalRecordService(db).list_my_records(
            rejected, operator=current_user
        )
    )


@router.get(
    "/{record_id}/reviews",
    response_model=ApiResponse[list[ReviewHistoryRead]],
    summary="查询审核历史",
)
def review_history(
    record_id: int,
    current_user: RecordViewer,
    db: DatabaseSession,
) -> ApiResponse[list[ReviewHistoryRead]]:
    return ApiResponse(
        data=ReviewService(db).get_history(record_id, operator=current_user)
    )


@router.get(
    "/{record_id}/latest-review",
    response_model=ApiResponse[RecordReviewRead],
    summary="查询最近一次退回意见",
)
def latest_review(
    record_id: int,
    current_user: RecordViewer,
    db: DatabaseSession,
) -> ApiResponse[RecordReviewRead]:
    return ApiResponse(
        data=ReviewService(db).get_latest_review(
            record_id, operator=current_user
        )
    )


@router.post(
    "/{record_id}/review/start",
    response_model=ApiResponse[RecordReviewStartResponse],
    summary="开始审核并取得审核锁",
    description="仅 SUBMITTED；不能自审；同一病历只能由一名审核人占用。",
)
def start_review(
    record_id: int,
    request: Request,
    current_user: Reviewer,
    db: DatabaseSession,
) -> ApiResponse[RecordReviewStartResponse]:
    return ApiResponse(
        message="已开始审核",
        data=ReviewService(db).start_review(
            record_id,
            operator=current_user,
            audit_context=_audit_context(request),
        ),
    )


@router.post(
    "/{record_id}/review/approve",
    response_model=ApiResponse[RecordReviewDecisionResponse],
    summary="审核通过",
    description="仅当前审核锁持有人可将 REVIEWING 转为 APPROVED。",
)
def approve_review(
    record_id: int,
    payload: RecordReviewApproveRequest,
    request: Request,
    current_user: Reviewer,
    db: DatabaseSession,
) -> ApiResponse[RecordReviewDecisionResponse]:
    return ApiResponse(
        message="病历审核通过",
        data=ReviewService(db).approve(
            record_id,
            payload,
            operator=current_user,
            audit_context=_audit_context(request),
        ),
    )


@router.post(
    "/{record_id}/review/reject",
    response_model=ApiResponse[RecordReviewDecisionResponse],
    summary="退回病历",
    description="退回原因至少 5 个字符；仅当前审核锁持有人可操作。",
)
def reject_review(
    record_id: int,
    payload: RecordReviewRejectRequest,
    request: Request,
    current_user: Reviewer,
    db: DatabaseSession,
) -> ApiResponse[RecordReviewDecisionResponse]:
    return ApiResponse(
        message="病历已退回修改",
        data=ReviewService(db).reject(
            record_id,
            payload,
            operator=current_user,
            audit_context=_audit_context(request),
        ),
    )


@router.get(
    "/{record_id}/versions/{version}/full",
    response_model=ApiResponse[dict[str, Any]],
    summary="查看不可变完整版本快照",
)
def get_version_full(
    record_id: int,
    version: int,
    current_user: RecordViewer,
    db: DatabaseSession,
) -> ApiResponse[dict[str, Any]]:
    return ApiResponse(
        data=ReviewService(db).get_version_full(
            record_id, version, operator=current_user
        )
    )
