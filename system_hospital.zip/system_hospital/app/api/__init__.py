"""HTTP API 层。"""

