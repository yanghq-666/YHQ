"""主病历状态转换的唯一规则表。"""

from app.core.exceptions import InvalidMedicalRecordStateError
from app.models.enums import MedicalRecordStatus


class MedicalRecordStateMachine:
    TRANSITIONS = {
        # 新业务直接完成；SUBMITTED 仅保留给历史审核数据兼容。
        MedicalRecordStatus.DRAFT: {
            MedicalRecordStatus.APPROVED,
            MedicalRecordStatus.SUBMITTED,
        },
        MedicalRecordStatus.SUBMITTED: {MedicalRecordStatus.REVIEWING},
        MedicalRecordStatus.REVIEWING: {
            MedicalRecordStatus.REJECTED,
            MedicalRecordStatus.APPROVED,
        },
        MedicalRecordStatus.REJECTED: {MedicalRecordStatus.SUBMITTED},
        MedicalRecordStatus.APPROVED: {MedicalRecordStatus.ARCHIVED},
        MedicalRecordStatus.ARCHIVED: set(),
    }
    EDITABLE = {MedicalRecordStatus.DRAFT}

    @classmethod
    def ensure_transition(
        cls,
        from_status: MedicalRecordStatus,
        to_status: MedicalRecordStatus,
    ) -> None:
        if to_status not in cls.TRANSITIONS[from_status]:
            raise InvalidMedicalRecordStateError(
                f"病历不允许从 {from_status.value} 转换为 {to_status.value}"
            )

    @classmethod
    def ensure_editable(cls, status: MedicalRecordStatus) -> None:
        if status not in cls.EDITABLE:
            raise InvalidMedicalRecordStateError(
                f"病历当前状态 {status.value} 不允许修改临床记录"
            )
