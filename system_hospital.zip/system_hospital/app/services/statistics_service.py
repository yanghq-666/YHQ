"""统计分析服务：统一时区、连续时间轴及中文展示标签。"""

from collections import Counter
from datetime import datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

from sqlalchemy.orm import Session

from app.models.encounter import Encounter
from app.models.enums import MedicalRecordStatus
from app.models.medical_record import MedicalRecord
from app.models.patient import Patient
from app.models.user import User
from app.repositories.statistics_repository import StatisticsRepository
from app.schemas.statistics import StatisticPoint, StatisticsSummary
from app.web.display_helpers import encounter_type_label, status_label

LOCAL_TIMEZONE = ZoneInfo("Asia/Shanghai")


class StatisticsService:
    def __init__(self, db: Session) -> None:
        self.repository = StatisticsRepository(db)

    def summary(self) -> StatisticsSummary:
        start, end = self._today_bounds()
        return StatisticsSummary(
            patients=self.repository.count(Patient, Patient.deleted_at.is_(None)),
            users=self.repository.count(User, User.deleted_at.is_(None)),
            doctors=self.repository.doctor_count(),
            encounters_today=self.repository.count(
                Encounter,
                Encounter.deleted_at.is_(None),
                Encounter.visit_time >= start,
                Encounter.visit_time < end,
            ),
            medical_records=self.repository.count(
                MedicalRecord, MedicalRecord.deleted_at.is_(None)
            ),
            draft_records=self._record_count(MedicalRecordStatus.DRAFT),
            completed_records=self._record_count(MedicalRecordStatus.APPROVED),
        )

    def patients_monthly(self, months: int = 6) -> list[StatisticPoint]:
        today = datetime.now(LOCAL_TIMEZONE).date().replace(day=1)
        month_keys: list[str] = []
        cursor = today
        for _ in range(months):
            month_keys.append(cursor.strftime("%Y-%m"))
            cursor = (cursor - timedelta(days=1)).replace(day=1)
        month_keys.reverse()
        start = datetime.strptime(month_keys[0] + "-01", "%Y-%m-%d").replace(
            tzinfo=LOCAL_TIMEZONE
        ).astimezone(timezone.utc)
        counts = Counter(
            self._to_local(item).strftime("%Y-%m")
            for item in self.repository.created_dates(Patient, start)
        )
        return [StatisticPoint(name=key, value=counts[key]) for key in month_keys]

    def encounters_daily(self, days: int = 7) -> list[StatisticPoint]:
        today = datetime.now(LOCAL_TIMEZONE).date()
        date_keys = [today - timedelta(days=offset) for offset in range(days - 1, -1, -1)]
        start = datetime.combine(date_keys[0], time.min, tzinfo=LOCAL_TIMEZONE).astimezone(timezone.utc)
        counts = Counter(
            self._to_local(item).date()
            for item in self.repository.encounter_dates(start)
        )
        return [StatisticPoint(name=item.strftime("%m-%d"), value=counts[item]) for item in date_keys]

    def encounter_types(self) -> list[StatisticPoint]:
        return [StatisticPoint(name=encounter_type_label(key), value=value) for key, value in self.repository.grouped_encounter_types()]

    def departments(self) -> list[StatisticPoint]:
        return [StatisticPoint(name=name, value=value) for name, value in self.repository.grouped_departments()]

    def record_statuses(self) -> list[StatisticPoint]:
        return [StatisticPoint(name=status_label(key), value=value) for key, value in self.repository.grouped_record_statuses()]

    def top_diagnoses(self) -> list[StatisticPoint]:
        return [StatisticPoint(name=name, value=value) for name, value in self.repository.top_diagnoses()]

    def all_charts(self) -> dict[str, list[dict[str, object]]]:
        return {
            "patients_monthly": [item.model_dump() for item in self.patients_monthly()],
            "encounters_daily": [item.model_dump() for item in self.encounters_daily()],
            "encounter_types": [item.model_dump() for item in self.encounter_types()],
            "departments": [item.model_dump() for item in self.departments()],
            "record_statuses": [item.model_dump() for item in self.record_statuses()],
            "top_diagnoses": [item.model_dump() for item in self.top_diagnoses()],
        }

    def _record_count(self, status: MedicalRecordStatus) -> int:
        return self.repository.count(
            MedicalRecord,
            MedicalRecord.deleted_at.is_(None),
            MedicalRecord.status == status,
        )

    @staticmethod
    def _today_bounds() -> tuple[datetime, datetime]:
        now = datetime.now(LOCAL_TIMEZONE)
        start = datetime.combine(now.date(), time.min, tzinfo=LOCAL_TIMEZONE)
        return start.astimezone(timezone.utc), (start + timedelta(days=1)).astimezone(timezone.utc)

    @staticmethod
    def _to_local(value: datetime) -> datetime:
        """SQLite 可能返回无时区值；项目约定此时按 UTC 解释。"""
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone(LOCAL_TIMEZONE)
