"""检查报告状态机与查询业务。"""

from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.core.exceptions import InvalidMedicalRecordStateError, PermissionDeniedError, ResourceNotFoundError
from app.models.enums import ExaminationStatus
from app.models.examination import Examination
from app.models.user import User
from app.repositories.examination_repository import ExaminationRepository
from app.repositories.medical_record_repository import MedicalRecordRepository
from app.repositories.user_repository import UserRepository
from app.schemas.examination import ExaminationCancel, ExaminationComplete, ExaminationCreate, ExaminationFilter, ExaminationRead
from app.services.audit_service import AuditContext, AuditService
from app.services.examination_access_policy import ExaminationAccessPolicy
from app.services.sequence_service import SequenceService


class ExaminationService:
    def __init__(self, db: Session) -> None:
        self.db = db
        self.examinations = ExaminationRepository(db)
        self.records = MedicalRecordRepository(db)
        self.policy = ExaminationAccessPolicy(UserRepository(db))
        self.audit = AuditService(db)
        self.sequence = SequenceService(db)

    def create_examination(self, record_id: int, payload: ExaminationCreate, *, operator: User, audit_context: AuditContext) -> ExaminationRead:
        record = self._record(record_id, operator)
        if not self.policy.can_create(record, operator):
            raise PermissionDeniedError("无权为该病历创建检查")
        try:
            item = Examination(examination_no=self.sequence.generate_number(prefix="EX", sequence_name="examination"), patient_id=record.encounter.patient_id, encounter_id=record.encounter_id, record_id=record.id, status=ExaminationStatus.PENDING, requested_by=operator.id, **payload.model_dump())
            self.examinations.create(item)
            self.audit.record(user_id=operator.id, action="EXAMINATION_CREATE", module="examination", target_type="examination", target_id=item.id, context=audit_context, new_value={"examination_no": item.examination_no, "record_id": record.id})
            self.db.commit()
            return ExaminationRead.model_validate(item)
        except Exception:
            self.db.rollback()
            raise

    def start_examination(self, examination_id: int, *, operator: User, audit_context: AuditContext) -> ExaminationRead:
        item, _ = self._examination(examination_id, operator)
        if not self.policy.can_process(operator):
            raise PermissionDeniedError("仅影像人员或管理员可以开始检查")
        if item.status != ExaminationStatus.PENDING:
            raise InvalidMedicalRecordStateError("只有待处理检查可以开始")
        try:
            item.status = ExaminationStatus.IN_PROGRESS
            item.performed_by = operator.id
            item.performed_at = datetime.now(timezone.utc)
            self.audit.record(user_id=operator.id, action="EXAMINATION_START", module="examination", target_type="examination", target_id=item.id, context=audit_context, old_value={"status": "PENDING"}, new_value={"status": "IN_PROGRESS"})
            self.db.commit()
            return ExaminationRead.model_validate(item)
        except Exception:
            self.db.rollback()
            raise

    def complete_examination(self, examination_id: int, payload: ExaminationComplete, *, operator: User, audit_context: AuditContext) -> ExaminationRead:
        item, _ = self._examination(examination_id, operator)
        if not self.policy.can_process(operator):
            raise PermissionDeniedError("仅影像人员或管理员可以完成检查")
        if item.status != ExaminationStatus.IN_PROGRESS:
            raise InvalidMedicalRecordStateError("只有处理中检查可以完成")
        now = datetime.now(timezone.utc)
        try:
            item.findings = payload.findings
            item.conclusion = payload.conclusion
            item.status = ExaminationStatus.COMPLETED
            item.performed_by = operator.id
            item.performed_at = item.performed_at or now
            item.reported_at = now
            self.audit.record(user_id=operator.id, action="EXAMINATION_COMPLETE", module="examination", target_type="examination", target_id=item.id, context=audit_context, old_value={"status": "IN_PROGRESS"}, new_value={"status": "COMPLETED"})
            self.db.commit()
            return ExaminationRead.model_validate(item)
        except Exception:
            self.db.rollback()
            raise

    def cancel_examination(self, examination_id: int, payload: ExaminationCancel, *, operator: User, audit_context: AuditContext) -> ExaminationRead:
        item, _ = self._examination(examination_id, operator)
        if not self.policy.can_process(operator):
            raise PermissionDeniedError("仅影像人员或管理员可以取消检查")
        if item.status != ExaminationStatus.PENDING:
            raise InvalidMedicalRecordStateError("只有待处理检查可以取消")
        try:
            item.status = ExaminationStatus.CANCELLED
            self.audit.record(user_id=operator.id, action="EXAMINATION_CANCEL", module="examination", target_type="examination", target_id=item.id, context=audit_context, old_value={"status": "PENDING"}, new_value={"status": "CANCELLED", "reason": payload.reason})
            self.db.commit()
            return ExaminationRead.model_validate(item)
        except Exception:
            self.db.rollback()
            raise

    def get_examination(self, examination_id: int, *, operator: User) -> ExaminationRead:
        item, _ = self._examination(examination_id, operator)
        return ExaminationRead.model_validate(item)

    def list_examinations(self, record_id: int, params: ExaminationFilter, *, operator: User) -> list[ExaminationRead]:
        record = self._record(record_id, operator)
        return [ExaminationRead.model_validate(item) for item in self.examinations.list_by_record(record.id, params)]

    def _record(self, record_id: int, operator: User):
        record = self.records.get_by_id(record_id)
        if record is None:
            raise ResourceNotFoundError("病历不存在")
        if not self.policy.can_view(record, operator):
            raise PermissionDeniedError("无权访问该病历")
        return record

    def _examination(self, examination_id: int, operator: User):
        item = self.examinations.get_by_id(examination_id)
        if item is None:
            raise ResourceNotFoundError("检查不存在")
        return item, self._record(item.record_id, operator)
