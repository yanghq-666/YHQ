"""医嘱创建、修改、状态流转、查询和软删除业务。"""

from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.exceptions import (
    ConflictError,
    InvalidMedicalRecordStateError,
    ResourceNotFoundError,
    ValidationError,
)
from app.models.enums import (
    EncounterType,
    ExaminationStatus,
    LabReportStatus,
    MedicalOrderStatus,
    MedicalOrderType,
    PrescriptionStatus,
    PrescriptionType,
)
from app.models.examination import Examination
from app.models.lab_report import LabReport
from app.models.medical_order import MedicalOrder
from app.models.prescription import Prescription, PrescriptionItem
from app.models.user import User
from app.repositories.medical_order_repository import MedicalOrderRepository
from app.schemas.medical_order import (
    MedicalOrderCreate,
    MedicalOrderFilter,
    MedicalOrderRead,
    MedicalOrderStatusResponse,
    MedicalOrderUpdate,
)
from app.services.audit_service import AuditContext, AuditService
from app.services.catalog_service import CatalogService
from app.services.medical_record_service import MedicalRecordService
from app.services.sequence_service import SequenceService


class MedicalOrderService:
    NEW_ORDER_TYPES = (
        MedicalOrderType.MEDICATION,
        MedicalOrderType.LAB,
        MedicalOrderType.EXAMINATION,
        MedicalOrderType.TREATMENT,
        MedicalOrderType.NURSING,
        MedicalOrderType.OTHER,
    )
    GENERATED_FIELDS = {
        "drug_catalog_id",
        "duration",
        "duration_unit",
        "quantity",
        "quantity_unit",
        "lab_test_catalog_id",
        "lab_report_type",
        "specimen_type",
        "examination_type",
        "body_part",
    }

    def __init__(self, db: Session) -> None:
        self.db = db
        self.repository = MedicalOrderRepository(db)
        self.records = MedicalRecordService(db)
        self.sequences = SequenceService(db)
        self.audit = AuditService(db)
        self.catalogs = CatalogService(db)

    def create_order(
        self,
        record_id: int,
        payload: MedicalOrderCreate,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> MedicalOrderRead:
        record = self.records.get_editable_record(record_id, operator=operator)
        self._validate_times(payload.start_time, payload.end_time)
        for attempt in range(3):
            try:
                order = MedicalOrder(
                    order_no=self.sequences.generate_number(
                        prefix="MO", sequence_name="medical_order"
                    ),
                    encounter_id=record.encounter_id,
                    record_id=record.id,
                    status=MedicalOrderStatus.ACTIVE,
                    created_by=operator.id,
                    **payload.model_dump(exclude=self.GENERATED_FIELDS),
                )
                self.repository.create(order)
                self._sync_generated_resource(order, record, payload, operator)
                self.audit.record(
                    user_id=operator.id,
                    action="MEDICAL_ORDER_CREATE",
                    module="medical_order",
                    target_type="medical_order",
                    target_id=order.id,
                    context=audit_context,
                    new_value=self._metadata(order),
                )
                self.db.commit()
                self.db.refresh(order)
                return MedicalOrderRead.model_validate(order)
            except IntegrityError as exc:
                self.db.rollback()
                if attempt == 2:
                    raise ConflictError("医嘱编号生成冲突，请重试") from exc
            except Exception:
                self.db.rollback()
                raise
        raise ConflictError("医嘱编号生成失败")

    def list_orders(
        self,
        record_id: int,
        filters: MedicalOrderFilter,
        *,
        operator: User,
    ) -> list[MedicalOrderRead]:
        self.records.get_record(record_id, operator=operator)
        return [
            MedicalOrderRead.model_validate(item)
            for item in self.repository.list_by_record(
                record_id,
                order_type=filters.order_type,
                status=filters.status,
            )
        ]

    def get_editable_order(
        self, order_id: int, *, operator: User
    ) -> MedicalOrderRead:
        """为服务端表单读取可编辑医嘱，状态规则仍由业务层维护。"""
        order = self._get(order_id)
        self.records.get_editable_record(order.record_id, operator=operator)
        if order.status != MedicalOrderStatus.ACTIVE:
            raise InvalidMedicalRecordStateError("只有生效中的医嘱允许修改")
        return MedicalOrderRead.model_validate(order)

    def get_generated_values(self, order_id: int) -> dict[str, object]:
        values: dict[str, object] = {}
        prescription = self.db.scalar(
            select(Prescription).where(Prescription.order_id == order_id)
        )
        if prescription:
            item = self.db.scalar(
                select(PrescriptionItem).where(
                    PrescriptionItem.prescription_id == prescription.id,
                    PrescriptionItem.deleted_at.is_(None),
                )
            )
            if item:
                for field in (
                    "drug_catalog_id", "duration", "duration_unit",
                    "quantity", "quantity_unit",
                ):
                    values[field] = getattr(item, field)
        report = self.db.scalar(
            select(LabReport).where(LabReport.order_id == order_id)
        )
        if report:
            values.update(
                lab_test_catalog_id=report.lab_test_catalog_id,
                lab_report_type=report.report_type,
                specimen_type=report.specimen_type,
            )
        examination = self.db.scalar(
            select(Examination).where(Examination.order_id == order_id)
        )
        if examination:
            values.update(
                examination_type=examination.examination_type.value,
                body_part=examination.body_part,
            )
        return values

    def update_order(
        self,
        order_id: int,
        payload: MedicalOrderUpdate,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> MedicalOrderRead:
        order = self._get(order_id)
        self.records.get_editable_record(order.record_id, operator=operator)
        if order.status != MedicalOrderStatus.ACTIVE:
            raise InvalidMedicalRecordStateError("只有生效中的医嘱允许修改")
        changes = payload.model_dump(exclude_unset=True)
        if not changes:
            raise ValidationError("没有可更新的医嘱字段")
        if "order_type" in changes and changes["order_type"] != order.order_type:
            raise ValidationError("医嘱类型创建后不能修改")
        generated_changes = {
            field: changes.pop(field)
            for field in list(changes)
            if field in self.GENERATED_FIELDS
        }
        start_time = changes.get("start_time", order.start_time)
        end_time = changes.get("end_time", order.end_time)
        self._validate_times(start_time, end_time)
        changed_fields = sorted(
            field for field, value in changes.items() if getattr(order, field) != value
        )
        if not changed_fields and not generated_changes:
            raise ValidationError("医嘱内容没有变化")
        try:
            for field in changed_fields:
                setattr(order, field, changes[field])
            self.repository.update(order)
            self._update_generated_resource(order, generated_changes)
            self.audit.record(
                user_id=operator.id,
                action="MEDICAL_ORDER_UPDATE",
                module="medical_order",
                target_type="medical_order",
                target_id=order.id,
                context=audit_context,
                old_value={"changed_fields": changed_fields},
                new_value={"changed_fields": changed_fields},
            )
            self.db.commit()
            self.db.refresh(order)
            return MedicalOrderRead.model_validate(order)
        except Exception:
            self.db.rollback()
            raise

    def _sync_generated_resource(
        self, order: MedicalOrder, record, payload: MedicalOrderCreate, operator: User
    ) -> None:
        if order.order_type == MedicalOrderType.MEDICATION:
            if self.db.scalar(select(Prescription.id).where(Prescription.order_id == order.id)):
                return
            drug = self.catalogs.get_drug(payload.drug_catalog_id)
            order.order_content = drug.drug_name
            order.dosage_unit = drug.unit
            prescription_type = {
                EncounterType.OUTPATIENT: PrescriptionType.OUTPATIENT,
                EncounterType.INPATIENT: PrescriptionType.INPATIENT,
            }.get(record.encounter.encounter_type, PrescriptionType.OTHER)
            prescription = Prescription(
                prescription_no=self.sequences.generate_number(prefix="RX", sequence_name="prescription"),
                encounter_id=record.encounter_id,
                record_id=record.id,
                order_id=order.id,
                doctor_id=operator.id,
                prescription_type=prescription_type,
                status=PrescriptionStatus.DRAFT,
                notes="由药物医嘱自动生成",
            )
            self.db.add(prescription)
            self.db.flush()
            self.db.add(PrescriptionItem(
                prescription_id=prescription.id,
                drug_catalog_id=drug.id,
                drug_name=drug.drug_name,
                generic_name=drug.generic_name,
                dosage_form=drug.dosage_form,
                specification=drug.specification,
                dosage=payload.dosage,
                dosage_unit=drug.unit,
                frequency=payload.frequency,
                route=payload.route,
                duration=payload.duration,
                duration_unit=payload.duration_unit or "天",
                quantity=payload.quantity,
                quantity_unit=payload.quantity_unit or drug.unit,
                remark=payload.remark,
            ))
        elif order.order_type == MedicalOrderType.LAB:
            if self.db.scalar(select(LabReport.id).where(LabReport.order_id == order.id)):
                return
            catalog = (
                self.catalogs.get_lab_test(payload.lab_test_catalog_id)
                if payload.lab_test_catalog_id else None
            )
            if catalog:
                order.order_content = catalog.test_name
            self.db.add(LabReport(
                report_no=self.sequences.generate_number(prefix="LAB", sequence_name="lab_report"),
                patient_id=record.encounter.patient_id,
                encounter_id=record.encounter_id,
                record_id=record.id,
                order_id=order.id,
                lab_test_catalog_id=catalog.id if catalog else None,
                report_name=catalog.test_name if catalog else order.order_content,
                report_type=payload.lab_report_type or "其他",
                specimen_type=payload.specimen_type,
                status=LabReportStatus.PENDING,
                requested_by=operator.id,
            ))
        elif order.order_type == MedicalOrderType.EXAMINATION:
            if self.db.scalar(select(Examination.id).where(Examination.order_id == order.id)):
                return
            self.db.add(Examination(
                examination_no=self.sequences.generate_number(prefix="EX", sequence_name="examination"),
                patient_id=record.encounter.patient_id,
                encounter_id=record.encounter_id,
                record_id=record.id,
                order_id=order.id,
                examination_type=payload.examination_type,
                examination_name=order.order_content,
                body_part=payload.body_part,
                clinical_indication=payload.remark,
                status=ExaminationStatus.PENDING,
                requested_by=operator.id,
            ))
        self.db.flush()

    def _update_generated_resource(
        self, order: MedicalOrder, generated_changes: dict[str, object]
    ) -> None:
        if order.order_type == MedicalOrderType.MEDICATION:
            prescription = self.db.scalar(select(Prescription).where(Prescription.order_id == order.id))
            item = self.db.scalar(select(PrescriptionItem).where(PrescriptionItem.prescription_id == prescription.id)) if prescription else None
            if item:
                if generated_changes.get("drug_catalog_id"):
                    drug = self.catalogs.get_drug(generated_changes["drug_catalog_id"])
                    item.drug_catalog_id = drug.id
                    item.drug_name = drug.drug_name
                    item.generic_name = drug.generic_name
                    item.dosage_form = drug.dosage_form
                    item.specification = drug.specification
                    item.dosage_unit = drug.unit
                    item.quantity_unit = generated_changes.get("quantity_unit") or drug.unit
                for field in ("duration", "duration_unit", "quantity", "quantity_unit"):
                    if field in generated_changes:
                        setattr(item, field, generated_changes[field])
                item.dosage, item.frequency, item.route, item.remark = order.dosage, order.frequency, order.route, order.remark
        elif order.order_type == MedicalOrderType.LAB:
            report = self.db.scalar(select(LabReport).where(LabReport.order_id == order.id))
            if report:
                report.report_name = order.order_content
                for source, target in (("lab_test_catalog_id", "lab_test_catalog_id"), ("lab_report_type", "report_type"), ("specimen_type", "specimen_type")):
                    if source in generated_changes:
                        setattr(report, target, generated_changes[source])
        elif order.order_type == MedicalOrderType.EXAMINATION:
            examination = self.db.scalar(select(Examination).where(Examination.order_id == order.id))
            if examination:
                examination.examination_name = order.order_content
                examination.clinical_indication = order.remark
                for field in ("examination_type", "body_part"):
                    if field in generated_changes:
                        setattr(examination, field, generated_changes[field])
        self.db.flush()

    def stop_order(
        self,
        order_id: int,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> MedicalOrderStatusResponse:
        order = self._get(order_id)
        self.records.get_editable_record(order.record_id, operator=operator)
        return self._transition(
            order,
            target=MedicalOrderStatus.STOPPED,
            action="MEDICAL_ORDER_STOP",
            operator=operator,
            audit_context=audit_context,
        )

    def complete_order(
        self,
        order_id: int,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> MedicalOrderStatusResponse:
        order = self._get(order_id)
        self.records.get_editable_record(order.record_id, operator=operator)
        return self._transition(
            order,
            target=MedicalOrderStatus.COMPLETED,
            action="MEDICAL_ORDER_COMPLETE",
            operator=operator,
            audit_context=audit_context,
        )

    def delete_order(
        self,
        order_id: int,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> None:
        order = self._get(order_id)
        self.records.get_editable_record(order.record_id, operator=operator)
        if order.status != MedicalOrderStatus.ACTIVE:
            raise InvalidMedicalRecordStateError("只有生效中的医嘱允许删除")
        try:
            self.repository.soft_delete(order, datetime.now(timezone.utc))
            self.audit.record(
                user_id=operator.id,
                action="MEDICAL_ORDER_DELETE",
                module="medical_order",
                target_type="medical_order",
                target_id=order.id,
                context=audit_context,
                old_value=self._metadata(order),
                new_value={"deleted": True},
            )
            self.db.commit()
        except Exception:
            self.db.rollback()
            raise

    def _transition(
        self,
        order: MedicalOrder,
        *,
        target: MedicalOrderStatus,
        action: str,
        operator: User,
        audit_context: AuditContext,
    ) -> MedicalOrderStatusResponse:
        if order.status != MedicalOrderStatus.ACTIVE:
            raise InvalidMedicalRecordStateError(
                f"医嘱状态不能从 {order.status.value} 转换为 {target.value}"
            )
        old_status = order.status
        transitioned_at = datetime.now(timezone.utc)
        try:
            order.status = target
            if target == MedicalOrderStatus.STOPPED:
                order.stopped_by = operator.id
                order.stopped_at = transitioned_at
            self.repository.update(order)
            self.audit.record(
                user_id=operator.id,
                action=action,
                module="medical_order",
                target_type="medical_order",
                target_id=order.id,
                context=audit_context,
                old_value={"status": old_status.value},
                new_value={"status": target.value},
            )
            self.db.commit()
            return MedicalOrderStatusResponse(
                id=order.id,
                order_no=order.order_no,
                old_status=old_status,
                status=target,
                stopped_by=order.stopped_by,
                stopped_at=order.stopped_at,
            )
        except Exception:
            self.db.rollback()
            raise

    def _get(self, order_id: int) -> MedicalOrder:
        order = self.repository.get_by_id(order_id)
        if order is None:
            raise ResourceNotFoundError("医嘱不存在")
        return order

    @staticmethod
    def _validate_times(
        start_time: datetime | None, end_time: datetime | None
    ) -> None:
        if start_time and end_time:
            left = MedicalOrderService._aware_utc(start_time)
            right = MedicalOrderService._aware_utc(end_time)
            if left > right:
                raise ValidationError("医嘱开始时间不能晚于结束时间")

    @staticmethod
    def _aware_utc(value: datetime) -> datetime:
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)

    @staticmethod
    def _metadata(order: MedicalOrder) -> dict[str, object]:
        return {
            "order_no": order.order_no,
            "record_id": order.record_id,
            "order_type": order.order_type.value,
            "status": order.status.value,
        }
