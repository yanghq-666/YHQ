"""附件对象存储抽象、本地实现与可选 MinIO 实现。"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from hashlib import sha256
from pathlib import Path
from typing import BinaryIO, Iterator
from urllib.parse import quote
from uuid import uuid4

from fastapi.responses import FileResponse, Response, StreamingResponse

from app.core.exceptions import PayloadTooLargeError, ResourceNotFoundError, ValidationError


@dataclass(frozen=True)
class StoredFile:
    object_key: str
    storage_name: str
    file_size: int
    file_hash: str


class StorageService(ABC):
    provider: str

    def generate_object_key(self, extension: str) -> str:
        now = datetime.now()
        normalized = extension.lower().lstrip(".")
        return f"medical-records/{now:%Y/%m}/{uuid4().hex}.{normalized}"

    @abstractmethod
    def save(self, stream: BinaryIO, object_key: str, *, max_bytes: int, content_type: str) -> StoredFile: ...

    @abstractmethod
    def open(self, object_key: str) -> BinaryIO: ...

    @abstractmethod
    def delete(self, object_key: str) -> None: ...

    @abstractmethod
    def exists(self, object_key: str) -> bool: ...

    @abstractmethod
    def get_download_response(self, object_key: str, *, filename: str, media_type: str, inline: bool = False) -> Response: ...


class LocalStorageService(StorageService):
    provider = "local"
    CHUNK_SIZE = 1024 * 1024

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def _resolve(self, object_key: str) -> Path:
        if not object_key or Path(object_key).is_absolute():
            raise ValidationError("非法对象键")
        path = (self.root / object_key).resolve()
        try:
            path.relative_to(self.root)
        except ValueError as exc:
            raise ValidationError("非法对象键") from exc
        return path

    def save(self, stream: BinaryIO, object_key: str, *, max_bytes: int, content_type: str) -> StoredFile:
        del content_type
        path = self._resolve(object_key)
        path.parent.mkdir(parents=True, exist_ok=True)
        digest = sha256()
        size = 0
        try:
            with path.open("xb") as destination:
                while chunk := stream.read(self.CHUNK_SIZE):
                    size += len(chunk)
                    if size > max_bytes:
                        raise PayloadTooLargeError(f"文件大小不能超过 {max_bytes // 1024 // 1024} MB")
                    digest.update(chunk)
                    destination.write(chunk)
        except Exception:
            path.unlink(missing_ok=True)
            raise
        return StoredFile(object_key, path.name, size, digest.hexdigest())

    def open(self, object_key: str) -> BinaryIO:
        path = self._resolve(object_key)
        if not path.is_file():
            raise ResourceNotFoundError("附件文件不存在")
        return path.open("rb")

    def delete(self, object_key: str) -> None:
        self._resolve(object_key).unlink(missing_ok=True)

    def exists(self, object_key: str) -> bool:
        return self._resolve(object_key).is_file()

    def get_download_response(self, object_key: str, *, filename: str, media_type: str, inline: bool = False) -> Response:
        path = self._resolve(object_key)
        if not path.is_file():
            raise ResourceNotFoundError("附件文件不存在")
        return FileResponse(path, media_type=media_type, filename=filename, content_disposition_type="inline" if inline else "attachment")


class _HashingLimitedReader:
    def __init__(self, stream: BinaryIO, max_bytes: int) -> None:
        self.stream = stream
        self.max_bytes = max_bytes
        self.size = 0
        self.digest = sha256()

    def read(self, size: int = -1) -> bytes:
        chunk = self.stream.read(size)
        self.size += len(chunk)
        if self.size > self.max_bytes:
            raise PayloadTooLargeError(f"文件大小不能超过 {self.max_bytes // 1024 // 1024} MB")
        self.digest.update(chunk)
        return chunk


class MinioStorageService(StorageService):
    provider = "minio"

    def __init__(self, *, endpoint: str, access_key: str, secret_key: str, bucket: str, secure: bool) -> None:
        try:
            from minio import Minio
        except ImportError as exc:
            raise RuntimeError("启用 MinIO 前请安装可选依赖 minio") from exc
        self.client = Minio(endpoint, access_key=access_key, secret_key=secret_key, secure=secure)
        self.bucket = bucket
        if not self.client.bucket_exists(bucket):
            self.client.make_bucket(bucket)

    def save(self, stream: BinaryIO, object_key: str, *, max_bytes: int, content_type: str) -> StoredFile:
        reader = _HashingLimitedReader(stream, max_bytes)
        try:
            self.client.put_object(self.bucket, object_key, reader, length=-1, part_size=5 * 1024 * 1024, content_type=content_type)
        except Exception:
            try:
                self.client.remove_object(self.bucket, object_key)
            except Exception:
                pass
            raise
        return StoredFile(object_key, Path(object_key).name, reader.size, reader.digest.hexdigest())

    def open(self, object_key: str):
        if not self.exists(object_key):
            raise ResourceNotFoundError("附件文件不存在")
        return self.client.get_object(self.bucket, object_key)

    def delete(self, object_key: str) -> None:
        self.client.remove_object(self.bucket, object_key)

    def exists(self, object_key: str) -> bool:
        try:
            self.client.stat_object(self.bucket, object_key)
            return True
        except Exception:
            return False

    def get_download_response(self, object_key: str, *, filename: str, media_type: str, inline: bool = False) -> Response:
        response = self.open(object_key)

        def chunks() -> Iterator[bytes]:
            try:
                for chunk in response.stream(1024 * 1024):
                    yield chunk
            finally:
                response.close()
                response.release_conn()

        disposition = "inline" if inline else "attachment"
        safe_name = quote(filename.replace("\r", "").replace("\n", ""))
        return StreamingResponse(chunks(), media_type=media_type, headers={"Content-Disposition": f"{disposition}; filename*=UTF-8''{safe_name}"})


def build_storage_service(settings) -> StorageService:
    if settings.storage_provider == "local":
        return LocalStorageService(settings.local_storage_path)
    required = {
        "MINIO_ENDPOINT": settings.minio_endpoint,
        "MINIO_ACCESS_KEY": settings.minio_access_key,
        "MINIO_SECRET_KEY": settings.minio_secret_key,
        "MINIO_BUCKET": settings.minio_bucket,
    }
    missing = [name for name, value in required.items() if not value]
    if missing:
        raise RuntimeError(f"MinIO 配置不完整：{', '.join(missing)}")
    return MinioStorageService(
        endpoint=settings.minio_endpoint,
        access_key=settings.minio_access_key.get_secret_value(),
        secret_key=settings.minio_secret_key.get_secret_value(),
        bucket=settings.minio_bucket,
        secure=settings.minio_secure,
    )
