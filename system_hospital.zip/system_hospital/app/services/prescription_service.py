"""处方、处方项目、签发与取消业务。"""

from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.exceptions import (
    ConflictError,
    InvalidMedicalRecordStateError,
    ResourceNotFoundError,
    ValidationError,
)
from app.models.enums import (
    EncounterType,
    PrescriptionStatus,
    PrescriptionType,
)
from app.models.prescription import Prescription, PrescriptionItem
from app.models.user import User
from app.repositories.prescription_repository import (
    PrescriptionItemRepository,
    PrescriptionRepository,
)
from app.repositories.user_repository import UserRepository
from app.schemas.prescription import (
    PrescriptionCancelRequest,
    PrescriptionCreate,
    PrescriptionDetail,
    PrescriptionItemCreate,
    PrescriptionItemRead,
    PrescriptionItemUpdate,
    PrescriptionListItem,
    PrescriptionRead,
    PrescriptionStatusResponse,
    PrescriptionUpdate,
)
from app.services.audit_service import AuditContext, AuditService
from app.services.catalog_service import CatalogService
from app.services.medical_record_service import MedicalRecordService
from app.services.sequence_service import SequenceService


class PrescriptionService:
    def __init__(self, db: Session) -> None:
        self.db = db
        self.repository = PrescriptionRepository(db)
        self.items = PrescriptionItemRepository(db)
        self.records = MedicalRecordService(db)
        self.users = UserRepository(db)
        self.sequences = SequenceService(db)
        self.audit = AuditService(db)
        self.catalogs = CatalogService(db)

    def create_prescription(
        self,
        record_id: int,
        payload: PrescriptionCreate,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> PrescriptionDetail:
        record = self.records.get_editable_record(record_id, operator=operator)
        prescription_type = payload.prescription_type or self._default_type(
            record.encounter.encounter_type
        )
        self._validate_type(record.encounter.encounter_type, prescription_type)
        roles = self.users.get_role_codes(operator.id)
        doctor_id = (
            operator.id
            if roles & {"DOCTOR", "SENIOR_DOCTOR"}
            else record.encounter.doctor_id
        )
        for attempt in range(3):
            try:
                prescription = Prescription(
                    prescription_no=self.sequences.generate_number(
                        prefix="RX", sequence_name="prescription"
                    ),
                    encounter_id=record.encounter_id,
                    record_id=record.id,
                    doctor_id=doctor_id,
                    prescription_type=prescription_type,
                    status=PrescriptionStatus.DRAFT,
                    notes=payload.notes,
                )
                self.repository.create(prescription)
                for item_payload in payload.items:
                    item = self._new_item(prescription.id, item_payload)
                    self.items.create(item)
                    self._audit_item_create(
                        item, operator=operator, audit_context=audit_context
                    )
                self.audit.record(
                    user_id=operator.id,
                    action="PRESCRIPTION_CREATE",
                    module="prescription",
                    target_type="prescription",
                    target_id=prescription.id,
                    context=audit_context,
                    new_value={
                        "prescription_no": prescription.prescription_no,
                        "record_id": record.id,
                        "prescription_type": prescription_type.value,
                        "item_count": len(payload.items),
                    },
                )
                self.db.commit()
                result = self.repository.get_by_id(prescription.id)
                assert result is not None
                return self._detail(result)
            except IntegrityError as exc:
                self.db.rollback()
                if attempt == 2:
                    raise ConflictError("处方编号生成冲突，请重试") from exc
            except Exception:
                self.db.rollback()
                raise
        raise ConflictError("处方编号生成失败")

    def list_prescriptions(
        self, record_id: int, *, operator: User
    ) -> list[PrescriptionListItem]:
        self.records.get_record(record_id, operator=operator)
        return [
            PrescriptionListItem(
                **PrescriptionRead.model_validate(item).model_dump(),
                item_count=len(self._active_items(item)),
            )
            for item in self.repository.list_by_record(record_id)
        ]

    def get_prescription_detail(
        self, prescription_id: int, *, operator: User
    ) -> PrescriptionDetail:
        prescription = self._get(prescription_id)
        self.records.get_record(prescription.record_id, operator=operator)
        return self._detail(prescription)

    def get_editable_prescription_detail(
        self, prescription_id: int, *, operator: User
    ) -> PrescriptionDetail:
        """为服务端表单读取可编辑草稿处方。"""
        return self._detail(
            self._get_editable(prescription_id, operator=operator)
        )

    def update_prescription(
        self,
        prescription_id: int,
        payload: PrescriptionUpdate,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> PrescriptionDetail:
        prescription = self._get_editable(prescription_id, operator=operator)
        changes = payload.model_dump(exclude_unset=True)
        if not changes:
            raise ValidationError("没有可更新的处方字段")
        if "prescription_type" in changes:
            self._validate_type(
                prescription.record.encounter.encounter_type,
                changes["prescription_type"],
            )
        changed_fields = sorted(
            field
            for field, value in changes.items()
            if getattr(prescription, field) != value
        )
        if not changed_fields:
            raise ValidationError("处方内容没有变化")
        try:
            for field in changed_fields:
                setattr(prescription, field, changes[field])
            self.repository.update(prescription)
            self.audit.record(
                user_id=operator.id,
                action="PRESCRIPTION_UPDATE",
                module="prescription",
                target_type="prescription",
                target_id=prescription.id,
                context=audit_context,
                old_value={"changed_fields": changed_fields},
                new_value={"changed_fields": changed_fields},
            )
            self.db.commit()
            result = self.repository.get_by_id(prescription.id)
            assert result is not None
            return self._detail(result)
        except Exception:
            self.db.rollback()
            raise

    def add_item(
        self,
        prescription_id: int,
        payload: PrescriptionItemCreate,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> PrescriptionItemRead:
        prescription = self._get_editable(prescription_id, operator=operator)
        try:
            item = self._new_item(prescription.id, payload)
            self.items.create(item)
            self._audit_item_create(
                item, operator=operator, audit_context=audit_context
            )
            self.db.commit()
            self.db.refresh(item)
            # 同一事务会话内后续读取处方详情时也必须看到新项目。
            self.db.expire(prescription, ["items"])
            return PrescriptionItemRead.model_validate(item)
        except Exception:
            self.db.rollback()
            raise

    def update_item(
        self,
        item_id: int,
        payload: PrescriptionItemUpdate,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> PrescriptionItemRead:
        item = self._get_item(item_id)
        self._ensure_prescription_editable(item.prescription, operator=operator)
        changes = payload.model_dump(exclude_unset=True)
        catalog_id = changes.get("drug_catalog_id")
        if catalog_id is not None:
            drug = self.catalogs.get_drug(catalog_id)
            changes.update(
                drug_name=drug.drug_name,
                generic_name=drug.generic_name,
                dosage_form=drug.dosage_form,
                specification=drug.specification,
                dosage_unit=drug.unit,
                quantity_unit=drug.unit,
            )
        if not changes:
            raise ValidationError("没有可更新的处方项目字段")
        changed_fields = sorted(
            field for field, value in changes.items() if getattr(item, field) != value
        )
        if not changed_fields:
            raise ValidationError("处方项目内容没有变化")
        try:
            for field in changed_fields:
                setattr(item, field, changes[field])
            self.items.update(item)
            self.audit.record(
                user_id=operator.id,
                action="PRESCRIPTION_ITEM_UPDATE",
                module="prescription",
                target_type="prescription_item",
                target_id=item.id,
                context=audit_context,
                old_value={"changed_fields": changed_fields},
                new_value={"changed_fields": changed_fields},
            )
            self.db.commit()
            self.db.refresh(item)
            return PrescriptionItemRead.model_validate(item)
        except Exception:
            self.db.rollback()
            raise

    def remove_item(
        self,
        item_id: int,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> None:
        item = self._get_item(item_id)
        self._ensure_prescription_editable(item.prescription, operator=operator)
        try:
            self.items.soft_delete(item, datetime.now(timezone.utc))
            self.audit.record(
                user_id=operator.id,
                action="PRESCRIPTION_ITEM_DELETE",
                module="prescription",
                target_type="prescription_item",
                target_id=item.id,
                context=audit_context,
                old_value={"prescription_id": item.prescription_id},
                new_value={"deleted": True},
            )
            self.db.commit()
        except Exception:
            self.db.rollback()
            raise

    def issue_prescription(
        self,
        prescription_id: int,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> PrescriptionStatusResponse:
        prescription = self._get_editable(prescription_id, operator=operator)
        items = self.items.list_by_prescription(prescription.id)
        if not items:
            raise ValidationError("处方至少需要一个有效项目才能签发")
        invalid_ids = [item.id for item in items if not self._valid_for_issue(item)]
        if invalid_ids:
            raise ValidationError(
                f"处方项目用药信息不完整：{', '.join(map(str, invalid_ids))}"
            )
        old_status = prescription.status
        try:
            prescription.status = PrescriptionStatus.ISSUED
            self.repository.update(prescription)
            self.audit.record(
                user_id=operator.id,
                action="PRESCRIPTION_ISSUE",
                module="prescription",
                target_type="prescription",
                target_id=prescription.id,
                context=audit_context,
                old_value={"status": old_status.value},
                new_value={
                    "status": PrescriptionStatus.ISSUED.value,
                    "item_count": len(items),
                },
            )
            self.db.commit()
            return PrescriptionStatusResponse(
                id=prescription.id,
                prescription_no=prescription.prescription_no,
                old_status=old_status,
                status=prescription.status,
            )
        except Exception:
            self.db.rollback()
            raise

    def cancel_prescription(
        self,
        prescription_id: int,
        payload: PrescriptionCancelRequest,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> PrescriptionStatusResponse:
        prescription = self._get(prescription_id)
        self.records.get_editable_record(
            prescription.record_id, operator=operator
        )
        if prescription.status not in {
            PrescriptionStatus.DRAFT,
            PrescriptionStatus.ISSUED,
        }:
            raise InvalidMedicalRecordStateError("当前处方状态不允许取消")
        old_status = prescription.status
        cancelled_at = datetime.now(timezone.utc)
        try:
            prescription.status = PrescriptionStatus.CANCELLED
            prescription.cancelled_by = operator.id
            prescription.cancelled_at = cancelled_at
            prescription.cancel_reason = payload.reason
            self.repository.update(prescription)
            self.audit.record(
                user_id=operator.id,
                action="PRESCRIPTION_CANCEL",
                module="prescription",
                target_type="prescription",
                target_id=prescription.id,
                context=audit_context,
                old_value={"status": old_status.value},
                new_value={
                    "status": PrescriptionStatus.CANCELLED.value,
                    "has_reason": True,
                },
            )
            self.db.commit()
            return PrescriptionStatusResponse(
                id=prescription.id,
                prescription_no=prescription.prescription_no,
                old_status=old_status,
                status=prescription.status,
                cancelled_by=operator.id,
                cancelled_at=cancelled_at,
                cancel_reason=payload.reason,
            )
        except Exception:
            self.db.rollback()
            raise

    def _get(self, prescription_id: int) -> Prescription:
        prescription = self.repository.get_by_id(prescription_id)
        if prescription is None:
            raise ResourceNotFoundError("处方不存在")
        return prescription

    def _get_editable(
        self, prescription_id: int, *, operator: User
    ) -> Prescription:
        prescription = self._get(prescription_id)
        self._ensure_prescription_editable(prescription, operator=operator)
        return prescription

    def _ensure_prescription_editable(
        self, prescription: Prescription, *, operator: User
    ) -> None:
        self.records.get_editable_record(
            prescription.record_id, operator=operator
        )
        if prescription.order_id is not None:
            raise InvalidMedicalRecordStateError(
                "该处方由药物医嘱自动生成，请编辑对应医嘱"
            )
        if prescription.status != PrescriptionStatus.DRAFT:
            raise InvalidMedicalRecordStateError("只有草稿处方允许修改")

    def _get_item(self, item_id: int) -> PrescriptionItem:
        item = self.items.get_by_id(item_id)
        if item is None:
            raise ResourceNotFoundError("处方项目不存在")
        return item

    def _new_item(
        self, prescription_id: int, payload: PrescriptionItemCreate
    ) -> PrescriptionItem:
        values = payload.model_dump()
        if payload.drug_catalog_id is not None:
            drug = self.catalogs.get_drug(payload.drug_catalog_id)
            values.update(
                drug_name=drug.drug_name,
                generic_name=drug.generic_name,
                dosage_form=drug.dosage_form,
                specification=drug.specification,
                dosage_unit=drug.unit,
                quantity_unit=drug.unit,
            )
        return PrescriptionItem(
            prescription_id=prescription_id,
            **values,
        )

    def _audit_item_create(
        self,
        item: PrescriptionItem,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> None:
        self.audit.record(
            user_id=operator.id,
            action="PRESCRIPTION_ITEM_CREATE",
            module="prescription",
            target_type="prescription_item",
            target_id=item.id,
            context=audit_context,
            new_value={
                "prescription_id": item.prescription_id,
                "sort_order": item.sort_order,
            },
        )

    @staticmethod
    def _detail(prescription: Prescription) -> PrescriptionDetail:
        return PrescriptionDetail(
            **PrescriptionRead.model_validate(prescription).model_dump(),
            items=[
                PrescriptionItemRead.model_validate(item)
                for item in PrescriptionService._active_items(prescription)
            ],
        )

    @staticmethod
    def _active_items(prescription: Prescription) -> list[PrescriptionItem]:
        return [item for item in prescription.items if item.deleted_at is None]

    @staticmethod
    def _valid_for_issue(item: PrescriptionItem) -> bool:
        if not item.drug_name.strip() or not (item.frequency or "").strip():
            return False
        try:
            return Decimal((item.dosage or "").strip()) > 0
        except (InvalidOperation, ValueError):
            return False

    @staticmethod
    def _default_type(encounter_type: EncounterType) -> PrescriptionType:
        if encounter_type == EncounterType.OUTPATIENT:
            return PrescriptionType.OUTPATIENT
        if encounter_type == EncounterType.INPATIENT:
            return PrescriptionType.INPATIENT
        return PrescriptionType.OTHER

    @staticmethod
    def _validate_type(
        encounter_type: EncounterType, prescription_type: PrescriptionType
    ) -> None:
        allowed = {
            EncounterType.OUTPATIENT: {
                PrescriptionType.OUTPATIENT,
                PrescriptionType.OTHER,
            },
            EncounterType.INPATIENT: {
                PrescriptionType.INPATIENT,
                PrescriptionType.DISCHARGE,
                PrescriptionType.OTHER,
            },
            EncounterType.EMERGENCY: {
                PrescriptionType.OUTPATIENT,
                PrescriptionType.OTHER,
            },
        }
        if prescription_type not in allowed[encounter_type]:
            raise ValidationError("处方类型与就诊类型不匹配")
