"""统一的只追加审计日志服务。"""

from dataclasses import dataclass
from typing import Any

from sqlalchemy.orm import Session

from app.models.audit_log import AuditLog


@dataclass(frozen=True)
class AuditContext:
    request_method: str | None = None
    request_path: str | None = None
    ip_address: str | None = None


class AuditService:
    def __init__(self, db: Session) -> None:
        self.db = db

    def record(
        self,
        *,
        user_id: int,
        action: str,
        module: str,
        target_type: str,
        target_id: int,
        context: AuditContext,
        old_value: dict[str, Any] | None = None,
        new_value: dict[str, Any] | None = None,
    ) -> AuditLog:
        log = AuditLog(
            user_id=user_id,
            action=action,
            module=module,
            target_type=target_type,
            target_id=target_id,
            request_method=context.request_method,
            request_path=context.request_path,
            ip_address=context.ip_address,
            old_value=old_value,
            new_value=new_value,
        )
        self.db.add(log)
        self.db.flush()
        return log

