"""角色、权限与科室管理业务。"""

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.exceptions import ConflictError, ResourceNotFoundError, ValidationError
from app.models.enums import DepartmentStatus
from app.models.department import Department
from app.models.role import ACTIVE_ROLE_CODES
from app.repositories.role_repository import RoleRepository
from app.schemas.department import (
    DepartmentCreate,
    DepartmentResponse,
    DepartmentUpdate,
)
from app.schemas.role import PermissionResponse, RoleResponse


class AdminService:
    def __init__(self, db: Session) -> None:
        self.db = db
        self.repository = RoleRepository(db)

    def list_roles(self) -> list[RoleResponse]:
        return [
            RoleResponse(
                id=role.id,
                code=role.code,
                name=role.name,
                description=role.description,
                created_at=role.created_at,
                updated_at=role.updated_at,
                permissions=self.repository.get_permission_codes(role.id),
            )
            for role in self.repository.list_roles()
            if role.code in ACTIVE_ROLE_CODES
        ]

    def list_permissions(self) -> list[PermissionResponse]:
        return [
            PermissionResponse.model_validate(permission)
            for permission in self.repository.list_permissions()
        ]

    def list_departments(self) -> list[DepartmentResponse]:
        return [
            DepartmentResponse.model_validate(department)
            for department in self.repository.list_departments()
        ]

    def create_department(self, payload: DepartmentCreate) -> Department:
        code = payload.department_code.strip().upper()
        if self.repository.get_department_by_code(code) is not None:
            raise ConflictError("科室编码已存在")
        department = Department(
            department_code=code,
            name=payload.name.strip(),
            description=(payload.description.strip() if payload.description else None),
            status=payload.status,
        )
        try:
            self.db.add(department)
            self.db.commit()
            self.db.refresh(department)
            return department
        except IntegrityError as exc:
            self.db.rollback()
            raise ConflictError("科室编码已存在") from exc
        except Exception:
            self.db.rollback()
            raise

    def get_department(self, department_id: int) -> Department:
        department = self.repository.get_department(department_id)
        if department is None:
            raise ResourceNotFoundError("科室不存在")
        return department

    def update_department(
        self, department_id: int, payload: DepartmentUpdate
    ) -> Department:
        department = self.get_department(department_id)
        changes = payload.model_dump(exclude_unset=True)
        if not changes:
            raise ValidationError("没有可更新的科室信息")
        if "name" in changes and changes["name"] is not None:
            changes["name"] = changes["name"].strip()
        if "description" in changes and changes["description"] is not None:
            changes["description"] = changes["description"].strip() or None
        for field, value in changes.items():
            setattr(department, field, value)
        try:
            self.db.commit()
            self.db.refresh(department)
            return department
        except Exception:
            self.db.rollback()
            raise

    def set_department_active(
        self, department_id: int, *, active: bool
    ) -> Department:
        return self.update_department(
            department_id,
            DepartmentUpdate(
                status=(
                    DepartmentStatus.ACTIVE
                    if active
                    else DepartmentStatus.INACTIVE
                )
            ),
        )

    def assign_role_permissions(
        self, role_id: int, permission_ids: list[int]
    ) -> RoleResponse:
        role = self.repository.get_role(role_id)
        if role is None:
            raise ResourceNotFoundError("角色不存在")
        unique_ids = set(permission_ids)
        if len(self.repository.get_permissions_by_ids(unique_ids)) != len(unique_ids):
            raise ResourceNotFoundError("一个或多个权限不存在")
        try:
            self.repository.replace_role_permissions(role.id, unique_ids)
            self.db.commit()
        except Exception:
            self.db.rollback()
            raise
        return next(item for item in self.list_roles() if item.id == role.id)
