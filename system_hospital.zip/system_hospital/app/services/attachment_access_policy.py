"""附件查看、上传和软删除数据范围策略。"""

from app.models.attachment import Attachment
from app.models.enums import MedicalRecordStatus
from app.models.medical_record import MedicalRecord
from app.models.user import User
from app.repositories.user_repository import UserRepository
from app.services.medical_record_access_policy import MedicalRecordAccessPolicy


class AttachmentAccessPolicy:
    def __init__(self, users: UserRepository) -> None:
        self.users = users
        self.records = MedicalRecordAccessPolicy(users)

    def can_view(self, record: MedicalRecord, user: User) -> bool:
        return self.records.can_view(record, user)

    def can_upload(self, record: MedicalRecord, user: User) -> bool:
        roles = self.users.get_role_codes(user.id)
        if user.is_superuser or "ADMIN" in roles:
            return True
        if roles & {"LAB_TECHNICIAN", "RADIOLOGY_TECHNICIAN"}:
            return self.records.can_view(record, user)
        return self.records.can_update(record, user)

    def can_delete(self, attachment: Attachment, record: MedicalRecord, user: User) -> bool:
        if record.status not in {MedicalRecordStatus.DRAFT, MedicalRecordStatus.REJECTED}:
            return False
        roles = self.users.get_role_codes(user.id)
        return user.is_superuser or "ADMIN" in roles or attachment.uploaded_by == user.id
