"""登录认证业务。"""

from app.core.exceptions import AuthenticationError, PermissionDeniedError
from app.core.security import verify_password
from app.models.base import utc_now
from app.models.enums import UserStatus
from app.models.user import User
from app.repositories.user_repository import UserRepository


class AuthService:
    def __init__(self, repository: UserRepository) -> None:
        self.repository = repository

    def authenticate(self, username: str, password: str) -> User:
        """验证账号状态与密码；失败时不泄露账号是否存在。"""
        user = self.repository.get_by_username(username.strip())
        if user is None or not verify_password(password, user.password_hash):
            raise AuthenticationError("用户名或密码错误")
        if user.status != UserStatus.ACTIVE or not user.is_active:
            raise PermissionDeniedError("账号已被禁用")

        user.last_login_at = utc_now()
        self.repository.db.commit()
        self.repository.db.refresh(user)
        return user
