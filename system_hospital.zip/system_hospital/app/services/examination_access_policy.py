"""检查报告数据范围策略；检查回报不受病历可编辑状态限制。"""

from app.models.medical_record import MedicalRecord
from app.models.user import User
from app.repositories.user_repository import UserRepository
from app.services.medical_record_access_policy import MedicalRecordAccessPolicy


class ExaminationAccessPolicy:
    def __init__(self, users: UserRepository) -> None:
        self.users = users
        self.records = MedicalRecordAccessPolicy(users)

    def can_view(self, record: MedicalRecord, user: User) -> bool:
        return self.records.can_view(record, user)

    def can_create(self, record: MedicalRecord, user: User) -> bool:
        roles = self.users.get_role_codes(user.id)
        return (user.is_superuser or bool(roles & {"ADMIN", "DOCTOR", "SENIOR_DOCTOR"})) and self.records.can_update(record, user)

    def can_process(self, user: User) -> bool:
        roles = self.users.get_role_codes(user.id)
        return user.is_superuser or bool(roles & {"ADMIN", "RADIOLOGY_TECHNICIAN"})
