"""检验报告状态机、结果录入与查询业务。"""

from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.core.exceptions import InvalidMedicalRecordStateError, PermissionDeniedError, ResourceNotFoundError
from app.models.enums import LabReportStatus
from app.models.lab_report import LabReport, LabResult
from app.models.user import User
from app.repositories.lab_report_repository import LabReportRepository, LabResultRepository
from app.repositories.medical_record_repository import MedicalRecordRepository
from app.repositories.user_repository import UserRepository
from app.schemas.lab_report import LabReportCancel, LabReportComplete, LabReportCreate, LabReportDetail, LabReportFilter, LabResultRead, LabResultsBatchCreate, LabResultUpdate
from app.services.audit_service import AuditContext, AuditService
from app.services.catalog_service import CatalogService
from app.services.lab_report_access_policy import LabReportAccessPolicy
from app.services.sequence_service import SequenceService


class LabReportService:
    def __init__(self, db: Session) -> None:
        self.db = db
        self.reports = LabReportRepository(db)
        self.results = LabResultRepository(db)
        self.records = MedicalRecordRepository(db)
        self.policy = LabReportAccessPolicy(UserRepository(db))
        self.audit = AuditService(db)
        self.sequence = SequenceService(db)
        self.catalogs = CatalogService(db)

    def create_report(self, record_id: int, payload: LabReportCreate, *, operator: User, audit_context: AuditContext) -> LabReportDetail:
        record = self._record(record_id, operator)
        if not self.policy.can_create(record, operator):
            raise PermissionDeniedError("无权为该病历创建检验报告")
        try:
            values = payload.model_dump()
            if payload.lab_test_catalog_id is not None:
                catalog = self.catalogs.get_lab_test(payload.lab_test_catalog_id)
                values.update(
                    report_name=catalog.test_name,
                    report_type=catalog.result_type,
                )
            report = LabReport(
                report_no=self.sequence.generate_number(prefix="LAB", sequence_name="lab_report"),
                patient_id=record.encounter.patient_id,
                encounter_id=record.encounter_id,
                record_id=record.id,
                status=LabReportStatus.PENDING,
                requested_by=operator.id,
                **values,
            )
            self.reports.create(report)
            self.audit.record(user_id=operator.id, action="LAB_REPORT_CREATE", module="lab", target_type="lab_report", target_id=report.id, context=audit_context, new_value={"report_no": report.report_no, "record_id": record.id})
            self.db.commit()
            return self._read(self.reports.get_by_id(report.id))
        except Exception:
            self.db.rollback()
            raise

    def start_report(self, report_id: int, *, operator: User, audit_context: AuditContext) -> LabReportDetail:
        report, _ = self._report(report_id, operator)
        if not self.policy.can_process(operator):
            raise PermissionDeniedError("仅检验人员或管理员可以开始处理检验报告")
        if report.status != LabReportStatus.PENDING:
            raise InvalidMedicalRecordStateError("只有待处理检验报告可以开始")
        try:
            report.status = LabReportStatus.IN_PROGRESS
            report.performed_by = operator.id
            self.audit.record(user_id=operator.id, action="LAB_REPORT_START", module="lab", target_type="lab_report", target_id=report.id, context=audit_context, old_value={"status": "PENDING"}, new_value={"status": "IN_PROGRESS"})
            self.db.commit()
            return self._read(self.reports.get_by_id(report.id))
        except Exception:
            self.db.rollback()
            raise

    def add_results(self, report_id: int, payload: LabResultsBatchCreate, *, operator: User, audit_context: AuditContext) -> list[LabResultRead]:
        report, _ = self._report(report_id, operator)
        if not self.policy.can_process(operator):
            raise PermissionDeniedError("仅检验人员或管理员可以录入检验结果")
        if report.status != LabReportStatus.IN_PROGRESS:
            raise InvalidMedicalRecordStateError("只有处理中检验报告可以录入结果")
        try:
            items = []
            for item in payload.results:
                values = item.model_dump()
                if item.lab_test_catalog_id is not None:
                    catalog = self.catalogs.get_lab_test(item.lab_test_catalog_id)
                    values.update(
                        item_code=catalog.test_code,
                        item_name=catalog.test_name,
                        unit=catalog.unit,
                        reference_range=catalog.reference_range,
                    )
                items.append(LabResult(lab_report_id=report.id, **values))
            self.results.create_many(items)
            self.audit.record(user_id=operator.id, action="LAB_RESULT_CREATE", module="lab", target_type="lab_report", target_id=report.id, context=audit_context, new_value={"created_count": len(items), "item_codes": [item.item_code for item in items]})
            self.db.commit()
            return [LabResultRead.model_validate(item) for item in items]
        except Exception:
            self.db.rollback()
            raise

    def update_result(self, result_id: int, payload: LabResultUpdate, *, operator: User, audit_context: AuditContext) -> LabResultRead:
        result = self.results.get_by_id(result_id)
        if result is None:
            raise ResourceNotFoundError("检验结果不存在")
        report, _ = self._report(result.lab_report_id, operator)
        if not self.policy.can_process(operator):
            raise PermissionDeniedError("无权修改检验结果")
        if report.status == LabReportStatus.COMPLETED:
            raise InvalidMedicalRecordStateError("已完成检验报告的结果不能直接修改")
        if report.status != LabReportStatus.IN_PROGRESS:
            raise InvalidMedicalRecordStateError("当前检验报告状态不允许修改结果")
        changes = payload.model_dump(exclude_unset=True)
        catalog_id = changes.get("lab_test_catalog_id")
        if catalog_id is not None:
            catalog = self.catalogs.get_lab_test(catalog_id)
            changes.update(
                item_code=catalog.test_code,
                item_name=catalog.test_name,
                unit=catalog.unit,
                reference_range=catalog.reference_range,
            )
        next_value = changes.get("result_value", result.result_value)
        next_text = changes.get("result_text", result.result_text)
        if not (next_value or next_text):
            raise InvalidMedicalRecordStateError(
                "result_value 和 result_text 至少保留一项"
            )
        try:
            for name, value in changes.items():
                setattr(result, name, value)
            self.audit.record(user_id=operator.id, action="LAB_RESULT_UPDATE", module="lab", target_type="lab_result", target_id=result.id, context=audit_context, new_value={"changed_fields": sorted(changes)})
            self.db.commit()
            return LabResultRead.model_validate(result)
        except Exception:
            self.db.rollback()
            raise

    def complete_report(self, report_id: int, payload: LabReportComplete, *, operator: User, audit_context: AuditContext) -> LabReportDetail:
        report, _ = self._report(report_id, operator)
        if not self.policy.can_process(operator):
            raise PermissionDeniedError("仅检验人员或管理员可以完成检验报告")
        if report.status != LabReportStatus.IN_PROGRESS:
            raise InvalidMedicalRecordStateError("只有处理中检验报告可以完成")
        if not self.results.list_by_report(report.id):
            raise InvalidMedicalRecordStateError("检验报告至少需要一项有效结果")
        now = datetime.now(timezone.utc)
        try:
            report.result_summary = payload.result_summary
            report.conclusion = payload.conclusion
            report.status = LabReportStatus.COMPLETED
            report.performed_by = operator.id
            report.reported_at = now
            self.audit.record(user_id=operator.id, action="LAB_REPORT_COMPLETE", module="lab", target_type="lab_report", target_id=report.id, context=audit_context, old_value={"status": "IN_PROGRESS"}, new_value={"status": "COMPLETED", "result_count": len(report.results)})
            self.db.commit()
            return self._read(self.reports.get_by_id(report.id))
        except Exception:
            self.db.rollback()
            raise

    def cancel_report(self, report_id: int, payload: LabReportCancel, *, operator: User, audit_context: AuditContext) -> LabReportDetail:
        report, _ = self._report(report_id, operator)
        if not self.policy.can_process(operator):
            raise PermissionDeniedError("仅检验人员或管理员可以取消检验报告")
        if report.status != LabReportStatus.PENDING:
            raise InvalidMedicalRecordStateError("只有待处理检验报告可以取消")
        try:
            report.status = LabReportStatus.CANCELLED
            self.audit.record(user_id=operator.id, action="LAB_REPORT_CANCEL", module="lab", target_type="lab_report", target_id=report.id, context=audit_context, old_value={"status": "PENDING"}, new_value={"status": "CANCELLED", "reason": payload.reason})
            self.db.commit()
            return self._read(self.reports.get_by_id(report.id))
        except Exception:
            self.db.rollback()
            raise

    def get_report(self, report_id: int, *, operator: User) -> LabReportDetail:
        report, _ = self._report(report_id, operator)
        return self._read(report)

    def get_result(self, result_id: int, *, operator: User) -> LabResultRead:
        result = self.results.get_by_id(result_id)
        if result is None:
            raise ResourceNotFoundError("检验结果不存在")
        self._report(result.lab_report_id, operator)
        return LabResultRead.model_validate(result)

    def list_reports(self, record_id: int, params: LabReportFilter, *, operator: User) -> list[LabReportDetail]:
        record = self._record(record_id, operator)
        return [self._read(item) for item in self.reports.list_by_record(record.id, params)]

    def _record(self, record_id: int, operator: User):
        record = self.records.get_by_id(record_id)
        if record is None:
            raise ResourceNotFoundError("病历不存在")
        if not self.policy.can_view(record, operator):
            raise PermissionDeniedError("无权访问该病历")
        return record

    def _report(self, report_id: int, operator: User):
        report = self.reports.get_by_id(report_id)
        if report is None:
            raise ResourceNotFoundError("检验报告不存在")
        return report, self._record(report.record_id, operator)

    @staticmethod
    def _read(report: LabReport | None) -> LabReportDetail:
        assert report is not None
        return LabReportDetail.model_validate(report)
