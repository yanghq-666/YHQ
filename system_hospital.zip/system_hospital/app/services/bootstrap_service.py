"""系统角色、权限、科室和管理员的幂等初始化。"""

from dataclasses import dataclass

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.security import hash_password
from app.models.department import Department
from app.models.catalog import DiagnosisCatalog, DrugCatalog, LabTestCatalog
from app.models.enums import DepartmentStatus, UserStatus
from app.models.permission import Permission, RolePermission
from app.models.role import Role
from app.models.user import User, UserRole


@dataclass(frozen=True)
class PermissionSeed:
    code: str
    name: str
    module: str


PERMISSIONS = (
    PermissionSeed("patient:view", "查看患者", "patient"),
    PermissionSeed("patient:create", "创建患者", "patient"),
    PermissionSeed("patient:update", "修改患者", "patient"),
    PermissionSeed("encounter:view", "查看就诊", "encounter"),
    PermissionSeed("encounter:create", "创建就诊", "encounter"),
    PermissionSeed("encounter:update", "修改就诊", "encounter"),
    PermissionSeed("record:view", "查看病历", "record"),
    PermissionSeed("record:create", "创建病历", "record"),
    PermissionSeed("record:update", "修改病历", "record"),
    PermissionSeed("record:submit", "完成病历", "record"),
    PermissionSeed("record:review", "审核病历", "record"),
    PermissionSeed("record:archive", "归档病历", "record"),
    PermissionSeed("diagnosis:create", "创建诊断", "diagnosis"),
    PermissionSeed("diagnosis:update", "修改诊断", "diagnosis"),
    PermissionSeed("order:create", "创建医嘱", "order"),
    PermissionSeed("order:update", "修改医嘱", "order"),
    PermissionSeed("prescription:create", "创建处方", "prescription"),
    PermissionSeed("prescription:update", "修改处方", "prescription"),
    PermissionSeed("attachment:upload", "上传附件", "attachment"),
    PermissionSeed("attachment:view", "查看附件", "attachment"),
    PermissionSeed("lab:view", "查看检验报告", "lab"),
    PermissionSeed("lab:create", "创建检验报告", "lab"),
    PermissionSeed("lab:update", "处理检验报告", "lab"),
    PermissionSeed("lab:complete", "完成检验报告", "lab"),
    PermissionSeed("examination:view", "查看检查报告", "examination"),
    PermissionSeed("examination:create", "创建检查报告", "examination"),
    PermissionSeed("examination:update", "处理检查报告", "examination"),
    PermissionSeed("examination:complete", "完成检查报告", "examination"),
    PermissionSeed("admin:user", "用户管理", "admin"),
    PermissionSeed("admin:role", "角色权限管理", "admin"),
    PermissionSeed("admin:department", "科室管理", "admin"),
    PermissionSeed("audit:view", "查看审计日志", "audit"),
)

ROLES = {
    "ADMIN": ("系统管理员", "拥有系统全部权限"),
    "DOCTOR": ("医生", "负责患者、就诊和临床病历业务"),
    "LAB_TECHNICIAN": ("检验人员", "处理检验资料"),
}

DOCTOR_PERMISSIONS = {
    "patient:view",
    "patient:create",
    "patient:update",
    "encounter:view",
    "encounter:create",
    "encounter:update",
    "record:view",
    "record:create",
    "record:update",
    "record:submit",
    "diagnosis:create",
    "diagnosis:update",
    "order:create",
    "order:update",
    "prescription:create",
    "prescription:update",
    "attachment:upload",
    "attachment:view",
    "lab:view",
    "lab:create",
    "examination:view",
    "examination:create",
}

ROLE_PERMISSIONS = {
    "ADMIN": {item.code for item in PERMISSIONS},
    "DOCTOR": DOCTOR_PERMISSIONS,
    "LAB_TECHNICIAN": {
        "patient:view",
        "encounter:view",
        "record:view",
        "attachment:upload",
        "attachment:view",
        "lab:view",
        "lab:update",
        "lab:complete",
    },
}

DEPARTMENTS = (
    ("INTERNAL", "内科"),
    ("SURGERY", "外科"),
    ("CARDIOLOGY", "心内科"),
    ("RESPIRATORY", "呼吸科"),
    ("PEDIATRICS", "儿科"),
    ("EMERGENCY", "急诊科"),
    ("LABORATORY", "检验科"),
    ("RADIOLOGY", "影像科"),
    ("RECORDS", "病案室"),
)

DRUG_CATALOGS = (
    ("DRUG001", "对乙酰氨基酚片", "对乙酰氨基酚", "片剂", "0.5g", "片", "演示制药"),
    ("DRUG002", "布洛芬缓释胶囊", "布洛芬", "胶囊剂", "0.3g", "粒", "演示制药"),
    ("DRUG003", "阿莫西林胶囊", "阿莫西林", "胶囊剂", "0.25g", "粒", "演示制药"),
    ("DRUG004", "头孢克肟片", "头孢克肟", "片剂", "0.1g", "片", "演示制药"),
    ("DRUG005", "氯雷他定片", "氯雷他定", "片剂", "10mg", "片", "演示制药"),
    ("DRUG006", "奥美拉唑肠溶胶囊", "奥美拉唑", "胶囊剂", "20mg", "粒", "演示制药"),
    ("DRUG007", "二甲双胍片", "盐酸二甲双胍", "片剂", "0.5g", "片", "演示制药"),
    ("DRUG008", "硝苯地平缓释片", "硝苯地平", "缓释片", "20mg", "片", "演示制药"),
    ("DRUG009", "生理氯化钠溶液", "氯化钠", "注射剂", "0.9% 500ml", "袋", "演示制药"),
    ("DRUG010", "维生素C片", "维生素C", "片剂", "0.1g", "片", "演示制药"),
)

DIAGNOSIS_CATALOGS = (
    ("I10", "原发性高血压"),
    ("E11.9", "2型糖尿病"),
    ("J06.9", "急性上呼吸道感染"),
    ("J18.9", "肺炎"),
    ("K29.7", "胃炎"),
    ("J45.9", "支气管哮喘"),
    ("K21.9", "胃食管反流病"),
    ("N39.0", "泌尿道感染"),
)

LAB_TEST_CATALOGS = (
    ("WBC", "白细胞计数", "10^9/L", "3.5-9.5", "NUMERIC"),
    ("RBC", "红细胞计数", "10^12/L", "3.8-5.8", "NUMERIC"),
    ("HGB", "血红蛋白", "g/L", "115-175", "NUMERIC"),
    ("PLT", "血小板计数", "10^9/L", "125-350", "NUMERIC"),
    ("GLU", "空腹血糖", "mmol/L", "3.9-6.1", "NUMERIC"),
    ("ALT", "丙氨酸氨基转移酶", "U/L", "7-40", "NUMERIC"),
    ("AST", "天门冬氨酸氨基转移酶", "U/L", "13-35", "NUMERIC"),
    ("CREA", "肌酐", "μmol/L", "41-111", "NUMERIC"),
    ("CRP", "C反应蛋白", "mg/L", "0-10", "NUMERIC"),
    ("UA", "尿酸", "μmol/L", "155-428", "NUMERIC"),
)


def initialize_system_data(
    db: Session,
    *,
    admin_username: str,
    admin_password: str,
    admin_real_name: str,
) -> dict[str, int]:
    """幂等写入系统基础数据，已有管理员密码不会被覆盖。"""
    if not admin_username.strip():
        raise ValueError("管理员用户名不能为空")
    if not admin_password:
        raise ValueError("必须通过环境变量提供管理员初始密码")

    try:
        permission_by_code: dict[str, Permission] = {}
        for seed in PERMISSIONS:
            permission = db.scalar(
                select(Permission).where(Permission.code == seed.code)
            )
            if permission is None:
                permission = Permission(
                    code=seed.code,
                    name=seed.name,
                    module=seed.module,
                )
                db.add(permission)
            else:
                permission.name = seed.name
                permission.module = seed.module
            permission_by_code[seed.code] = permission
        db.flush()

        role_by_code: dict[str, Role] = {}
        for code, (name, description) in ROLES.items():
            role = db.scalar(select(Role).where(Role.code == code))
            if role is None:
                role = Role(
                    code=code,
                    name=name,
                    description=description,
                    is_system=True,
                )
                db.add(role)
            else:
                role.name = name
                role.description = description
                role.is_system = True
            role_by_code[code] = role
        db.flush()

        existing_links = set(
            db.execute(
                select(RolePermission.role_id, RolePermission.permission_id)
            ).all()
        )
        for role_code, permission_codes in ROLE_PERMISSIONS.items():
            role = role_by_code[role_code]
            desired_ids = {
                permission_by_code[permission_code].id
                for permission_code in permission_codes
            }
            for link in list(
                db.scalars(
                    select(RolePermission).where(
                        RolePermission.role_id == role.id
                    )
                ).all()
            ):
                if link.permission_id not in desired_ids:
                    db.delete(link)
                    existing_links.discard((role.id, link.permission_id))
            for permission_code in permission_codes:
                permission = permission_by_code[permission_code]
                key = (role.id, permission.id)
                if key not in existing_links:
                    db.add(
                        RolePermission(
                            role_id=role.id,
                            permission_id=permission.id,
                        )
                    )
                    existing_links.add(key)

        for department_code, name in DEPARTMENTS:
            department = db.scalar(
                select(Department).where(
                    Department.department_code == department_code
                )
            )
            if department is None:
                db.add(
                    Department(
                        department_code=department_code,
                        name=name,
                        status=DepartmentStatus.ACTIVE,
                    )
                )
            else:
                department.name = name
        db.flush()

        for code, name, generic, dosage_form, specification, unit, manufacturer in DRUG_CATALOGS:
            item = db.scalar(select(DrugCatalog).where(DrugCatalog.drug_code == code))
            if item is None:
                item = DrugCatalog(drug_code=code, drug_name=name)
                db.add(item)
            item.drug_name = name
            item.generic_name = generic
            item.dosage_form = dosage_form
            item.specification = specification
            item.unit = unit
            item.manufacturer = manufacturer
            item.is_active = True

        for code, name in DIAGNOSIS_CATALOGS:
            item = db.scalar(select(DiagnosisCatalog).where(DiagnosisCatalog.diagnosis_code == code))
            if item is None:
                item = DiagnosisCatalog(diagnosis_code=code, diagnosis_name=name)
                db.add(item)
            item.diagnosis_name = name
            item.is_active = True

        for code, name, unit, reference_range, result_type in LAB_TEST_CATALOGS:
            item = db.scalar(select(LabTestCatalog).where(LabTestCatalog.test_code == code))
            if item is None:
                item = LabTestCatalog(test_code=code, test_name=name)
                db.add(item)
            item.test_name = name
            item.unit = unit
            item.reference_range = reference_range
            item.result_type = result_type
            item.is_active = True
        db.flush()

        admin = db.scalar(
            select(User).where(User.username == admin_username.strip())
        )
        if admin is None:
            admin = User(
                username=admin_username.strip(),
                password_hash=hash_password(admin_password),
                real_name=admin_real_name.strip() or "系统管理员",
                status=UserStatus.ACTIVE,
                is_active=True,
                is_superuser=True,
            )
            db.add(admin)
            db.flush()
        else:
            admin.status = UserStatus.ACTIVE
            admin.is_active = True
            admin.is_superuser = True
            admin.deleted_at = None

        admin_role = role_by_code["ADMIN"]
        admin_link = db.scalar(
            select(UserRole).where(
                UserRole.user_id == admin.id,
                UserRole.role_id == admin_role.id,
            )
        )
        if admin_link is None:
            db.add(UserRole(user_id=admin.id, role_id=admin_role.id))

        db.commit()
        return {
            "permissions": len(PERMISSIONS),
            "roles": len(ROLES),
            "departments": len(DEPARTMENTS),
            "admin_user_id": admin.id,
            "catalogs": len(DRUG_CATALOGS) + len(DIAGNOSIS_CATALOGS) + len(LAB_TEST_CATALOGS),
        }
    except Exception:
        db.rollback()
        raise


def initialize_demo_accounts(db: Session, *, password: str) -> int:
    """幂等创建三角色演示账号，并停用旧流程演示账号。"""
    if len(password) < 8 or len(password.encode("utf-8")) > 72:
        raise ValueError("演示账号密码必须为 8 至 72 个字节")
    specs = (
        ("admin", "演示管理员", None, "ADMIN", True, None),
        ("doctor01", "演示医生", "DEMO-D001", "DOCTOR", False, "INTERNAL"),
        (
            "lab01",
            "演示检验人员",
            "DEMO-L001",
            "LAB_TECHNICIAN",
            False,
            "LABORATORY",
        ),
    )
    try:
        for username, real_name, employee_no, role_code, superuser, dept_code in specs:
            role = db.scalar(select(Role).where(Role.code == role_code))
            department = (
                db.scalar(
                    select(Department).where(
                        Department.department_code == dept_code
                    )
                )
                if dept_code
                else None
            )
            if role is None or (dept_code and department is None):
                raise ValueError("请先初始化角色和科室基础数据")
            user = db.scalar(select(User).where(User.username == username))
            if user is None:
                user = User(
                    username=username,
                    password_hash=hash_password(password),
                    real_name=real_name,
                    employee_no=employee_no,
                    department_id=department.id if department else None,
                    status=UserStatus.ACTIVE,
                    is_active=True,
                    is_superuser=superuser,
                )
                db.add(user)
                db.flush()
            user.password_hash = hash_password(password)
            user.real_name = real_name
            user.department_id = department.id if department else None
            user.status = UserStatus.ACTIVE
            user.is_active = True
            user.is_superuser = superuser
            user.deleted_at = None
            for link in list(
                db.scalars(
                    select(UserRole).where(UserRole.user_id == user.id)
                ).all()
            ):
                db.delete(link)
            db.add(UserRole(user_id=user.id, role_id=role.id))
        for username in ("director01", "record01"):
            legacy_user = db.scalar(select(User).where(User.username == username))
            if legacy_user is not None:
                legacy_user.status = UserStatus.INACTIVE
                legacy_user.is_active = False
        db.commit()
        return len(specs)
    except Exception:
        db.rollback()
        raise
