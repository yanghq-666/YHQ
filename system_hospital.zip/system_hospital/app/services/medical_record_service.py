"""主病历创建、查询、编辑、提交、版本和软删除业务。"""

from datetime import datetime, timezone
from math import ceil
from typing import Any
from zoneinfo import ZoneInfo

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.exceptions import (
    ConflictError,
    EncounterNotFoundError,
    InvalidMedicalRecordStateError,
    MedicalRecordIncompleteError,
    MedicalRecordNotFoundError,
    PermissionDeniedError,
    ResourceNotFoundError,
    ValidationError,
)
from app.models.enums import EncounterStatus, EncounterType, MedicalRecordStatus
from app.models.medical_record import MedicalRecord, MedicalRecordVersion
from app.models.record_review import RecordReview
from app.models.enums import ReviewAction
from app.models.user import User
from app.repositories.encounter_repository import EncounterRepository
from app.repositories.attachment_repository import AttachmentRepository
from app.repositories.diagnosis_repository import DiagnosisRepository
from app.repositories.medical_order_repository import MedicalOrderRepository
from app.repositories.medical_record_repository import (
    MedicalRecordRepository,
    MedicalRecordVersionRepository,
)
from app.repositories.prescription_repository import PrescriptionRepository
from app.repositories.examination_repository import ExaminationRepository
from app.repositories.lab_report_repository import LabReportRepository
from app.schemas.common import PageData
from app.schemas.medical_record import (
    CONTENT_FIELDS,
    MedicalRecordCreate,
    MedicalRecordArchiveResponse,
    MedicalRecordCompleteResponse,
    MedicalRecordDetail,
    MedicalRecordListItem,
    MedicalRecordSearchParams,
    MedicalRecordSubmitResponse,
    MedicalRecordUpdate,
    MedicalRecordVersionRead,
    MyMedicalRecordSearchParams,
)
from app.schemas.attachment import AttachmentRead
from app.schemas.diagnosis import DiagnosisRead
from app.schemas.examination import ExaminationRead
from app.schemas.lab_report import LabReportDetail
from app.schemas.medical_order import MedicalOrderRead
from app.schemas.medical_record_full import MedicalRecordFull
from app.schemas.prescription import (
    PrescriptionDetail,
    PrescriptionItemRead,
    PrescriptionRead,
)
from app.services.audit_service import AuditContext, AuditService
from app.services.medical_record_access_policy import MedicalRecordAccessPolicy
from app.repositories.user_repository import UserRepository
from app.repositories.record_review_repository import RecordReviewRepository
from app.schemas.record_review import MedicalRecordResubmitRequest, RecordReviewRead
from app.services.medical_record_state_machine import MedicalRecordStateMachine

LOCAL_TIMEZONE = ZoneInfo("Asia/Shanghai")


class MedicalRecordService:
    MAX_DAILY_SEQUENCE = 999_999
    SUBMIT_REQUIRED_FIELDS = (
        "chief_complaint",
        "present_illness",
        "physical_exam",
    )
    EDITABLE_STATUSES = MedicalRecordStateMachine.EDITABLE

    def __init__(self, db: Session) -> None:
        self.db = db
        self.repository = MedicalRecordRepository(db)
        self.versions = MedicalRecordVersionRepository(db)
        self.encounters = EncounterRepository(db)
        self.diagnoses = DiagnosisRepository(db)
        self.orders = MedicalOrderRepository(db)
        self.prescriptions = PrescriptionRepository(db)
        self.lab_reports = LabReportRepository(db)
        self.examinations = ExaminationRepository(db)
        self.attachments = AttachmentRepository(db)
        self.users = UserRepository(db)
        self.access_policy = MedicalRecordAccessPolicy(self.users)
        self.audit = AuditService(db)
        self.reviews = RecordReviewRepository(db)

    def create_record(
        self,
        encounter_id: int,
        payload: MedicalRecordCreate,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> MedicalRecordDetail:
        encounter = self.encounters.get_by_id(encounter_id)
        if encounter is None:
            raise EncounterNotFoundError()
        if encounter.status == EncounterStatus.CANCELLED:
            raise InvalidMedicalRecordStateError("已取消就诊不能创建病历")
        if self.repository.exists_by_encounter(
            encounter_id, include_deleted=True
        ):
            raise ConflictError("该就诊已存在主病历")
        if not self.access_policy.can_create(encounter, operator):
            if encounter.status == EncounterStatus.COMPLETED:
                raise PermissionDeniedError("普通医生不能为已完成就诊补录病历")
            raise PermissionDeniedError("无权为该就诊创建病历")

        for attempt in range(3):
            try:
                values = payload.model_dump()
                if not values.get("chief_complaint"):
                    values["chief_complaint"] = encounter.chief_complaint
                if not values.get("allergy_history"):
                    values["allergy_history"] = encounter.patient.allergy_history
                record = MedicalRecord(
                    record_no=self._next_record_no(),
                    encounter_id=encounter.id,
                    status=MedicalRecordStatus.DRAFT,
                    created_by=operator.id,
                    updated_by=operator.id,
                    **values,
                )
                self.repository.create(record)
                self.audit.record(
                    user_id=operator.id,
                    action="MEDICAL_RECORD_CREATE",
                    module="medical_record",
                    target_type="medical_record",
                    target_id=record.id,
                    context=audit_context,
                    new_value=self._audit_metadata(record),
                )
                self.db.commit()
                result = self.repository.get_by_id(record.id)
                assert result is not None
                return MedicalRecordDetail.model_validate(result)
            except IntegrityError as exc:
                self.db.rollback()
                if self.repository.exists_by_encounter(
                    encounter_id, include_deleted=True
                ):
                    raise ConflictError("该就诊已存在主病历") from exc
                if attempt == 2:
                    raise ConflictError("病历编号生成冲突，请重试") from exc
            except Exception:
                self.db.rollback()
                raise
        raise ConflictError("病历编号生成失败")

    def get_record(self, record_id: int, *, operator: User) -> MedicalRecord:
        record = self.repository.get_by_id(record_id)
        if record is None:
            raise MedicalRecordNotFoundError()
        self.validate_record_access(record, operator=operator)
        return record

    def get_record_detail(
        self, record_id: int, *, operator: User
    ) -> MedicalRecordDetail:
        return MedicalRecordDetail.model_validate(
            self.get_record(record_id, operator=operator)
        )

    def get_by_encounter(
        self, encounter_id: int, *, operator: User
    ) -> MedicalRecordDetail:
        encounter = self.encounters.get_by_id(encounter_id)
        if encounter is None:
            raise EncounterNotFoundError()
        record = self.repository.get_by_encounter_id(encounter_id)
        if record is None:
            raise MedicalRecordNotFoundError()
        self.validate_record_access(record, operator=operator)
        return MedicalRecordDetail.model_validate(record)

    def list_records(
        self, params: MedicalRecordSearchParams, *, operator: User
    ) -> PageData[MedicalRecordListItem]:
        records, total = self.repository.search(
            params,
            access_filter=self.access_policy.scope_filter(operator),
        )
        return self._page(records, total, params.page, params.page_size)

    def list_my_records(
        self, params: MyMedicalRecordSearchParams, *, operator: User
    ) -> PageData[MedicalRecordListItem]:
        records, total = self.repository.list_by_doctor(
            params,
            user_id=operator.id,
            access_filter=self.access_policy.scope_filter(operator),
        )
        return self._page(records, total, params.page, params.page_size)

    def update_record(
        self,
        record_id: int,
        payload: MedicalRecordUpdate,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> MedicalRecordDetail:
        record = self.get_record(record_id, operator=operator)
        self.ensure_record_editable(record)
        if not self.access_policy.can_update(record, operator):
            raise PermissionDeniedError("无权修改该病历")
        changes = payload.model_dump(exclude_unset=True)
        if not changes:
            raise ValidationError("没有可更新的字段")

        changed_fields = sorted(
            field for field, value in changes.items() if getattr(record, field) != value
        )
        if not changed_fields:
            raise ValidationError("病历内容没有变化")
        try:
            for field in changed_fields:
                setattr(record, field, changes[field])
            record.updated_by = operator.id
            self.repository.update(record)
            audit_value = {
                "status": record.status.value,
                "changed_fields": changed_fields,
            }
            self.audit.record(
                user_id=operator.id,
                action="MEDICAL_RECORD_UPDATE",
                module="medical_record",
                target_type="medical_record",
                target_id=record.id,
                context=audit_context,
                old_value=audit_value,
                new_value=audit_value,
            )
            self.db.commit()
            result = self.repository.get_by_id(record.id)
            assert result is not None
            return MedicalRecordDetail.model_validate(result)
        except Exception:
            self.db.rollback()
            raise

    def submit_record(
        self,
        record_id: int,
        payload: MedicalRecordResubmitRequest | None = None,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> MedicalRecordSubmitResponse:
        record = self.get_record(record_id, operator=operator)
        MedicalRecordStateMachine.ensure_transition(
            record.status, MedicalRecordStatus.SUBMITTED
        )
        if not self.access_policy.can_submit(record, operator):
            raise PermissionDeniedError("无权提交该病历")
        self.validate_submit_requirements(record)
        old_status = record.status
        is_resubmit = old_status == MedicalRecordStatus.REJECTED
        reason = (payload.change_reason or "").strip() if payload else ""
        if is_resubmit and len(reason) < 5:
            raise ValidationError("重新提交时必须填写至少 5 个字符的修改说明")
        reason = reason or "首次提交"
        submitted_at = datetime.now(timezone.utc)
        try:
            version = self.create_version(
                record,
                operator=operator,
                change_reason=reason,
                audit_context=audit_context,
            )
            record.status = MedicalRecordStatus.SUBMITTED
            record.submitted_by = operator.id
            record.submitted_at = submitted_at
            record.updated_by = operator.id
            record.current_reviewer_id = None
            self.repository.update(record)
            action = ReviewAction.RESUBMIT if is_resubmit else ReviewAction.SUBMIT
            review_round = self.reviews.latest_round(record.id) + (
                1 if is_resubmit else 0
            )
            review_round = max(1, review_round)
            self.reviews.create(
                RecordReview(
                    record_id=record.id,
                    reviewer_id=operator.id,
                    action=action,
                    comment=reason,
                    from_status=old_status,
                    to_status=MedicalRecordStatus.SUBMITTED,
                    record_version=version.version,
                    review_round=review_round,
                )
            )
            self.audit.record(
                user_id=operator.id,
                action=(
                    "MEDICAL_RECORD_RESUBMIT"
                    if is_resubmit
                    else "MEDICAL_RECORD_SUBMIT"
                ),
                module="medical_record",
                target_type="medical_record",
                target_id=record.id,
                context=audit_context,
                old_value={"status": old_status.value},
                new_value={
                    "status": MedicalRecordStatus.SUBMITTED.value,
                    "version": version.version,
                },
            )
            self.db.commit()
            return MedicalRecordSubmitResponse(
                id=record.id,
                record_no=record.record_no,
                old_status=old_status,
                status=record.status,
                submitted_by=operator.id,
                submitted_at=submitted_at,
                version=version.version,
            )
        except IntegrityError as exc:
            self.db.rollback()
            raise ConflictError("病历版本生成冲突，请重试") from exc
        except Exception:
            self.db.rollback()
            raise

    def complete_record(
        self,
        record_id: int,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> MedicalRecordCompleteResponse:
        """医生完成草稿病历并生成不可变版本，不再进入审核流程。"""
        record = self.get_record(record_id, operator=operator)
        MedicalRecordStateMachine.ensure_transition(
            record.status, MedicalRecordStatus.APPROVED
        )
        if not self.access_policy.can_submit(record, operator):
            raise PermissionDeniedError("无权完成该病历")
        self.validate_submit_requirements(record)
        completed_at = datetime.now(timezone.utc)
        try:
            version = self.create_version(
                record,
                operator=operator,
                change_reason="医生完成病历",
                audit_context=audit_context,
            )
            old_status = record.status
            record.status = MedicalRecordStatus.APPROVED
            record.completed_by = operator.id
            record.completed_at = completed_at
            record.updated_by = operator.id
            record.approved_version = version.version
            record.current_reviewer_id = None
            encounter = self.encounters.get_by_id(record.encounter_id)
            if (
                encounter is not None
                and encounter.encounter_type
                in {EncounterType.OUTPATIENT, EncounterType.EMERGENCY}
                and encounter.status == EncounterStatus.IN_PROGRESS
            ):
                encounter.status = EncounterStatus.COMPLETED
                self.encounters.update(encounter)
                self.audit.record(
                    user_id=operator.id,
                    action="ENCOUNTER_COMPLETE",
                    module="encounter",
                    target_type="encounter",
                    target_id=encounter.id,
                    context=audit_context,
                    old_value={"status": EncounterStatus.IN_PROGRESS.value},
                    new_value={
                        "status": EncounterStatus.COMPLETED.value,
                        "source": "medical_record_complete",
                    },
                )
            self.audit.record(
                user_id=operator.id,
                action="MEDICAL_RECORD_COMPLETE",
                module="medical_record",
                target_type="medical_record",
                target_id=record.id,
                context=audit_context,
                old_value={"status": old_status.value},
                new_value={
                    "status": MedicalRecordStatus.APPROVED.value,
                    "completed_by": operator.id,
                    "version": version.version,
                },
            )
            self.db.commit()
            return MedicalRecordCompleteResponse(
                id=record.id,
                record_no=record.record_no,
                old_status=old_status,
                status=record.status,
                completed_by=operator.id,
                completed_at=completed_at,
                version=version.version,
            )
        except Exception:
            self.db.rollback()
            raise

    def delete_draft(
        self,
        record_id: int,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> None:
        record = self.get_record(record_id, operator=operator)
        if record.status != MedicalRecordStatus.DRAFT:
            raise InvalidMedicalRecordStateError("只有草稿病历允许删除")
        if not self.access_policy.can_delete(record, operator):
            raise PermissionDeniedError("无权删除该病历")
        try:
            self.repository.soft_delete(record, datetime.now(timezone.utc))
            self.audit.record(
                user_id=operator.id,
                action="MEDICAL_RECORD_DELETE",
                module="medical_record",
                target_type="medical_record",
                target_id=record.id,
                context=audit_context,
                old_value=self._audit_metadata(record),
                new_value={"deleted": True},
            )
            self.db.commit()
        except Exception:
            self.db.rollback()
            raise

    def archive_record(
        self,
        record_id: int,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> MedicalRecordArchiveResponse:
        """归档已审核通过的病历；状态流转和审计在同一事务中完成。"""
        record = self.get_record(record_id, operator=operator)
        if not self.access_policy.can_archive(record, operator):
            raise PermissionDeniedError("无权归档该病历")
        MedicalRecordStateMachine.ensure_transition(
            record.status, MedicalRecordStatus.ARCHIVED
        )
        if record.approved_version is None:
            raise InvalidMedicalRecordStateError("病历缺少审核通过版本，不能归档")
        old_status = record.status
        archived_at = datetime.now(timezone.utc)
        try:
            record.status = MedicalRecordStatus.ARCHIVED
            record.archived_by = operator.id
            record.archived_at = archived_at
            record.updated_by = operator.id
            self.repository.update(record)
            self.audit.record(
                user_id=operator.id,
                action="MEDICAL_RECORD_ARCHIVE",
                module="medical_record",
                target_type="medical_record",
                target_id=record.id,
                context=audit_context,
                old_value={"status": old_status.value},
                new_value={
                    "status": record.status.value,
                    "approved_version": record.approved_version,
                    "archived_by": operator.id,
                },
            )
            self.db.commit()
        except Exception:
            self.db.rollback()
            raise
        return MedicalRecordArchiveResponse(
            id=record.id,
            record_no=record.record_no,
            old_status=old_status,
            status=record.status,
            archived_by=operator.id,
            archived_at=archived_at,
        )

    def list_versions(
        self, record_id: int, *, operator: User
    ) -> list[MedicalRecordVersionRead]:
        record = self.get_record(record_id, operator=operator)
        return [
            MedicalRecordVersionRead.model_validate(item)
            for item in self.versions.list_by_record(record.id)
        ]

    def get_version(
        self, record_id: int, version: int, *, operator: User
    ) -> MedicalRecordVersionRead:
        record = self.get_record(record_id, operator=operator)
        result = self.versions.get_by_record_and_version(record.id, version)
        if result is None:
            raise ResourceNotFoundError("病历版本不存在")
        return MedicalRecordVersionRead.model_validate(result)

    def get_full_record(
        self, record_id: int, *, operator: User
    ) -> MedicalRecordFull:
        record = self.get_record(record_id, operator=operator)
        diagnoses = self.diagnoses.list_by_record(record.id)
        orders = self.orders.list_by_record(record.id)
        prescriptions = self.prescriptions.list_by_record(record.id)
        labs = self.lab_reports.list_by_record(record.id)
        examinations = self.examinations.list_by_record(record.id)
        attachments = self.attachments.list_by_record(record.id)
        detail = MedicalRecordDetail.model_validate(record)
        return MedicalRecordFull(
            patient=detail.encounter.patient,
            encounter=detail.encounter,
            medical_record=detail,
            diagnoses=[DiagnosisRead.model_validate(item) for item in diagnoses],
            medical_orders=[MedicalOrderRead.model_validate(item) for item in orders],
            prescriptions=[
                PrescriptionDetail(
                    **PrescriptionRead.model_validate(item).model_dump(),
                    items=[
                        PrescriptionItemRead.model_validate(child)
                        for child in item.items
                        if child.deleted_at is None
                    ],
                )
                for item in prescriptions
            ],
            lab_reports=[LabReportDetail.model_validate(item) for item in labs],
            examinations=[ExaminationRead.model_validate(item) for item in examinations],
            attachments=[AttachmentRead.model_validate(item) for item in attachments],
            versions=[
                MedicalRecordVersionRead.model_validate(item)
                for item in self.versions.list_by_record(record.id)
            ],
            review_history=[
                RecordReviewRead.model_validate(item)
                for item in self.reviews.list_by_record(record.id)
            ],
        )

    def validate_record_access(
        self, record: MedicalRecord, *, operator: User
    ) -> None:
        if not self.access_policy.can_view(record, operator):
            raise PermissionDeniedError("无权访问该病历")

    def get_editable_record(
        self, record_id: int, *, operator: User
    ) -> MedicalRecord:
        record = self.get_record(record_id, operator=operator)
        self.ensure_record_editable(record)
        if not self.access_policy.can_update(record, operator):
            raise PermissionDeniedError("无权修改该病历的临床记录")
        return record

    @classmethod
    def ensure_record_editable(cls, record: MedicalRecord) -> None:
        MedicalRecordStateMachine.ensure_editable(record.status)

    def validate_submit_requirements(self, record: MedicalRecord) -> None:
        missing = [
            field
            for field in self.SUBMIT_REQUIRED_FIELDS
            if not (getattr(record, field) or "").strip()
        ]
        if not self.diagnoses.has_any(record.id):
            missing.append("diagnoses")
        elif not self.diagnoses.has_primary(record.id):
            missing.append("primary_diagnosis")
        if missing:
            raise MedicalRecordIncompleteError(missing)

    def create_version(
        self,
        record: MedicalRecord,
        *,
        operator: User,
        change_reason: str,
        audit_context: AuditContext,
    ) -> MedicalRecordVersion:
        version = MedicalRecordVersion(
            record_id=record.id,
            version=self.versions.get_latest_version_number(record.id) + 1,
            snapshot_data=self._version_snapshot(record),
            change_reason=change_reason,
            created_by=operator.id,
        )
        self.versions.create(version)
        self.audit.record(
            user_id=operator.id,
            action="MEDICAL_RECORD_VERSION_CREATE",
            module="medical_record",
            target_type="medical_record",
            target_id=record.id,
            context=audit_context,
            new_value={
                "version": version.version,
                "change_reason": change_reason,
            },
        )
        return version

    def _next_record_no(self) -> str:
        sequence_date = datetime.now(LOCAL_TIMEZONE).date()
        value = self.repository.next_sequence_value(sequence_date)
        if value > self.MAX_DAILY_SEQUENCE:
            raise ValidationError("当日病历编号已用尽")
        return f"MR{sequence_date:%Y%m%d}{value:06d}"

    @staticmethod
    def _page(
        records: list[MedicalRecord], total: int, page: int, page_size: int
    ) -> PageData[MedicalRecordListItem]:
        return PageData(
            items=[MedicalRecordListItem.model_validate(item) for item in records],
            page=page,
            page_size=page_size,
            total=total,
            pages=ceil(total / page_size) if total else 0,
        )

    def _version_snapshot(self, record: MedicalRecord) -> dict[str, Any]:
        medical_record: dict[str, Any] = {
            field: getattr(record, field) for field in CONTENT_FIELDS
        }
        medical_record.update(
            {
                "record_no": record.record_no,
                "encounter_id": record.encounter_id,
                "status": record.status.value,
            }
        )
        diagnoses = [
            {
                "id": item.id,
                "diagnosis_catalog_id": item.diagnosis_catalog_id,
                "diagnosis_name": item.diagnosis_name,
                "diagnosis_no": item.diagnosis_no,
                "diagnosis_code": item.diagnosis_code,
                "diagnosis_type": item.diagnosis_type.value,
                "description": item.description,
                "sort_order": item.sort_order,
                "is_primary": item.is_primary,
            }
            for item in self.diagnoses.list_by_record(record.id)
        ]
        orders = [
            {
                "id": item.id,
                "order_no": item.order_no,
                "order_type": item.order_type.value,
                "order_content": item.order_content,
                "dosage": item.dosage,
                "dosage_unit": item.dosage_unit,
                "frequency": item.frequency,
                "route": item.route,
                "start_time": (
                    item.start_time.isoformat() if item.start_time else None
                ),
                "end_time": item.end_time.isoformat() if item.end_time else None,
                "status": item.status.value,
                "remark": item.remark,
            }
            for item in self.orders.list_by_record(record.id)
        ]
        prescriptions = []
        for prescription in self.prescriptions.list_by_record(record.id):
            items = [
                {
                    "id": item.id,
                    "drug_catalog_id": item.drug_catalog_id,
                    "drug_name": item.drug_name,
                    "generic_name": item.generic_name,
                    "dosage_form": item.dosage_form,
                    "specification": item.specification,
                    "dosage": item.dosage,
                    "dosage_unit": item.dosage_unit,
                    "frequency": item.frequency,
                    "route": item.route,
                    "duration": item.duration,
                    "duration_unit": item.duration_unit,
                    "quantity": (
                        str(item.quantity) if item.quantity is not None else None
                    ),
                    "quantity_unit": item.quantity_unit,
                    "usage_instruction": item.usage_instruction,
                    "remark": item.remark,
                    "sort_order": item.sort_order,
                }
                for item in prescription.items
                if item.deleted_at is None
            ]
            prescriptions.append(
                {
                    "prescription": {
                        "id": prescription.id,
                        "prescription_no": prescription.prescription_no,
                        "doctor_id": prescription.doctor_id,
                        "prescription_type": prescription.prescription_type.value,
                        "status": prescription.status.value,
                        "notes": prescription.notes,
                    },
                    "items": items,
                }
            )
        lab_reports = []
        lab_results = []
        for report in self.lab_reports.list_by_record(record.id):
            lab_reports.append(
                {
                    "id": report.id,
                    "lab_test_catalog_id": report.lab_test_catalog_id,
                    "report_no": report.report_no,
                    "report_name": report.report_name,
                    "report_type": report.report_type,
                    "specimen_type": report.specimen_type,
                    "status": report.status.value,
                    "result_summary": report.result_summary,
                    "conclusion": report.conclusion,
                    "collected_at": report.collected_at.isoformat() if report.collected_at else None,
                    "reported_at": report.reported_at.isoformat() if report.reported_at else None,
                }
            )
            lab_results.extend(
                {
                    "id": result.id,
                    "lab_report_id": result.lab_report_id,
                    "lab_test_catalog_id": result.lab_test_catalog_id,
                    "item_code": result.item_code,
                    "item_name": result.item_name,
                    "result_value": result.result_value,
                    "result_text": result.result_text,
                    "unit": result.unit,
                    "reference_range": result.reference_range,
                    "abnormal_flag": result.abnormal_flag.value,
                    "sort_order": result.sort_order,
                    "remark": result.remark,
                }
                for result in report.results
            )
        examinations = [
            {
                "id": item.id,
                "examination_no": item.examination_no,
                "examination_type": item.examination_type.value,
                "examination_name": item.examination_name,
                "body_part": item.body_part,
                "clinical_indication": item.clinical_indication,
                "findings": item.findings,
                "conclusion": item.conclusion,
                "status": item.status.value,
                "performed_at": item.performed_at.isoformat() if item.performed_at else None,
                "reported_at": item.reported_at.isoformat() if item.reported_at else None,
            }
            for item in self.examinations.list_by_record(record.id)
        ]
        attachments_metadata = [
            {
                "id": item.id,
                "original_name": item.original_name,
                "mime_type": item.mime_type,
                "file_hash": item.file_hash,
                "category": item.category.value,
                "lab_report_id": item.lab_report_id,
                "examination_id": item.examination_id,
                "created_at": item.created_at.isoformat(),
            }
            for item in self.attachments.list_by_record(record.id)
        ]
        return {
            "medical_record": medical_record,
            "diagnoses": diagnoses,
            "medical_orders": orders,
            "prescriptions": prescriptions,
            "lab_reports": lab_reports,
            "lab_results": lab_results,
            "examinations": examinations,
            "attachments_metadata": attachments_metadata,
        }

    @staticmethod
    def _audit_metadata(record: MedicalRecord) -> dict[str, Any]:
        """审计只保存结构性信息，完整正文由版本快照承担。"""
        return {
            "record_no": record.record_no,
            "encounter_id": record.encounter_id,
            "status": record.status.value,
            "populated_fields": sorted(
                field for field in CONTENT_FIELDS if getattr(record, field)
            ),
        }
