"""管理员用户管理业务。"""

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.exceptions import (
    ConflictError,
    ResourceNotFoundError,
    ValidationError,
)
from app.core.security import hash_password
from app.models.enums import DepartmentStatus, UserStatus
from app.models.role import ACTIVE_ROLE_CODES
from app.models.user import User
from app.repositories.role_repository import RoleRepository
from app.repositories.user_repository import UserRepository
from app.schemas.user import UserCreate, UserResponse, UserUpdate


class UserService:
    def __init__(self, db: Session) -> None:
        self.db = db
        self.users = UserRepository(db)
        self.roles = RoleRepository(db)

    def list_users(self, *, offset: int, limit: int) -> list[UserResponse]:
        return [
            self.to_response(user)
            for user in self.users.list_users(offset=offset, limit=limit)
        ]

    def get_user(self, user_id: int) -> User:
        user = self.users.get_by_id(user_id)
        if user is None:
            raise ResourceNotFoundError("用户不存在")
        return user

    def create_user(self, payload: UserCreate) -> User:
        username = payload.username.strip()
        if self.users.get_any_by_username(username) is not None:
            raise ConflictError("用户名已存在")

        employee_no = self._normalize_optional(payload.employee_no)
        if (
            employee_no
            and self.users.get_any_by_employee_no(employee_no) is not None
        ):
            raise ConflictError("工号已存在")

        self._validate_department(payload.department_id)
        role_ids = set(payload.role_ids)
        self._validate_roles(role_ids)

        user = User(
            username=username,
            password_hash=hash_password(payload.password),
            real_name=payload.real_name.strip(),
            employee_no=employee_no,
            email=self._normalize_optional(payload.email),
            phone=self._normalize_optional(payload.phone),
            department_id=payload.department_id,
            status=(
                UserStatus.ACTIVE
                if payload.is_active
                else UserStatus.INACTIVE
            ),
            is_active=payload.is_active,
            is_superuser=payload.is_superuser,
        )
        try:
            self.db.add(user)
            self.db.flush()
            self.users.replace_roles(user.id, role_ids)
            self.db.commit()
            return self.get_user(user.id)
        except IntegrityError as exc:
            self.db.rollback()
            raise ConflictError("用户名或工号已存在") from exc
        except Exception:
            self.db.rollback()
            raise

    def update_user(self, user_id: int, payload: UserUpdate) -> User:
        user = self.get_user(user_id)
        fields = payload.model_fields_set

        if "employee_no" in fields:
            employee_no = self._normalize_optional(payload.employee_no)
            existing = (
                self.users.get_any_by_employee_no(employee_no)
                if employee_no
                else None
            )
            if existing is not None and existing.id != user.id:
                raise ConflictError("工号已存在")
            user.employee_no = employee_no
        if "real_name" in fields and payload.real_name is not None:
            user.real_name = payload.real_name.strip()
        if "email" in fields:
            user.email = self._normalize_optional(payload.email)
        if "phone" in fields:
            user.phone = self._normalize_optional(payload.phone)
        if "department_id" in fields:
            self._validate_department(payload.department_id)
            user.department_id = payload.department_id
        if "password" in fields and payload.password is not None:
            user.password_hash = hash_password(payload.password)
        if "is_active" in fields and payload.is_active is not None:
            user.is_active = payload.is_active
            user.status = (
                UserStatus.ACTIVE
                if payload.is_active
                else UserStatus.INACTIVE
            )
        if "is_superuser" in fields and payload.is_superuser is not None:
            user.is_superuser = payload.is_superuser

        try:
            self.db.commit()
            return self.get_user(user.id)
        except IntegrityError as exc:
            self.db.rollback()
            raise ConflictError("用户信息与现有数据冲突") from exc
        except Exception:
            self.db.rollback()
            raise

    def assign_roles(self, user_id: int, role_ids: list[int]) -> User:
        user = self.get_user(user_id)
        unique_role_ids = set(role_ids)
        self._validate_roles(unique_role_ids)
        try:
            self.users.replace_roles(user.id, unique_role_ids)
            self.db.commit()
            return self.get_user(user.id)
        except IntegrityError as exc:
            self.db.rollback()
            raise ConflictError("角色绑定失败") from exc
        except Exception:
            self.db.rollback()
            raise

    def to_response(self, user: User) -> UserResponse:
        return UserResponse(
            id=user.id,
            username=user.username,
            real_name=user.real_name,
            employee_no=user.employee_no,
            email=user.email,
            phone=user.phone,
            department_id=user.department_id,
            department=user.department,
            status=user.status,
            is_active=user.is_active,
            is_superuser=user.is_superuser,
            last_login_at=user.last_login_at,
            created_at=user.created_at,
            updated_at=user.updated_at,
            roles=sorted(self.users.get_role_codes(user.id)),
            permissions=sorted(self.users.get_permission_codes(user.id)),
        )

    def _validate_roles(self, role_ids: set[int]) -> None:
        roles = self.roles.get_roles_by_ids(role_ids)
        if len(roles) != len(role_ids):
            raise ResourceNotFoundError("一个或多个角色不存在")
        if any(role.code not in ACTIVE_ROLE_CODES for role in roles):
            raise ValidationError("新用户只能分配系统管理员、医生或检验人员角色")

    def _validate_department(self, department_id: int | None) -> None:
        if department_id is None:
            return
        department = self.roles.get_department(department_id)
        if department is None:
            raise ResourceNotFoundError("科室不存在")
        if department.status != DepartmentStatus.ACTIVE:
            raise ValidationError("不能分配已停用科室")

    @staticmethod
    def _normalize_optional(value: str | None) -> str | None:
        if value is None:
            return None
        normalized = value.strip()
        return normalized or None
