"""患者建档、查询、脱敏、软删除与审计业务。"""

from datetime import datetime, timezone
from math import ceil
from typing import Any

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.data_masking import mask_id_card, mask_phone
from app.core.exceptions import (
    ConflictError,
    DuplicatePatientError,
    InvalidPatientDataError,
    PatientNotFoundError,
)
from app.models.patient import Patient
from app.models.user import User
from app.repositories.patient_repository import PatientRepository
from app.repositories.encounter_repository import EncounterRepository
from app.repositories.user_repository import UserRepository
from app.schemas.common import PageData
from app.schemas.patient import (
    PatientCreate,
    PatientDetail,
    PatientListItem,
    PatientSearchParams,
    PatientUpdate,
)
from app.services.audit_service import AuditContext, AuditService


class PatientService:
    MAX_PATIENT_SEQUENCE = 999_999

    def __init__(self, db: Session) -> None:
        self.db = db
        self.repository = PatientRepository(db)
        self.encounters = EncounterRepository(db)
        self.audit = AuditService(db)
        self.users = UserRepository(db)

    def create_patient(
        self,
        payload: PatientCreate,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> PatientDetail:
        for attempt in range(3):
            if payload.id_card and self.repository.get_by_id_card(payload.id_card):
                raise DuplicatePatientError()
            try:
                patient_no = self._next_patient_no()
                patient = Patient(patient_no=patient_no, **payload.model_dump())
                self.repository.create(patient)
                self.audit.record(
                    user_id=operator.id,
                    action="PATIENT_CREATE",
                    module="patient",
                    target_type="patient",
                    target_id=patient.id,
                    context=audit_context,
                    new_value=self._audit_snapshot(patient),
                )
                self.db.commit()
                self.db.refresh(patient)
                return self.to_detail(patient, operator=operator)
            except IntegrityError as exc:
                self.db.rollback()
                if payload.id_card and self.repository.get_by_id_card(
                    payload.id_card
                ):
                    raise DuplicatePatientError() from exc
                if attempt == 2:
                    raise ConflictError("患者编号生成冲突，请重试") from exc
            except Exception:
                self.db.rollback()
                raise
        raise ConflictError("患者编号生成失败")

    def list_patients(
        self, params: PatientSearchParams, *, operator: User
    ) -> PageData[PatientListItem]:
        patients, total = self.repository.search(params)
        can_view_sensitive = self._can_view_sensitive(operator)
        return PageData(
            items=[
                PatientListItem(
                    **self._response_data(
                        item, can_view_sensitive=can_view_sensitive
                    )
                )
                for item in patients
            ],
            page=params.page,
            page_size=params.page_size,
            total=total,
            pages=ceil(total / params.page_size) if total else 0,
        )

    def get_patient(self, patient_id: int) -> Patient:
        patient = self.repository.get_by_id(patient_id)
        if patient is None:
            raise PatientNotFoundError()
        return patient

    def get_patient_detail(
        self, patient_id: int, *, operator: User
    ) -> PatientDetail:
        return self.to_detail(self.get_patient(patient_id), operator=operator)

    def update_patient(
        self,
        patient_id: int,
        payload: PatientUpdate,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> PatientDetail:
        patient = self.get_patient(patient_id)
        old_value = self._audit_snapshot(patient)
        changes = payload.model_dump(exclude_unset=True)
        if not changes:
            raise InvalidPatientDataError("没有可更新的字段")

        new_id_card = changes.get("id_card")
        if new_id_card:
            duplicate = self.repository.get_by_id_card(new_id_card)
            if duplicate is not None and duplicate.id != patient.id:
                raise DuplicatePatientError()

        for field, value in changes.items():
            setattr(patient, field, value)
        try:
            self.repository.update(patient)
            self.audit.record(
                user_id=operator.id,
                action="PATIENT_UPDATE",
                module="patient",
                target_type="patient",
                target_id=patient.id,
                context=audit_context,
                old_value=old_value,
                new_value=self._audit_snapshot(patient),
            )
            self.db.commit()
            self.db.refresh(patient)
            return self.to_detail(patient, operator=operator)
        except IntegrityError as exc:
            self.db.rollback()
            raise DuplicatePatientError() from exc
        except Exception:
            self.db.rollback()
            raise

    def delete_patient(
        self,
        patient_id: int,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> None:
        patient = self.get_patient(patient_id)
        self._ensure_patient_can_be_deleted(patient)
        old_value = self._audit_snapshot(patient)
        try:
            self.repository.soft_delete(patient, datetime.now(timezone.utc))
            self.audit.record(
                user_id=operator.id,
                action="PATIENT_DELETE",
                module="patient",
                target_type="patient",
                target_id=patient.id,
                context=audit_context,
                old_value=old_value,
                new_value={"deleted": True},
            )
            self.db.commit()
        except Exception:
            self.db.rollback()
            raise

    def restore_patient(
        self,
        patient_id: int,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> PatientDetail:
        patient = self.repository.get_by_id(patient_id, include_deleted=True)
        if patient is None:
            raise PatientNotFoundError()
        if patient.deleted_at is None:
            return self.to_detail(patient, operator=operator)
        old_value = {"deleted": True}
        try:
            patient.deleted_at = None
            self.repository.update(patient)
            self.audit.record(
                user_id=operator.id,
                action="PATIENT_RESTORE",
                module="patient",
                target_type="patient",
                target_id=patient.id,
                context=audit_context,
                old_value=old_value,
                new_value=self._audit_snapshot(patient),
            )
            self.db.commit()
            self.db.refresh(patient)
            return self.to_detail(patient, operator=operator)
        except Exception:
            self.db.rollback()
            raise

    def to_list_item(
        self, patient: Patient, *, operator: User
    ) -> PatientListItem:
        return PatientListItem(
            **self._response_data(
                patient,
                can_view_sensitive=self._can_view_sensitive(operator),
            )
        )

    def to_detail(self, patient: Patient, *, operator: User) -> PatientDetail:
        return PatientDetail(
            **self._response_data(
                patient,
                can_view_sensitive=self._can_view_sensitive(operator),
            )
        )

    def _next_patient_no(self) -> str:
        year = datetime.now(timezone.utc).year
        value = self.repository.next_sequence_value(year)
        if value > self.MAX_PATIENT_SEQUENCE:
            raise InvalidPatientDataError("本年度患者编号已用尽")
        return f"P{year}{value:06d}"

    def _can_view_sensitive(self, operator: User) -> bool:
        return operator.is_superuser or "ADMIN" in self.users.get_role_codes(
            operator.id
        )

    def _response_data(
        self, patient: Patient, *, can_view_sensitive: bool
    ) -> dict[str, Any]:
        return {
            "id": patient.id,
            "patient_no": patient.patient_no,
            "name": patient.name,
            "gender": patient.gender,
            "birthday": patient.birthday,
            "id_card": (
                patient.id_card
                if can_view_sensitive
                else mask_id_card(patient.id_card)
            ),
            "phone": (
                patient.phone
                if can_view_sensitive
                else mask_phone(patient.phone)
            ),
            "address": patient.address,
            "blood_type": patient.blood_type,
            "allergy_history": patient.allergy_history,
            "emergency_contact": patient.emergency_contact,
            "emergency_phone": (
                patient.emergency_phone
                if can_view_sensitive
                else mask_phone(patient.emergency_phone)
            ),
            "remark": patient.remark,
            "created_at": patient.created_at,
            "updated_at": patient.updated_at,
        }

    @staticmethod
    def _audit_snapshot(patient: Patient) -> dict[str, Any]:
        """审计保留业务变化，同时避免复制完整身份证和电话。"""
        return {
            "patient_no": patient.patient_no,
            "name": patient.name,
            "gender": patient.gender.value,
            "birthday": patient.birthday.isoformat() if patient.birthday else None,
            "id_card": mask_id_card(patient.id_card),
            "phone": mask_phone(patient.phone),
            "address": patient.address,
            "blood_type": patient.blood_type.value,
            "allergy_history": patient.allergy_history,
            "emergency_contact": patient.emergency_contact,
            "emergency_phone": mask_phone(patient.emergency_phone),
            "remark": patient.remark,
        }

    def _ensure_patient_can_be_deleted(self, patient: Patient) -> None:
        if self.encounters.exists_by_patient(patient.id):
            raise ConflictError("患者已有就诊记录，不允许删除")
