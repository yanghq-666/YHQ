"""就诊创建、查询、状态机、数据范围和审计业务。"""

from datetime import datetime, timezone
from math import ceil
from zoneinfo import ZoneInfo

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.exceptions import (
    ConflictError,
    EncounterNotFoundError,
    InvalidEncounterDataError,
    InvalidEncounterStateError,
    PatientNotFoundError,
    PermissionDeniedError,
    ResourceNotFoundError,
)
from app.models.encounter import Encounter
from app.models.enums import (
    DepartmentStatus,
    EncounterStatus,
    EncounterType,
    MedicalRecordStatus,
    UserStatus,
)
from app.models.user import User
from app.repositories.encounter_repository import EncounterRepository
from app.repositories.medical_record_repository import MedicalRecordRepository
from app.repositories.patient_repository import PatientRepository
from app.repositories.role_repository import RoleRepository
from app.repositories.user_repository import UserRepository
from app.schemas.common import PageData
from app.schemas.encounter import (
    EncounterCreate,
    EncounterDetail,
    EncounterListItem,
    EncounterSearchParams,
    EncounterStatusResponse,
    EncounterUpdate,
)
from app.services.audit_service import AuditContext, AuditService
from app.services.encounter_access_policy import EncounterAccessPolicy

LOCAL_TIMEZONE = ZoneInfo("Asia/Shanghai")


class EncounterService:
    MAX_DAILY_SEQUENCE = 999_999

    def __init__(self, db: Session) -> None:
        self.db = db
        self.repository = EncounterRepository(db)
        self.medical_records = MedicalRecordRepository(db)
        self.patients = PatientRepository(db)
        self.users = UserRepository(db)
        self.roles = RoleRepository(db)
        self.audit = AuditService(db)
        self.access_policy = EncounterAccessPolicy(self.users)

    def create_encounter(
        self,
        payload: EncounterCreate,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> EncounterDetail:
        patient = self.patients.get_by_id(payload.patient_id)
        if patient is None:
            raise PatientNotFoundError()
        self._validate_assignment(
            payload.doctor_id, payload.department_id, operator=operator
        )
        self._validate_times(payload.admission_time, payload.discharge_time)

        for attempt in range(3):
            try:
                encounter = Encounter(
                    encounter_no=self._next_encounter_no(),
                    status=EncounterStatus.REGISTERED,
                    created_by=operator.id,
                    **payload.model_dump(),
                )
                self.repository.create(encounter)
                self.audit.record(
                    user_id=operator.id,
                    action="ENCOUNTER_CREATE",
                    module="encounter",
                    target_type="encounter",
                    target_id=encounter.id,
                    context=audit_context,
                    new_value=self._snapshot(encounter),
                )
                self.db.commit()
                result = self.repository.get_by_id(encounter.id)
                assert result is not None
                return EncounterDetail.model_validate(result)
            except IntegrityError as exc:
                self.db.rollback()
                if attempt == 2:
                    raise ConflictError("就诊编号生成冲突，请重试") from exc
            except Exception:
                self.db.rollback()
                raise
        raise ConflictError("就诊编号生成失败")

    def list_encounters(
        self, params: EncounterSearchParams, *, operator: User
    ) -> PageData[EncounterListItem]:
        items, total = self.repository.search(
            params,
            access_filter=self.access_policy.scope_filter(operator),
        )
        return PageData(
            items=[EncounterListItem.model_validate(item) for item in items],
            page=params.page,
            page_size=params.page_size,
            total=total,
            pages=ceil(total / params.page_size) if total else 0,
        )

    def list_by_patient(
        self, patient_id: int, *, operator: User
    ) -> list[EncounterListItem]:
        if self.patients.get_by_id(patient_id) is None:
            raise PatientNotFoundError()
        encounters = self.repository.list_by_patient(
            patient_id,
            access_filter=self.access_policy.scope_filter(operator),
        )
        return [EncounterListItem.model_validate(item) for item in encounters]

    def get_encounter(self, encounter_id: int, *, operator: User) -> Encounter:
        encounter = self.repository.get_by_id(encounter_id)
        if encounter is None:
            raise EncounterNotFoundError()
        if not self.access_policy.can_access(encounter, operator):
            raise PermissionDeniedError("无权访问该就诊")
        return encounter

    def get_encounter_detail(
        self, encounter_id: int, *, operator: User
    ) -> EncounterDetail:
        return EncounterDetail.model_validate(
            self.get_encounter(encounter_id, operator=operator)
        )

    def update_encounter(
        self,
        encounter_id: int,
        payload: EncounterUpdate,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> EncounterDetail:
        encounter = self.get_encounter(encounter_id, operator=operator)
        if encounter.status in {
            EncounterStatus.COMPLETED,
            EncounterStatus.CANCELLED,
        }:
            raise InvalidEncounterStateError("终态就诊不允许修改")
        changes = payload.model_dump(exclude_unset=True)
        if not changes:
            raise InvalidEncounterDataError("没有可更新的字段")

        doctor_id = changes.get("doctor_id", encounter.doctor_id)
        department_id = changes.get("department_id", encounter.department_id)
        self._validate_assignment(doctor_id, department_id, operator=operator)
        admission_time = changes.get("admission_time", encounter.admission_time)
        discharge_time = changes.get("discharge_time", encounter.discharge_time)
        self._validate_times(admission_time, discharge_time)

        old_value = self._snapshot(encounter)
        for field, value in changes.items():
            setattr(encounter, field, value)
        try:
            self.repository.update(encounter)
            self.audit.record(
                user_id=operator.id,
                action="ENCOUNTER_UPDATE",
                module="encounter",
                target_type="encounter",
                target_id=encounter.id,
                context=audit_context,
                old_value=old_value,
                new_value=self._snapshot(encounter),
            )
            self.db.commit()
            result = self.repository.get_by_id(encounter.id)
            assert result is not None
            return EncounterDetail.model_validate(result)
        except Exception:
            self.db.rollback()
            raise

    def start_encounter(
        self,
        encounter_id: int,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> EncounterStatusResponse:
        return self._transition(
            encounter_id,
            expected=EncounterStatus.REGISTERED,
            target=EncounterStatus.IN_PROGRESS,
            action="ENCOUNTER_START",
            operator=operator,
            audit_context=audit_context,
        )

    def complete_encounter(
        self,
        encounter_id: int,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> EncounterStatusResponse:
        encounter = self.get_encounter(encounter_id, operator=operator)
        if encounter.encounter_type in {
            EncounterType.OUTPATIENT,
            EncounterType.EMERGENCY,
        }:
            record = self.medical_records.get_by_encounter_id(encounter.id)
            if record is None or record.status not in {
                MedicalRecordStatus.APPROVED,
                MedicalRecordStatus.ARCHIVED,
            }:
                raise InvalidEncounterStateError(
                    "请先完成病历后再结束本次就诊"
                )
        if (
            encounter.encounter_type == EncounterType.INPATIENT
            and encounter.discharge_time is None
        ):
            raise InvalidEncounterDataError("住院就诊完成前必须填写出院时间")
        return self._transition_encounter(
            encounter,
            expected=EncounterStatus.IN_PROGRESS,
            target=EncounterStatus.COMPLETED,
            action="ENCOUNTER_COMPLETE",
            operator=operator,
            audit_context=audit_context,
        )

    def cancel_encounter(
        self,
        encounter_id: int,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> EncounterStatusResponse:
        return self._transition(
            encounter_id,
            expected=EncounterStatus.REGISTERED,
            target=EncounterStatus.CANCELLED,
            action="ENCOUNTER_CANCEL",
            operator=operator,
            audit_context=audit_context,
        )

    def delete_encounter(
        self,
        encounter_id: int,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> None:
        encounter = self.get_encounter(encounter_id, operator=operator)
        if encounter.status == EncounterStatus.COMPLETED:
            raise InvalidEncounterStateError("已完成就诊不允许删除")
        if self.has_medical_record(encounter.id):
            raise InvalidEncounterStateError("已有病历的就诊不允许删除")
        old_value = self._snapshot(encounter)
        try:
            self.repository.soft_delete(encounter, datetime.now(timezone.utc))
            self.audit.record(
                user_id=operator.id,
                action="ENCOUNTER_DELETE",
                module="encounter",
                target_type="encounter",
                target_id=encounter.id,
                context=audit_context,
                old_value=old_value,
                new_value={"deleted": True},
            )
            self.db.commit()
        except Exception:
            self.db.rollback()
            raise

    def has_medical_record(self, encounter_id: int) -> bool:
        """病历即使软删除也保留医疗历史，关联就诊不得再删除。"""
        return self.medical_records.exists_by_encounter(
            encounter_id, include_deleted=True
        )

    def has_completed_medical_record(self, encounter_id: int) -> bool:
        record = self.medical_records.get_by_encounter_id(encounter_id)
        return record is not None and record.status in {
            MedicalRecordStatus.APPROVED,
            MedicalRecordStatus.ARCHIVED,
        }

    def _transition(
        self,
        encounter_id: int,
        *,
        expected: EncounterStatus,
        target: EncounterStatus,
        action: str,
        operator: User,
        audit_context: AuditContext,
    ) -> EncounterStatusResponse:
        encounter = self.get_encounter(encounter_id, operator=operator)
        return self._transition_encounter(
            encounter,
            expected=expected,
            target=target,
            action=action,
            operator=operator,
            audit_context=audit_context,
        )

    def _transition_encounter(
        self,
        encounter: Encounter,
        *,
        expected: EncounterStatus,
        target: EncounterStatus,
        action: str,
        operator: User,
        audit_context: AuditContext,
    ) -> EncounterStatusResponse:
        if encounter.status != expected:
            raise InvalidEncounterStateError(
                f"就诊状态不能从 {encounter.status.value} 转换为 {target.value}"
            )
        old_status = encounter.status
        try:
            encounter.status = target
            self.repository.update(encounter)
            self.audit.record(
                user_id=operator.id,
                action=action,
                module="encounter",
                target_type="encounter",
                target_id=encounter.id,
                context=audit_context,
                old_value={"status": old_status.value},
                new_value={"status": target.value},
            )
            self.db.commit()
            return EncounterStatusResponse(
                id=encounter.id,
                encounter_no=encounter.encounter_no,
                old_status=old_status,
                status=target,
            )
        except Exception:
            self.db.rollback()
            raise

    def _validate_assignment(
        self, doctor_id: int, department_id: int, *, operator: User
    ) -> None:
        doctor = self.users.get_by_id(doctor_id)
        if doctor is None:
            raise ResourceNotFoundError("医生不存在")
        if doctor.status != UserStatus.ACTIVE or not doctor.is_active:
            raise InvalidEncounterDataError("医生账号不可用")
        doctor_roles = self.users.get_role_codes(doctor.id)
        if not doctor_roles & {"DOCTOR", "SENIOR_DOCTOR"}:
            raise InvalidEncounterDataError("指定用户不具备医生角色")

        department = self.roles.get_department(department_id)
        if department is None:
            raise ResourceNotFoundError("科室不存在")
        if department.status != DepartmentStatus.ACTIVE:
            raise InvalidEncounterDataError("科室已停用")

        operator_roles = self.users.get_role_codes(operator.id)
        is_admin = operator.is_superuser or "ADMIN" in operator_roles
        if not is_admin:
            if operator.department_id != department_id:
                raise PermissionDeniedError("只能创建或调整本科室就诊")
            if doctor.department_id != department_id:
                raise InvalidEncounterDataError("医生不属于指定科室")

    def _next_encounter_no(self) -> str:
        sequence_date = datetime.now(LOCAL_TIMEZONE).date()
        value = self.repository.next_sequence_value(sequence_date)
        if value > self.MAX_DAILY_SEQUENCE:
            raise InvalidEncounterDataError("当日就诊编号已用尽")
        return f"E{sequence_date:%Y%m%d}{value:06d}"

    @staticmethod
    def _validate_times(
        admission_time: datetime | None, discharge_time: datetime | None
    ) -> None:
        if admission_time and discharge_time:
            left = EncounterService._ensure_aware_utc(admission_time)
            right = EncounterService._ensure_aware_utc(discharge_time)
            if left > right:
                raise InvalidEncounterDataError("入院时间不能晚于出院时间")

    @staticmethod
    def _ensure_aware_utc(value: datetime) -> datetime:
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)

    @staticmethod
    def _snapshot(encounter: Encounter) -> dict[str, object]:
        return {
            "encounter_no": encounter.encounter_no,
            "patient_id": encounter.patient_id,
            "doctor_id": encounter.doctor_id,
            "department_id": encounter.department_id,
            "encounter_type": encounter.encounter_type.value,
            "visit_time": encounter.visit_time.isoformat(),
            "status": encounter.status.value,
            "chief_complaint": encounter.chief_complaint,
            "admission_time": (
                encounter.admission_time.isoformat()
                if encounter.admission_time
                else None
            ),
            "discharge_time": (
                encounter.discharge_time.isoformat()
                if encounter.discharge_time
                else None
            ),
            "room_no": encounter.room_no,
            "bed_no": encounter.bed_no,
            "remark": encounter.remark,
        }
