"""病历审核锁、状态决策、任务列表和审核时间线。"""

from math import ceil

from sqlalchemy.orm import Session

from app.core.exceptions import (
    ConflictError,
    InvalidMedicalRecordStateError,
    MedicalRecordNotFoundError,
    PermissionDeniedError,
    ResourceNotFoundError,
)
from app.models.base import utc_now
from app.models.enums import MedicalRecordStatus, ReviewAction
from app.models.record_review import RecordReview
from app.models.user import User
from app.repositories.medical_record_repository import (
    MedicalRecordRepository,
    MedicalRecordVersionRepository,
)
from app.repositories.record_review_repository import RecordReviewRepository
from app.repositories.user_repository import UserRepository
from app.schemas.common import PageData
from app.schemas.record_review import (
    MyReviewSearchParams,
    PendingReviewListItem,
    PendingReviewSearchParams,
    RecordReviewApproveRequest,
    RecordReviewDecisionResponse,
    RecordReviewRead,
    RecordReviewRejectRequest,
    RecordReviewStartResponse,
    ReviewTaskListItem,
)
from app.services.audit_service import AuditContext, AuditService
from app.services.medical_record_access_policy import MedicalRecordAccessPolicy
from app.services.medical_record_state_machine import MedicalRecordStateMachine


class ReviewService:
    def __init__(self, db: Session) -> None:
        self.db = db
        self.records = MedicalRecordRepository(db)
        self.versions = MedicalRecordVersionRepository(db)
        self.reviews = RecordReviewRepository(db)
        self.policy = MedicalRecordAccessPolicy(UserRepository(db))
        self.audit = AuditService(db)

    def start_review(
        self,
        record_id: int,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> RecordReviewStartResponse:
        record = self._record(record_id)
        if not self.policy.can_review(record, operator):
            if record.created_by == operator.id:
                raise PermissionDeniedError("审核人不能审核自己创建的病历")
            raise PermissionDeniedError("无权审核该病历")
        if (
            record.status == MedicalRecordStatus.REVIEWING
            and record.current_reviewer_id not in {None, operator.id}
        ):
            raise ConflictError("该病历正在由其他审核医生处理")
        MedicalRecordStateMachine.ensure_transition(
            record.status, MedicalRecordStatus.REVIEWING
        )
        version = self.versions.get_latest_version_number(record.id)
        if version < 1:
            raise ConflictError("病历没有可供审核的提交版本")
        review_round = max(1, self.reviews.latest_round(record.id))
        try:
            if not self.records.conditional_start_review(record.id, operator.id):
                self.db.rollback()
                current = self._record(record.id)
                if current.current_reviewer_id not in {None, operator.id}:
                    raise ConflictError("该病历正在由其他审核医生处理")
                raise InvalidMedicalRecordStateError(
                    "病历当前状态不允许开始审核"
                )
            review = RecordReview(
                record_id=record.id,
                reviewer_id=operator.id,
                action=ReviewAction.START_REVIEW,
                comment=None,
                from_status=MedicalRecordStatus.SUBMITTED,
                to_status=MedicalRecordStatus.REVIEWING,
                record_version=version,
                review_round=review_round,
            )
            self.reviews.create(review)
            self._audit_transition(
                record_id=record.id,
                operator=operator,
                action="MEDICAL_RECORD_REVIEW_START",
                version=version,
                from_status=MedicalRecordStatus.SUBMITTED,
                to_status=MedicalRecordStatus.REVIEWING,
                context=audit_context,
            )
            self.db.commit()
            return RecordReviewStartResponse(
                record_id=record.id,
                status=MedicalRecordStatus.REVIEWING,
                current_reviewer_id=operator.id,
                record_version=version,
                review_round=review_round,
            )
        except Exception:
            self.db.rollback()
            raise

    def approve(
        self,
        record_id: int,
        payload: RecordReviewApproveRequest,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> RecordReviewDecisionResponse:
        record, version, review_round = self._decision_context(
            record_id, operator
        )
        MedicalRecordStateMachine.ensure_transition(
            record.status, MedicalRecordStatus.APPROVED
        )
        reviewed_at = utc_now()
        try:
            if not self.records.conditional_review_decision(
                record.id,
                operator.id,
                to_status=MedicalRecordStatus.APPROVED,
                reviewed_at=reviewed_at,
                approved_version=version,
            ):
                raise ConflictError("审核锁已变化，请刷新后重试")
            self.reviews.create(
                RecordReview(
                    record_id=record.id,
                    reviewer_id=operator.id,
                    action=ReviewAction.APPROVE,
                    comment=payload.comment.strip() if payload.comment else None,
                    from_status=MedicalRecordStatus.REVIEWING,
                    to_status=MedicalRecordStatus.APPROVED,
                    record_version=version,
                    review_round=review_round,
                )
            )
            self._audit_transition(
                record_id=record.id,
                operator=operator,
                action="MEDICAL_RECORD_APPROVE",
                version=version,
                from_status=MedicalRecordStatus.REVIEWING,
                to_status=MedicalRecordStatus.APPROVED,
                context=audit_context,
            )
            self.db.commit()
            return RecordReviewDecisionResponse(
                record_id=record.id,
                status=MedicalRecordStatus.APPROVED,
                reviewed_by=operator.id,
                reviewed_at=reviewed_at,
                approved_version=version,
            )
        except Exception:
            self.db.rollback()
            raise

    def reject(
        self,
        record_id: int,
        payload: RecordReviewRejectRequest,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> RecordReviewDecisionResponse:
        record, version, review_round = self._decision_context(
            record_id, operator
        )
        MedicalRecordStateMachine.ensure_transition(
            record.status, MedicalRecordStatus.REJECTED
        )
        try:
            if not self.records.conditional_review_decision(
                record.id,
                operator.id,
                to_status=MedicalRecordStatus.REJECTED,
            ):
                raise ConflictError("审核锁已变化，请刷新后重试")
            self.reviews.create(
                RecordReview(
                    record_id=record.id,
                    reviewer_id=operator.id,
                    action=ReviewAction.REJECT,
                    comment=payload.comment,
                    from_status=MedicalRecordStatus.REVIEWING,
                    to_status=MedicalRecordStatus.REJECTED,
                    record_version=version,
                    review_round=review_round,
                )
            )
            self._audit_transition(
                record_id=record.id,
                operator=operator,
                action="MEDICAL_RECORD_REJECT",
                version=version,
                from_status=MedicalRecordStatus.REVIEWING,
                to_status=MedicalRecordStatus.REJECTED,
                context=audit_context,
            )
            self.db.commit()
            return RecordReviewDecisionResponse(
                record_id=record.id,
                status=MedicalRecordStatus.REJECTED,
                reviewed_by=None,
                reviewed_at=None,
                approved_version=None,
            )
        except Exception:
            self.db.rollback()
            raise

    def list_pending(
        self, params: PendingReviewSearchParams, *, operator: User
    ) -> PageData[PendingReviewListItem]:
        records, total = self.records.pending_review(
            status=params.status,
            access_filter=self.policy.review_scope_filter(operator),
            page=params.page,
            page_size=params.page_size,
            patient_name=params.patient_name,
            record_no=params.record_no,
            department_name=params.department_name,
            doctor_name=params.doctor_name,
            start_date=params.start_date,
            end_date=params.end_date,
        )
        items = [
            PendingReviewListItem(
                record_id=record.id,
                record_no=record.record_no,
                patient=record.encounter.patient,
                encounter_no=record.encounter.encounter_no,
                department=record.encounter.department,
                doctor=record.encounter.doctor,
                submitted_at=record.submitted_at,
                status=record.status,
                current_version=self.versions.get_latest_version_number(record.id),
                current_reviewer_id=record.current_reviewer_id,
            )
            for record in records
            if record.submitted_at is not None
        ]
        return PageData(
            items=items,
            page=params.page,
            page_size=params.page_size,
            total=total,
            pages=ceil(total / params.page_size) if total else 0,
        )

    def list_my_reviews(
        self, params: MyReviewSearchParams, *, operator: User
    ) -> PageData[ReviewTaskListItem]:
        rows, total = self.reviews.list_by_reviewer(operator.id, params)
        return PageData(
            items=[
                ReviewTaskListItem(
                    **RecordReviewRead.model_validate(row).model_dump(),
                    record_no=row.record.record_no,
                    status=row.record.status,
                )
                for row in rows
            ],
            page=params.page,
            page_size=params.page_size,
            total=total,
            pages=ceil(total / params.page_size) if total else 0,
        )

    def get_history(
        self, record_id: int, *, operator: User
    ) -> list[RecordReviewRead]:
        record = self._record(record_id)
        if not self.policy.can_view(record, operator):
            raise PermissionDeniedError("无权查看该病历审核历史")
        return [
            RecordReviewRead.model_validate(item)
            for item in self.reviews.list_by_record(record.id)
        ]

    def get_latest_review(
        self, record_id: int, *, operator: User
    ) -> RecordReviewRead:
        record = self._record(record_id)
        if not self.policy.can_view(record, operator):
            raise PermissionDeniedError("无权查看该病历审核意见")
        review = self.reviews.get_latest(record.id)
        if review is None:
            raise ResourceNotFoundError("该病历没有审核记录")
        return RecordReviewRead.model_validate(review)

    def get_version_full(
        self, record_id: int, version: int, *, operator: User
    ) -> dict:
        record = self._record(record_id)
        if not self.policy.can_view(record, operator):
            raise PermissionDeniedError("无权查看该病历版本")
        item = self.versions.get_by_record_and_version(record.id, version)
        if item is None:
            raise ResourceNotFoundError("病历版本不存在")
        return item.snapshot_data

    def _decision_context(
        self, record_id: int, operator: User
    ) -> tuple:
        record = self._record(record_id)
        if not self.policy.can_review(record, operator):
            if record.created_by == operator.id:
                raise PermissionDeniedError("审核人不能审核自己创建的病历")
            raise PermissionDeniedError("无权审核该病历")
        if record.status != MedicalRecordStatus.REVIEWING:
            raise InvalidMedicalRecordStateError("病历当前不在审核中")
        if record.current_reviewer_id != operator.id:
            raise ConflictError("该病历正在由其他审核医生处理")
        active_review = self.reviews.get_latest(record.id)
        if (
            active_review is None
            or active_review.action != ReviewAction.START_REVIEW
            or active_review.reviewer_id != operator.id
        ):
            raise ConflictError("当前审核任务与审核锁不一致")
        return (
            record,
            active_review.record_version,
            active_review.review_round,
        )

    def _record(self, record_id: int):
        record = self.records.get_by_id(record_id)
        if record is None:
            raise MedicalRecordNotFoundError()
        return record

    def _audit_transition(
        self,
        *,
        record_id: int,
        operator: User,
        action: str,
        version: int,
        from_status: MedicalRecordStatus,
        to_status: MedicalRecordStatus,
        context: AuditContext,
    ) -> None:
        self.audit.record(
            user_id=operator.id,
            action=action,
            module="medical_record_review",
            target_type="medical_record",
            target_id=record_id,
            context=context,
            old_value={"status": from_status.value},
            new_value={
                "status": to_status.value,
                "reviewer_id": operator.id,
                "record_version": version,
            },
        )
