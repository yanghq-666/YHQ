"""附件校验、存储、授权访问和审计业务。"""

from datetime import datetime, timezone
from pathlib import PurePath
from urllib.parse import unquote

from fastapi import UploadFile
from fastapi.responses import Response
from sqlalchemy.orm import Session

from app.core.exceptions import PermissionDeniedError, ResourceNotFoundError, ValidationError
from app.models.attachment import Attachment
from app.models.enums import AttachmentCategory, StorageProvider
from app.models.user import User
from app.repositories.attachment_repository import AttachmentRepository
from app.repositories.examination_repository import ExaminationRepository
from app.repositories.lab_report_repository import LabReportRepository
from app.repositories.medical_record_repository import MedicalRecordRepository
from app.repositories.user_repository import UserRepository
from app.schemas.attachment import AttachmentRead
from app.services.attachment_access_policy import AttachmentAccessPolicy
from app.services.audit_service import AuditContext, AuditService
from app.services.storage_service import StorageService


class AttachmentService:
    ALLOWED = {
        ".pdf": ("application/pdf", b"%PDF-"),
        ".png": ("image/png", b"\x89PNG\r\n\x1a\n"),
        ".jpg": ("image/jpeg", b"\xff\xd8\xff"),
        ".jpeg": ("image/jpeg", b"\xff\xd8\xff"),
    }

    def __init__(self, db: Session, storage: StorageService, *, max_upload_size_mb: int) -> None:
        self.db = db
        self.storage = storage
        self.max_bytes = max_upload_size_mb * 1024 * 1024
        self.attachments = AttachmentRepository(db)
        self.records = MedicalRecordRepository(db)
        self.labs = LabReportRepository(db)
        self.examinations = ExaminationRepository(db)
        self.policy = AttachmentAccessPolicy(UserRepository(db))
        self.audit = AuditService(db)

    def upload(self, record_id: int, upload: UploadFile, *, category: AttachmentCategory, description: str | None, lab_report_id: int | None, examination_id: int | None, operator: User, audit_context: AuditContext) -> AttachmentRead:
        record = self._record(record_id, operator)
        if not self.policy.can_upload(record, operator):
            raise PermissionDeniedError("无权向该病历上传附件")
        self._validate_links(record.id, lab_report_id, examination_id)
        filename, extension, mime_type = self._validate_file(upload)
        object_key = self.storage.generate_object_key(extension)
        stored = self.storage.save(upload.file, object_key, max_bytes=self.max_bytes, content_type=mime_type)
        try:
            attachment = Attachment(
                patient_id=record.encounter.patient_id,
                encounter_id=record.encounter_id,
                record_id=record.id,
                lab_report_id=lab_report_id,
                examination_id=examination_id,
                category=category,
                original_name=filename,
                storage_name=stored.storage_name,
                storage_provider=StorageProvider(self.storage.provider),
                object_key=stored.object_key,
                mime_type=mime_type,
                file_extension=extension,
                file_size=stored.file_size,
                file_hash=stored.file_hash,
                description=description.strip() if description and description.strip() else None,
                uploaded_by=operator.id,
                created_at=datetime.now(timezone.utc),
            )
            self.attachments.create(attachment)
            self.audit.record(user_id=operator.id, action="ATTACHMENT_UPLOAD", module="attachment", target_type="attachment", target_id=attachment.id, context=audit_context, new_value={"record_id": record.id, "category": category.value, "mime_type": mime_type, "file_size": stored.file_size, "file_hash": stored.file_hash})
            self.db.commit()
            return AttachmentRead.model_validate(attachment)
        except Exception:
            self.db.rollback()
            try:
                self.storage.delete(stored.object_key)
            except Exception:
                # 元数据事务仍需保留原始异常；对象清理由运维巡检再次处理。
                pass
            raise

    def get_attachment(self, attachment_id: int, *, operator: User) -> AttachmentRead:
        attachment, _ = self._attachment(attachment_id, operator)
        return AttachmentRead.model_validate(attachment)

    def get_content(self, attachment_id: int, *, operator: User, audit_context: AuditContext, inline: bool) -> Response:
        attachment, _ = self._attachment(attachment_id, operator)
        if not self.storage.exists(attachment.object_key):
            raise ResourceNotFoundError("附件文件不存在")
        try:
            self.audit.record(user_id=operator.id, action="ATTACHMENT_DOWNLOAD", module="attachment", target_type="attachment", target_id=attachment.id, context=audit_context, new_value={"inline": inline, "record_id": attachment.record_id})
            self.db.commit()
        except Exception:
            self.db.rollback()
            raise
        return self.storage.get_download_response(attachment.object_key, filename=attachment.original_name, media_type=attachment.mime_type, inline=inline)

    def delete_attachment(self, attachment_id: int, *, operator: User, audit_context: AuditContext) -> None:
        attachment, record = self._attachment(attachment_id, operator)
        if not self.policy.can_delete(attachment, record, operator):
            raise PermissionDeniedError("当前病历状态或用户身份不允许删除附件")
        try:
            self.attachments.soft_delete(attachment, datetime.now(timezone.utc))
            self.audit.record(user_id=operator.id, action="ATTACHMENT_DELETE", module="attachment", target_type="attachment", target_id=attachment.id, context=audit_context, old_value={"record_id": attachment.record_id, "file_hash": attachment.file_hash}, new_value={"deleted": True})
            self.db.commit()
        except Exception:
            self.db.rollback()
            raise

    def list_for_record(self, record_id: int, *, operator: User) -> list[AttachmentRead]:
        record = self._record(record_id, operator)
        return [AttachmentRead.model_validate(item) for item in self.attachments.list_by_record(record.id)]

    def _record(self, record_id: int, operator: User):
        record = self.records.get_by_id(record_id)
        if record is None:
            raise ResourceNotFoundError("病历不存在")
        if not self.policy.can_view(record, operator):
            raise PermissionDeniedError("无权访问该病历")
        return record

    def _attachment(self, attachment_id: int, operator: User):
        attachment = self.attachments.get_by_id(attachment_id)
        if attachment is None:
            raise ResourceNotFoundError("附件不存在")
        return attachment, self._record(attachment.record_id, operator)

    def _validate_links(self, record_id: int, lab_report_id: int | None, examination_id: int | None) -> None:
        if lab_report_id is not None:
            report = self.labs.get_by_id(lab_report_id)
            if report is None or report.record_id != record_id:
                raise ValidationError("检验报告与病历关联不一致")
        if examination_id is not None:
            examination = self.examinations.get_by_id(examination_id)
            if examination is None or examination.record_id != record_id:
                raise ValidationError("检查与病历关联不一致")

    @classmethod
    def _validate_file(cls, upload: UploadFile) -> tuple[str, str, str]:
        filename = upload.filename or ""
        decoded = filename
        for _ in range(3):
            decoded = unquote(decoded)
        if not filename or len(filename) > 255 or decoded != PurePath(decoded).name or any(part in decoded for part in ("/", "\\", "..")):
            raise ValidationError("文件名包含非法路径")
        extension = PurePath(filename).suffix.lower()
        expected = cls.ALLOWED.get(extension)
        if expected is None:
            raise ValidationError("仅允许上传 PDF、PNG、JPG、JPEG 文件")
        mime_type, signature = expected
        if (upload.content_type or "").lower() != mime_type:
            raise ValidationError("文件扩展名与 MIME 类型不一致")
        header = upload.file.read(max(len(item[1]) for item in cls.ALLOWED.values()))
        upload.file.seek(0)
        if not header.startswith(signature):
            raise ValidationError("文件内容与声明类型不一致")
        return filename, extension, mime_type
