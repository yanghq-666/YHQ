"""就诊数据范围策略，避免权限范围散落在 Router。"""

from sqlalchemy import ColumnElement, false, or_, true

from app.models.encounter import Encounter
from app.models.user import User
from app.repositories.user_repository import UserRepository


class EncounterAccessPolicy:
    UNRESTRICTED_ROLES = {
        "ADMIN",
        "RECORD_ADMIN",
        "LAB_TECHNICIAN",
        "RADIOLOGY_TECHNICIAN",
    }

    def __init__(self, users: UserRepository) -> None:
        self.users = users

    def scope_filter(self, user: User) -> ColumnElement[bool]:
        roles = self.users.get_role_codes(user.id)
        if user.is_superuser or roles & self.UNRESTRICTED_ROLES:
            return true()
        if "SENIOR_DOCTOR" in roles or "NURSE" in roles:
            return (
                Encounter.department_id == user.department_id
                if user.department_id is not None
                else false()
            )
        if "DOCTOR" in roles:
            filters: list[ColumnElement[bool]] = [Encounter.doctor_id == user.id]
            if user.department_id is not None:
                filters.append(Encounter.department_id == user.department_id)
            return or_(*filters)
        return false()

    def can_access(self, encounter: Encounter, user: User) -> bool:
        roles = self.users.get_role_codes(user.id)
        if user.is_superuser or roles & self.UNRESTRICTED_ROLES:
            return True
        if "SENIOR_DOCTOR" in roles or "NURSE" in roles:
            return (
                user.department_id is not None
                and encounter.department_id == user.department_id
            )
        if "DOCTOR" in roles:
            return encounter.doctor_id == user.id or (
                user.department_id is not None
                and encounter.department_id == user.department_id
            )
        return False

