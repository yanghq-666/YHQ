"""全局检验、检查和附件工作列表服务。"""

from math import ceil

from sqlalchemy.orm import Session

from app.models.user import User
from app.repositories.user_repository import UserRepository
from app.repositories.worklist_repository import WorklistRepository
from app.schemas.common import PageData
from app.schemas.worklist import (
    AttachmentWorklistItem,
    AttachmentWorklistParams,
    ExaminationWorklistItem,
    ExaminationWorklistParams,
    LabWorklistItem,
    LabWorklistParams,
)
from app.services.encounter_access_policy import EncounterAccessPolicy


class WorklistService:
    def __init__(self, db: Session) -> None:
        self.db = db
        self.users = UserRepository(db)
        self.repository = WorklistRepository(db)
        self.scope = EncounterAccessPolicy(self.users)

    def list_labs(
        self, params: LabWorklistParams, *, operator: User
    ) -> PageData[LabWorklistItem]:
        rows, total = self.repository.list_labs(
            params, access_filter=self.scope.scope_filter(operator)
        )
        items = [
            LabWorklistItem(
                id=report.id,
                report_no=report.report_no,
                report_name=report.report_name,
                specimen_type=report.specimen_type,
                status=report.status,
                patient_name=patient.name,
                patient_no=patient.patient_no,
                encounter_no=encounter.encounter_no,
                record_no=record.record_no,
                requested_by_name=requester.real_name,
                reported_at=report.reported_at,
                created_at=report.created_at,
            )
            for report, patient, encounter, record, requester in rows
        ]
        return self._page(items, total, params)

    def list_examinations(
        self, params: ExaminationWorklistParams, *, operator: User
    ) -> PageData[ExaminationWorklistItem]:
        rows, total = self.repository.list_examinations(
            params, access_filter=self.scope.scope_filter(operator)
        )
        items = [
            ExaminationWorklistItem(
                id=item.id,
                examination_no=item.examination_no,
                examination_type=item.examination_type,
                examination_name=item.examination_name,
                body_part=item.body_part,
                status=item.status,
                patient_name=patient.name,
                patient_no=patient.patient_no,
                encounter_no=encounter.encounter_no,
                record_no=record.record_no,
                requested_by_name=requester.real_name,
                reported_at=item.reported_at,
                created_at=item.created_at,
            )
            for item, patient, encounter, record, requester in rows
        ]
        return self._page(items, total, params)

    def list_attachments(
        self, params: AttachmentWorklistParams, *, operator: User
    ) -> PageData[AttachmentWorklistItem]:
        rows, total = self.repository.list_attachments(
            params, access_filter=self.scope.scope_filter(operator)
        )
        items = [
            AttachmentWorklistItem(
                id=item.id,
                original_name=item.original_name,
                mime_type=item.mime_type,
                file_size=item.file_size,
                category=item.category,
                patient_name=patient.name,
                patient_no=patient.patient_no,
                encounter_no=encounter.encounter_no,
                record_no=record.record_no,
                uploaded_by_name=uploader.real_name,
                created_at=item.created_at,
            )
            for item, patient, encounter, record, uploader in rows
        ]
        return self._page(items, total, params)

    def user_names(self, *user_ids: int | None) -> dict[int, str]:
        return {
            user_id: user.real_name
            for user_id in {item for item in user_ids if item is not None}
            if (user := self.users.get_by_id(user_id)) is not None
        }

    @staticmethod
    def _page(items, total: int, params):
        return PageData(
            items=items,
            page=params.page,
            page_size=params.page_size,
            total=total,
            pages=ceil(total / params.page_size) if total else 0,
        )
