"""录入表单使用的轻量字典查询。"""

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.exceptions import ValidationError
from app.models.catalog import DiagnosisCatalog, DrugCatalog, LabTestCatalog


class CatalogService:
    def __init__(self, db: Session) -> None:
        self.db = db

    def list_drugs(self) -> list[DrugCatalog]:
        return list(self.db.scalars(select(DrugCatalog).where(DrugCatalog.is_active.is_(True)).order_by(DrugCatalog.drug_name)))

    def list_diagnoses(self) -> list[DiagnosisCatalog]:
        return list(self.db.scalars(select(DiagnosisCatalog).where(DiagnosisCatalog.is_active.is_(True)).order_by(DiagnosisCatalog.diagnosis_name)))

    def list_lab_tests(self) -> list[LabTestCatalog]:
        return list(self.db.scalars(select(LabTestCatalog).where(LabTestCatalog.is_active.is_(True)).order_by(LabTestCatalog.test_code)))

    def get_drug(self, catalog_id: int) -> DrugCatalog:
        item = self.db.get(DrugCatalog, catalog_id)
        if item is None or not item.is_active:
            raise ValidationError("所选药品不存在或已停用")
        return item

    def get_diagnosis(self, catalog_id: int) -> DiagnosisCatalog:
        item = self.db.get(DiagnosisCatalog, catalog_id)
        if item is None or not item.is_active:
            raise ValidationError("所选疾病不存在或已停用")
        return item

    def get_lab_test(self, catalog_id: int) -> LabTestCatalog:
        item = self.db.get(LabTestCatalog, catalog_id)
        if item is None or not item.is_active:
            raise ValidationError("所选检验项目不存在或已停用")
        return item
