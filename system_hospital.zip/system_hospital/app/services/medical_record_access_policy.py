"""病历数据范围和临床写入权限策略。"""

from sqlalchemy import ColumnElement, false

from app.models.encounter import Encounter
from app.models.enums import EncounterStatus
from app.models.medical_record import MedicalRecord
from app.models.user import User
from app.repositories.user_repository import UserRepository
from app.services.encounter_access_policy import EncounterAccessPolicy


class MedicalRecordAccessPolicy:
    def __init__(self, users: UserRepository) -> None:
        self.users = users
        self.encounters = EncounterAccessPolicy(users)

    def scope_filter(self, user: User) -> ColumnElement[bool]:
        return self.encounters.scope_filter(user)

    def can_view(self, record: MedicalRecord, user: User) -> bool:
        return self.encounters.can_access(record.encounter, user)

    def can_create(self, encounter: Encounter, user: User) -> bool:
        if encounter.status == EncounterStatus.CANCELLED:
            return False
        roles = self.users.get_role_codes(user.id)
        if user.is_superuser or "ADMIN" in roles:
            return True
        if "SENIOR_DOCTOR" in roles:
            return encounter.doctor_id == user.id or (
                user.department_id is not None
                and encounter.department_id == user.department_id
            )
        if "DOCTOR" in roles:
            return (
                encounter.doctor_id == user.id
                and encounter.status != EncounterStatus.COMPLETED
            )
        return False

    def can_update(self, record: MedicalRecord, user: User) -> bool:
        roles = self.users.get_role_codes(user.id)
        if user.is_superuser or "ADMIN" in roles:
            return True
        if "SENIOR_DOCTOR" in roles:
            return record.encounter.doctor_id == user.id or (
                user.department_id is not None
                and record.encounter.department_id == user.department_id
            )
        if "DOCTOR" in roles:
            return (
                record.encounter.doctor_id == user.id
                or record.created_by == user.id
            )
        return False

    def can_submit(self, record: MedicalRecord, user: User) -> bool:
        return self.can_update(record, user)

    def can_delete(self, record: MedicalRecord, user: User) -> bool:
        return self.can_update(record, user)

    def can_review(self, record: MedicalRecord, user: User) -> bool:
        """审核必须是上级医生/管理员、符合科室范围且不能自审。"""
        if record.created_by == user.id:
            return False
        roles = self.users.get_role_codes(user.id)
        return user.is_superuser or "ADMIN" in roles or (
            "SENIOR_DOCTOR" in roles
            and user.department_id is not None
            and user.department_id == record.encounter.department_id
        )

    def review_scope_filter(self, user: User) -> ColumnElement[bool]:
        roles = self.users.get_role_codes(user.id)
        if user.is_superuser or "ADMIN" in roles:
            return MedicalRecord.created_by != user.id
        if "SENIOR_DOCTOR" in roles and user.department_id is not None:
            return (
                (Encounter.department_id == user.department_id)
                & (MedicalRecord.created_by != user.id)
            )
        return false()

    def can_archive(self, _record: MedicalRecord, user: User) -> bool:
        """为下一阶段归档流程预留统一策略入口。"""
        roles = self.users.get_role_codes(user.id)
        return user.is_superuser or bool(roles & {"ADMIN", "RECORD_ADMIN"})
