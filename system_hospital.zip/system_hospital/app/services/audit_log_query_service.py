"""审计日志分页展示服务。"""

from math import ceil

from sqlalchemy.orm import Session

from app.repositories.audit_log_repository import AuditLogRepository
from app.schemas.audit_log import AuditLogListItem, AuditLogSearchParams
from app.schemas.common import PageData


class AuditLogQueryService:
    def __init__(self, db: Session) -> None:
        self.repository = AuditLogRepository(db)

    def search(self, params: AuditLogSearchParams) -> PageData[AuditLogListItem]:
        rows, total = self.repository.search(params)
        items = [
            AuditLogListItem(
                id=log.id,
                user_id=log.user_id,
                username=user.username if user else None,
                real_name=user.real_name if user else None,
                action=log.action,
                module=log.module,
                target_type=log.target_type,
                target_id=log.target_id,
                request_method=log.request_method,
                request_path=log.request_path,
                ip_address=log.ip_address,
                created_at=log.created_at,
            )
            for log, user in rows
        ]
        return PageData(
            items=items,
            page=params.page,
            page_size=params.page_size,
            total=total,
            pages=ceil(total / params.page_size) if total else 0,
        )
