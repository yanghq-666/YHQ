"""诊断创建、主诊断约束、修改、查询和软删除业务。"""

from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.core.exceptions import ResourceNotFoundError, ValidationError
from app.models.diagnosis import Diagnosis
from app.models.user import User
from app.repositories.diagnosis_repository import DiagnosisRepository
from app.schemas.diagnosis import DiagnosisCreate, DiagnosisRead, DiagnosisUpdate
from app.services.audit_service import AuditContext, AuditService
from app.services.catalog_service import CatalogService
from app.services.medical_record_service import MedicalRecordService
from app.services.sequence_service import SequenceService


class DiagnosisService:
    def __init__(self, db: Session) -> None:
        self.db = db
        self.repository = DiagnosisRepository(db)
        self.records = MedicalRecordService(db)
        self.audit = AuditService(db)
        self.sequences = SequenceService(db)
        self.catalogs = CatalogService(db)

    def create_diagnosis(
        self,
        record_id: int,
        payload: DiagnosisCreate,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> DiagnosisRead:
        record = self.records.get_editable_record(record_id, operator=operator)
        try:
            demoted_ids: list[int] = []
            if payload.is_primary:
                demoted_ids = self.repository.clear_primary(
                    record_id=record.id,
                    diagnosis_type=payload.diagnosis_type,
                )
            values = payload.model_dump()
            if payload.diagnosis_catalog_id is not None:
                catalog = self.catalogs.get_diagnosis(payload.diagnosis_catalog_id)
                values.update(
                    diagnosis_name=catalog.diagnosis_name,
                    diagnosis_code=catalog.diagnosis_code,
                )
            diagnosis = Diagnosis(
                encounter_id=record.encounter_id,
                record_id=record.id,
                created_by=operator.id,
                diagnosis_no=self.sequences.generate_number(
                    prefix="DX", sequence_name="diagnosis"
                ),
                **values,
            )
            self.repository.create(diagnosis)
            self.audit.record(
                user_id=operator.id,
                action="DIAGNOSIS_CREATE",
                module="diagnosis",
                target_type="diagnosis",
                target_id=diagnosis.id,
                context=audit_context,
                new_value={
                    "record_id": record.id,
                    "diagnosis_no": diagnosis.diagnosis_no,
                    "diagnosis_type": diagnosis.diagnosis_type.value,
                    "is_primary": diagnosis.is_primary,
                    "demoted_primary_ids": demoted_ids,
                },
            )
            self.db.commit()
            self.db.refresh(diagnosis)
            return DiagnosisRead.model_validate(diagnosis)
        except Exception:
            self.db.rollback()
            raise

    def list_diagnoses(
        self, record_id: int, *, operator: User
    ) -> list[DiagnosisRead]:
        self.records.get_record(record_id, operator=operator)
        return [
            DiagnosisRead.model_validate(item)
            for item in self.repository.list_by_record(record_id)
        ]

    def update_diagnosis(
        self,
        diagnosis_id: int,
        payload: DiagnosisUpdate,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> DiagnosisRead:
        diagnosis = self._get(diagnosis_id)
        self.records.get_editable_record(diagnosis.record_id, operator=operator)
        changes = payload.model_dump(exclude_unset=True)
        catalog_id = changes.get("diagnosis_catalog_id")
        if catalog_id is not None:
            catalog = self.catalogs.get_diagnosis(catalog_id)
            changes.update(
                diagnosis_name=catalog.diagnosis_name,
                diagnosis_code=catalog.diagnosis_code,
            )
        if not changes:
            raise ValidationError("没有可更新的诊断字段")
        changed_fields = sorted(
            field
            for field, value in changes.items()
            if getattr(diagnosis, field) != value
        )
        if not changed_fields:
            raise ValidationError("诊断内容没有变化")
        target_type = changes.get("diagnosis_type", diagnosis.diagnosis_type)
        target_primary = changes.get("is_primary", diagnosis.is_primary)
        try:
            demoted_ids: list[int] = []
            if target_primary:
                demoted_ids = self.repository.clear_primary(
                    record_id=diagnosis.record_id,
                    diagnosis_type=target_type,
                    exclude_id=diagnosis.id,
                )
            for field in changed_fields:
                setattr(diagnosis, field, changes[field])
            self.repository.update(diagnosis)
            self.audit.record(
                user_id=operator.id,
                action="DIAGNOSIS_UPDATE",
                module="diagnosis",
                target_type="diagnosis",
                target_id=diagnosis.id,
                context=audit_context,
                old_value={"changed_fields": changed_fields},
                new_value={
                    "changed_fields": changed_fields,
                    "diagnosis_type": diagnosis.diagnosis_type.value,
                    "is_primary": diagnosis.is_primary,
                    "demoted_primary_ids": demoted_ids,
                },
            )
            self.db.commit()
            self.db.refresh(diagnosis)
            return DiagnosisRead.model_validate(diagnosis)
        except Exception:
            self.db.rollback()
            raise

    def delete_diagnosis(
        self,
        diagnosis_id: int,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> None:
        diagnosis = self._get(diagnosis_id)
        self.records.get_editable_record(diagnosis.record_id, operator=operator)
        try:
            self.repository.soft_delete(diagnosis, datetime.now(timezone.utc))
            self.audit.record(
                user_id=operator.id,
                action="DIAGNOSIS_DELETE",
                module="diagnosis",
                target_type="diagnosis",
                target_id=diagnosis.id,
                context=audit_context,
                old_value={
                    "record_id": diagnosis.record_id,
                    "diagnosis_type": diagnosis.diagnosis_type.value,
                    "is_primary": diagnosis.is_primary,
                },
                new_value={"deleted": True},
            )
            self.db.commit()
        except Exception:
            self.db.rollback()
            raise

    def set_primary_diagnosis(
        self,
        diagnosis_id: int,
        *,
        operator: User,
        audit_context: AuditContext,
    ) -> DiagnosisRead:
        return self.update_diagnosis(
            diagnosis_id,
            DiagnosisUpdate(is_primary=True),
            operator=operator,
            audit_context=audit_context,
        )

    def _get(self, diagnosis_id: int) -> Diagnosis:
        diagnosis = self.repository.get_by_id(diagnosis_id)
        if diagnosis is None:
            raise ResourceNotFoundError("诊断不存在")
        return diagnosis
