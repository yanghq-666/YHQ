"""跨业务复用的并发安全编号生成服务。"""

from datetime import datetime
from zoneinfo import ZoneInfo

from sqlalchemy import update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.exceptions import ValidationError
from app.models.business_sequence import BusinessSequence

LOCAL_TIMEZONE = ZoneInfo("Asia/Shanghai")


class SequenceService:
    MAX_DAILY_SEQUENCE = 999_999

    def __init__(self, db: Session) -> None:
        self.db = db

    def generate_number(self, *, prefix: str, sequence_name: str) -> str:
        sequence_date = datetime.now(LOCAL_TIMEZONE).date()
        statement = (
            update(BusinessSequence)
            .where(
                BusinessSequence.sequence_name == sequence_name,
                BusinessSequence.sequence_date == sequence_date,
            )
            .values(current_value=BusinessSequence.current_value + 1)
            .returning(BusinessSequence.current_value)
        )
        value = self.db.scalar(statement)
        if value is None:
            try:
                with self.db.begin_nested():
                    self.db.add(
                        BusinessSequence(
                            sequence_name=sequence_name,
                            sequence_date=sequence_date,
                            current_value=1,
                        )
                    )
                    self.db.flush()
                value = 1
            except IntegrityError:
                value = self.db.scalar(statement)
                if value is None:
                    raise
        if value > self.MAX_DAILY_SEQUENCE:
            raise ValidationError(f"{sequence_name} 当日编号已用尽")
        return f"{prefix}{sequence_date:%Y%m%d}{value:06d}"
