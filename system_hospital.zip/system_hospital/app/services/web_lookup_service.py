"""Web 表单所需患者、医生和科室选项查询。"""

from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.models.department import Department
from app.models.enums import DepartmentStatus, UserStatus
from app.models.patient import Patient
from app.models.role import Role
from app.models.user import User, UserRole
from app.repositories.user_repository import UserRepository


class WebLookupService:
    def __init__(self, db: Session) -> None:
        self.db = db
        self.users = UserRepository(db)

    def encounter_form_options(
        self,
        operator: User,
        *,
        selected_patient_id: int | None = None,
    ) -> dict[str, list[object]]:
        roles = self.users.get_role_codes(operator.id)
        unrestricted = operator.is_superuser or "ADMIN" in roles

        department_statement = select(Department).where(
            Department.status == DepartmentStatus.ACTIVE
        )
        doctor_statement = (
            select(User)
            .join(UserRole, UserRole.user_id == User.id)
            .join(Role, Role.id == UserRole.role_id)
            .options(selectinload(User.department))
            .where(
                User.deleted_at.is_(None),
                User.status == UserStatus.ACTIVE,
                User.is_active.is_(True),
                Role.code.in_(("DOCTOR", "SENIOR_DOCTOR")),
            )
            .distinct()
        )
        if not unrestricted:
            department_statement = department_statement.where(
                Department.id == operator.department_id
            )
            doctor_statement = doctor_statement.where(
                User.department_id == operator.department_id
            )

        departments = list(
            self.db.scalars(
                department_statement.order_by(Department.name)
            ).all()
        )
        doctors = list(
            self.db.scalars(doctor_statement.order_by(User.real_name)).all()
        )
        patient_statement = (
            select(Patient)
            .where(Patient.deleted_at.is_(None))
            .order_by(Patient.created_at.desc(), Patient.id.desc())
            .limit(100)
        )
        patients = list(self.db.scalars(patient_statement).all())
        if selected_patient_id and all(
            item.id != selected_patient_id for item in patients
        ):
            selected = self.db.get(Patient, selected_patient_id)
            if selected is not None and selected.deleted_at is None:
                patients.append(selected)
        return {
            "patients": patients,
            "doctors": doctors,
            "departments": departments,
        }
