"""Dashboard 统计和最近业务数据聚合。"""

from dataclasses import dataclass
from datetime import datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session, joinedload

from app.models.encounter import Encounter
from app.models.enums import LabReportStatus, MedicalRecordStatus
from app.models.lab_report import LabReport
from app.models.medical_record import MedicalRecord
from app.models.patient import Patient
from app.models.role import Role
from app.models.user import User, UserRole
from app.repositories.user_repository import UserRepository
from app.services.encounter_access_policy import EncounterAccessPolicy
from app.services.medical_record_access_policy import MedicalRecordAccessPolicy

LOCAL_TIMEZONE = ZoneInfo("Asia/Shanghai")


@dataclass(frozen=True)
class DashboardData:
    view: str
    cards: list[dict[str, object]]
    recent_encounters: list[Encounter]
    pending_records: list[MedicalRecord]
    recent_records: list[MedicalRecord]
    pending_archive_records: list[MedicalRecord]


class DashboardService:
    """按角色返回展示所需的只读聚合数据。"""

    def __init__(self, db: Session) -> None:
        self.db = db
        self.users = UserRepository(db)

    def get_dashboard(self, user: User) -> DashboardData:
        roles = self.users.get_role_codes(user.id)
        if user.is_superuser or "ADMIN" in roles:
            view = "admin"
            cards = self._admin_cards()
        elif "LAB_TECHNICIAN" in roles:
            view = "lab"
            cards = self._lab_cards()
        else:
            view = "doctor"
            cards = self._doctor_cards(user)

        show_clinical_lists = view in {"admin", "doctor"}
        return DashboardData(
            view=view,
            cards=cards,
            recent_encounters=(self._recent_encounters(user) if show_clinical_lists else []),
            pending_records=[],
            recent_records=(self._recent_records(user) if show_clinical_lists else []),
            pending_archive_records=[],
        )

    def _admin_cards(self) -> list[dict[str, object]]:
        start, end = self._today_bounds()
        return [
            self._card(
                "患者总数",
                self._count(Patient, Patient.deleted_at.is_(None)),
                "people",
                "primary",
            ),
            self._card(
                "今日就诊",
                self._count(
                    Encounter,
                    Encounter.deleted_at.is_(None),
                    Encounter.visit_time >= start,
                    Encounter.visit_time < end,
                ),
                "calendar2-check",
                "warning",
            ),
            self._card("医生总数", self._doctor_count(), "person-workspace", "success"),
            self._card(
                "检验报告",
                self._count(LabReport, LabReport.deleted_at.is_(None)),
                "droplet-half",
                "info",
            ),
            self._card(
                "草稿病历",
                self._record_count(MedicalRecordStatus.DRAFT),
                "file-earmark-text",
                "secondary",
            ),
            self._card(
                "已完成病历",
                self._record_count(MedicalRecordStatus.APPROVED),
                "check2-circle",
                "success",
            ),
            self._card(
                "用户总数",
                self._count(User, User.deleted_at.is_(None)),
                "person-badge",
                "primary",
            ),
        ]

    def _lab_cards(self) -> list[dict[str, object]]:
        start, end = self._today_bounds()
        return [
            self._card(
                "待检验",
                self._lab_count(LabReportStatus.PENDING),
                "inbox",
                "warning",
            ),
            self._card(
                "进行中",
                self._lab_count(LabReportStatus.IN_PROGRESS),
                "hourglass-split",
                "primary",
            ),
            self._card(
                "今日完成",
                self._count(
                    LabReport,
                    LabReport.deleted_at.is_(None),
                    LabReport.status == LabReportStatus.COMPLETED,
                    LabReport.reported_at >= start,
                    LabReport.reported_at < end,
                ),
                "calendar2-check",
                "success",
            ),
            self._card(
                "已完成报告",
                self._lab_count(LabReportStatus.COMPLETED),
                "check2-circle",
                "info",
            ),
        ]

    def _doctor_cards(self, user: User) -> list[dict[str, object]]:
        start, end = self._today_bounds()
        mine = or_(MedicalRecord.created_by == user.id, Encounter.doctor_id == user.id)
        return [
            self._card(
                "今日就诊",
                self._count(
                    Encounter,
                    Encounter.deleted_at.is_(None),
                    Encounter.doctor_id == user.id,
                    Encounter.visit_time >= start,
                    Encounter.visit_time < end,
                ),
                "calendar2-check",
                "primary",
            ),
            self._card(
                "我的草稿病历",
                self._mine_record_count(mine, MedicalRecordStatus.DRAFT),
                "file-earmark-text",
                "secondary",
            ),
            self._card(
                "已完成病历",
                self._mine_record_count(mine, MedicalRecordStatus.APPROVED),
                "check2-circle",
                "success",
            ),
            self._card(
                "检验待结果",
                self._count(
                    LabReport,
                    LabReport.deleted_at.is_(None),
                    LabReport.requested_by == user.id,
                    LabReport.status.in_(
                        (LabReportStatus.PENDING, LabReportStatus.IN_PROGRESS)
                    ),
                ),
                "droplet-half",
                "warning",
            ),
        ]

    def _recent_encounters(self, user: User) -> list[Encounter]:
        scope = EncounterAccessPolicy(self.users).scope_filter(user)
        statement = (
            select(Encounter)
            .options(
                joinedload(Encounter.patient),
                joinedload(Encounter.doctor),
                joinedload(Encounter.department),
            )
            .where(Encounter.deleted_at.is_(None), scope)
            .order_by(Encounter.visit_time.desc(), Encounter.id.desc())
            .limit(10)
        )
        return list(self.db.scalars(statement).unique().all())

    def _recent_records(self, user: User) -> list[MedicalRecord]:
        scope = MedicalRecordAccessPolicy(self.users).scope_filter(user)
        statement = (
            select(MedicalRecord)
            .join(MedicalRecord.encounter)
            .options(
                joinedload(MedicalRecord.encounter).joinedload(Encounter.patient),
                joinedload(MedicalRecord.encounter).joinedload(Encounter.doctor),
                joinedload(MedicalRecord.encounter).joinedload(Encounter.department),
            )
            .where(MedicalRecord.deleted_at.is_(None), scope)
            .order_by(MedicalRecord.updated_at.desc(), MedicalRecord.id.desc())
            .limit(10)
        )
        return list(self.db.scalars(statement).unique().all())

    def _mine_record_count(
        self, mine, status: MedicalRecordStatus | None = None
    ) -> int:
        filters = [MedicalRecord.deleted_at.is_(None), mine]
        if status is not None:
            filters.append(MedicalRecord.status == status)
        statement = (
            select(func.count(MedicalRecord.id))
            .join(MedicalRecord.encounter)
            .where(*filters)
        )
        return self.db.scalar(statement) or 0

    def _record_count(self, status: MedicalRecordStatus) -> int:
        return self._count(
            MedicalRecord,
            MedicalRecord.deleted_at.is_(None),
            MedicalRecord.status == status,
        )


    def _lab_count(self, status: LabReportStatus) -> int:
        return self._count(
            LabReport,
            LabReport.deleted_at.is_(None),
            LabReport.status == status,
        )

    def _doctor_count(self) -> int:
        statement = (
            select(func.count(func.distinct(User.id)))
            .join(UserRole, UserRole.user_id == User.id)
            .join(Role, Role.id == UserRole.role_id)
            .where(
                User.deleted_at.is_(None),
                User.is_active.is_(True),
                Role.code == "DOCTOR",
            )
        )
        return self.db.scalar(statement) or 0

    def _count(self, model, *filters) -> int:
        return self.db.scalar(select(func.count(model.id)).where(*filters)) or 0

    @staticmethod
    def _card(
        label: str, value: int, icon: str, color: str
    ) -> dict[str, object]:
        return {"label": label, "value": value, "icon": icon, "color": color}

    @staticmethod
    def _today_bounds() -> tuple[datetime, datetime]:
        now = datetime.now(LOCAL_TIMEZONE)
        start = datetime.combine(now.date(), time.min, tzinfo=LOCAL_TIMEZONE)
        return (
            start.astimezone(timezone.utc),
            (start + timedelta(days=1)).astimezone(timezone.utc),
        )
