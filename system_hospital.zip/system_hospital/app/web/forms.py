"""HTML 表单到 Pydantic Schema 的安全转换辅助。"""

from datetime import date, datetime
from typing import Any

from pydantic import ValidationError as PydanticValidationError


def optional_text(value: Any) -> str | None:
    if value is None:
        return None
    normalized = str(value).strip()
    return normalized or None


def optional_int(value: Any) -> int | None:
    normalized = optional_text(value)
    return int(normalized) if normalized is not None else None


def optional_date(value: Any) -> date | None:
    normalized = optional_text(value)
    return date.fromisoformat(normalized) if normalized else None


def optional_datetime(value: Any) -> datetime | None:
    normalized = optional_text(value)
    return datetime.fromisoformat(normalized) if normalized else None


def validation_message(exc: PydanticValidationError | ValueError) -> str:
    if isinstance(exc, PydanticValidationError):
        errors = exc.errors()
        if errors:
            message = str(errors[0].get("msg", "表单内容不正确"))
            return message.removeprefix("Value error, ")
    return str(exc) or "表单内容不正确"


def compact_query(values: Any) -> dict[str, str]:
    """移除 HTML 筛选表单提交的空字符串，交由 Schema 使用默认值。"""
    return {
        str(key): str(value).strip()
        for key, value in values.items()
        if str(value).strip()
    }
