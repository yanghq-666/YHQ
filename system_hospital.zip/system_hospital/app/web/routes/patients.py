"""患者管理 Web 页面。"""

from typing import Annotated, Any

from fastapi import APIRouter, Depends, Request
from pydantic import ValidationError as PydanticValidationError

from app.api.deps import DatabaseSession
from app.core.exceptions import AppException
from app.models.enums import BloodType, Gender
from app.models.user import User
from app.schemas.medical_record import MedicalRecordSearchParams
from app.schemas.patient import PatientCreate, PatientSearchParams, PatientUpdate
from app.services.audit_service import AuditContext
from app.services.encounter_service import EncounterService
from app.services.medical_record_service import MedicalRecordService
from app.services.patient_service import PatientService
from app.web.deps import redirect_with_flash, require_web_permission
from app.web.forms import (
    compact_query,
    optional_date,
    optional_text,
    validation_message,
)
from app.web.templating import render_template

router = APIRouter(tags=["Web Patients"])
PatientViewer = Annotated[User, Depends(require_web_permission("patient:view"))]
PatientCreator = Annotated[
    User, Depends(require_web_permission("patient:create"))
]
PatientEditor = Annotated[
    User, Depends(require_web_permission("patient:update"))
]


def _audit_context(request: Request) -> AuditContext:
    return AuditContext(
        request_method=request.method,
        request_path=request.url.path,
        ip_address=request.client.host if request.client else None,
    )


def _form_payload(
    form: Any, *, include_sensitive: bool = True
) -> dict[str, Any]:
    values = {
        "name": str(form.get("name", "")),
        "gender": str(form.get("gender", Gender.UNKNOWN.value)),
        "birthday": optional_date(form.get("birthday")),
        "address": optional_text(form.get("address")),
        "blood_type": str(form.get("blood_type", BloodType.UNKNOWN.value)),
        "allergy_history": optional_text(form.get("allergy_history")),
        "emergency_contact": optional_text(form.get("emergency_contact")),
        "remark": optional_text(form.get("remark")),
    }
    if include_sensitive:
        values.update(
            id_card=optional_text(form.get("id_card")),
            phone=optional_text(form.get("phone")),
            emergency_phone=optional_text(form.get("emergency_phone")),
        )
    return values


def _form_values(data: Any | None = None) -> dict[str, Any]:
    if data is None:
        return {"gender": Gender.UNKNOWN.value, "blood_type": BloodType.UNKNOWN.value}
    if hasattr(data, "model_dump"):
        return data.model_dump(mode="json")
    return dict(data)


def _render_form(
    request: Request,
    *,
    title: str,
    form_action: str,
    values: dict[str, Any],
    editing: bool,
    can_edit_sensitive: bool,
    error: str | None = None,
    status_code: int = 200,
):
    return render_template(
        request,
        "patients/form.html",
        status_code=status_code,
        title=title,
        page_title=title,
        active_menu="patients",
        form_action=form_action,
        form_values=values,
        editing=editing,
        can_edit_sensitive=can_edit_sensitive,
        genders=list(Gender),
        blood_types=list(BloodType),
        error=error,
    )


@router.get("/patients", include_in_schema=False)
def patient_list(
    request: Request,
    current_user: PatientViewer,
    db: DatabaseSession,
):
    error = None
    status_code = 200
    try:
        params = PatientSearchParams(**compact_query(request.query_params))
    except PydanticValidationError as exc:
        params = PatientSearchParams()
        error = validation_message(exc)
        status_code = 422
    page = PatientService(db).list_patients(params, operator=current_user)
    return render_template(
        request,
        "patients/list.html",
        status_code=status_code,
        title="患者管理",
        active_menu="patients",
        page=page,
        params=params,
        genders=list(Gender),
        blood_types=list(BloodType),
        error=error,
    )


@router.get("/patients/new", include_in_schema=False)
def patient_create_page(request: Request, _user: PatientCreator):
    return _render_form(
        request,
        title="新增患者",
        form_action="/patients/new",
        values=_form_values(),
        editing=False,
        can_edit_sensitive=True,
    )


@router.post("/patients/new", include_in_schema=False)
async def patient_create(
    request: Request,
    current_user: PatientCreator,
    db: DatabaseSession,
):
    form = await request.form()
    try:
        values = _form_payload(form)
        payload = PatientCreate(**values)
        patient = PatientService(db).create_patient(
            payload,
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except (PydanticValidationError, ValueError) as exc:
        values = dict(form)
        return _render_form(
            request,
            title="新增患者",
            form_action="/patients/new",
            values=_form_values(values),
            editing=False,
            can_edit_sensitive=True,
            error=validation_message(exc),
            status_code=422,
        )
    except AppException as exc:
        return _render_form(
            request,
            title="新增患者",
            form_action="/patients/new",
            values=_form_values(values),
            editing=False,
            can_edit_sensitive=True,
            error=exc.message,
            status_code=exc.status_code,
        )
    return redirect_with_flash(
        f"/patients/{patient.id}", "患者建档成功"
    )


@router.get("/patients/{patient_id}", include_in_schema=False)
def patient_detail(
    patient_id: int,
    request: Request,
    current_user: PatientViewer,
    db: DatabaseSession,
):
    service = PatientService(db)
    patient = service.get_patient_detail(patient_id, operator=current_user)
    permissions = request.state.web_context["permissions"]
    encounters = (
        EncounterService(db).list_by_patient(patient_id, operator=current_user)
        if "encounter:view" in permissions
        else []
    )
    records = (
        MedicalRecordService(db).list_records(
            MedicalRecordSearchParams(patient_id=patient_id, page_size=100),
            operator=current_user,
        ).items
        if "record:view" in permissions
        else []
    )
    return render_template(
        request,
        "patients/detail.html",
        title=f"患者 {patient.name}",
        active_menu="patients",
        patient=patient,
        encounters=encounters,
        records=records,
    )


@router.get("/patients/{patient_id}/edit", include_in_schema=False)
def patient_edit_page(
    patient_id: int,
    request: Request,
    current_user: PatientEditor,
    db: DatabaseSession,
):
    patient = PatientService(db).get_patient_detail(
        patient_id, operator=current_user
    )
    can_edit_sensitive = current_user.is_superuser or (
        "ADMIN" in request.state.web_context["roles"]
    )
    return _render_form(
        request,
        title="编辑患者",
        form_action=f"/patients/{patient_id}/edit",
        values=_form_values(patient),
        editing=True,
        can_edit_sensitive=can_edit_sensitive,
    )


@router.post("/patients/{patient_id}/edit", include_in_schema=False)
async def patient_edit(
    patient_id: int,
    request: Request,
    current_user: PatientEditor,
    db: DatabaseSession,
):
    form = await request.form()
    can_edit_sensitive = current_user.is_superuser or (
        "ADMIN" in request.state.web_context["roles"]
    )
    try:
        values = _form_payload(
            form, include_sensitive=can_edit_sensitive
        )
        payload = PatientUpdate(**values)
        patient = PatientService(db).update_patient(
            patient_id,
            payload,
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except (PydanticValidationError, ValueError) as exc:
        values = dict(form)
        return _render_form(
            request,
            title="编辑患者",
            form_action=f"/patients/{patient_id}/edit",
            values=_form_values(values),
            editing=True,
            can_edit_sensitive=can_edit_sensitive,
            error=validation_message(exc),
            status_code=422,
        )
    except AppException as exc:
        return _render_form(
            request,
            title="编辑患者",
            form_action=f"/patients/{patient_id}/edit",
            values=_form_values(values),
            editing=True,
            can_edit_sensitive=can_edit_sensitive,
            error=exc.message,
            status_code=exc.status_code,
        )
    return redirect_with_flash(
        f"/patients/{patient.id}", "患者信息更新成功"
    )


@router.post("/patients/{patient_id}/delete", include_in_schema=False)
def patient_delete(
    patient_id: int,
    request: Request,
    current_user: PatientEditor,
    db: DatabaseSession,
):
    try:
        PatientService(db).delete_patient(
            patient_id,
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except AppException as exc:
        return redirect_with_flash(
            f"/patients/{patient_id}", exc.message, category="danger"
        )
    return redirect_with_flash("/patients", "患者已删除")
