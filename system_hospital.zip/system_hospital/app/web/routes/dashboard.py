"""角色化工作台与个人信息页面。"""

from fastapi import APIRouter, Request

from app.api.deps import DatabaseSession
from app.repositories.user_repository import UserRepository
from app.services.dashboard_service import DashboardService
from app.web.deps import CurrentWebUser
from app.web.templating import render_template

router = APIRouter(tags=["Web"])


@router.get("/dashboard", include_in_schema=False)
def dashboard(request: Request, current_user: CurrentWebUser, db: DatabaseSession):
    return render_template(
        request,
        "dashboard/index.html",
        title="首页",
        active_menu="dashboard",
        dashboard=DashboardService(db).get_dashboard(current_user),
    )


@router.get("/profile", include_in_schema=False)
def profile(request: Request, current_user: CurrentWebUser, db: DatabaseSession):
    users = UserRepository(db)
    return render_template(
        request,
        "profile.html",
        title="个人信息",
        active_menu="profile",
        role_codes=sorted(users.get_role_codes(current_user.id)),
        permission_codes=sorted(users.get_permission_codes(current_user.id)),
    )
