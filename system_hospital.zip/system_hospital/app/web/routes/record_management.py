"""病案管理员的病历查询与归档页面。"""

from typing import Annotated

from fastapi import APIRouter, Depends, Request
from pydantic import ValidationError as PydanticValidationError

from app.api.deps import DatabaseSession
from app.core.exceptions import AppException
from app.models.enums import MedicalRecordStatus
from app.models.user import User
from app.schemas.medical_record import MedicalRecordSearchParams
from app.services.audit_service import AuditContext
from app.services.medical_record_service import MedicalRecordService
from app.web.deps import redirect_with_flash, require_web_permission
from app.web.forms import compact_query, validation_message
from app.web.templating import render_template

router = APIRouter(tags=["Web Record Management"])
RecordArchiver = Annotated[User, Depends(require_web_permission("record:archive"))]


@router.get("/records", include_in_schema=False)
def record_management(
    request: Request,
    current_user: RecordArchiver,
    db: DatabaseSession,
):
    error = None
    status_code = 200
    try:
        params = MedicalRecordSearchParams(**compact_query(request.query_params))
    except PydanticValidationError as exc:
        params = MedicalRecordSearchParams()
        error = validation_message(exc)
        status_code = 422
    page = MedicalRecordService(db).list_records(params, operator=current_user)
    return render_template(
        request,
        "records/list.html",
        status_code=status_code,
        title="病案管理",
        active_menu="record-admin",
        page=page,
        params=params,
        statuses=list(MedicalRecordStatus),
        error=error,
    )


@router.post("/records/{record_id}/archive", include_in_schema=False)
def archive_record(
    record_id: int,
    request: Request,
    current_user: RecordArchiver,
    db: DatabaseSession,
):
    try:
        MedicalRecordService(db).archive_record(
            record_id,
            operator=current_user,
            audit_context=AuditContext(
                request.method,
                request.url.path,
                request.client.host if request.client else None,
            ),
        )
    except AppException as exc:
        return redirect_with_flash("/records", exc.message, category="danger")
    return redirect_with_flash("/records", "病历归档成功")
