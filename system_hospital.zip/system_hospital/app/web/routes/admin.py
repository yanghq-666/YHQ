"""系统用户、科室与角色权限管理 Web 页面。"""

from typing import Annotated, Any

from fastapi import APIRouter, Depends, Request
from pydantic import ValidationError as PydanticValidationError

from app.api.deps import DatabaseSession
from app.core.exceptions import AppException
from app.models.enums import DepartmentStatus
from app.models.user import User
from app.schemas.department import DepartmentCreate, DepartmentUpdate
from app.schemas.user import UserCreate, UserUpdate
from app.services.admin_service import AdminService
from app.services.user_service import UserService
from app.web.deps import redirect_with_flash, require_web_permission
from app.web.forms import optional_int, optional_text, validation_message
from app.web.templating import render_template

router = APIRouter(tags=["Web System Administration"])
UserAdmin = Annotated[User, Depends(require_web_permission("admin:user"))]
DepartmentAdmin = Annotated[
    User, Depends(require_web_permission("admin:department"))
]
RoleAdmin = Annotated[User, Depends(require_web_permission("admin:role"))]


def _user_options(db) -> tuple[list[Any], list[Any]]:
    admin = AdminService(db)
    return admin.list_roles(), admin.list_departments()


def _user_values(user: Any | None = None) -> dict[str, Any]:
    if user is None:
        return {
            "username": "",
            "real_name": "",
            "employee_no": "",
            "email": "",
            "phone": "",
            "department_id": None,
            "role_ids": [],
            "is_active": True,
        }
    return {
        "username": user.username,
        "real_name": user.real_name,
        "employee_no": user.employee_no or "",
        "email": user.email or "",
        "phone": user.phone or "",
        "department_id": user.department_id,
        "role_ids": list(user.roles),
        "is_active": user.is_active,
    }


def _render_user_form(
    request: Request,
    db,
    *,
    values: dict[str, Any],
    editing: bool,
    user_id: int | None = None,
    error: str | None = None,
    status_code: int = 200,
):
    roles, departments = _user_options(db)
    return render_template(
        request,
        "admin/user_form.html",
        status_code=status_code,
        title="编辑用户" if editing else "新增用户",
        active_menu="admin-users",
        form_action=(f"/admin/users/{user_id}/edit" if editing else "/admin/users/new"),
        values=values,
        roles=roles,
        departments=departments,
        editing=editing,
        user_id=user_id,
        error=error,
    )


@router.get("/admin/users", include_in_schema=False)
def users_page(request: Request, _user: UserAdmin, db: DatabaseSession):
    users = UserService(db).list_users(offset=0, limit=200)
    return render_template(
        request,
        "admin/users.html",
        title="用户管理",
        active_menu="admin-users",
        users=users,
    )


@router.get("/admin/users/new", include_in_schema=False)
def user_create_page(request: Request, _user: UserAdmin, db: DatabaseSession):
    return _render_user_form(
        request, db, values=_user_values(), editing=False
    )


@router.post("/admin/users/new", include_in_schema=False)
async def user_create(
    request: Request, _user: UserAdmin, db: DatabaseSession
):
    form = await request.form()
    values = {
        "username": optional_text(form.get("username")) or "",
        "password": str(form.get("password") or ""),
        "real_name": optional_text(form.get("real_name")) or "",
        "employee_no": optional_text(form.get("employee_no")),
        "email": optional_text(form.get("email")),
        "phone": optional_text(form.get("phone")),
        "department_id": optional_int(form.get("department_id")),
        "role_ids": [int(item) for item in form.getlist("role_ids")],
        "is_active": form.get("is_active") == "on",
    }
    try:
        user = UserService(db).create_user(UserCreate(**values))
    except (PydanticValidationError, ValueError) as exc:
        return _render_user_form(
            request,
            db,
            values=values,
            editing=False,
            error=validation_message(exc),
            status_code=422,
        )
    except AppException as exc:
        return _render_user_form(
            request,
            db,
            values=values,
            editing=False,
            error=exc.message,
            status_code=exc.status_code,
        )
    return redirect_with_flash(f"/admin/users/{user.id}/edit", "用户创建成功")


@router.get("/admin/users/{user_id}/edit", include_in_schema=False)
def user_edit_page(
    user_id: int,
    request: Request,
    _user: UserAdmin,
    db: DatabaseSession,
):
    service = UserService(db)
    user = service.to_response(service.get_user(user_id))
    return _render_user_form(
        request,
        db,
        values=_user_values(user),
        editing=True,
        user_id=user_id,
    )


@router.post("/admin/users/{user_id}/edit", include_in_schema=False)
async def user_edit(
    user_id: int,
    request: Request,
    _user: UserAdmin,
    db: DatabaseSession,
):
    form = await request.form()
    role_ids = [int(item) for item in form.getlist("role_ids")]
    values = {
        "real_name": optional_text(form.get("real_name")) or "",
        "employee_no": optional_text(form.get("employee_no")),
        "email": optional_text(form.get("email")),
        "phone": optional_text(form.get("phone")),
        "department_id": optional_int(form.get("department_id")),
        "is_active": form.get("is_active") == "on",
        "role_ids": role_ids,
        "username": str(form.get("username") or ""),
    }
    try:
        service = UserService(db)
        updated = service.update_user(
            user_id,
            UserUpdate(
                real_name=values["real_name"],
                employee_no=values["employee_no"],
                email=values["email"],
                phone=values["phone"],
                department_id=values["department_id"],
                is_active=values["is_active"],
            ),
        )
        service.assign_roles(updated.id, role_ids)
    except (PydanticValidationError, ValueError) as exc:
        return _render_user_form(
            request, db, values=values, editing=True, user_id=user_id,
            error=validation_message(exc), status_code=422,
        )
    except AppException as exc:
        return _render_user_form(
            request, db, values=values, editing=True, user_id=user_id,
            error=exc.message, status_code=exc.status_code,
        )
    return redirect_with_flash("/admin/users", "用户信息和角色已保存")


@router.post("/admin/users/{user_id}/toggle", include_in_schema=False)
def toggle_user(
    user_id: int,
    request: Request,
    current_user: UserAdmin,
    db: DatabaseSession,
):
    service = UserService(db)
    user = service.get_user(user_id)
    if user.id == current_user.id and user.is_active:
        return redirect_with_flash(
            "/admin/users", "不能停用当前登录账号", category="danger"
        )
    enable = not user.is_active
    service.update_user(user.id, UserUpdate(is_active=enable))
    return redirect_with_flash(
        "/admin/users", "用户已启用" if enable else "用户已停用"
    )


@router.post("/admin/users/{user_id}/reset-password", include_in_schema=False)
async def reset_password(
    user_id: int,
    request: Request,
    _user: UserAdmin,
    db: DatabaseSession,
):
    form = await request.form()
    try:
        UserService(db).update_user(
            user_id, UserUpdate(password=str(form.get("password") or ""))
        )
    except (PydanticValidationError, AppException) as exc:
        message = exc.message if isinstance(exc, AppException) else validation_message(exc)
        return redirect_with_flash(
            f"/admin/users/{user_id}/edit", message, category="danger"
        )
    return redirect_with_flash(
        f"/admin/users/{user_id}/edit", "密码重置成功"
    )


@router.get("/admin/departments", include_in_schema=False)
def departments_page(
    request: Request, _user: DepartmentAdmin, db: DatabaseSession
):
    return render_template(
        request,
        "admin/departments.html",
        title="科室管理",
        active_menu="admin-departments",
        departments=AdminService(db).list_departments(),
        statuses=list(DepartmentStatus),
    )


@router.post("/admin/departments/new", include_in_schema=False)
async def create_department(
    request: Request, _user: DepartmentAdmin, db: DatabaseSession
):
    form = await request.form()
    try:
        payload = DepartmentCreate(
            department_code=str(form.get("department_code") or ""),
            name=str(form.get("name") or ""),
            description=optional_text(form.get("description")),
        )
        AdminService(db).create_department(payload)
    except (PydanticValidationError, AppException) as exc:
        message = exc.message if isinstance(exc, AppException) else validation_message(exc)
        return redirect_with_flash(
            "/admin/departments", message, category="danger"
        )
    return redirect_with_flash("/admin/departments", "科室创建成功")


@router.post("/admin/departments/{department_id}/edit", include_in_schema=False)
async def edit_department(
    department_id: int,
    request: Request,
    _user: DepartmentAdmin,
    db: DatabaseSession,
):
    form = await request.form()
    try:
        payload = DepartmentUpdate(
            name=str(form.get("name") or ""),
            description=optional_text(form.get("description")),
            status=DepartmentStatus(str(form.get("status") or "ACTIVE")),
        )
        AdminService(db).update_department(department_id, payload)
    except (PydanticValidationError, ValueError, AppException) as exc:
        message = exc.message if isinstance(exc, AppException) else validation_message(exc)
        return redirect_with_flash(
            "/admin/departments", message, category="danger"
        )
    return redirect_with_flash("/admin/departments", "科室更新成功")


@router.get("/admin/roles", include_in_schema=False)
def roles_page(request: Request, _user: RoleAdmin, db: DatabaseSession):
    return render_template(
        request,
        "admin/roles.html",
        title="角色权限",
        active_menu="admin-roles",
        roles=AdminService(db).list_roles(),
    )


@router.get("/admin/roles/{role_id}", include_in_schema=False)
def role_detail(
    role_id: int,
    request: Request,
    _user: RoleAdmin,
    db: DatabaseSession,
):
    service = AdminService(db)
    role = next((item for item in service.list_roles() if item.id == role_id), None)
    if role is None:
        from app.core.exceptions import ResourceNotFoundError

        raise ResourceNotFoundError("角色不存在")
    return render_template(
        request,
        "admin/role_detail.html",
        title=f"角色权限：{role.name}",
        active_menu="admin-roles",
        role=role,
        all_permissions=service.list_permissions(),
    )


@router.post("/admin/roles/{role_id}", include_in_schema=False)
async def save_role_permissions(
    role_id: int,
    request: Request,
    _user: RoleAdmin,
    db: DatabaseSession,
):
    form = await request.form()
    permission_ids = [int(item) for item in form.getlist("permission_ids")]
    try:
        AdminService(db).assign_role_permissions(role_id, permission_ids)
    except AppException as exc:
        return redirect_with_flash(
            f"/admin/roles/{role_id}", exc.message, category="danger"
        )
    return redirect_with_flash(
        f"/admin/roles/{role_id}", "角色权限保存成功"
    )
