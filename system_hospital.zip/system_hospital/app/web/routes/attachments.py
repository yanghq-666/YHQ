"""使用 Web Cookie 身份的附件工作列表、上传、查看与下载。"""

from typing import Annotated

from fastapi import APIRouter, Depends, File, Form, Request, UploadFile
from pydantic import ValidationError as PydanticValidationError
from fastapi.responses import Response

from app.api.deps import DatabaseSession, Storage
from app.core.config import get_settings
from app.core.exceptions import AppException
from app.models.enums import AttachmentCategory
from app.models.user import User
from app.schemas.worklist import AttachmentWorklistParams
from app.services.attachment_service import AttachmentService
from app.services.audit_service import AuditContext
from app.services.medical_record_service import MedicalRecordService
from app.services.worklist_service import WorklistService
from app.web.deps import redirect_with_flash, require_web_permission
from app.web.forms import compact_query, optional_int, optional_text, validation_message
from app.web.templating import render_template

router = APIRouter(tags=["Web Attachments"])
AttachmentViewer = Annotated[
    User, Depends(require_web_permission("attachment:view"))
]
AttachmentUploader = Annotated[
    User, Depends(require_web_permission("attachment:upload"))
]


@router.get("/attachments", include_in_schema=False)
def attachment_list(
    request: Request,
    current_user: AttachmentViewer,
    db: DatabaseSession,
):
    error = None
    status_code = 200
    try:
        params = AttachmentWorklistParams(**compact_query(request.query_params))
    except PydanticValidationError as exc:
        params = AttachmentWorklistParams()
        error = validation_message(exc)
        status_code = 422
    page = WorklistService(db).list_attachments(params, operator=current_user)
    return render_template(
        request,
        "attachments/list.html",
        status_code=status_code,
        title="附件管理",
        active_menu="attachments",
        page=page,
        params=params,
        categories=list(AttachmentCategory),
        error=error,
    )


@router.get("/attachments/upload", include_in_schema=False)
def attachment_upload_page(
    request: Request,
    current_user: AttachmentUploader,
    db: DatabaseSession,
    record_id: int,
    category: AttachmentCategory = AttachmentCategory.MEDICAL_RECORD,
    lab_report_id: int | None = None,
    examination_id: int | None = None,
):
    record = MedicalRecordService(db).get_record_detail(
        record_id, operator=current_user
    )
    return render_template(
        request,
        "attachments/upload.html",
        title="上传附件",
        active_menu="attachments",
        record=record,
        categories=list(AttachmentCategory),
        values={
            "category": category.value,
            "lab_report_id": lab_report_id or "",
            "examination_id": examination_id or "",
            "description": "",
        },
    )


@router.post("/attachments/upload", include_in_schema=False)
def attachment_upload(
    request: Request,
    current_user: AttachmentUploader,
    db: DatabaseSession,
    storage: Storage,
    record_id: Annotated[int, Form(gt=0)],
    file: Annotated[UploadFile, File()],
    category: Annotated[AttachmentCategory, Form()] = AttachmentCategory.MEDICAL_RECORD,
    description: Annotated[str | None, Form(max_length=2000)] = None,
    lab_report_id: Annotated[int | None, Form(gt=0)] = None,
    examination_id: Annotated[int | None, Form(gt=0)] = None,
):
    try:
        attachment = AttachmentService(
            db,
            storage,
            max_upload_size_mb=get_settings().max_upload_size_mb,
        ).upload(
            record_id,
            file,
            category=category,
            description=optional_text(description),
            lab_report_id=optional_int(lab_report_id),
            examination_id=optional_int(examination_id),
            operator=current_user,
            audit_context=AuditContext(
                request.method,
                request.url.path,
                request.client.host if request.client else None,
            ),
        )
    except AppException as exc:
        return redirect_with_flash(
            f"/attachments/upload?record_id={record_id}&category={category.value}",
            exc.message,
            category="danger",
        )
    return redirect_with_flash(
        f"/medical-records/{record_id}",
        f"附件“{attachment.original_name}”上传成功",
    )


def _content(
    attachment_id: int,
    request: Request,
    current_user: User,
    db,
    storage,
    *,
    inline: bool,
) -> Response:
    service = AttachmentService(
        db,
        storage,
        max_upload_size_mb=get_settings().max_upload_size_mb,
    )
    return service.get_content(
        attachment_id,
        operator=current_user,
        audit_context=AuditContext(
            request.method,
            request.url.path,
            request.client.host if request.client else None,
        ),
        inline=inline,
    )


@router.get("/attachments/{attachment_id}/content", include_in_schema=False)
def view_attachment(
    attachment_id: int,
    request: Request,
    current_user: AttachmentViewer,
    db: DatabaseSession,
    storage: Storage,
) -> Response:
    return _content(
        attachment_id,
        request,
        current_user,
        db,
        storage,
        inline=True,
    )


@router.get("/attachments/{attachment_id}/download", include_in_schema=False)
def download_attachment(
    attachment_id: int,
    request: Request,
    current_user: AttachmentViewer,
    db: DatabaseSession,
    storage: Storage,
) -> Response:
    return _content(
        attachment_id,
        request,
        current_user,
        db,
        storage,
        inline=False,
    )
