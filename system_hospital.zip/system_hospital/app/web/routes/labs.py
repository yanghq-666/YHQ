"""检验申请、工作列表、结果录入与完成页面。"""

from typing import Annotated, Any

from fastapi import APIRouter, Depends, Request
from pydantic import ValidationError as PydanticValidationError

from app.api.deps import DatabaseSession, Storage
from app.core.config import get_settings
from app.core.exceptions import AppException
from app.models.enums import AbnormalFlag, LabReportStatus
from app.models.user import User
from app.schemas.lab_report import (
    LabReportComplete,
    LabReportCreate,
    LabResultCreate,
    LabResultsBatchCreate,
    LabResultUpdate,
)
from app.schemas.worklist import LabWorklistParams
from app.services.attachment_service import AttachmentService
from app.services.audit_service import AuditContext
from app.services.catalog_service import CatalogService
from app.services.lab_report_service import LabReportService
from app.services.medical_record_service import MedicalRecordService
from app.services.worklist_service import WorklistService
from app.web.deps import redirect_with_flash, require_web_permission
from app.web.forms import compact_query, optional_int, optional_text, validation_message
from app.web.templating import render_template

router = APIRouter(tags=["Web Lab Reports"])
LabViewer = Annotated[User, Depends(require_web_permission("lab:view"))]
LabCreator = Annotated[User, Depends(require_web_permission("lab:create"))]
LabEditor = Annotated[User, Depends(require_web_permission("lab:update"))]
LabCompleter = Annotated[User, Depends(require_web_permission("lab:complete"))]


def _context(request: Request) -> AuditContext:
    return AuditContext(
        request.method,
        request.url.path,
        request.client.host if request.client else None,
    )


@router.get("/labs", include_in_schema=False)
def lab_list(request: Request, current_user: LabViewer, db: DatabaseSession):
    error = None
    status_code = 200
    try:
        params = LabWorklistParams(**compact_query(request.query_params))
    except PydanticValidationError as exc:
        params = LabWorklistParams()
        error = validation_message(exc)
        status_code = 422
    return render_template(
        request,
        "labs/list.html",
        status_code=status_code,
        title="检验管理",
        active_menu="labs",
        page=WorklistService(db).list_labs(params, operator=current_user),
        params=params,
        statuses=list(LabReportStatus),
        error=error,
    )


@router.get("/medical-records/{record_id}/labs/new", include_in_schema=False)
def lab_create_page(
    record_id: int,
    request: Request,
    current_user: LabCreator,
    db: DatabaseSession,
):
    record = MedicalRecordService(db).get_record_detail(
        record_id, operator=current_user
    )
    return render_template(
        request,
        "labs/form.html",
        title="申请检验",
        active_menu="labs",
        record=record,
        values={},
        lab_test_catalogs=CatalogService(db).list_lab_tests(),
    )


@router.post("/medical-records/{record_id}/labs/new", include_in_schema=False)
async def lab_create(
    record_id: int,
    request: Request,
    current_user: LabCreator,
    db: DatabaseSession,
):
    form = await request.form()
    values = dict(form)
    try:
        payload = LabReportCreate(
            lab_test_catalog_id=optional_int(form.get("lab_test_catalog_id")),
            report_name=str(form.get("report_name") or ""),
            report_type=str(form.get("report_type") or ""),
            specimen_type=optional_text(form.get("specimen_type")),
            collected_at=optional_text(form.get("collected_at")),
        )
        report = LabReportService(db).create_report(
            record_id,
            payload,
            operator=current_user,
            audit_context=_context(request),
        )
    except (PydanticValidationError, ValueError, AppException) as exc:
        message = exc.message if isinstance(exc, AppException) else validation_message(exc)
        record = MedicalRecordService(db).get_record_detail(
            record_id, operator=current_user
        )
        return render_template(
            request, "labs/form.html", status_code=getattr(exc, "status_code", 422),
            title="申请检验", active_menu="labs", record=record,
            values=values, error=message,
            lab_test_catalogs=CatalogService(db).list_lab_tests(),
        )
    return redirect_with_flash(f"/labs/{report.id}", "检验申请创建成功")


@router.get("/labs/{report_id}", include_in_schema=False)
def lab_detail(
    report_id: int,
    request: Request,
    current_user: LabViewer,
    db: DatabaseSession,
    storage: Storage,
):
    report = LabReportService(db).get_report(report_id, operator=current_user)
    record = MedicalRecordService(db).get_record_detail(
        report.record_id, operator=current_user
    )
    attachments = [
        item
        for item in AttachmentService(
            db, storage, max_upload_size_mb=get_settings().max_upload_size_mb
        ).list_for_record(report.record_id, operator=current_user)
        if item.lab_report_id == report.id
    ]
    names = WorklistService(db).user_names(
        report.requested_by, report.performed_by, report.reviewed_by
    )
    return render_template(
        request,
        "labs/detail.html",
        title=f"检验报告 {report.report_no}",
        active_menu="labs",
        report=report,
        record=record,
        attachments=attachments,
        user_names=names,
    )


@router.post("/labs/{report_id}/start", include_in_schema=False)
def lab_start(
    report_id: int,
    request: Request,
    current_user: LabEditor,
    db: DatabaseSession,
):
    try:
        LabReportService(db).start_report(
            report_id, operator=current_user, audit_context=_context(request)
        )
    except AppException as exc:
        return redirect_with_flash(f"/labs/{report_id}", exc.message, category="danger")
    return redirect_with_flash(f"/labs/{report_id}", "检验报告已开始处理")


def _result_values(data: Any | None = None) -> dict[str, Any]:
    if data is None:
        return {}
    return data.model_dump(mode="json") if hasattr(data, "model_dump") else dict(data)


@router.get("/labs/{report_id}/results/new", include_in_schema=False)
def result_create_page(
    report_id: int,
    request: Request,
    current_user: LabEditor,
    db: DatabaseSession,
):
    report = LabReportService(db).get_report(report_id, operator=current_user)
    return render_template(
        request, "labs/result_form.html", title="新增检验结果",
        active_menu="labs", report=report,
        values={"lab_test_catalog_id": report.lab_test_catalog_id},
        abnormal_flags=list(AbnormalFlag), editing=False,
        lab_test_catalogs=CatalogService(db).list_lab_tests(),
    )


def _result_payload(form) -> dict[str, Any]:
    return {
        "lab_test_catalog_id": optional_int(form.get("lab_test_catalog_id")),
        "item_code": optional_text(form.get("item_code")),
        "item_name": str(form.get("item_name") or ""),
        "result_value": optional_text(form.get("result_value")),
        "result_text": optional_text(form.get("result_text")),
        "unit": optional_text(form.get("unit")),
        "reference_range": optional_text(form.get("reference_range")),
        "abnormal_flag": str(form.get("abnormal_flag") or "UNKNOWN"),
        "sort_order": optional_int(form.get("sort_order")) or 0,
        "remark": optional_text(form.get("remark")),
    }


@router.post("/labs/{report_id}/results/new", include_in_schema=False)
async def result_create(
    report_id: int,
    request: Request,
    current_user: LabEditor,
    db: DatabaseSession,
):
    form = await request.form()
    values = _result_payload(form)
    try:
        item = LabResultCreate(**values)
        LabReportService(db).add_results(
            report_id, LabResultsBatchCreate(results=[item]),
            operator=current_user, audit_context=_context(request),
        )
    except (PydanticValidationError, ValueError, AppException) as exc:
        message = exc.message if isinstance(exc, AppException) else validation_message(exc)
        report = LabReportService(db).get_report(report_id, operator=current_user)
        return render_template(
            request, "labs/result_form.html", status_code=getattr(exc, "status_code", 422),
            title="新增检验结果", active_menu="labs", report=report,
            values=values, abnormal_flags=list(AbnormalFlag), editing=False,
            lab_test_catalogs=CatalogService(db).list_lab_tests(),
            error=message,
        )
    return redirect_with_flash(f"/labs/{report_id}", "检验结果添加成功")


@router.get("/labs/{report_id}/results/{result_id}/edit", include_in_schema=False)
def result_edit_page(
    report_id: int,
    result_id: int,
    request: Request,
    current_user: LabEditor,
    db: DatabaseSession,
):
    service = LabReportService(db)
    report = service.get_report(report_id, operator=current_user)
    result = service.get_result(result_id, operator=current_user)
    if result.lab_report_id != report.id:
        from app.core.exceptions import ResourceNotFoundError
        raise ResourceNotFoundError("检验结果不存在")
    return render_template(
        request, "labs/result_form.html", title="编辑检验结果",
        active_menu="labs", report=report, values=_result_values(result),
        abnormal_flags=list(AbnormalFlag), editing=True, result_id=result_id,
        lab_test_catalogs=CatalogService(db).list_lab_tests(),
    )


@router.post("/labs/{report_id}/results/{result_id}/edit", include_in_schema=False)
async def result_edit(
    report_id: int,
    result_id: int,
    request: Request,
    current_user: LabEditor,
    db: DatabaseSession,
):
    form = await request.form()
    values = _result_payload(form)
    try:
        LabReportService(db).update_result(
            result_id, LabResultUpdate(**values), operator=current_user,
            audit_context=_context(request),
        )
    except (PydanticValidationError, ValueError, AppException) as exc:
        message = exc.message if isinstance(exc, AppException) else validation_message(exc)
        return redirect_with_flash(f"/labs/{report_id}", message, category="danger")
    return redirect_with_flash(f"/labs/{report_id}", "检验结果更新成功")


@router.post("/labs/{report_id}/complete", include_in_schema=False)
async def lab_complete(
    report_id: int,
    request: Request,
    current_user: LabCompleter,
    db: DatabaseSession,
):
    form = await request.form()
    try:
        payload = LabReportComplete(
            result_summary=str(form.get("result_summary") or ""),
            conclusion=str(form.get("conclusion") or ""),
        )
        LabReportService(db).complete_report(
            report_id, payload, operator=current_user,
            audit_context=_context(request),
        )
    except (PydanticValidationError, AppException) as exc:
        message = exc.message if isinstance(exc, AppException) else validation_message(exc)
        return redirect_with_flash(f"/labs/{report_id}", message, category="danger")
    return redirect_with_flash(f"/labs/{report_id}", "检验报告已完成")
