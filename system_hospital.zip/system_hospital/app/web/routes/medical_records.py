"""病历工作站 Web 页面。"""

from typing import Annotated, Any

from fastapi import APIRouter, Depends, Request
from pydantic import ValidationError as PydanticValidationError

from app.api.deps import DatabaseSession
from app.core.exceptions import AppException, MedicalRecordNotFoundError
from app.models.enums import MedicalRecordStatus
from app.models.user import User
from app.schemas.medical_record import (
    CONTENT_FIELDS,
    MedicalRecordCreate,
    MedicalRecordSearchParams,
    MedicalRecordUpdate,
    MyMedicalRecordSearchParams,
)
from app.services.audit_service import AuditContext
from app.services.encounter_service import EncounterService
from app.services.medical_record_service import MedicalRecordService
from app.repositories.user_repository import UserRepository
from app.web.deps import redirect_with_flash, require_web_permission
from app.web.forms import compact_query, optional_text, validation_message
from app.web.templating import render_template

router = APIRouter(tags=["Web Medical Records"])
RecordViewer = Annotated[User, Depends(require_web_permission("record:view"))]
RecordCreator = Annotated[User, Depends(require_web_permission("record:create"))]
RecordEditor = Annotated[User, Depends(require_web_permission("record:update"))]
RecordSubmitter = Annotated[User, Depends(require_web_permission("record:submit"))]


def _audit_context(request: Request) -> AuditContext:
    return AuditContext(
        request_method=request.method,
        request_path=request.url.path,
        ip_address=request.client.host if request.client else None,
    )


def _content_payload(form: Any) -> dict[str, str | None]:
    return {field: optional_text(form.get(field)) for field in CONTENT_FIELDS}


def _content_values(data: Any | None = None) -> dict[str, Any]:
    if data is None:
        return {field: "" for field in CONTENT_FIELDS}
    source = data.model_dump(mode="json") if hasattr(data, "model_dump") else dict(data)
    return {field: source.get(field) or "" for field in CONTENT_FIELDS}


def _render_record_form(
    request: Request,
    *,
    title: str,
    form_action: str,
    encounter: Any,
    values: dict[str, Any],
    editing: bool,
    record_id: int | None = None,
    error: str | None = None,
    status_code: int = 200,
):
    return render_template(
        request,
        "medical_records/form.html",
        status_code=status_code,
        title=title,
        page_title=title,
        active_menu="records-drafts",
        form_action=form_action,
        encounter=encounter,
        form_values=values,
        editing=editing,
        record_id=record_id,
        error=error,
    )


def _list_page(
    request: Request,
    db,
    current_user: User,
    *,
    title: str,
    active_menu: str,
    mine: bool,
    forced_status: MedicalRecordStatus | None = None,
):
    error = None
    status_code = 200
    try:
        values = compact_query(request.query_params)
        if mine:
            params = MyMedicalRecordSearchParams(**values)
        else:
            params = MedicalRecordSearchParams(**values)
        if forced_status is not None:
            params = params.model_copy(update={"status": forced_status})
    except PydanticValidationError as exc:
        params = (
            MyMedicalRecordSearchParams(status=forced_status)
            if mine
            else MedicalRecordSearchParams(status=forced_status)
        )
        error = validation_message(exc)
        status_code = 422
    service = MedicalRecordService(db)
    page = (
        service.list_my_records(params, operator=current_user)
        if mine
        else service.list_records(params, operator=current_user)
    )
    return render_template(
        request,
        "medical_records/list.html",
        status_code=status_code,
        title=title,
        active_menu=active_menu,
        page=page,
        params=params,
        statuses=list(MedicalRecordStatus),
        forced_status=forced_status,
        error=error,
    )


@router.get("/medical-records", include_in_schema=False)
def record_index(request: Request, current_user: RecordViewer, db: DatabaseSession):
    return _list_page(
        request,
        db,
        current_user,
        title="病历查询",
        active_menu="records-my",
        mine=False,
    )


@router.get("/medical-records/my", include_in_schema=False)
def my_records(request: Request, current_user: RecordViewer, db: DatabaseSession):
    return _list_page(
        request,
        db,
        current_user,
        title="我的病历",
        active_menu="records-my",
        mine=True,
    )


@router.get("/medical-records/drafts", include_in_schema=False)
def draft_records(request: Request, current_user: RecordViewer, db: DatabaseSession):
    return _list_page(
        request,
        db,
        current_user,
        title="草稿病历",
        active_menu="records-drafts",
        mine=True,
        forced_status=MedicalRecordStatus.DRAFT,
    )


@router.get("/medical-records/submitted", include_in_schema=False)
def submitted_records(request: Request, current_user: RecordViewer, db: DatabaseSession):
    return _list_page(
        request,
        db,
        current_user,
        title="历史待审核病历",
        active_menu="records-submitted",
        mine=True,
        forced_status=MedicalRecordStatus.SUBMITTED,
    )


@router.get("/medical-records/approved", include_in_schema=False)
def approved_records(request: Request, current_user: RecordViewer, db: DatabaseSession):
    return _list_page(
        request,
        db,
        current_user,
        title="已完成病历",
        active_menu="records-approved",
        mine=True,
        forced_status=MedicalRecordStatus.APPROVED,
    )


@router.get("/medical-records/archived", include_in_schema=False)
def archived_records(request: Request, current_user: RecordViewer, db: DatabaseSession):
    return _list_page(
        request,
        db,
        current_user,
        title="已归档病历",
        active_menu="records-archived",
        mine=False,
        forced_status=MedicalRecordStatus.ARCHIVED,
    )


@router.get("/medical-records/rejected", include_in_schema=False)
def rejected_records(request: Request, current_user: RecordViewer, db: DatabaseSession):
    return _list_page(
        request,
        db,
        current_user,
        title="已退回病历",
        active_menu="records-rejected",
        mine=True,
        forced_status=MedicalRecordStatus.REJECTED,
    )


@router.get("/encounters/{encounter_id}/medical-record", include_in_schema=False)
def encounter_record(
    encounter_id: int,
    current_user: RecordViewer,
    db: DatabaseSession,
):
    record = MedicalRecordService(db).get_by_encounter(
        encounter_id, operator=current_user
    )
    return redirect_with_flash(
        f"/medical-records/{record.id}", "已进入病历工作站", category="info"
    )


@router.get("/encounters/{encounter_id}/medical-record/new", include_in_schema=False)
def record_create_page(
    encounter_id: int,
    request: Request,
    current_user: RecordCreator,
    db: DatabaseSession,
):
    encounter = EncounterService(db).get_encounter_detail(
        encounter_id, operator=current_user
    )
    service = MedicalRecordService(db)
    try:
        existing = service.get_by_encounter(encounter_id, operator=current_user)
    except MedicalRecordNotFoundError:
        existing = None
    if existing is not None:
        return redirect_with_flash(
            f"/medical-records/{existing.id}", "该就诊已存在主病历", category="info"
        )
    values = _content_values()
    values["chief_complaint"] = encounter.chief_complaint or ""
    values["allergy_history"] = encounter.patient.allergy_history or ""
    return _render_record_form(
        request,
        title="创建病历草稿",
        form_action=f"/encounters/{encounter_id}/medical-record/new",
        encounter=encounter,
        values=values,
        editing=False,
    )


@router.post("/encounters/{encounter_id}/medical-record/new", include_in_schema=False)
async def record_create(
    encounter_id: int,
    request: Request,
    current_user: RecordCreator,
    db: DatabaseSession,
):
    form = await request.form()
    values = _content_payload(form)
    encounter = EncounterService(db).get_encounter_detail(
        encounter_id, operator=current_user
    )
    try:
        payload = MedicalRecordCreate(**values)
        record = MedicalRecordService(db).create_record(
            encounter_id,
            payload,
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except (PydanticValidationError, ValueError) as exc:
        return _render_record_form(
            request,
            title="创建病历草稿",
            form_action=f"/encounters/{encounter_id}/medical-record/new",
            encounter=encounter,
            values=_content_values(values),
            editing=False,
            error=validation_message(exc),
            status_code=422,
        )
    except AppException as exc:
        return _render_record_form(
            request,
            title="创建病历草稿",
            form_action=f"/encounters/{encounter_id}/medical-record/new",
            encounter=encounter,
            values=_content_values(values),
            editing=False,
            error=exc.message,
            status_code=exc.status_code,
        )
    return redirect_with_flash(f"/medical-records/{record.id}", "病历草稿创建成功")


@router.get("/medical-records/{record_id}", include_in_schema=False)
def record_workspace(
    record_id: int,
    request: Request,
    current_user: RecordViewer,
    db: DatabaseSession,
):
    full = MedicalRecordService(db).get_full_record(record_id, operator=current_user)
    return render_template(
        request,
        "medical_records/detail.html",
        title=f"病历 {full.medical_record.record_no}",
        active_menu="records-my",
        full=full,
        editable=full.medical_record.status in {
            MedicalRecordStatus.DRAFT,
        },
        latest_rejection=next(
            (
                item
                for item in reversed(full.review_history)
                if item.action.value == "REJECT"
            ),
            None,
        ),
    )


@router.get("/medical-records/{record_id}/edit", include_in_schema=False)
def record_edit_page(
    record_id: int,
    request: Request,
    current_user: RecordEditor,
    db: DatabaseSession,
):
    service = MedicalRecordService(db)
    service.get_editable_record(record_id, operator=current_user)
    record = service.get_record_detail(record_id, operator=current_user)
    return _render_record_form(
        request,
        title="编辑病历",
        form_action=f"/medical-records/{record_id}/edit",
        encounter=record.encounter,
        values=_content_values(record),
        editing=True,
        record_id=record_id,
    )


@router.post("/medical-records/{record_id}/edit", include_in_schema=False)
async def record_edit(
    record_id: int,
    request: Request,
    current_user: RecordEditor,
    db: DatabaseSession,
):
    form = await request.form()
    values = _content_payload(form)
    service = MedicalRecordService(db)
    record = service.get_record_detail(record_id, operator=current_user)
    try:
        payload = MedicalRecordUpdate(**values)
        result = service.update_record(
            record_id,
            payload,
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except (PydanticValidationError, ValueError) as exc:
        return _render_record_form(
            request,
            title="编辑病历",
            form_action=f"/medical-records/{record_id}/edit",
            encounter=record.encounter,
            values=_content_values(values),
            editing=True,
            record_id=record_id,
            error=validation_message(exc),
            status_code=422,
        )
    except AppException as exc:
        return _render_record_form(
            request,
            title="编辑病历",
            form_action=f"/medical-records/{record_id}/edit",
            encounter=record.encounter,
            values=_content_values(values),
            editing=True,
            record_id=record_id,
            error=exc.message,
            status_code=exc.status_code,
        )
    return redirect_with_flash(f"/medical-records/{result.id}", "病历内容保存成功")


@router.post("/medical-records/{record_id}/complete", include_in_schema=False)
def record_complete(
    record_id: int,
    request: Request,
    current_user: RecordSubmitter,
    db: DatabaseSession,
):
    try:
        result = MedicalRecordService(db).complete_record(
            record_id,
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except AppException as exc:
        message = exc.message
        if exc.data and isinstance(exc.data, dict) and exc.data.get("missing_fields"):
            message = f"{message}：{', '.join(exc.data['missing_fields'])}"
        return redirect_with_flash(
            f"/medical-records/{record_id}", message, category="danger"
        )
    return redirect_with_flash(
        f"/medical-records/{record_id}",
        f"病历已完成并转为只读，已生成 V{result.version}",
    )


@router.post("/medical-records/{record_id}/submit", include_in_schema=False)
def legacy_record_submit(
    record_id: int,
    request: Request,
    current_user: RecordSubmitter,
    db: DatabaseSession,
):
    """兼容旧页面地址；直接执行完成病历。"""
    return record_complete(record_id, request, current_user, db)


@router.post("/medical-records/{record_id}/delete", include_in_schema=False)
def record_delete(
    record_id: int,
    request: Request,
    current_user: RecordEditor,
    db: DatabaseSession,
):
    try:
        MedicalRecordService(db).delete_draft(
            record_id,
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except AppException as exc:
        return redirect_with_flash(
            f"/medical-records/{record_id}", exc.message, category="danger"
        )
    return redirect_with_flash("/medical-records/drafts", "病历草稿已删除")


@router.get("/medical-records/{record_id}/versions", include_in_schema=False)
def record_versions(
    record_id: int,
    request: Request,
    current_user: RecordViewer,
    db: DatabaseSession,
):
    service = MedicalRecordService(db)
    record = service.get_record_detail(record_id, operator=current_user)
    versions = service.list_versions(record_id, operator=current_user)
    users = UserRepository(db)
    creator_names = {
        item.created_by: (users.get_by_id(item.created_by).real_name if users.get_by_id(item.created_by) else "未知用户")
        for item in versions
    }
    return render_template(
        request,
        "medical_records/versions.html",
        title="病历版本",
        active_menu="records-my",
        record=record,
        versions=versions,
        creator_names=creator_names,
    )


@router.get("/medical-records/{record_id}/versions/{version}", include_in_schema=False)
def record_version_detail(
    record_id: int,
    version: int,
    request: Request,
    current_user: RecordViewer,
    db: DatabaseSession,
):
    service = MedicalRecordService(db)
    record = service.get_record_detail(record_id, operator=current_user)
    item = service.get_version(record_id, version, operator=current_user)
    return render_template(
        request,
        "medical_records/version_detail.html",
        title=f"病历版本 V{version}",
        active_menu="records-my",
        record=record,
        version=item,
    )
