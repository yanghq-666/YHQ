"""Web 登录、首页跳转与退出。"""

from typing import Annotated

from fastapi import APIRouter, Form, Request
from fastapi.responses import RedirectResponse

from app.api.deps import DatabaseSession
from app.core.config import get_settings
from app.core.exceptions import AppException
from app.core.security import create_access_token
from app.repositories.user_repository import UserRepository
from app.services.auth_service import AuthService
from app.web.deps import (
    ACCESS_TOKEN_COOKIE,
    FLASH_COOKIE,
    CurrentWebUser,
    OptionalWebUser,
    encode_flash,
    read_flash,
)
from app.web.templating import template_context, templates

router = APIRouter(tags=["Web"])


@router.get("/", include_in_schema=False)
def index(current_user: OptionalWebUser) -> RedirectResponse:
    target = "/dashboard" if current_user is not None else "/login"
    return RedirectResponse(target, status_code=303)


@router.get("/login", include_in_schema=False)
def login_page(request: Request, current_user: OptionalWebUser):
    if current_user is not None:
        return RedirectResponse("/dashboard", status_code=303)
    response = templates.TemplateResponse(
        request,
        "auth/login.html",
        template_context(request, flash=read_flash(request)),
    )
    response.delete_cookie(FLASH_COOKIE, path="/")
    return response


@router.post("/login", include_in_schema=False)
def web_login(
    request: Request,
    db: DatabaseSession,
    username: Annotated[str, Form()] = "",
    password: Annotated[str, Form()] = "",
):
    try:
        user = AuthService(UserRepository(db)).authenticate(username, password)
    except AppException:
        return templates.TemplateResponse(
            request,
            "auth/login.html",
            template_context(request, error="用户名或密码错误"),
            status_code=401,
        )

    settings = get_settings()
    access_token = create_access_token(user.id, user.username, settings=settings)
    response = RedirectResponse("/dashboard", status_code=303)
    response.set_cookie(
        ACCESS_TOKEN_COOKIE,
        access_token,
        max_age=settings.access_token_expire_minutes * 60,
        httponly=True,
        secure=settings.web_cookie_secure,
        samesite="lax",
        path="/",
    )
    response.set_cookie(
        FLASH_COOKIE,
        encode_flash("登录成功"),
        max_age=30,
        httponly=True,
        secure=settings.web_cookie_secure,
        samesite="lax",
        path="/",
    )
    return response


@router.post("/logout", include_in_schema=False)
def logout(_current_user: CurrentWebUser) -> RedirectResponse:
    settings = get_settings()
    response = RedirectResponse("/login", status_code=303)
    response.delete_cookie(ACCESS_TOKEN_COOKIE, path="/")
    response.set_cookie(
        FLASH_COOKIE,
        encode_flash("已安全退出"),
        max_age=30,
        httponly=True,
        secure=settings.web_cookie_secure,
        samesite="lax",
        path="/",
    )
    return response
