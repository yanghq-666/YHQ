"""病历工作站中的诊断、医嘱和处方 Web 操作。"""

from typing import Annotated, Any, Callable

from fastapi import APIRouter, Depends, Request
from pydantic import ValidationError as PydanticValidationError

from app.api.deps import DatabaseSession
from app.core.exceptions import AppException, ResourceNotFoundError
from app.models.enums import ExaminationType, MedicalOrderType, PrescriptionType
from app.models.user import User
from app.schemas.diagnosis import DiagnosisCreate, DiagnosisUpdate
from app.schemas.medical_order import MedicalOrderCreate, MedicalOrderUpdate
from app.schemas.prescription import (
    PrescriptionCancelRequest,
    PrescriptionCreate,
    PrescriptionItemCreate,
    PrescriptionItemUpdate,
    PrescriptionUpdate,
)
from app.services.audit_service import AuditContext
from app.services.catalog_service import CatalogService
from app.services.diagnosis_service import DiagnosisService
from app.services.medical_order_service import MedicalOrderService
from app.services.medical_record_service import MedicalRecordService
from app.services.prescription_service import PrescriptionService
from app.web.deps import redirect_with_flash, require_web_permission
from app.web.forms import (
    optional_datetime,
    optional_int,
    optional_text,
    validation_message,
)
from app.web.templating import render_template

router = APIRouter(tags=["Web Clinical Records"])
DiagnosisCreator = Annotated[User, Depends(require_web_permission("diagnosis:create"))]
DiagnosisEditor = Annotated[User, Depends(require_web_permission("diagnosis:update"))]
OrderCreator = Annotated[User, Depends(require_web_permission("order:create"))]
OrderEditor = Annotated[User, Depends(require_web_permission("order:update"))]
PrescriptionCreator = Annotated[
    User, Depends(require_web_permission("prescription:create"))
]
PrescriptionEditor = Annotated[
    User, Depends(require_web_permission("prescription:update"))
]
RecordViewer = Annotated[User, Depends(require_web_permission("record:view"))]


def _audit_context(request: Request) -> AuditContext:
    return AuditContext(
        request_method=request.method,
        request_path=request.url.path,
        ip_address=request.client.host if request.client else None,
    )


def _full_record(db, record_id: int, operator: User):
    return MedicalRecordService(db).get_full_record(record_id, operator=operator)


def _editable_record(db, record_id: int, operator: User):
    service = MedicalRecordService(db)
    service.get_editable_record(record_id, operator=operator)
    return service.get_record_detail(record_id, operator=operator)


def _editable_full_record(db, record_id: int, operator: User):
    _editable_record(db, record_id, operator)
    return _full_record(db, record_id, operator)


def _find(items: list[Any], item_id: int, label: str) -> Any:
    result = next((item for item in items if item.id == item_id), None)
    if result is None:
        raise ResourceNotFoundError(f"{label}不存在")
    return result


def _form_values(data: Any | None, defaults: dict[str, Any]) -> dict[str, Any]:
    if data is None:
        return defaults.copy()
    if hasattr(data, "model_dump"):
        return data.model_dump(mode="json")
    return dict(data)


def _diagnosis_payload(form: Any) -> dict[str, Any]:
    return {
        "diagnosis_catalog_id": optional_int(form.get("diagnosis_catalog_id")),
        "diagnosis_name": str(form.get("diagnosis_name", "")),
        "diagnosis_code": optional_text(form.get("diagnosis_code")),
        "description": optional_text(form.get("description")),
        "is_primary": form.get("is_primary") == "on",
    }


def _render_diagnosis_form(
    request: Request,
    *,
    record: Any,
    values: dict[str, Any],
    title: str,
    form_action: str,
    catalogs: list[Any],
    error: str | None = None,
    status_code: int = 200,
):
    return render_template(
        request,
        "clinical/diagnosis_form.html",
        status_code=status_code,
        title=title,
        page_title=title,
        active_menu="records-my",
        record=record,
        form_action=form_action,
        form_values=values,
        diagnosis_catalogs=catalogs,
        error=error,
    )


@router.get("/medical-records/{record_id}/diagnoses/new", include_in_schema=False)
def diagnosis_create_page(
    record_id: int,
    request: Request,
    current_user: DiagnosisCreator,
    db: DatabaseSession,
):
    full = _editable_full_record(db, record_id, current_user)
    return _render_diagnosis_form(
        request,
        record=full.medical_record,
        values=_form_values(
            None,
            {"is_primary": False},
        ),
        title="新增诊断",
        form_action=f"/medical-records/{record_id}/diagnoses/new",
        catalogs=CatalogService(db).list_diagnoses(),
    )


@router.post("/medical-records/{record_id}/diagnoses/new", include_in_schema=False)
async def diagnosis_create(
    record_id: int,
    request: Request,
    current_user: DiagnosisCreator,
    db: DatabaseSession,
):
    form = await request.form()
    values = dict(form)
    record = _editable_record(db, record_id, current_user)
    try:
        values = _diagnosis_payload(form)
        DiagnosisService(db).create_diagnosis(
            record_id,
            DiagnosisCreate(**values),
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except (PydanticValidationError, ValueError) as exc:
        return _render_diagnosis_form(
            request,
            record=record,
            values=values,
            title="新增诊断",
            form_action=f"/medical-records/{record_id}/diagnoses/new",
            catalogs=CatalogService(db).list_diagnoses(),
            error=validation_message(exc),
            status_code=422,
        )
    except AppException as exc:
        return _render_diagnosis_form(
            request,
            record=record,
            values=values,
            title="新增诊断",
            form_action=f"/medical-records/{record_id}/diagnoses/new",
            catalogs=CatalogService(db).list_diagnoses(),
            error=exc.message,
            status_code=exc.status_code,
        )
    return redirect_with_flash(f"/medical-records/{record_id}#diagnoses", "诊断创建成功")


@router.get(
    "/medical-records/{record_id}/diagnoses/{diagnosis_id}/edit",
    include_in_schema=False,
)
def diagnosis_edit_page(
    record_id: int,
    diagnosis_id: int,
    request: Request,
    current_user: DiagnosisEditor,
    db: DatabaseSession,
):
    full = _editable_full_record(db, record_id, current_user)
    diagnosis = _find(full.diagnoses, diagnosis_id, "诊断")
    return _render_diagnosis_form(
        request,
        record=full.medical_record,
        values=_form_values(diagnosis, {}),
        title="编辑诊断",
        form_action=f"/medical-records/{record_id}/diagnoses/{diagnosis_id}/edit",
        catalogs=CatalogService(db).list_diagnoses(),
    )


@router.post(
    "/medical-records/{record_id}/diagnoses/{diagnosis_id}/edit",
    include_in_schema=False,
)
async def diagnosis_edit(
    record_id: int,
    diagnosis_id: int,
    request: Request,
    current_user: DiagnosisEditor,
    db: DatabaseSession,
):
    form = await request.form()
    values = dict(form)
    full = _editable_full_record(db, record_id, current_user)
    _find(full.diagnoses, diagnosis_id, "诊断")
    try:
        values = _diagnosis_payload(form)
        DiagnosisService(db).update_diagnosis(
            diagnosis_id,
            DiagnosisUpdate(**values),
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except (PydanticValidationError, ValueError) as exc:
        return _render_diagnosis_form(
            request,
            record=full.medical_record,
            values=values,
            title="编辑诊断",
            form_action=f"/medical-records/{record_id}/diagnoses/{diagnosis_id}/edit",
            catalogs=CatalogService(db).list_diagnoses(),
            error=validation_message(exc),
            status_code=422,
        )
    except AppException as exc:
        return _render_diagnosis_form(
            request,
            record=full.medical_record,
            values=values,
            title="编辑诊断",
            form_action=f"/medical-records/{record_id}/diagnoses/{diagnosis_id}/edit",
            catalogs=CatalogService(db).list_diagnoses(),
            error=exc.message,
            status_code=exc.status_code,
        )
    return redirect_with_flash(f"/medical-records/{record_id}#diagnoses", "诊断更新成功")


@router.post(
    "/medical-records/{record_id}/diagnoses/{diagnosis_id}/delete",
    include_in_schema=False,
)
def diagnosis_delete(
    record_id: int,
    diagnosis_id: int,
    request: Request,
    current_user: DiagnosisEditor,
    db: DatabaseSession,
):
    full = _editable_full_record(db, record_id, current_user)
    _find(full.diagnoses, diagnosis_id, "诊断")
    try:
        DiagnosisService(db).delete_diagnosis(
            diagnosis_id,
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except AppException as exc:
        return redirect_with_flash(
            f"/medical-records/{record_id}#diagnoses", exc.message, category="danger"
        )
    return redirect_with_flash(f"/medical-records/{record_id}#diagnoses", "诊断已删除")


def _order_payload(form: Any) -> dict[str, Any]:
    return {
        "order_type": str(form.get("order_type", MedicalOrderType.OTHER.value)),
        "order_content": str(form.get("order_content", "")),
        "dosage": optional_text(form.get("dosage")),
        "dosage_unit": optional_text(form.get("dosage_unit")),
        "frequency": optional_text(form.get("frequency")),
        "route": optional_text(form.get("route")),
        "start_time": optional_datetime(form.get("start_time")),
        "end_time": optional_datetime(form.get("end_time")),
        "remark": optional_text(form.get("remark")),
        "drug_catalog_id": optional_int(form.get("drug_catalog_id")),
        "duration": optional_int(form.get("duration")),
        "duration_unit": optional_text(form.get("duration_unit")),
        "quantity": optional_text(form.get("quantity")),
        "quantity_unit": optional_text(form.get("quantity_unit")),
        "lab_test_catalog_id": optional_int(form.get("lab_test_catalog_id")),
        "lab_report_type": optional_text(form.get("lab_report_type")),
        "specimen_type": optional_text(form.get("specimen_type")),
        "examination_type": optional_text(form.get("examination_type")),
        "body_part": optional_text(form.get("body_part")),
    }


def _order_values(data: Any | None = None) -> dict[str, Any]:
    values = _form_values(data, {"order_type": MedicalOrderType.OTHER.value})
    for field in ("start_time", "end_time"):
        value = values.get(field)
        if value:
            if isinstance(value, str):
                try:
                    value = optional_datetime(value)
                except ValueError:
                    continue
            values[field] = value.strftime("%Y-%m-%dT%H:%M") if value else ""
    return values


def _render_order_form(
    request: Request,
    *,
    db: Any,
    record: Any,
    values: dict[str, Any],
    title: str,
    form_action: str,
    error: str | None = None,
    status_code: int = 200,
    current_order_type: MedicalOrderType | None = None,
):
    order_types = list(MedicalOrderService.NEW_ORDER_TYPES)
    if current_order_type is not None and current_order_type not in order_types:
        order_types.insert(0, current_order_type)
    return render_template(
        request,
        "clinical/order_form.html",
        status_code=status_code,
        title=title,
        page_title=title,
        active_menu="records-my",
        record=record,
        form_action=form_action,
        form_values=_order_values(values),
        order_types=order_types,
        drug_catalogs=CatalogService(db).list_drugs(),
        lab_test_catalogs=CatalogService(db).list_lab_tests(),
        examination_types=list(ExaminationType),
        frequency_options=("每日1次", "每日2次", "每日3次", "每日4次", "必要时", "睡前"),
        route_options=("口服", "静脉滴注", "静脉注射", "肌内注射", "皮下注射", "外用"),
        error=error,
    )


@router.get("/medical-records/{record_id}/orders/new", include_in_schema=False)
def order_create_page(
    record_id: int,
    request: Request,
    current_user: OrderCreator,
    db: DatabaseSession,
):
    record = _editable_record(db, record_id, current_user)
    return _render_order_form(
        request,
        db=db,
        record=record,
        values=_order_values(),
        title="新增医嘱",
        form_action=f"/medical-records/{record_id}/orders/new",
    )


@router.post("/medical-records/{record_id}/orders/new", include_in_schema=False)
async def order_create(
    record_id: int,
    request: Request,
    current_user: OrderCreator,
    db: DatabaseSession,
):
    form = await request.form()
    record = _editable_record(db, record_id, current_user)
    try:
        values = _order_payload(form)
        MedicalOrderService(db).create_order(
            record_id,
            MedicalOrderCreate(**values),
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except (PydanticValidationError, ValueError) as exc:
        return _render_order_form(
            request,
            db=db,
            record=record,
            values=dict(form),
            title="新增医嘱",
            form_action=f"/medical-records/{record_id}/orders/new",
            error=validation_message(exc),
            status_code=422,
        )
    except AppException as exc:
        return _render_order_form(
            request,
            db=db,
            record=record,
            values=dict(form),
            title="新增医嘱",
            form_action=f"/medical-records/{record_id}/orders/new",
            error=exc.message,
            status_code=exc.status_code,
        )
    return redirect_with_flash(f"/medical-records/{record_id}#orders", "医嘱创建成功")


@router.get(
    "/medical-records/{record_id}/orders/{order_id}/edit", include_in_schema=False
)
def order_edit_page(
    record_id: int,
    order_id: int,
    request: Request,
    current_user: OrderEditor,
    db: DatabaseSession,
):
    full = _editable_full_record(db, record_id, current_user)
    order = MedicalOrderService(db).get_editable_order(
        order_id, operator=current_user
    )
    if order.record_id != record_id:
        raise ResourceNotFoundError("医嘱不存在")
    values = _order_values(order)
    values.update(MedicalOrderService(db).get_generated_values(order_id))
    return _render_order_form(
        request,
        db=db,
        record=full.medical_record,
        values=values,
        title="编辑医嘱",
        form_action=f"/medical-records/{record_id}/orders/{order_id}/edit",
        current_order_type=order.order_type,
    )


@router.post(
    "/medical-records/{record_id}/orders/{order_id}/edit", include_in_schema=False
)
async def order_edit(
    record_id: int,
    order_id: int,
    request: Request,
    current_user: OrderEditor,
    db: DatabaseSession,
):
    form = await request.form()
    full = _editable_full_record(db, record_id, current_user)
    order = MedicalOrderService(db).get_editable_order(
        order_id, operator=current_user
    )
    if order.record_id != record_id:
        raise ResourceNotFoundError("医嘱不存在")
    try:
        values = _order_payload(form)
        MedicalOrderService(db).update_order(
            order_id,
            MedicalOrderUpdate(**values),
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except (PydanticValidationError, ValueError) as exc:
        return _render_order_form(
            request,
            db=db,
            record=full.medical_record,
            values=dict(form),
            title="编辑医嘱",
            form_action=f"/medical-records/{record_id}/orders/{order_id}/edit",
            error=validation_message(exc),
            status_code=422,
            current_order_type=order.order_type,
        )
    except AppException as exc:
        return _render_order_form(
            request,
            db=db,
            record=full.medical_record,
            values=dict(form),
            title="编辑医嘱",
            form_action=f"/medical-records/{record_id}/orders/{order_id}/edit",
            error=exc.message,
            status_code=exc.status_code,
            current_order_type=order.order_type,
        )
    return redirect_with_flash(f"/medical-records/{record_id}#orders", "医嘱更新成功")


def _run_order_action(
    record_id: int,
    order_id: int,
    request: Request,
    current_user: User,
    db,
    action: Callable[..., Any],
    message: str,
):
    full = _full_record(db, record_id, current_user)
    _find(full.medical_orders, order_id, "医嘱")
    try:
        action(
            order_id,
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except AppException as exc:
        return redirect_with_flash(
            f"/medical-records/{record_id}#orders", exc.message, category="danger"
        )
    return redirect_with_flash(f"/medical-records/{record_id}#orders", message)


@router.post(
    "/medical-records/{record_id}/orders/{order_id}/stop", include_in_schema=False
)
def order_stop(
    record_id: int,
    order_id: int,
    request: Request,
    current_user: OrderEditor,
    db: DatabaseSession,
):
    return _run_order_action(
        record_id,
        order_id,
        request,
        current_user,
        db,
        MedicalOrderService(db).stop_order,
        "医嘱已停止",
    )


@router.post(
    "/medical-records/{record_id}/orders/{order_id}/complete", include_in_schema=False
)
def order_complete(
    record_id: int,
    order_id: int,
    request: Request,
    current_user: OrderEditor,
    db: DatabaseSession,
):
    return _run_order_action(
        record_id,
        order_id,
        request,
        current_user,
        db,
        MedicalOrderService(db).complete_order,
        "医嘱已完成",
    )


@router.post(
    "/medical-records/{record_id}/orders/{order_id}/delete", include_in_schema=False
)
def order_delete(
    record_id: int,
    order_id: int,
    request: Request,
    current_user: OrderEditor,
    db: DatabaseSession,
):
    return _run_order_action(
        record_id,
        order_id,
        request,
        current_user,
        db,
        MedicalOrderService(db).delete_order,
        "医嘱已删除",
    )


def _prescription_payload(form: Any) -> dict[str, Any]:
    return {
        "prescription_type": str(
            form.get("prescription_type", PrescriptionType.OUTPATIENT.value)
        ),
        "notes": optional_text(form.get("notes")),
    }


def _render_prescription_form(
    request: Request,
    *,
    record: Any,
    values: dict[str, Any],
    title: str,
    form_action: str,
    error: str | None = None,
    status_code: int = 200,
):
    return render_template(
        request,
        "clinical/prescription_form.html",
        status_code=status_code,
        title=title,
        page_title=title,
        active_menu="records-my",
        record=record,
        form_action=form_action,
        form_values=values,
        prescription_types=list(PrescriptionType),
        error=error,
    )


@router.get(
    "/medical-records/{record_id}/prescriptions/new",
    include_in_schema=False,
)
def prescription_create_page(
    record_id: int,
    request: Request,
    current_user: PrescriptionCreator,
    db: DatabaseSession,
):
    record = _editable_record(db, record_id, current_user)
    return _render_prescription_form(
        request,
        record=record,
        values={"prescription_type": PrescriptionType.OUTPATIENT.value},
        title="新建处方",
        form_action=f"/medical-records/{record_id}/prescriptions/new",
    )


@router.post(
    "/medical-records/{record_id}/prescriptions/new",
    include_in_schema=False,
)
async def prescription_create(
    record_id: int,
    request: Request,
    current_user: PrescriptionCreator,
    db: DatabaseSession,
):
    form = await request.form()
    values = _prescription_payload(form)
    record = _editable_record(db, record_id, current_user)
    try:
        result = PrescriptionService(db).create_prescription(
            record_id,
            PrescriptionCreate(**values),
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except (PydanticValidationError, ValueError) as exc:
        return _render_prescription_form(
            request,
            record=record,
            values=values,
            title="新建处方",
            form_action=f"/medical-records/{record_id}/prescriptions/new",
            error=validation_message(exc),
            status_code=422,
        )
    except AppException as exc:
        return _render_prescription_form(
            request,
            record=record,
            values=values,
            title="新建处方",
            form_action=f"/medical-records/{record_id}/prescriptions/new",
            error=exc.message,
            status_code=exc.status_code,
        )
    return redirect_with_flash(
        f"/medical-records/{record_id}/prescriptions/{result.id}",
        "处方创建成功，请添加药品",
    )


@router.get(
    "/medical-records/{record_id}/prescriptions/{prescription_id}",
    include_in_schema=False,
)
def prescription_detail(
    record_id: int,
    prescription_id: int,
    request: Request,
    current_user: RecordViewer,
    db: DatabaseSession,
):
    record = MedicalRecordService(db).get_record_detail(
        record_id, operator=current_user
    )
    prescription = PrescriptionService(db).get_prescription_detail(
        prescription_id, operator=current_user
    )
    if prescription.record_id != record_id:
        raise ResourceNotFoundError("处方不存在")
    return render_template(
        request,
        "clinical/prescription_detail.html",
        title=f"处方 {prescription.prescription_no}",
        active_menu="records-my",
        record=record,
        prescription=prescription,
    )


@router.get(
    "/medical-records/{record_id}/prescriptions/{prescription_id}/edit",
    include_in_schema=False,
)
def prescription_edit_page(
    record_id: int,
    prescription_id: int,
    request: Request,
    current_user: PrescriptionEditor,
    db: DatabaseSession,
):
    record = _editable_record(db, record_id, current_user)
    prescription = PrescriptionService(db).get_editable_prescription_detail(
        prescription_id, operator=current_user
    )
    if prescription.record_id != record_id:
        raise ResourceNotFoundError("处方不存在")
    return _render_prescription_form(
        request,
        record=record,
        values=_form_values(prescription, {}),
        title="编辑处方",
        form_action=(
            f"/medical-records/{record_id}/prescriptions/"
            f"{prescription_id}/edit"
        ),
    )


@router.post(
    "/medical-records/{record_id}/prescriptions/{prescription_id}/edit",
    include_in_schema=False,
)
async def prescription_edit(
    record_id: int,
    prescription_id: int,
    request: Request,
    current_user: PrescriptionEditor,
    db: DatabaseSession,
):
    form = await request.form()
    values = _prescription_payload(form)
    record = _editable_record(db, record_id, current_user)
    prescription = PrescriptionService(db).get_editable_prescription_detail(
        prescription_id, operator=current_user
    )
    if prescription.record_id != record_id:
        raise ResourceNotFoundError("处方不存在")
    try:
        PrescriptionService(db).update_prescription(
            prescription_id,
            PrescriptionUpdate(**values),
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except (PydanticValidationError, ValueError) as exc:
        return _render_prescription_form(
            request,
            record=record,
            values=values,
            title="编辑处方",
            form_action=(
                f"/medical-records/{record_id}/prescriptions/"
                f"{prescription_id}/edit"
            ),
            error=validation_message(exc),
            status_code=422,
        )
    except AppException as exc:
        return _render_prescription_form(
            request,
            record=record,
            values=values,
            title="编辑处方",
            form_action=(
                f"/medical-records/{record_id}/prescriptions/"
                f"{prescription_id}/edit"
            ),
            error=exc.message,
            status_code=exc.status_code,
        )
    return redirect_with_flash(
        f"/medical-records/{record_id}/prescriptions/{prescription_id}",
        "处方信息更新成功",
    )


def _item_payload(form: Any) -> dict[str, Any]:
    quantity = optional_text(form.get("quantity"))
    return {
        "drug_catalog_id": optional_int(form.get("drug_catalog_id")),
        "drug_name": str(form.get("drug_name", "")),
        "generic_name": optional_text(form.get("generic_name")),
        "dosage_form": optional_text(form.get("dosage_form")),
        "specification": optional_text(form.get("specification")),
        "dosage": optional_text(form.get("dosage")),
        "dosage_unit": optional_text(form.get("dosage_unit")),
        "frequency": optional_text(form.get("frequency")),
        "route": optional_text(form.get("route")),
        "duration": optional_int(form.get("duration")),
        "duration_unit": optional_text(form.get("duration_unit")),
        "quantity": quantity,
        "quantity_unit": optional_text(form.get("quantity_unit")),
        "usage_instruction": optional_text(form.get("usage_instruction")),
        "remark": optional_text(form.get("remark")),
        "sort_order": optional_int(form.get("sort_order")) or 0,
    }


def _render_item_form(
    request: Request,
    *,
    db: Any,
    record: Any,
    prescription: Any,
    values: dict[str, Any],
    title: str,
    form_action: str,
    error: str | None = None,
    status_code: int = 200,
):
    return render_template(
        request,
        "clinical/prescription_item_form.html",
        status_code=status_code,
        title=title,
        page_title=title,
        active_menu="records-my",
        record=record,
        prescription=prescription,
        form_values=values,
        form_action=form_action,
        error=error,
        drug_catalogs=CatalogService(db).list_drugs(),
        frequency_options=("每日1次", "每日2次", "每日3次", "每日4次", "必要时", "睡前"),
        route_options=("口服", "静脉滴注", "静脉注射", "肌内注射", "皮下注射", "外用"),
    )


@router.get(
    "/medical-records/{record_id}/prescriptions/{prescription_id}/items/new",
    include_in_schema=False,
)
def item_create_page(
    record_id: int,
    prescription_id: int,
    request: Request,
    current_user: PrescriptionEditor,
    db: DatabaseSession,
):
    record = _editable_record(db, record_id, current_user)
    prescription = PrescriptionService(db).get_editable_prescription_detail(
        prescription_id, operator=current_user
    )
    if prescription.record_id != record_id:
        raise ResourceNotFoundError("处方不存在")
    return _render_item_form(
        request,
        db=db,
        record=record,
        prescription=prescription,
        values={"sort_order": len(prescription.items)},
        title="添加处方项目",
        form_action=(
            f"/medical-records/{record_id}/prescriptions/"
            f"{prescription_id}/items/new"
        ),
    )


@router.post(
    "/medical-records/{record_id}/prescriptions/{prescription_id}/items/new",
    include_in_schema=False,
)
async def item_create(
    record_id: int,
    prescription_id: int,
    request: Request,
    current_user: PrescriptionEditor,
    db: DatabaseSession,
):
    form = await request.form()
    record = _editable_record(db, record_id, current_user)
    prescription = PrescriptionService(db).get_editable_prescription_detail(
        prescription_id, operator=current_user
    )
    if prescription.record_id != record_id:
        raise ResourceNotFoundError("处方不存在")
    try:
        values = _item_payload(form)
        PrescriptionService(db).add_item(
            prescription_id,
            PrescriptionItemCreate(**values),
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except (PydanticValidationError, ValueError) as exc:
        return _render_item_form(
            request,
            db=db,
            record=record,
            prescription=prescription,
            values=dict(form),
            title="添加处方项目",
            form_action=(
                f"/medical-records/{record_id}/prescriptions/"
                f"{prescription_id}/items/new"
            ),
            error=validation_message(exc),
            status_code=422,
        )
    except AppException as exc:
        return _render_item_form(
            request,
            db=db,
            record=record,
            prescription=prescription,
            values=dict(form),
            title="添加处方项目",
            form_action=(
                f"/medical-records/{record_id}/prescriptions/"
                f"{prescription_id}/items/new"
            ),
            error=exc.message,
            status_code=exc.status_code,
        )
    return redirect_with_flash(
        f"/medical-records/{record_id}/prescriptions/{prescription_id}",
        "处方项目添加成功",
    )


@router.get(
    "/medical-records/{record_id}/prescriptions/{prescription_id}/items/"
    "{item_id}/edit",
    include_in_schema=False,
)
def item_edit_page(
    record_id: int,
    prescription_id: int,
    item_id: int,
    request: Request,
    current_user: PrescriptionEditor,
    db: DatabaseSession,
):
    record = _editable_record(db, record_id, current_user)
    prescription = PrescriptionService(db).get_editable_prescription_detail(
        prescription_id, operator=current_user
    )
    if prescription.record_id != record_id:
        raise ResourceNotFoundError("处方不存在")
    item = _find(prescription.items, item_id, "处方项目")
    return _render_item_form(
        request,
        db=db,
        record=record,
        prescription=prescription,
        values=_form_values(item, {}),
        title="编辑处方项目",
        form_action=(
            f"/medical-records/{record_id}/prescriptions/{prescription_id}/"
            f"items/{item_id}/edit"
        ),
    )


@router.post(
    "/medical-records/{record_id}/prescriptions/{prescription_id}/items/"
    "{item_id}/edit",
    include_in_schema=False,
)
async def item_edit(
    record_id: int,
    prescription_id: int,
    item_id: int,
    request: Request,
    current_user: PrescriptionEditor,
    db: DatabaseSession,
):
    form = await request.form()
    record = _editable_record(db, record_id, current_user)
    prescription = PrescriptionService(db).get_editable_prescription_detail(
        prescription_id, operator=current_user
    )
    if prescription.record_id != record_id:
        raise ResourceNotFoundError("处方不存在")
    _find(prescription.items, item_id, "处方项目")
    try:
        values = _item_payload(form)
        PrescriptionService(db).update_item(
            item_id,
            PrescriptionItemUpdate(**values),
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except (PydanticValidationError, ValueError) as exc:
        return _render_item_form(
            request,
            db=db,
            record=record,
            prescription=prescription,
            values=dict(form),
            title="编辑处方项目",
            form_action=(
                f"/medical-records/{record_id}/prescriptions/{prescription_id}/"
                f"items/{item_id}/edit"
            ),
            error=validation_message(exc),
            status_code=422,
        )
    except AppException as exc:
        return _render_item_form(
            request,
            db=db,
            record=record,
            prescription=prescription,
            values=dict(form),
            title="编辑处方项目",
            form_action=(
                f"/medical-records/{record_id}/prescriptions/{prescription_id}/"
                f"items/{item_id}/edit"
            ),
            error=exc.message,
            status_code=exc.status_code,
        )
    return redirect_with_flash(
        f"/medical-records/{record_id}/prescriptions/{prescription_id}",
        "处方项目更新成功",
    )


@router.post(
    "/medical-records/{record_id}/prescriptions/{prescription_id}/items/"
    "{item_id}/delete",
    include_in_schema=False,
)
def item_delete(
    record_id: int,
    prescription_id: int,
    item_id: int,
    request: Request,
    current_user: PrescriptionEditor,
    db: DatabaseSession,
):
    prescription = PrescriptionService(db).get_prescription_detail(
        prescription_id, operator=current_user
    )
    if prescription.record_id != record_id:
        raise ResourceNotFoundError("处方不存在")
    _find(prescription.items, item_id, "处方项目")
    try:
        PrescriptionService(db).remove_item(
            item_id,
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except AppException as exc:
        return redirect_with_flash(
            f"/medical-records/{record_id}/prescriptions/{prescription_id}",
            exc.message,
            category="danger",
        )
    return redirect_with_flash(
        f"/medical-records/{record_id}/prescriptions/{prescription_id}",
        "处方项目已删除",
    )


@router.post(
    "/medical-records/{record_id}/prescriptions/{prescription_id}/issue",
    include_in_schema=False,
)
def prescription_issue(
    record_id: int,
    prescription_id: int,
    request: Request,
    current_user: PrescriptionEditor,
    db: DatabaseSession,
):
    prescription = PrescriptionService(db).get_prescription_detail(
        prescription_id, operator=current_user
    )
    if prescription.record_id != record_id:
        raise ResourceNotFoundError("处方不存在")
    try:
        PrescriptionService(db).issue_prescription(
            prescription_id,
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except AppException as exc:
        return redirect_with_flash(
            f"/medical-records/{record_id}/prescriptions/{prescription_id}",
            exc.message,
            category="danger",
        )
    return redirect_with_flash(
        f"/medical-records/{record_id}/prescriptions/{prescription_id}",
        "处方签发成功",
    )


@router.post(
    "/medical-records/{record_id}/prescriptions/{prescription_id}/cancel",
    include_in_schema=False,
)
async def prescription_cancel(
    record_id: int,
    prescription_id: int,
    request: Request,
    current_user: PrescriptionEditor,
    db: DatabaseSession,
):
    form = await request.form()
    prescription = PrescriptionService(db).get_prescription_detail(
        prescription_id, operator=current_user
    )
    if prescription.record_id != record_id:
        raise ResourceNotFoundError("处方不存在")
    try:
        payload = PrescriptionCancelRequest(reason=str(form.get("reason", "")))
        PrescriptionService(db).cancel_prescription(
            prescription_id,
            payload,
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except (PydanticValidationError, ValueError) as exc:
        return redirect_with_flash(
            f"/medical-records/{record_id}/prescriptions/{prescription_id}",
            validation_message(exc),
            category="danger",
        )
    except AppException as exc:
        return redirect_with_flash(
            f"/medical-records/{record_id}/prescriptions/{prescription_id}",
            exc.message,
            category="danger",
        )
    return redirect_with_flash(
        f"/medical-records/{record_id}/prescriptions/{prescription_id}",
        "处方已取消",
    )
