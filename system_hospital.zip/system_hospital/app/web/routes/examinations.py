"""检查申请、影像工作列表与报告完成页面。"""

from typing import Annotated

from fastapi import APIRouter, Depends, Request
from pydantic import ValidationError as PydanticValidationError

from app.api.deps import DatabaseSession, Storage
from app.core.config import get_settings
from app.core.exceptions import AppException
from app.models.enums import ExaminationStatus, ExaminationType
from app.models.user import User
from app.schemas.examination import ExaminationComplete, ExaminationCreate
from app.schemas.worklist import ExaminationWorklistParams
from app.services.attachment_service import AttachmentService
from app.services.audit_service import AuditContext
from app.services.examination_service import ExaminationService
from app.services.medical_record_service import MedicalRecordService
from app.services.worklist_service import WorklistService
from app.web.deps import redirect_with_flash, require_web_permission
from app.web.forms import compact_query, optional_text, validation_message
from app.web.templating import render_template

router = APIRouter(tags=["Web Examinations"])
Viewer = Annotated[User, Depends(require_web_permission("examination:view"))]
Creator = Annotated[User, Depends(require_web_permission("examination:create"))]
Editor = Annotated[User, Depends(require_web_permission("examination:update"))]
Completer = Annotated[User, Depends(require_web_permission("examination:complete"))]


def _context(request: Request) -> AuditContext:
    return AuditContext(request.method, request.url.path, request.client.host if request.client else None)


@router.get("/examinations", include_in_schema=False)
def examination_list(request: Request, current_user: Viewer, db: DatabaseSession):
    error = None
    status_code = 200
    try:
        params = ExaminationWorklistParams(**compact_query(request.query_params))
    except PydanticValidationError as exc:
        params = ExaminationWorklistParams()
        error = validation_message(exc)
        status_code = 422
    return render_template(
        request, "examinations/list.html", status_code=status_code,
        title="检查管理", active_menu="examinations",
        page=WorklistService(db).list_examinations(params, operator=current_user),
        params=params, statuses=list(ExaminationStatus),
        examination_types=list(ExaminationType), error=error,
    )


@router.get("/medical-records/{record_id}/examinations/new", include_in_schema=False)
def examination_create_page(
    record_id: int, request: Request, current_user: Creator, db: DatabaseSession
):
    record = MedicalRecordService(db).get_record_detail(record_id, operator=current_user)
    return render_template(
        request, "examinations/form.html", title="申请检查",
        active_menu="examinations", record=record, values={},
        examination_types=list(ExaminationType),
    )


@router.post("/medical-records/{record_id}/examinations/new", include_in_schema=False)
async def examination_create(
    record_id: int, request: Request, current_user: Creator, db: DatabaseSession
):
    form = await request.form()
    values = dict(form)
    try:
        payload = ExaminationCreate(
            examination_type=str(form.get("examination_type") or ""),
            examination_name=str(form.get("examination_name") or ""),
            body_part=optional_text(form.get("body_part")),
            clinical_indication=optional_text(form.get("clinical_indication")),
        )
        item = ExaminationService(db).create_examination(
            record_id, payload, operator=current_user, audit_context=_context(request)
        )
    except (PydanticValidationError, ValueError, AppException) as exc:
        message = exc.message if isinstance(exc, AppException) else validation_message(exc)
        record = MedicalRecordService(db).get_record_detail(record_id, operator=current_user)
        return render_template(
            request, "examinations/form.html", status_code=getattr(exc, "status_code", 422),
            title="申请检查", active_menu="examinations", record=record,
            values=values, examination_types=list(ExaminationType), error=message,
        )
    return redirect_with_flash(f"/examinations/{item.id}", "检查申请创建成功")


@router.get("/examinations/{examination_id}", include_in_schema=False)
def examination_detail(
    examination_id: int, request: Request, current_user: Viewer,
    db: DatabaseSession, storage: Storage,
):
    item = ExaminationService(db).get_examination(examination_id, operator=current_user)
    record = MedicalRecordService(db).get_record_detail(item.record_id, operator=current_user)
    attachments = [
        attachment for attachment in AttachmentService(
            db, storage, max_upload_size_mb=get_settings().max_upload_size_mb
        ).list_for_record(item.record_id, operator=current_user)
        if attachment.examination_id == item.id
    ]
    names = WorklistService(db).user_names(item.requested_by, item.performed_by)
    return render_template(
        request, "examinations/detail.html",
        title=f"检查报告 {item.examination_no}", active_menu="examinations",
        item=item, record=record, attachments=attachments, user_names=names,
    )


@router.post("/examinations/{examination_id}/start", include_in_schema=False)
def examination_start(
    examination_id: int, request: Request, current_user: Editor, db: DatabaseSession
):
    try:
        ExaminationService(db).start_examination(
            examination_id, operator=current_user, audit_context=_context(request)
        )
    except AppException as exc:
        return redirect_with_flash(f"/examinations/{examination_id}", exc.message, category="danger")
    return redirect_with_flash(f"/examinations/{examination_id}", "检查已开始")


@router.post("/examinations/{examination_id}/complete", include_in_schema=False)
async def examination_complete(
    examination_id: int, request: Request, current_user: Completer, db: DatabaseSession
):
    form = await request.form()
    try:
        payload = ExaminationComplete(
            findings=str(form.get("findings") or ""),
            conclusion=str(form.get("conclusion") or ""),
        )
        ExaminationService(db).complete_examination(
            examination_id, payload, operator=current_user, audit_context=_context(request)
        )
    except (PydanticValidationError, AppException) as exc:
        message = exc.message if isinstance(exc, AppException) else validation_message(exc)
        return redirect_with_flash(f"/examinations/{examination_id}", message, category="danger")
    return redirect_with_flash(f"/examinations/{examination_id}", "检查报告已完成")
