"""统计分析可视化页面。"""

from typing import Annotated

from fastapi import APIRouter, Depends, Request

from app.api.deps import DatabaseSession
from app.models.user import User
from app.services.statistics_service import StatisticsService
from app.web.deps import require_web_permission
from app.web.templating import render_template

router = APIRouter(tags=["Web Statistics"])
StatisticsViewer = Annotated[User, Depends(require_web_permission("audit:view"))]


@router.get("/statistics", include_in_schema=False)
def statistics_page(
    request: Request,
    _user: StatisticsViewer,
    db: DatabaseSession,
):
    service = StatisticsService(db)
    return render_template(
        request,
        "statistics/index.html",
        title="统计分析",
        active_menu="statistics",
        summary=service.summary(),
        charts=service.all_charts(),
    )
