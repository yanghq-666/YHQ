"""只读操作日志 Web 页面。"""

from typing import Annotated

from fastapi import APIRouter, Depends, Request
from pydantic import ValidationError as PydanticValidationError

from app.api.deps import DatabaseSession
from app.models.user import User
from app.schemas.audit_log import AuditLogSearchParams
from app.services.audit_log_query_service import AuditLogQueryService
from app.web.deps import require_web_permission
from app.web.forms import compact_query, validation_message
from app.web.templating import render_template

router = APIRouter(tags=["Web Audit Logs"])
AuditViewer = Annotated[User, Depends(require_web_permission("audit:view"))]


@router.get("/audit-logs", include_in_schema=False)
def audit_logs(
    request: Request, _user: AuditViewer, db: DatabaseSession
):
    error = None
    status_code = 200
    try:
        params = AuditLogSearchParams(**compact_query(request.query_params))
    except PydanticValidationError as exc:
        params = AuditLogSearchParams()
        error = validation_message(exc)
        status_code = 422
    return render_template(
        request,
        "audit_logs/list.html",
        status_code=status_code,
        title="操作日志",
        active_menu="audit-logs",
        page=AuditLogQueryService(db).search(params),
        params=params,
        error=error,
    )
