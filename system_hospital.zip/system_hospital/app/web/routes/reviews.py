"""病历审核工作站 Web 页面与表单操作。"""

from typing import Annotated

from fastapi import APIRouter, Depends, Request
from fastapi.responses import RedirectResponse
from pydantic import ValidationError as PydanticValidationError

from app.api.deps import DatabaseSession
from app.core.exceptions import AppException
from app.models.enums import MedicalRecordStatus, ReviewAction
from app.models.user import User
from app.schemas.record_review import (
    MyReviewSearchParams,
    PendingReviewSearchParams,
    RecordReviewApproveRequest,
    RecordReviewRejectRequest,
)
from app.services.audit_service import AuditContext
from app.services.medical_record_service import MedicalRecordService
from app.services.review_service import ReviewService
from app.web.deps import redirect_with_flash, require_web_permission
from app.web.forms import compact_query, optional_text, validation_message
from app.web.templating import render_template

router = APIRouter(tags=["Web Medical Record Reviews"])
Reviewer = Annotated[User, Depends(require_web_permission("record:review"))]


def _audit_context(request: Request) -> AuditContext:
    return AuditContext(
        request_method=request.method,
        request_path=request.url.path,
        ip_address=request.client.host if request.client else None,
    )


def _pending_page(
    request: Request,
    db,
    current_user: User,
    *,
    status: MedicalRecordStatus,
    title: str,
    active_menu: str,
):
    error = None
    status_code = 200
    values = compact_query(request.query_params)
    values.pop("status", None)
    try:
        params = PendingReviewSearchParams(**values, status=status)
    except PydanticValidationError as exc:
        params = PendingReviewSearchParams(status=status)
        error = validation_message(exc)
        status_code = 422
    page = ReviewService(db).list_pending(params, operator=current_user)
    return render_template(
        request,
        "reviews/pending.html",
        status_code=status_code,
        title=title,
        active_menu=active_menu,
        page=page,
        params=params,
        list_status=status,
        error=error,
    )


@router.get("/reviews/pending", include_in_schema=False)
def pending_reviews(
    request: Request,
    current_user: Reviewer,
    db: DatabaseSession,
):
    return _pending_page(
        request,
        db,
        current_user,
        status=MedicalRecordStatus.SUBMITTED,
        title="待审核病历",
        active_menu="reviews-pending",
    )


@router.get("/reviews/reviewing", include_in_schema=False)
def reviewing_records(
    request: Request,
    current_user: Reviewer,
    db: DatabaseSession,
):
    return _pending_page(
        request,
        db,
        current_user,
        status=MedicalRecordStatus.REVIEWING,
        title="审核中病历",
        active_menu="reviews-reviewing",
    )


@router.get("/reviews/mine", include_in_schema=False)
def my_review_records(
    request: Request,
    current_user: Reviewer,
    db: DatabaseSession,
):
    error = None
    status_code = 200
    try:
        params = MyReviewSearchParams(**compact_query(request.query_params))
    except PydanticValidationError as exc:
        params = MyReviewSearchParams()
        error = validation_message(exc)
        status_code = 422
    page = ReviewService(db).list_my_reviews(params, operator=current_user)
    return render_template(
        request,
        "reviews/mine.html",
        status_code=status_code,
        title="我的审核记录",
        active_menu="reviews-mine",
        page=page,
        params=params,
        review_actions=list(ReviewAction),
        error=error,
    )


@router.get("/reviews/my", include_in_schema=False)
def legacy_my_reviews(_current_user: Reviewer):
    """保留旧菜单地址，避免已有书签失效。"""
    return RedirectResponse("/reviews/mine", status_code=308)


@router.get("/reviews/{record_id}", include_in_schema=False)
def review_detail(
    record_id: int,
    request: Request,
    current_user: Reviewer,
    db: DatabaseSession,
):
    full = MedicalRecordService(db).get_full_record(
        record_id, operator=current_user
    )
    record = full.medical_record
    return render_template(
        request,
        "reviews/detail.html",
        title=f"审核病历 {record.record_no}",
        active_menu=(
            "reviews-reviewing"
            if record.status == MedicalRecordStatus.REVIEWING
            else "reviews-pending"
        ),
        full=full,
        can_start=(
            record.status == MedicalRecordStatus.SUBMITTED
            and record.created_by != current_user.id
        ),
        owns_review_lock=(
            record.status == MedicalRecordStatus.REVIEWING
            and record.current_reviewer_id == current_user.id
        ),
    )


@router.get(
    "/reviews/{record_id}/versions/{version}", include_in_schema=False
)
def review_version_detail(
    record_id: int,
    version: int,
    request: Request,
    current_user: Reviewer,
    db: DatabaseSession,
):
    review_service = ReviewService(db)
    snapshot = review_service.get_version_full(
        record_id, version, operator=current_user
    )
    record_service = MedicalRecordService(db)
    record = record_service.get_record_detail(record_id, operator=current_user)
    version_info = record_service.get_version(
        record_id, version, operator=current_user
    )
    return render_template(
        request,
        "reviews/version_detail.html",
        title=f"审核版本 V{version}",
        active_menu="reviews-mine",
        record=record,
        version=version_info,
        snapshot=snapshot,
    )


@router.post("/reviews/{record_id}/start", include_in_schema=False)
def start_review(
    record_id: int,
    request: Request,
    current_user: Reviewer,
    db: DatabaseSession,
):
    try:
        result = ReviewService(db).start_review(
            record_id,
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except AppException as exc:
        return redirect_with_flash(
            f"/reviews/{record_id}", exc.message, category="danger"
        )
    return redirect_with_flash(
        f"/reviews/{record_id}",
        f"已开始审核，本次审核对应 V{result.record_version}",
    )


@router.post("/reviews/{record_id}/approve", include_in_schema=False)
async def approve_review(
    record_id: int,
    request: Request,
    current_user: Reviewer,
    db: DatabaseSession,
):
    form = await request.form()
    try:
        payload = RecordReviewApproveRequest(
            comment=optional_text(form.get("comment"))
        )
        result = ReviewService(db).approve(
            record_id,
            payload,
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except PydanticValidationError as exc:
        return redirect_with_flash(
            f"/reviews/{record_id}",
            validation_message(exc),
            category="danger",
        )
    except AppException as exc:
        return redirect_with_flash(
            f"/reviews/{record_id}", exc.message, category="danger"
        )
    return redirect_with_flash(
        "/reviews/mine",
        f"病历审核通过，批准版本为 V{result.approved_version}",
    )


@router.post("/reviews/{record_id}/reject", include_in_schema=False)
async def reject_review(
    record_id: int,
    request: Request,
    current_user: Reviewer,
    db: DatabaseSession,
):
    form = await request.form()
    try:
        payload = RecordReviewRejectRequest(
            comment=optional_text(form.get("comment")) or ""
        )
        ReviewService(db).reject(
            record_id,
            payload,
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except PydanticValidationError as exc:
        return redirect_with_flash(
            f"/reviews/{record_id}",
            validation_message(exc),
            category="danger",
        )
    except AppException as exc:
        return redirect_with_flash(
            f"/reviews/{record_id}", exc.message, category="danger"
        )
    return redirect_with_flash("/reviews/mine", "病历已退回经治医生修改")
