"""就诊管理 Web 页面。"""

from typing import Annotated, Any, Callable

from fastapi import APIRouter, Depends, Request
from pydantic import ValidationError as PydanticValidationError

from app.api.deps import DatabaseSession
from app.core.exceptions import AppException
from app.models.enums import EncounterStatus, EncounterType
from app.models.user import User
from app.schemas.encounter import (
    EncounterCreate,
    EncounterSearchParams,
    EncounterUpdate,
)
from app.services.audit_service import AuditContext
from app.services.encounter_service import EncounterService
from app.services.web_lookup_service import WebLookupService
from app.web.deps import redirect_with_flash, require_web_permission
from app.web.forms import (
    compact_query,
    optional_datetime,
    optional_int,
    optional_text,
    validation_message,
)
from app.web.templating import render_template

router = APIRouter(tags=["Web Encounters"])
EncounterViewer = Annotated[
    User, Depends(require_web_permission("encounter:view"))
]
EncounterCreator = Annotated[
    User, Depends(require_web_permission("encounter:create"))
]
EncounterEditor = Annotated[
    User, Depends(require_web_permission("encounter:update"))
]


def _audit_context(request: Request) -> AuditContext:
    return AuditContext(
        request_method=request.method,
        request_path=request.url.path,
        ip_address=request.client.host if request.client else None,
    )


def _form_payload(form: Any, *, include_patient: bool) -> dict[str, Any]:
    values: dict[str, Any] = {
        "doctor_id": optional_int(form.get("doctor_id")),
        "department_id": optional_int(form.get("department_id")),
        "visit_time": optional_datetime(form.get("visit_time")),
        "chief_complaint": optional_text(form.get("chief_complaint")),
        "admission_time": optional_datetime(form.get("admission_time")),
        "discharge_time": optional_datetime(form.get("discharge_time")),
        "room_no": optional_text(form.get("room_no")),
        "bed_no": optional_text(form.get("bed_no")),
        "remark": optional_text(form.get("remark")),
    }
    if include_patient:
        values["patient_id"] = optional_int(form.get("patient_id"))
        values["encounter_type"] = str(
            form.get("encounter_type", EncounterType.OUTPATIENT.value)
        )
    return values


def _datetime_local(value: Any) -> str:
    if value is None or value == "":
        return ""
    if isinstance(value, str):
        try:
            value = optional_datetime(value)
        except ValueError:
            return value
    return value.strftime("%Y-%m-%dT%H:%M") if value else ""


def _form_values(data: Any | None = None) -> dict[str, Any]:
    if data is None:
        return {"encounter_type": EncounterType.OUTPATIENT.value}
    values = (
        data.model_dump(mode="json")
        if hasattr(data, "model_dump")
        else dict(data)
    )
    for field in ("visit_time", "admission_time", "discharge_time"):
        values[field] = _datetime_local(values.get(field))
    return values


def _render_form(
    request: Request,
    db,
    current_user: User,
    *,
    title: str,
    form_action: str,
    values: dict[str, Any],
    editing: bool,
    error: str | None = None,
    status_code: int = 200,
):
    selected_patient = optional_int(values.get("patient_id"))
    options = WebLookupService(db).encounter_form_options(
        current_user,
        selected_patient_id=selected_patient,
    )
    return render_template(
        request,
        "encounters/form.html",
        status_code=status_code,
        title=title,
        page_title=title,
        active_menu="encounters",
        form_action=form_action,
        form_values=values,
        encounter_types=list(EncounterType),
        editing=editing,
        error=error,
        **options,
    )


@router.get("/encounters", include_in_schema=False)
def encounter_list(
    request: Request,
    current_user: EncounterViewer,
    db: DatabaseSession,
):
    error = None
    status_code = 200
    try:
        params = EncounterSearchParams(**compact_query(request.query_params))
    except PydanticValidationError as exc:
        params = EncounterSearchParams()
        error = validation_message(exc)
        status_code = 422
    page = EncounterService(db).list_encounters(params, operator=current_user)
    options = WebLookupService(db).encounter_form_options(current_user)
    return render_template(
        request,
        "encounters/list.html",
        status_code=status_code,
        title="就诊管理",
        active_menu="encounters",
        page=page,
        params=params,
        statuses=list(EncounterStatus),
        encounter_types=list(EncounterType),
        error=error,
        **options,
    )


@router.get("/encounters/new", include_in_schema=False)
def encounter_create_page(
    request: Request,
    current_user: EncounterCreator,
    db: DatabaseSession,
    patient_id: int | None = None,
):
    values = _form_values()
    values["patient_id"] = patient_id
    return _render_form(
        request,
        db,
        current_user,
        title="新建就诊",
        form_action="/encounters/new",
        values=values,
        editing=False,
    )


@router.post("/encounters/new", include_in_schema=False)
async def encounter_create(
    request: Request,
    current_user: EncounterCreator,
    db: DatabaseSession,
):
    form = await request.form()
    try:
        values = _form_payload(form, include_patient=True)
        payload = EncounterCreate(**values)
        encounter = EncounterService(db).create_encounter(
            payload,
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except (PydanticValidationError, ValueError) as exc:
        values = dict(form)
        return _render_form(
            request,
            db,
            current_user,
            title="新建就诊",
            form_action="/encounters/new",
            values=_form_values(values),
            editing=False,
            error=validation_message(exc),
            status_code=422,
        )
    except AppException as exc:
        return _render_form(
            request,
            db,
            current_user,
            title="新建就诊",
            form_action="/encounters/new",
            values=_form_values(values),
            editing=False,
            error=exc.message,
            status_code=exc.status_code,
        )
    return redirect_with_flash(
        f"/encounters/{encounter.id}", "就诊创建成功"
    )


@router.get("/encounters/{encounter_id}", include_in_schema=False)
def encounter_detail(
    encounter_id: int,
    request: Request,
    current_user: EncounterViewer,
    db: DatabaseSession,
):
    service = EncounterService(db)
    encounter = service.get_encounter_detail(
        encounter_id, operator=current_user
    )
    return render_template(
        request,
        "encounters/detail.html",
        title=f"就诊 {encounter.encounter_no}",
        active_menu="encounters",
        encounter=encounter,
        has_medical_record=service.has_medical_record(encounter_id),
        medical_record_completed=service.has_completed_medical_record(
            encounter_id
        ),
    )


@router.get("/encounters/{encounter_id}/edit", include_in_schema=False)
def encounter_edit_page(
    encounter_id: int,
    request: Request,
    current_user: EncounterEditor,
    db: DatabaseSession,
):
    encounter = EncounterService(db).get_encounter_detail(
        encounter_id, operator=current_user
    )
    return _render_form(
        request,
        db,
        current_user,
        title="编辑就诊",
        form_action=f"/encounters/{encounter_id}/edit",
        values=_form_values(encounter),
        editing=True,
    )


@router.post("/encounters/{encounter_id}/edit", include_in_schema=False)
async def encounter_edit(
    encounter_id: int,
    request: Request,
    current_user: EncounterEditor,
    db: DatabaseSession,
):
    form = await request.form()
    try:
        values = _form_payload(form, include_patient=False)
        payload = EncounterUpdate(**values)
        encounter = EncounterService(db).update_encounter(
            encounter_id,
            payload,
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except (PydanticValidationError, ValueError) as exc:
        values = dict(form)
        return _render_form(
            request,
            db,
            current_user,
            title="编辑就诊",
            form_action=f"/encounters/{encounter_id}/edit",
            values=_form_values(values),
            editing=True,
            error=validation_message(exc),
            status_code=422,
        )
    except AppException as exc:
        return _render_form(
            request,
            db,
            current_user,
            title="编辑就诊",
            form_action=f"/encounters/{encounter_id}/edit",
            values=_form_values(values),
            editing=True,
            error=exc.message,
            status_code=exc.status_code,
        )
    return redirect_with_flash(
        f"/encounters/{encounter.id}", "就诊信息更新成功"
    )


def _run_action(
    encounter_id: int,
    request: Request,
    current_user: User,
    db,
    action: Callable[..., Any],
    success_message: str,
):
    try:
        action(
            encounter_id,
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except AppException as exc:
        return redirect_with_flash(
            f"/encounters/{encounter_id}",
            exc.message,
            category="danger",
        )
    return redirect_with_flash(
        f"/encounters/{encounter_id}", success_message
    )


@router.post("/encounters/{encounter_id}/start", include_in_schema=False)
def encounter_start(
    encounter_id: int,
    request: Request,
    current_user: EncounterEditor,
    db: DatabaseSession,
):
    return _run_action(
        encounter_id,
        request,
        current_user,
        db,
        EncounterService(db).start_encounter,
        "就诊已开始",
    )


@router.post("/encounters/{encounter_id}/complete", include_in_schema=False)
def encounter_complete(
    encounter_id: int,
    request: Request,
    current_user: EncounterEditor,
    db: DatabaseSession,
):
    return _run_action(
        encounter_id,
        request,
        current_user,
        db,
        EncounterService(db).complete_encounter,
        "就诊已完成",
    )


@router.post("/encounters/{encounter_id}/cancel", include_in_schema=False)
def encounter_cancel(
    encounter_id: int,
    request: Request,
    current_user: EncounterEditor,
    db: DatabaseSession,
):
    return _run_action(
        encounter_id,
        request,
        current_user,
        db,
        EncounterService(db).cancel_encounter,
        "就诊已取消",
    )


@router.post("/encounters/{encounter_id}/delete", include_in_schema=False)
def encounter_delete(
    encounter_id: int,
    request: Request,
    current_user: EncounterEditor,
    db: DatabaseSession,
):
    try:
        EncounterService(db).delete_encounter(
            encounter_id,
            operator=current_user,
            audit_context=_audit_context(request),
        )
    except AppException as exc:
        return redirect_with_flash(
            f"/encounters/{encounter_id}",
            exc.message,
            category="danger",
        )
    return redirect_with_flash("/encounters", "就诊已删除")
