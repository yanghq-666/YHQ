"""Web 页面统一中文标签与 Bootstrap 样式映射。"""

from enum import Enum
from typing import Any


STATUS_LABELS = {
    "DRAFT": "草稿",
    "SUBMITTED": "历史待审核",
    "REVIEWING": "历史审核中",
    "REJECTED": "历史已退回",
    "APPROVED": "已完成",
    "ARCHIVED": "已归档",
    "REGISTERED": "已登记",
    "IN_PROGRESS": "进行中",
    "COMPLETED": "已完成",
    "CANCELLED": "已取消",
    "ACTIVE": "启用",
    "STOPPED": "已停止",
    "ISSUED": "已签发",
    "PENDING": "待处理",
    "INACTIVE": "停用",
    "LOCKED": "已锁定",
}

STATUS_BADGES = {
    "DRAFT": "secondary",
    "SUBMITTED": "primary",
    "REVIEWING": "warning",
    "REJECTED": "danger",
    "APPROVED": "success",
    "ARCHIVED": "dark",
    "REGISTERED": "info",
    "IN_PROGRESS": "primary",
    "COMPLETED": "success",
    "CANCELLED": "secondary",
    "ACTIVE": "success",
    "STOPPED": "secondary",
    "ISSUED": "primary",
    "PENDING": "warning",
    "INACTIVE": "secondary",
    "LOCKED": "danger",
}

GENDER_LABELS = {
    "MALE": "男",
    "FEMALE": "女",
    "OTHER": "其他",
    "UNKNOWN": "未知",
}

ENCOUNTER_TYPE_LABELS = {
    "OUTPATIENT": "门诊",
    "INPATIENT": "住院",
    "EMERGENCY": "急诊",
}

ROLE_LABELS = {
    "ADMIN": "系统管理员",
    "DOCTOR": "医生",
    "SENIOR_DOCTOR": "上级医生",
    "NURSE": "护士",
    "LAB_TECHNICIAN": "检验人员",
    "RADIOLOGY_TECHNICIAN": "影像人员",
    "RECORD_ADMIN": "病案管理员",
}

DIAGNOSIS_TYPE_LABELS = {
    "PRELIMINARY": "初步诊断",
    "FINAL": "最终诊断",
}

ORDER_TYPE_LABELS = {
    "MEDICATION": "药物医嘱",
    "LAB": "检验医嘱",
    "EXAMINATION": "检查医嘱",
    "TREATMENT": "治疗医嘱",
    "NURSING": "护理医嘱",
    "OTHER": "其他医嘱",
}

ORDER_STATUS_LABELS = {
    "ACTIVE": "生效中",
    "STOPPED": "已停止",
    "COMPLETED": "已完成",
    "CANCELLED": "已取消",
}

PRESCRIPTION_TYPE_LABELS = {
    "OUTPATIENT": "门诊处方",
    "INPATIENT": "住院处方",
    "DISCHARGE": "出院带药",
    "OTHER": "其他处方",
}

EXAMINATION_TYPE_LABELS = {
    "XRAY": "X线",
    "CT": "CT",
    "MRI": "磁共振",
    "ULTRASOUND": "超声",
    "ECG": "心电图",
    "ENDOSCOPY": "内镜",
    "OTHER": "其他 / 自定义",
}

ABNORMAL_FLAG_LABELS = {
    "NORMAL": "正常",
    "HIGH": "偏高",
    "LOW": "偏低",
    "CRITICAL": "危急值",
    "ABNORMAL": "异常",
    "UNKNOWN": "未判定",
}

ATTACHMENT_CATEGORY_LABELS = {
    "MEDICAL_RECORD": "病历附件",
    "LAB_REPORT": "检验报告",
    "EXAMINATION": "检查报告",
    "IMAGE": "影像图片",
    "PDF": "PDF 文档",
    "OTHER": "其他附件",
}

REVIEW_ACTION_LABELS = {
    "SUBMIT": "提交病历",
    "START_REVIEW": "开始审核",
    "REJECT": "退回修改",
    "RESUBMIT": "重新提交",
    "APPROVE": "审核通过",
}

AUDIT_ACTION_LABELS = {
    "PATIENT_CREATE": "新增患者",
    "PATIENT_UPDATE": "修改患者",
    "PATIENT_DELETE": "删除患者",
    "PATIENT_RESTORE": "恢复患者",
    "ENCOUNTER_CREATE": "新建就诊",
    "ENCOUNTER_UPDATE": "修改就诊",
    "ENCOUNTER_START": "开始就诊",
    "ENCOUNTER_COMPLETE": "完成就诊",
    "ENCOUNTER_CANCEL": "取消就诊",
    "ENCOUNTER_DELETE": "删除就诊",
    "MEDICAL_RECORD_CREATE": "新建病历",
    "MEDICAL_RECORD_UPDATE": "修改病历",
    "MEDICAL_RECORD_SUBMIT": "提交病历",
    "MEDICAL_RECORD_RESUBMIT": "重新提交病历",
    "MEDICAL_RECORD_COMPLETE": "完成病历",
    "MEDICAL_RECORD_DELETE": "删除病历草稿",
    "MEDICAL_RECORD_VERSION_CREATE": "生成病历版本",
    "MEDICAL_RECORD_REVIEW_START": "开始审核病历",
    "MEDICAL_RECORD_REJECT": "退回病历",
    "MEDICAL_RECORD_APPROVE": "审核通过",
    "MEDICAL_RECORD_ARCHIVE": "归档病历",
    "DIAGNOSIS_CREATE": "新增诊断",
    "DIAGNOSIS_UPDATE": "修改诊断",
    "DIAGNOSIS_DELETE": "删除诊断",
    "MEDICAL_ORDER_CREATE": "新增医嘱",
    "MEDICAL_ORDER_UPDATE": "修改医嘱",
    "MEDICAL_ORDER_STOP": "停止医嘱",
    "MEDICAL_ORDER_COMPLETE": "完成医嘱",
    "MEDICAL_ORDER_DELETE": "删除医嘱",
    "PRESCRIPTION_CREATE": "新建处方",
    "PRESCRIPTION_UPDATE": "修改处方",
    "PRESCRIPTION_ISSUE": "签发处方",
    "PRESCRIPTION_CANCEL": "取消处方",
    "PRESCRIPTION_ITEM_CREATE": "新增处方项目",
    "PRESCRIPTION_ITEM_UPDATE": "修改处方项目",
    "PRESCRIPTION_ITEM_DELETE": "删除处方项目",
    "LAB_REPORT_CREATE": "新建检验报告",
    "LAB_REPORT_START": "开始检验",
    "LAB_REPORT_COMPLETE": "完成检验报告",
    "LAB_REPORT_CANCEL": "取消检验报告",
    "LAB_RESULT_CREATE": "新增检验结果",
    "LAB_RESULT_UPDATE": "修改检验结果",
    "EXAMINATION_CREATE": "新建检查申请",
    "EXAMINATION_START": "开始检查",
    "EXAMINATION_COMPLETE": "完成检查报告",
    "EXAMINATION_CANCEL": "取消检查",
    "ATTACHMENT_UPLOAD": "上传附件",
    "ATTACHMENT_DOWNLOAD": "访问附件",
    "ATTACHMENT_DELETE": "删除附件",
}

AUDIT_MODULE_LABELS = {
    "patient": "患者管理",
    "encounter": "就诊管理",
    "medical_record": "病历管理",
    "diagnosis": "诊断管理",
    "medical_order": "医嘱管理",
    "prescription": "处方管理",
    "lab": "检验管理",
    "examination": "检查管理",
    "attachment": "附件管理",
    "auth": "身份认证",
    "admin": "系统管理",
}

AUDIT_TARGET_LABELS = {
    "patient": "患者",
    "encounter": "就诊",
    "medical_record": "病历",
    "diagnosis": "诊断",
    "medical_order": "医嘱",
    "prescription": "处方",
    "prescription_item": "处方项目",
    "lab_report": "检验报告",
    "lab_result": "检验结果",
    "examination": "检查报告",
    "attachment": "附件",
    "user": "用户",
}


def _value(value: Any) -> str:
    if isinstance(value, Enum):
        return str(value.value)
    return str(value) if value is not None else ""


def status_label(value: Any) -> str:
    normalized = _value(value)
    return STATUS_LABELS.get(normalized, normalized or "-")


def status_badge(value: Any) -> str:
    return STATUS_BADGES.get(_value(value), "secondary")


def gender_label(value: Any) -> str:
    normalized = _value(value)
    return GENDER_LABELS.get(normalized, normalized or "-")


def encounter_type_label(value: Any) -> str:
    normalized = _value(value)
    return ENCOUNTER_TYPE_LABELS.get(normalized, normalized or "-")


def role_label(value: Any) -> str:
    normalized = _value(value)
    return ROLE_LABELS.get(normalized, normalized or "-")


def diagnosis_type_label(value: Any) -> str:
    normalized = _value(value)
    return DIAGNOSIS_TYPE_LABELS.get(normalized, normalized or "-")


def order_type_label(value: Any) -> str:
    normalized = _value(value)
    return ORDER_TYPE_LABELS.get(normalized, normalized or "-")


def order_status_label(value: Any) -> str:
    normalized = _value(value)
    return ORDER_STATUS_LABELS.get(normalized, normalized or "-")


def prescription_type_label(value: Any) -> str:
    normalized = _value(value)
    return PRESCRIPTION_TYPE_LABELS.get(normalized, normalized or "-")


def review_action_label(value: Any) -> str:
    normalized = _value(value)
    return REVIEW_ACTION_LABELS.get(normalized, normalized or "-")


def examination_type_label(value: Any) -> str:
    normalized = _value(value)
    return EXAMINATION_TYPE_LABELS.get(normalized, normalized or "-")


def abnormal_flag_label(value: Any) -> str:
    normalized = _value(value)
    return ABNORMAL_FLAG_LABELS.get(normalized, normalized or "-")


def attachment_category_label(value: Any) -> str:
    normalized = _value(value)
    return ATTACHMENT_CATEGORY_LABELS.get(normalized, normalized or "-")


def audit_action_label(value: Any) -> str:
    normalized = _value(value)
    return AUDIT_ACTION_LABELS.get(normalized, normalized or "-")


def audit_module_label(value: Any) -> str:
    normalized = _value(value)
    return AUDIT_MODULE_LABELS.get(normalized, normalized or "-")


def audit_target_label(value: Any) -> str:
    normalized = _value(value)
    return AUDIT_TARGET_LABELS.get(normalized, normalized or "-")


def file_size_label(value: Any) -> str:
    """将附件字节数转换为适合页面阅读的单位。"""
    try:
        size = max(0, int(value))
    except (TypeError, ValueError):
        return "-"
    if size < 1024:
        return f"{size} B"
    if size < 1024 * 1024:
        return f"{size / 1024:.1f} KB"
    return f"{size / (1024 * 1024):.1f} MB"
