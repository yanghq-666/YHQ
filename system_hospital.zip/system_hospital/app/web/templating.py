"""Jinja2 环境与公共模板上下文。"""

from pathlib import Path
from typing import Any
from urllib.parse import urlencode

from fastapi import Request
from fastapi.templating import Jinja2Templates

from app.core.config import get_settings
from app.web.display_helpers import (
    abnormal_flag_label,
    audit_action_label,
    audit_module_label,
    audit_target_label,
    attachment_category_label,
    diagnosis_type_label,
    encounter_type_label,
    examination_type_label,
    file_size_label,
    gender_label,
    order_type_label,
    order_status_label,
    prescription_type_label,
    review_action_label,
    role_label,
    status_badge,
    status_label,
)

PROJECT_ROOT = Path(__file__).resolve().parents[2]
TEMPLATES_DIR = PROJECT_ROOT / "templates"
STATIC_DIR = PROJECT_ROOT / "static"

templates = Jinja2Templates(directory=str(TEMPLATES_DIR))
templates.env.filters.update(
    status_label=status_label,
    status_badge=status_badge,
    gender_label=gender_label,
    encounter_type_label=encounter_type_label,
    role_label=role_label,
    diagnosis_type_label=diagnosis_type_label,
    order_type_label=order_type_label,
    order_status_label=order_status_label,
    prescription_type_label=prescription_type_label,
    review_action_label=review_action_label,
    examination_type_label=examination_type_label,
    abnormal_flag_label=abnormal_flag_label,
    attachment_category_label=attachment_category_label,
    audit_action_label=audit_action_label,
    audit_module_label=audit_module_label,
    audit_target_label=audit_target_label,
    file_size_label=file_size_label,
)


def page_url(request: Request, page: int) -> str:
    """保留当前筛选条件，仅替换分页参数。"""
    values = list(request.query_params.multi_items())
    values = [(key, value) for key, value in values if key != "page"]
    values.append(("page", str(page)))
    query = urlencode(values)
    return f"{request.url.path}?{query}"


templates.env.globals["page_url"] = page_url


def template_context(request: Request, **values: Any) -> dict[str, Any]:
    """合并请求身份上下文，确保所有页面共享一致布局数据。"""
    context: dict[str, Any] = {
        "app_name": get_settings().app_name,
        "current_user": None,
        "permissions": set(),
        "roles": set(),
        "primary_role": None,
        "active_menu": "",
        "flash": None,
    }
    context.update(getattr(request.state, "web_context", {}))
    context.update(values)
    return context


def render_template(
    request: Request,
    name: str,
    *,
    status_code: int = 200,
    **values: Any,
):
    """渲染页面并消费一次性 Flash Cookie。"""
    from app.web.deps import FLASH_COOKIE, read_flash

    values.setdefault("flash", read_flash(request))
    response = templates.TemplateResponse(
        request,
        name,
        template_context(request, **values),
        status_code=status_code,
    )
    response.delete_cookie(FLASH_COOKIE, path="/")
    return response
