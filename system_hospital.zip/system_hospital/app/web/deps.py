"""Web Cookie 身份认证、权限与轻量 Flash 支持。"""

import base64
import json
from collections.abc import Callable
from typing import Annotated, Any

from fastapi import Depends, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from app.api.deps import DatabaseSession, resolve_current_user
from app.core.exceptions import AppException, PermissionDeniedError
from app.models.user import User
from app.repositories.user_repository import UserRepository
from app.web.display_helpers import role_label

ACCESS_TOKEN_COOKIE = "access_token"
FLASH_COOKIE = "web_flash"


class WebAuthenticationRequired(Exception):
    """Web 页面未认证时交由异常处理器重定向登录页。"""


def _set_identity_context(request: Request, user: User, db: Session) -> None:
    repository = UserRepository(db)
    roles = repository.get_role_codes(user.id)
    permissions = repository.get_permission_codes(user.id)
    role_order = (
        "ADMIN",
        "DOCTOR",
        "LAB_TECHNICIAN",
    )
    primary_role = next((item for item in role_order if item in roles), None)
    request.state.web_context = {
        "current_user": user,
        "roles": roles,
        "permissions": permissions,
        "primary_role": role_label(primary_role),
    }


def get_optional_web_user(
    request: Request,
    db: DatabaseSession,
) -> User | None:
    token = request.cookies.get(ACCESS_TOKEN_COOKIE)
    if not token:
        return None
    try:
        user = resolve_current_user(token, db)
    except AppException:
        return None
    _set_identity_context(request, user, db)
    return user


def get_current_web_user(
    request: Request,
    db: DatabaseSession,
) -> User:
    user = get_optional_web_user(request, db)
    if user is None:
        raise WebAuthenticationRequired
    return user


CurrentWebUser = Annotated[User, Depends(get_current_web_user)]
OptionalWebUser = Annotated[User | None, Depends(get_optional_web_user)]


def require_web_permission(permission_code: str) -> Callable[..., User]:
    """Web 页面权限依赖；菜单隐藏之外仍在服务端执行 RBAC。"""

    def permission_dependency(
        request: Request,
        current_user: CurrentWebUser,
        db: DatabaseSession,
    ) -> User:
        permissions = UserRepository(db).get_permission_codes(current_user.id)
        if permission_code not in permissions:
            raise PermissionDeniedError("您没有权限访问该页面")
        request.state.web_context["permissions"] = permissions
        return current_user

    return permission_dependency


def require_web_any_permission(*permission_codes: str) -> Callable[..., User]:
    """至少拥有一项指定权限才允许访问 Web 页面。"""
    expected = set(permission_codes)

    def permission_dependency(
        request: Request,
        current_user: CurrentWebUser,
        db: DatabaseSession,
    ) -> User:
        permissions = UserRepository(db).get_permission_codes(current_user.id)
        if not permissions.intersection(expected):
            raise PermissionDeniedError("您没有权限访问该页面")
        request.state.web_context["permissions"] = permissions
        return current_user

    return permission_dependency


def encode_flash(message: str, category: str = "success") -> str:
    payload = json.dumps(
        {"message": message, "category": category},
        ensure_ascii=False,
    ).encode("utf-8")
    return base64.urlsafe_b64encode(payload).decode("ascii")


def read_flash(request: Request) -> dict[str, Any] | None:
    raw = request.cookies.get(FLASH_COOKIE)
    if not raw:
        return None
    try:
        value = json.loads(base64.urlsafe_b64decode(raw).decode("utf-8"))
    except (ValueError, UnicodeDecodeError, json.JSONDecodeError):
        return None
    if not isinstance(value, dict) or not isinstance(value.get("message"), str):
        return None
    return value


def redirect_with_flash(
    url: str,
    message: str,
    *,
    category: str = "success",
    status_code: int = 303,
) -> RedirectResponse:
    """创建携带一次性提示的站内重定向。"""
    from app.core.config import get_settings

    response = RedirectResponse(url, status_code=status_code)
    response.set_cookie(
        FLASH_COOKIE,
        encode_flash(message, category),
        max_age=30,
        httponly=True,
        secure=get_settings().web_cookie_secure,
        samesite="lax",
        path="/",
    )
    return response
