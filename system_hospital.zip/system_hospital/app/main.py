"""FastAPI 应用入口。"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.api.routes.admin import router as admin_router
from app.api.routes.auth import router as auth_router
from app.api.routes.attachments import router as attachments_router
from app.api.routes.diagnoses import router as diagnoses_router
from app.api.routes.encounters import patient_history_router
from app.api.routes.encounters import router as encounters_router
from app.api.routes.examinations import router as examinations_router
from app.api.routes.health import router as health_router
from app.api.routes.lab_reports import router as lab_reports_router
from app.api.routes.medical_records import encounter_record_router
from app.api.routes.medical_records import router as medical_records_router
from app.api.routes.medical_orders import router as medical_orders_router
from app.api.routes.patients import router as patients_router
from app.api.routes.prescriptions import router as prescriptions_router
from app.api.routes.statistics import router as statistics_router
from app.core.config import get_settings
from app.core.exceptions import register_exception_handlers
from app.web.routes.auth import router as web_auth_router
from app.web.routes.attachments import router as web_attachments_router
from app.web.routes.admin import router as web_admin_router
from app.web.routes.audit_logs import router as web_audit_logs_router
from app.web.routes.clinical_records import router as web_clinical_records_router
from app.web.routes.dashboard import router as web_dashboard_router
from app.web.routes.encounters import router as web_encounters_router
from app.web.routes.examinations import router as web_examinations_router
from app.web.routes.labs import router as web_labs_router
from app.web.routes.medical_records import router as web_medical_records_router
from app.web.routes.patients import router as web_patients_router
from app.web.routes.record_management import router as web_record_management_router
from app.web.routes.statistics import router as web_statistics_router
from app.web.templating import STATIC_DIR


def create_app() -> FastAPI:
    """创建并配置 FastAPI 应用。"""
    settings = get_settings()
    application = FastAPI(
        title=settings.app_name,
        version="0.1.0",
        debug=settings.debug,
    )

    application.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    register_exception_handlers(application)
    application.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
    application.include_router(web_auth_router)
    application.include_router(web_patients_router)
    application.include_router(web_encounters_router)
    application.include_router(web_medical_records_router)
    application.include_router(web_clinical_records_router)
    application.include_router(web_labs_router)
    application.include_router(web_examinations_router)
    application.include_router(web_attachments_router)
    application.include_router(web_record_management_router)
    application.include_router(web_statistics_router)
    application.include_router(web_admin_router)
    application.include_router(web_audit_logs_router)
    application.include_router(web_dashboard_router)
    application.include_router(health_router)
    application.include_router(auth_router)
    application.include_router(admin_router)
    application.include_router(patients_router)
    application.include_router(encounters_router)
    application.include_router(patient_history_router)
    application.include_router(medical_records_router)
    application.include_router(encounter_record_router)
    application.include_router(diagnoses_router)
    application.include_router(medical_orders_router)
    application.include_router(prescriptions_router)
    application.include_router(lab_reports_router)
    application.include_router(examinations_router)
    application.include_router(attachments_router)
    application.include_router(statistics_router)
    return application


app = create_app()
