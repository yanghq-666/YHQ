"""集中式应用配置。"""

from functools import lru_cache
from typing import Literal

from pydantic import AliasChoices, Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """从环境变量或项目根目录的 .env 文件读取配置。"""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    app_name: str = "医院病历管理系统"
    app_env: str = "development"
    # 使用 APP_DEBUG，避免读取某些开发环境预设的通用 DEBUG 变量。
    debug: bool = Field(default=False, validation_alias="APP_DEBUG")
    secret_key: SecretStr = Field(
        min_length=32,
        validation_alias=AliasChoices("JWT_SECRET_KEY", "SECRET_KEY"),
    )
    database_url: str
    jwt_algorithm: Literal["HS256"] = "HS256"
    access_token_expire_minutes: int = Field(default=30, gt=0, le=1440)
    web_cookie_secure: bool = False
    cors_origins: list[str] = [
        "http://localhost:8000",
        "http://127.0.0.1:8000",
    ]
    admin_username: str = Field(
        default="admin",
        validation_alias=AliasChoices(
            "INITIAL_ADMIN_USERNAME", "ADMIN_USERNAME"
        ),
    )
    admin_password: SecretStr | None = Field(
        default=None,
        validation_alias=AliasChoices(
            "INITIAL_ADMIN_PASSWORD", "ADMIN_PASSWORD"
        ),
    )
    admin_real_name: str = Field(
        default="系统管理员",
        validation_alias=AliasChoices(
            "INITIAL_ADMIN_REAL_NAME", "ADMIN_FULL_NAME"
        ),
    )
    demo_account_password: SecretStr | None = Field(
        default=None,
        min_length=8,
        max_length=72,
        validation_alias="DEMO_ACCOUNT_PASSWORD",
    )
    storage_provider: Literal["local", "minio"] = "local"
    local_storage_path: str = "./storage"
    max_upload_size_mb: int = Field(default=20, gt=0, le=1024)
    minio_endpoint: str | None = None
    minio_access_key: SecretStr | None = None
    minio_secret_key: SecretStr | None = None
    minio_bucket: str | None = None
    minio_secure: bool = False


@lru_cache
def get_settings() -> Settings:
    """返回进程级配置单例，避免重复解析环境变量。"""
    return Settings()  # type: ignore[call-arg]
