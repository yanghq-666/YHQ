"""敏感数据脱敏工具。"""


def mask_id_card(value: str | None) -> str | None:
    if not value:
        return value
    if len(value) >= 10:
        return f"{value[:6]}{'*' * (len(value) - 10)}{value[-4:]}"
    if len(value) <= 2:
        return "*" * len(value)
    return f"{value[0]}{'*' * (len(value) - 2)}{value[-1]}"


def mask_phone(value: str | None) -> str | None:
    if not value:
        return value
    if len(value) >= 7:
        return f"{value[:3]}{'*' * (len(value) - 7)}{value[-4:]}"
    return f"{value[0]}{'*' * (len(value) - 2)}{value[-1]}"

