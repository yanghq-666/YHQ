"""密码哈希和 JWT 工具。"""

from datetime import datetime, timedelta, timezone
from typing import Any

import bcrypt
import jwt
from jwt import InvalidTokenError

from app.core.config import Settings, get_settings
from app.core.exceptions import AuthenticationError


def hash_password(password: str) -> str:
    """使用 bcrypt 生成不可逆密码哈希。"""
    password_bytes = password.encode("utf-8")
    if len(password_bytes) < 8:
        raise ValueError("密码至少需要 8 个字节")
    if len(password_bytes) > 72:
        raise ValueError("密码不能超过 72 个字节")
    return bcrypt.hashpw(password_bytes, bcrypt.gensalt()).decode("utf-8")


def verify_password(password: str, password_hash: str) -> bool:
    """常量时间验证明文密码与 bcrypt 哈希。"""
    try:
        return bcrypt.checkpw(
            password.encode("utf-8"), password_hash.encode("utf-8")
        )
    except (TypeError, ValueError):
        return False


def create_access_token(
    subject: int,
    username: str,
    *,
    settings: Settings | None = None,
    expires_delta: timedelta | None = None,
) -> str:
    """签发只包含必要身份信息的短期访问令牌。"""
    resolved_settings = settings or get_settings()
    now = datetime.now(timezone.utc)
    expires_at = now + (
        expires_delta
        or timedelta(minutes=resolved_settings.access_token_expire_minutes)
    )
    payload = {
        "sub": str(subject),
        "username": username,
        "iat": now,
        "exp": expires_at,
        "token_type": "access",
    }
    return jwt.encode(
        payload,
        resolved_settings.secret_key.get_secret_value(),
        algorithm=resolved_settings.jwt_algorithm,
    )


def decode_access_token(
    token: str, *, settings: Settings | None = None
) -> dict[str, Any]:
    """验证令牌签名、有效期和类型。"""
    resolved_settings = settings or get_settings()
    try:
        payload = jwt.decode(
            token,
            resolved_settings.secret_key.get_secret_value(),
            algorithms=[resolved_settings.jwt_algorithm],
            options={"require": ["sub", "exp", "iat", "token_type"]},
        )
    except InvalidTokenError as exc:
        raise AuthenticationError("登录凭证无效或已过期") from exc

    if payload.get("token_type") != "access":
        raise AuthenticationError("登录凭证类型无效")
    return payload
