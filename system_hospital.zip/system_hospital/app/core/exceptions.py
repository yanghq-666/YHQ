"""应用异常与统一 JSON 错误响应。"""

from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.responses import Response
from starlette.exceptions import HTTPException as StarletteHTTPException


class AppException(Exception):
    """可安全返回给客户端的业务异常。"""

    def __init__(
        self, status_code: int, message: str, data: Any = None
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.message = message
        self.data = data


class AuthenticationError(AppException):
    def __init__(self, message: str = "身份认证失败") -> None:
        super().__init__(401, message)


class PermissionDeniedError(AppException):
    def __init__(self, message: str = "无权执行此操作") -> None:
        super().__init__(403, message)


class ResourceNotFoundError(AppException):
    def __init__(self, message: str = "资源不存在") -> None:
        super().__init__(404, message)


class ValidationError(AppException):
    def __init__(self, message: str = "请求参数不合法") -> None:
        super().__init__(400, message)


class ConflictError(AppException):
    def __init__(self, message: str = "资源已存在") -> None:
        super().__init__(409, message)


class PayloadTooLargeError(AppException):
    def __init__(self, message: str = "上传文件过大") -> None:
        super().__init__(413, message)


class PatientNotFoundError(ResourceNotFoundError):
    def __init__(self) -> None:
        super().__init__("患者不存在")


class DuplicatePatientError(ConflictError):
    def __init__(self) -> None:
        super().__init__("该身份证号已存在患者档案")


class InvalidPatientDataError(ValidationError):
    pass


class EncounterNotFoundError(ResourceNotFoundError):
    def __init__(self) -> None:
        super().__init__("就诊不存在")


class InvalidEncounterDataError(ValidationError):
    pass


class InvalidEncounterStateError(ConflictError):
    pass


class MedicalRecordNotFoundError(ResourceNotFoundError):
    def __init__(self) -> None:
        super().__init__("病历不存在")


class InvalidMedicalRecordStateError(ConflictError):
    pass


class MedicalRecordIncompleteError(AppException):
    def __init__(self, missing_fields: list[str]) -> None:
        super().__init__(
            422,
            "病历信息不完整",
            data={"missing_fields": missing_fields},
        )


def _error_body(code: int, message: str, data: Any = None) -> dict[str, Any]:
    return {
        "success": False,
        "code": code,
        "message": message,
        "data": data,
    }


def register_exception_handlers(app: FastAPI) -> None:
    """注册全局异常处理，避免不同接口返回不同错误结构。"""

    @app.exception_handler(AppException)
    async def handle_app_exception(
        request: Request, exc: AppException
    ) -> Response:
        if not request.url.path.startswith("/api/"):
            return _web_error_response(
                request, exc.status_code, message=exc.message
            )
        return JSONResponse(
            status_code=exc.status_code,
            content=_error_body(exc.status_code, exc.message, exc.data),
        )

    @app.exception_handler(RequestValidationError)
    async def handle_validation_exception(
        request: Request, exc: RequestValidationError
    ) -> Response:
        if not request.url.path.startswith("/api/"):
            return _web_error_response(
                request, 422, message="页面参数校验失败"
            )
        return JSONResponse(
            status_code=422,
            content=_error_body(
                422, "参数校验失败", jsonable_encoder(exc.errors())
            ),
        )

    @app.exception_handler(StarletteHTTPException)
    @app.exception_handler(HTTPException)
    async def handle_http_exception(
        request: Request, exc: HTTPException
    ) -> Response:
        if not request.url.path.startswith("/api/"):
            message = exc.detail if isinstance(exc.detail, str) else None
            return _web_error_response(
                request, exc.status_code, message=message
            )
        message = exc.detail if isinstance(exc.detail, str) else "请求失败"
        return JSONResponse(
            status_code=exc.status_code,
            content=_error_body(exc.status_code, message),
        )

    from app.web.deps import WebAuthenticationRequired

    @app.exception_handler(WebAuthenticationRequired)
    async def handle_web_authentication_required(
        _request: Request, _exc: WebAuthenticationRequired
    ) -> Response:
        from fastapi.responses import RedirectResponse

        return RedirectResponse("/login", status_code=303)

    @app.exception_handler(Exception)
    async def handle_unexpected_exception(
        request: Request, _exc: Exception
    ) -> Response:
        if not request.url.path.startswith("/api/"):
            return _web_error_response(request, 500)
        return JSONResponse(
            status_code=500,
            content=_error_body(500, "服务器内部错误"),
        )


def _web_error_response(
    request: Request,
    status_code: int,
    *,
    message: str | None = None,
) -> Response:
    """为浏览器页面隐藏内部错误细节，API 仍使用统一 JSON。"""
    from app.web.templating import template_context, templates

    known_status = status_code if status_code in {400, 403, 404, 409, 422, 500} else 500
    return templates.TemplateResponse(
        request,
        (
            f"errors/{known_status}.html"
            if known_status in {403, 404, 500}
            else "errors/operation.html"
        ),
        template_context(
            request,
            status_code=known_status,
            error_message=message,
        ),
        status_code=status_code,
    )
