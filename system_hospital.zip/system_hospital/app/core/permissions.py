"""后端 RBAC 权限依赖。"""

from collections.abc import Callable
from typing import Annotated

from fastapi import Depends
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.core.database import get_db
from app.core.exceptions import PermissionDeniedError
from app.models.user import User
from app.repositories.user_repository import UserRepository


def require_permissions(*required_codes: str) -> Callable[..., User]:
    """创建权限依赖；接口必须满足全部权限才允许访问。"""
    required = frozenset(required_codes)

    def permission_dependency(
        current_user: Annotated[User, Depends(get_current_user)],
        db: Annotated[Session, Depends(get_db)],
    ) -> User:
        granted = UserRepository(db).get_permission_codes(current_user.id)
        missing = required - granted
        if missing:
            raise PermissionDeniedError(
                f"缺少权限：{', '.join(sorted(missing))}"
            )
        return current_user

    return permission_dependency


def require_permission(required_code: str) -> Callable[..., User]:
    """单权限接口的便捷写法。"""
    return require_permissions(required_code)
