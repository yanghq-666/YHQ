"""用户与授权信息的数据访问。"""

from sqlalchemy import delete, select
from sqlalchemy.orm import Session, selectinload

from app.models.permission import Permission, RolePermission
from app.models.role import Role
from app.models.user import User, UserRole


class UserRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def get_by_username(self, username: str) -> User | None:
        statement = (
            select(User)
            .options(selectinload(User.department))
            .where(User.username == username, User.deleted_at.is_(None))
        )
        return self.db.scalar(statement)

    def get_any_by_username(self, username: str) -> User | None:
        return self.db.scalar(select(User).where(User.username == username))

    def get_any_by_employee_no(self, employee_no: str) -> User | None:
        return self.db.scalar(
            select(User).where(User.employee_no == employee_no)
        )

    def get_by_id(self, user_id: int) -> User | None:
        statement = (
            select(User)
            .options(selectinload(User.department))
            .where(User.id == user_id, User.deleted_at.is_(None))
        )
        return self.db.scalar(statement)

    def list_users(self, *, offset: int = 0, limit: int = 100) -> list[User]:
        statement = (
            select(User)
            .options(selectinload(User.department))
            .where(User.deleted_at.is_(None))
            .order_by(User.id)
            .offset(offset)
            .limit(limit)
        )
        return list(self.db.scalars(statement).all())

    def get_role_codes(self, user_id: int) -> set[str]:
        statement = (
            select(Role.code)
            .join(UserRole, UserRole.role_id == Role.id)
            .where(UserRole.user_id == user_id)
        )
        return set(self.db.scalars(statement).all())

    def replace_roles(self, user_id: int, role_ids: set[int]) -> None:
        self.db.execute(delete(UserRole).where(UserRole.user_id == user_id))
        self.db.add_all(
            UserRole(user_id=user_id, role_id=role_id)
            for role_id in sorted(role_ids)
        )

    def get_permission_codes(self, user_id: int) -> set[str]:
        statement = (
            select(Permission.code)
            .join(
                RolePermission,
                RolePermission.permission_id == Permission.id,
            )
            .join(UserRole, UserRole.role_id == RolePermission.role_id)
            .where(UserRole.user_id == user_id)
            .distinct()
        )
        return set(self.db.scalars(statement).all())
