"""诊断数据访问。"""

from datetime import datetime

from sqlalchemy import select, update
from sqlalchemy.orm import Session, joinedload

from app.models.diagnosis import Diagnosis
from app.models.enums import DiagnosisType
from app.models.medical_record import MedicalRecord


class DiagnosisRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create(self, diagnosis: Diagnosis) -> Diagnosis:
        self.db.add(diagnosis)
        self.db.flush()
        return diagnosis

    def get_by_id(self, diagnosis_id: int) -> Diagnosis | None:
        return self.db.scalar(
            select(Diagnosis)
            .options(
                joinedload(Diagnosis.record).joinedload(
                    MedicalRecord.encounter
                )
            )
            .where(
                Diagnosis.id == diagnosis_id,
                Diagnosis.deleted_at.is_(None),
            )
        )

    def list_by_record(self, record_id: int) -> list[Diagnosis]:
        statement = (
            select(Diagnosis)
            .where(
                Diagnosis.record_id == record_id,
                Diagnosis.deleted_at.is_(None),
            )
            .order_by(
                Diagnosis.is_primary.desc(),
                Diagnosis.sort_order.asc(),
                Diagnosis.created_at.asc(),
                Diagnosis.id.asc(),
            )
        )
        return list(self.db.scalars(statement).all())

    def clear_primary(
        self,
        *,
        record_id: int,
        diagnosis_type: DiagnosisType,
        exclude_id: int | None = None,
    ) -> list[int]:
        existing = select(Diagnosis.id).where(
            Diagnosis.record_id == record_id,
            Diagnosis.diagnosis_type == diagnosis_type,
            Diagnosis.is_primary.is_(True),
            Diagnosis.deleted_at.is_(None),
        )
        if exclude_id is not None:
            existing = existing.where(Diagnosis.id != exclude_id)
        ids = list(self.db.scalars(existing).all())
        if ids:
            self.db.execute(
                update(Diagnosis)
                .where(Diagnosis.id.in_(ids))
                .values(is_primary=False)
            )
        return ids

    def update(self, diagnosis: Diagnosis) -> Diagnosis:
        self.db.flush()
        return diagnosis

    def soft_delete(self, diagnosis: Diagnosis, deleted_at: datetime) -> None:
        diagnosis.deleted_at = deleted_at
        self.db.flush()

    def has_any(self, record_id: int) -> bool:
        return self.db.scalar(
            select(Diagnosis.id).where(
                Diagnosis.record_id == record_id,
                Diagnosis.deleted_at.is_(None),
            ).limit(1)
        ) is not None

    def has_primary(self, record_id: int) -> bool:
        return self.db.scalar(
            select(Diagnosis.id).where(
                Diagnosis.record_id == record_id,
                Diagnosis.is_primary.is_(True),
                Diagnosis.deleted_at.is_(None),
            ).limit(1)
        ) is not None
