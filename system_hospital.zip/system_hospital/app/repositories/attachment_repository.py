"""附件元数据访问。"""

from datetime import datetime

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.attachment import Attachment


class AttachmentRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create(self, attachment: Attachment) -> Attachment:
        self.db.add(attachment)
        self.db.flush()
        return attachment

    def get_by_id(self, attachment_id: int) -> Attachment | None:
        return self.db.scalar(select(Attachment).where(Attachment.id == attachment_id, Attachment.deleted_at.is_(None)))

    def list_by_record(self, record_id: int) -> list[Attachment]:
        return list(self.db.scalars(select(Attachment).where(Attachment.record_id == record_id, Attachment.deleted_at.is_(None)).order_by(Attachment.created_at, Attachment.id)).all())

    def soft_delete(self, attachment: Attachment, deleted_at: datetime) -> None:
        attachment.deleted_at = deleted_at
        self.db.flush()
