"""处方和处方项目数据访问。"""

from datetime import datetime

from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload, selectinload

from app.models.medical_record import MedicalRecord
from app.models.prescription import Prescription, PrescriptionItem


class PrescriptionRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create(self, prescription: Prescription) -> Prescription:
        self.db.add(prescription)
        self.db.flush()
        return prescription

    def get_by_id(self, prescription_id: int) -> Prescription | None:
        return self.db.scalar(
            select(Prescription)
            .options(
                selectinload(Prescription.items),
                joinedload(Prescription.record).joinedload(
                    MedicalRecord.encounter
                ),
            )
            .where(
                Prescription.id == prescription_id,
                Prescription.deleted_at.is_(None),
            )
        )

    def list_by_record(self, record_id: int) -> list[Prescription]:
        statement = (
            select(Prescription)
            .options(selectinload(Prescription.items))
            .where(
                Prescription.record_id == record_id,
                Prescription.deleted_at.is_(None),
            )
            .order_by(Prescription.created_at.desc(), Prescription.id.desc())
        )
        return list(self.db.scalars(statement).all())

    def update(self, prescription: Prescription) -> Prescription:
        self.db.flush()
        return prescription


class PrescriptionItemRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create(self, item: PrescriptionItem) -> PrescriptionItem:
        self.db.add(item)
        self.db.flush()
        return item

    def get_by_id(self, item_id: int) -> PrescriptionItem | None:
        return self.db.scalar(
            select(PrescriptionItem)
            .options(
                joinedload(PrescriptionItem.prescription)
                .joinedload(Prescription.record)
                .joinedload(MedicalRecord.encounter)
            )
            .where(
                PrescriptionItem.id == item_id,
                PrescriptionItem.deleted_at.is_(None),
            )
        )

    def list_by_prescription(self, prescription_id: int) -> list[PrescriptionItem]:
        statement = (
            select(PrescriptionItem)
            .where(
                PrescriptionItem.prescription_id == prescription_id,
                PrescriptionItem.deleted_at.is_(None),
            )
            .order_by(PrescriptionItem.sort_order, PrescriptionItem.id)
        )
        return list(self.db.scalars(statement).all())

    def update(self, item: PrescriptionItem) -> PrescriptionItem:
        self.db.flush()
        return item

    def soft_delete(self, item: PrescriptionItem, deleted_at: datetime) -> None:
        item.deleted_at = deleted_at
        self.db.flush()
