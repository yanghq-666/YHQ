"""只读审计日志检索。"""

from datetime import datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.models.audit_log import AuditLog
from app.models.user import User
from app.schemas.audit_log import AuditLogSearchParams

LOCAL_TIMEZONE = ZoneInfo("Asia/Shanghai")


class AuditLogRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def search(self, params: AuditLogSearchParams):
        filters = []
        if params.user:
            pattern = f"%{self._escape_like(params.user.strip())}%"
            filters.append(
                or_(
                    User.username.ilike(pattern, escape="\\"),
                    User.real_name.ilike(pattern, escape="\\"),
                )
            )
        if params.action:
            filters.append(
                AuditLog.action.ilike(
                    f"%{self._escape_like(params.action.strip())}%",
                    escape="\\",
                )
            )
        if params.start_date:
            filters.append(AuditLog.created_at >= self._day_start(params.start_date))
        if params.end_date:
            filters.append(
                AuditLog.created_at
                < self._day_start(params.end_date + timedelta(days=1))
            )
        base = select(AuditLog, User).outerjoin(User, User.id == AuditLog.user_id).where(*filters)
        total = self.db.scalar(
            select(func.count()).select_from(base.subquery())
        ) or 0
        rows = self.db.execute(
            base.order_by(AuditLog.created_at.desc(), AuditLog.id.desc())
            .offset((params.page - 1) * params.page_size)
            .limit(params.page_size)
        ).all()
        return rows, total

    @staticmethod
    def _escape_like(value: str) -> str:
        return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")

    @staticmethod
    def _day_start(value) -> datetime:
        local = datetime.combine(value, time.min, tzinfo=LOCAL_TIMEZONE)
        return local.astimezone(timezone.utc)
