"""医嘱数据访问。"""

from datetime import datetime

from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload

from app.models.enums import MedicalOrderStatus, MedicalOrderType
from app.models.medical_order import MedicalOrder
from app.models.medical_record import MedicalRecord


class MedicalOrderRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create(self, order: MedicalOrder) -> MedicalOrder:
        self.db.add(order)
        self.db.flush()
        return order

    def get_by_id(self, order_id: int) -> MedicalOrder | None:
        return self.db.scalar(
            select(MedicalOrder)
            .options(
                joinedload(MedicalOrder.record).joinedload(
                    MedicalRecord.encounter
                )
            )
            .where(
                MedicalOrder.id == order_id,
                MedicalOrder.deleted_at.is_(None),
            )
        )

    def list_by_record(
        self,
        record_id: int,
        *,
        order_type: MedicalOrderType | None = None,
        status: MedicalOrderStatus | None = None,
    ) -> list[MedicalOrder]:
        filters = [
            MedicalOrder.record_id == record_id,
            MedicalOrder.deleted_at.is_(None),
        ]
        if order_type is not None:
            filters.append(MedicalOrder.order_type == order_type)
        if status is not None:
            filters.append(MedicalOrder.status == status)
        statement = (
            select(MedicalOrder)
            .where(*filters)
            .order_by(MedicalOrder.created_at.desc(), MedicalOrder.id.desc())
        )
        return list(self.db.scalars(statement).all())

    def update(self, order: MedicalOrder) -> MedicalOrder:
        self.db.flush()
        return order

    def soft_delete(self, order: MedicalOrder, deleted_at: datetime) -> None:
        order.deleted_at = deleted_at
        self.db.flush()
