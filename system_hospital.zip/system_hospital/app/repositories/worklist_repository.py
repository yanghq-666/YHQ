"""检验、检查和附件跨病历工作列表查询。"""

from datetime import datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session, aliased

from app.models.attachment import Attachment
from app.models.encounter import Encounter
from app.models.examination import Examination
from app.models.lab_report import LabReport
from app.models.medical_record import MedicalRecord
from app.models.patient import Patient
from app.models.user import User
from app.schemas.worklist import (
    AttachmentWorklistParams,
    ExaminationWorklistParams,
    LabWorklistParams,
)

LOCAL_TIMEZONE = ZoneInfo("Asia/Shanghai")


class WorklistRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def list_labs(self, params: LabWorklistParams, *, access_filter):
        requester = aliased(User)
        filters = [
            LabReport.deleted_at.is_(None),
            MedicalRecord.deleted_at.is_(None),
            Encounter.deleted_at.is_(None),
            access_filter,
        ]
        if params.keyword:
            pattern = self._pattern(params.keyword)
            filters.append(
                or_(
                    LabReport.report_no.ilike(pattern, escape="\\"),
                    LabReport.report_name.ilike(pattern, escape="\\"),
                    Patient.name.ilike(pattern, escape="\\"),
                    Patient.patient_no.ilike(pattern, escape="\\"),
                    Encounter.encounter_no.ilike(pattern, escape="\\"),
                )
            )
        if params.status:
            filters.append(LabReport.status == params.status)
        self._date_filters(filters, LabReport.created_at, params)
        base = (
            select(LabReport, Patient, Encounter, MedicalRecord, requester)
            .join(Patient, Patient.id == LabReport.patient_id)
            .join(Encounter, Encounter.id == LabReport.encounter_id)
            .join(MedicalRecord, MedicalRecord.id == LabReport.record_id)
            .join(requester, requester.id == LabReport.requested_by)
            .where(*filters)
        )
        return self._page(base, LabReport.created_at, LabReport.id, params)

    def list_examinations(
        self, params: ExaminationWorklistParams, *, access_filter
    ):
        requester = aliased(User)
        filters = [
            Examination.deleted_at.is_(None),
            MedicalRecord.deleted_at.is_(None),
            Encounter.deleted_at.is_(None),
            access_filter,
        ]
        if params.keyword:
            pattern = self._pattern(params.keyword)
            filters.append(
                or_(
                    Examination.examination_no.ilike(pattern, escape="\\"),
                    Examination.examination_name.ilike(pattern, escape="\\"),
                    Patient.name.ilike(pattern, escape="\\"),
                    Patient.patient_no.ilike(pattern, escape="\\"),
                    Encounter.encounter_no.ilike(pattern, escape="\\"),
                )
            )
        if params.status:
            filters.append(Examination.status == params.status)
        if params.examination_type:
            filters.append(Examination.examination_type == params.examination_type)
        self._date_filters(filters, Examination.created_at, params)
        base = (
            select(Examination, Patient, Encounter, MedicalRecord, requester)
            .join(Patient, Patient.id == Examination.patient_id)
            .join(Encounter, Encounter.id == Examination.encounter_id)
            .join(MedicalRecord, MedicalRecord.id == Examination.record_id)
            .join(requester, requester.id == Examination.requested_by)
            .where(*filters)
        )
        return self._page(base, Examination.created_at, Examination.id, params)

    def list_attachments(
        self, params: AttachmentWorklistParams, *, access_filter
    ):
        uploader = aliased(User)
        filters = [
            Attachment.deleted_at.is_(None),
            MedicalRecord.deleted_at.is_(None),
            Encounter.deleted_at.is_(None),
            access_filter,
        ]
        if params.keyword:
            pattern = self._pattern(params.keyword)
            filters.append(
                or_(
                    Attachment.original_name.ilike(pattern, escape="\\"),
                    Patient.name.ilike(pattern, escape="\\"),
                    Patient.patient_no.ilike(pattern, escape="\\"),
                    Encounter.encounter_no.ilike(pattern, escape="\\"),
                    MedicalRecord.record_no.ilike(pattern, escape="\\"),
                )
            )
        if params.category:
            filters.append(Attachment.category == params.category)
        self._date_filters(filters, Attachment.created_at, params)
        base = (
            select(Attachment, Patient, Encounter, MedicalRecord, uploader)
            .join(Patient, Patient.id == Attachment.patient_id)
            .join(Encounter, Encounter.id == Attachment.encounter_id)
            .join(MedicalRecord, MedicalRecord.id == Attachment.record_id)
            .join(uploader, uploader.id == Attachment.uploaded_by)
            .where(*filters)
        )
        return self._page(base, Attachment.created_at, Attachment.id, params)

    def _page(self, base, created_column, id_column, params):
        total = self.db.scalar(
            select(func.count()).select_from(base.subquery())
        ) or 0
        rows = self.db.execute(
            base.order_by(created_column.desc(), id_column.desc())
            .offset((params.page - 1) * params.page_size)
            .limit(params.page_size)
        ).all()
        return rows, total

    @classmethod
    def _date_filters(cls, filters, column, params) -> None:
        if params.start_date:
            filters.append(column >= cls._day_start(params.start_date))
        if params.end_date:
            filters.append(
                column < cls._day_start(params.end_date + timedelta(days=1))
            )

    @classmethod
    def _pattern(cls, value: str) -> str:
        escaped = value.strip().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        return f"%{escaped}%"

    @staticmethod
    def _day_start(value) -> datetime:
        local = datetime.combine(value, time.min, tzinfo=LOCAL_TIMEZONE)
        return local.astimezone(timezone.utc)
