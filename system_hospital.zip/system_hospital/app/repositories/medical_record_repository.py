"""病历、版本快照和每日流水的数据访问。"""

from __future__ import annotations

from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

from sqlalchemy import ColumnElement, func, or_, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, joinedload

from app.models.encounter import Encounter
from app.models.department import Department
from app.models.medical_record import (
    MedicalRecord,
    MedicalRecordSequence,
    MedicalRecordVersion,
)
from app.models.patient import Patient
from app.models.user import User
from app.models.enums import MedicalRecordStatus
from app.schemas.medical_record import (
    MedicalRecordSearchParams,
    MyMedicalRecordSearchParams,
)

LOCAL_TIMEZONE = ZoneInfo("Asia/Shanghai")
SearchParams = MedicalRecordSearchParams | MyMedicalRecordSearchParams


class MedicalRecordRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create(self, record: MedicalRecord) -> MedicalRecord:
        self.db.add(record)
        self.db.flush()
        return record

    def get_by_id(
        self, record_id: int, *, include_deleted: bool = False
    ) -> MedicalRecord | None:
        statement = self._detail_statement().where(MedicalRecord.id == record_id)
        if not include_deleted:
            statement = statement.where(MedicalRecord.deleted_at.is_(None))
        return self.db.scalar(statement)

    def get_by_encounter_id(
        self, encounter_id: int, *, include_deleted: bool = False
    ) -> MedicalRecord | None:
        statement = self._detail_statement().where(
            MedicalRecord.encounter_id == encounter_id
        )
        if not include_deleted:
            statement = statement.where(MedicalRecord.deleted_at.is_(None))
        return self.db.scalar(statement)

    def get_by_record_no(self, record_no: str) -> MedicalRecord | None:
        return self.db.scalar(
            self._detail_statement().where(
                MedicalRecord.record_no == record_no,
                MedicalRecord.deleted_at.is_(None),
            )
        )

    def list(
        self,
        params: SearchParams,
        *,
        access_filter: ColumnElement[bool],
        mine_user_id: int | None = None,
    ) -> tuple[list[MedicalRecord], int]:
        filters = self._build_filters(params)
        filters.append(access_filter)
        if mine_user_id is not None:
            filters.append(
                or_(
                    MedicalRecord.created_by == mine_user_id,
                    Encounter.doctor_id == mine_user_id,
                )
            )
        base = (
            select(MedicalRecord)
            .join(MedicalRecord.encounter)
            .join(Encounter.patient)
            .where(*filters)
        )
        total = self.db.scalar(
            select(func.count()).select_from(base.subquery())
        ) or 0
        statement = (
            base.options(*self._detail_options())
            .order_by(
                MedicalRecord.updated_at.desc(),
                MedicalRecord.created_at.desc(),
                MedicalRecord.id.desc(),
            )
            .offset((params.page - 1) * params.page_size)
            .limit(params.page_size)
        )
        return list(self.db.scalars(statement).unique().all()), total

    def search(
        self,
        params: MedicalRecordSearchParams,
        *,
        access_filter: ColumnElement[bool],
    ) -> tuple[list[MedicalRecord], int]:
        return self.list(params, access_filter=access_filter)

    def list_by_doctor(
        self,
        params: MyMedicalRecordSearchParams,
        *,
        user_id: int,
        access_filter: ColumnElement[bool],
    ) -> tuple[list[MedicalRecord], int]:
        return self.list(
            params,
            access_filter=access_filter,
            mine_user_id=user_id,
        )

    def update(self, record: MedicalRecord) -> MedicalRecord:
        self.db.flush()
        return record

    def conditional_start_review(
        self, record_id: int, reviewer_id: int
    ) -> bool:
        result = self.db.execute(
            update(MedicalRecord)
            .where(
                MedicalRecord.id == record_id,
                MedicalRecord.status == MedicalRecordStatus.SUBMITTED,
                MedicalRecord.current_reviewer_id.is_(None),
                MedicalRecord.deleted_at.is_(None),
            )
            .values(
                status=MedicalRecordStatus.REVIEWING,
                current_reviewer_id=reviewer_id,
            )
            .execution_options(synchronize_session="fetch")
        )
        return result.rowcount == 1

    def conditional_review_decision(
        self,
        record_id: int,
        reviewer_id: int,
        *,
        to_status: MedicalRecordStatus,
        reviewed_at: datetime | None = None,
        approved_version: int | None = None,
    ) -> bool:
        values: dict[str, object] = {
            "status": to_status,
            "current_reviewer_id": None,
        }
        if to_status == MedicalRecordStatus.APPROVED:
            values.update(
                reviewed_by=reviewer_id,
                reviewed_at=reviewed_at,
                approved_version=approved_version,
            )
        result = self.db.execute(
            update(MedicalRecord)
            .where(
                MedicalRecord.id == record_id,
                MedicalRecord.status == MedicalRecordStatus.REVIEWING,
                MedicalRecord.current_reviewer_id == reviewer_id,
                MedicalRecord.deleted_at.is_(None),
            )
            .values(**values)
            .execution_options(synchronize_session="fetch")
        )
        return result.rowcount == 1

    def pending_review(
        self,
        *,
        status: MedicalRecordStatus,
        access_filter: ColumnElement[bool],
        page: int,
        page_size: int,
        patient_name: str | None = None,
        record_no: str | None = None,
        department_name: str | None = None,
        doctor_name: str | None = None,
        start_date: date | None = None,
        end_date: date | None = None,
    ) -> tuple[list[MedicalRecord], int]:
        filters: list[ColumnElement[bool]] = [
            MedicalRecord.deleted_at.is_(None),
            Encounter.deleted_at.is_(None),
            MedicalRecord.status == status,
            access_filter,
        ]
        if patient_name:
            filters.append(
                Patient.name.ilike(
                    f"%{self._escape_like(patient_name.strip())}%", escape="\\"
                )
            )
        if record_no:
            filters.append(
                MedicalRecord.record_no.ilike(
                    f"%{self._escape_like(record_no.strip())}%", escape="\\"
                )
            )
        if department_name:
            filters.append(
                Encounter.department.has(
                    Department.name.ilike(
                        f"%{self._escape_like(department_name.strip())}%",
                        escape="\\",
                    )
                )
            )
        if doctor_name:
            filters.append(
                Encounter.doctor.has(
                    User.real_name.ilike(
                        f"%{self._escape_like(doctor_name.strip())}%",
                        escape="\\",
                    )
                )
            )
        if start_date:
            filters.append(MedicalRecord.submitted_at >= self._day_start(start_date))
        if end_date:
            filters.append(
                MedicalRecord.submitted_at
                < self._day_start(end_date + timedelta(days=1))
            )
        base = (
            select(MedicalRecord)
            .join(MedicalRecord.encounter)
            .join(Encounter.patient)
            .where(*filters)
        )
        total = self.db.scalar(
            select(func.count()).select_from(base.subquery())
        ) or 0
        statement = (
            base.options(*self._detail_options())
            .order_by(
                MedicalRecord.submitted_at.desc(),
                MedicalRecord.id.desc(),
            )
            .offset((page - 1) * page_size)
            .limit(page_size)
        )
        return list(self.db.scalars(statement).unique().all()), total

    def soft_delete(self, record: MedicalRecord, deleted_at: datetime) -> None:
        record.deleted_at = deleted_at
        self.db.flush()

    def exists_by_encounter(
        self, encounter_id: int, *, include_deleted: bool = False
    ) -> bool:
        statement = select(func.count(MedicalRecord.id)).where(
            MedicalRecord.encounter_id == encounter_id
        )
        if not include_deleted:
            statement = statement.where(MedicalRecord.deleted_at.is_(None))
        return bool(self.db.scalar(statement))

    def next_sequence_value(self, sequence_date: date) -> int:
        statement = (
            update(MedicalRecordSequence)
            .where(MedicalRecordSequence.sequence_date == sequence_date)
            .values(current_value=MedicalRecordSequence.current_value + 1)
            .returning(MedicalRecordSequence.current_value)
        )
        current_value = self.db.scalar(statement)
        if current_value is not None:
            return current_value
        try:
            with self.db.begin_nested():
                self.db.add(
                    MedicalRecordSequence(
                        sequence_date=sequence_date,
                        current_value=1,
                    )
                )
                self.db.flush()
            return 1
        except IntegrityError:
            current_value = self.db.scalar(statement)
            if current_value is None:
                raise
            return current_value

    @staticmethod
    def _detail_options() -> tuple[object, ...]:
        encounter = joinedload(MedicalRecord.encounter)
        return (
            encounter.joinedload(Encounter.patient),
            joinedload(MedicalRecord.encounter).joinedload(Encounter.doctor),
            joinedload(MedicalRecord.encounter).joinedload(Encounter.department),
        )

    @classmethod
    def _detail_statement(cls):
        return select(MedicalRecord).options(*cls._detail_options())

    @classmethod
    def _build_filters(cls, params: SearchParams) -> list[ColumnElement[bool]]:
        filters: list[ColumnElement[bool]] = [
            MedicalRecord.deleted_at.is_(None),
            Encounter.deleted_at.is_(None),
        ]
        if params.keyword:
            escaped = cls._escape_like(params.keyword.strip())
            pattern = f"%{escaped}%"
            filters.append(
                or_(
                    MedicalRecord.record_no.ilike(pattern, escape="\\"),
                    Encounter.encounter_no.ilike(pattern, escape="\\"),
                    Patient.patient_no.ilike(pattern, escape="\\"),
                    Patient.name.ilike(pattern, escape="\\"),
                )
            )
        if getattr(params, "record_no", None):
            filters.append(MedicalRecord.record_no == params.record_no.strip())
        if getattr(params, "patient_id", None):
            filters.append(Encounter.patient_id == params.patient_id)
        if getattr(params, "patient_name", None):
            filters.append(Patient.name == params.patient_name.strip())
        if getattr(params, "doctor_id", None):
            filters.append(Encounter.doctor_id == params.doctor_id)
        if getattr(params, "department_id", None):
            filters.append(Encounter.department_id == params.department_id)
        if getattr(params, "encounter_id", None):
            filters.append(MedicalRecord.encounter_id == params.encounter_id)
        if params.status:
            filters.append(MedicalRecord.status == params.status)
        if params.start_date:
            filters.append(MedicalRecord.created_at >= cls._day_start(params.start_date))
        if params.end_date:
            filters.append(
                MedicalRecord.created_at
                < cls._day_start(params.end_date + timedelta(days=1))
            )
        return filters

    @staticmethod
    def _escape_like(value: str) -> str:
        return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")

    @staticmethod
    def _day_start(value: date) -> datetime:
        local = datetime.combine(value, time.min, tzinfo=LOCAL_TIMEZONE)
        return local.astimezone(timezone.utc)


class MedicalRecordVersionRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create(self, version: MedicalRecordVersion) -> MedicalRecordVersion:
        self.db.add(version)
        self.db.flush()
        return version

    def get_by_record_and_version(
        self, record_id: int, version: int
    ) -> MedicalRecordVersion | None:
        return self.db.scalar(
            select(MedicalRecordVersion).where(
                MedicalRecordVersion.record_id == record_id,
                MedicalRecordVersion.version == version,
            )
        )

    def list_by_record(self, record_id: int) -> list[MedicalRecordVersion]:
        statement = (
            select(MedicalRecordVersion)
            .where(MedicalRecordVersion.record_id == record_id)
            .order_by(MedicalRecordVersion.version.desc())
        )
        return list(self.db.scalars(statement).all())

    def get_latest_version_number(self, record_id: int) -> int:
        return self.db.scalar(
            select(func.max(MedicalRecordVersion.version)).where(
                MedicalRecordVersion.record_id == record_id
            )
        ) or 0
