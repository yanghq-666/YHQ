"""只读统计聚合数据库访问。"""

from datetime import datetime

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models.department import Department
from app.models.diagnosis import Diagnosis
from app.models.encounter import Encounter
from app.models.medical_record import MedicalRecord
from app.models.patient import Patient
from app.models.role import Role
from app.models.user import User, UserRole


class StatisticsRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def count(self, model, *filters) -> int:
        return self.db.scalar(select(func.count(model.id)).where(*filters)) or 0

    def doctor_count(self) -> int:
        statement = (
            select(func.count(func.distinct(User.id)))
            .join(UserRole, UserRole.user_id == User.id)
            .join(Role, Role.id == UserRole.role_id)
            .where(
                User.deleted_at.is_(None),
                User.is_active.is_(True),
                Role.code.in_(("DOCTOR", "SENIOR_DOCTOR")),
            )
        )
        return self.db.scalar(statement) or 0

    def created_dates(self, model, start: datetime) -> list[datetime]:
        statement = select(model.created_at).where(
            model.deleted_at.is_(None), model.created_at >= start
        )
        return list(self.db.scalars(statement).all())

    def encounter_dates(self, start: datetime) -> list[datetime]:
        statement = select(Encounter.visit_time).where(
            Encounter.deleted_at.is_(None), Encounter.visit_time >= start
        )
        return list(self.db.scalars(statement).all())

    def grouped_encounter_types(self):
        return self.db.execute(
            select(Encounter.encounter_type, func.count(Encounter.id))
            .where(Encounter.deleted_at.is_(None))
            .group_by(Encounter.encounter_type)
        ).all()

    def grouped_departments(self):
        return self.db.execute(
            select(Department.name, func.count(Encounter.id))
            .join(Encounter, Encounter.department_id == Department.id)
            .where(Encounter.deleted_at.is_(None))
            .group_by(Department.id, Department.name)
            .order_by(func.count(Encounter.id).desc())
            .limit(10)
        ).all()

    def grouped_record_statuses(self):
        return self.db.execute(
            select(MedicalRecord.status, func.count(MedicalRecord.id))
            .where(MedicalRecord.deleted_at.is_(None))
            .group_by(MedicalRecord.status)
        ).all()

    def top_diagnoses(self):
        return self.db.execute(
            select(Diagnosis.diagnosis_name, func.count(Diagnosis.id))
            .where(Diagnosis.deleted_at.is_(None))
            .group_by(Diagnosis.diagnosis_name)
            .order_by(func.count(Diagnosis.id).desc(), Diagnosis.diagnosis_name)
            .limit(10)
        ).all()
