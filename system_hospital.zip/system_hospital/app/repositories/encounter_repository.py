"""就诊持久化、查询和每日流水。"""

from __future__ import annotations

from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

from sqlalchemy import ColumnElement, func, or_, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, joinedload

from app.models.encounter import Encounter, EncounterSequence
from app.models.patient import Patient
from app.schemas.encounter import EncounterSearchParams

LOCAL_TIMEZONE = ZoneInfo("Asia/Shanghai")


class EncounterRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create(self, encounter: Encounter) -> Encounter:
        self.db.add(encounter)
        self.db.flush()
        return encounter

    def get_by_id(
        self, encounter_id: int, *, include_deleted: bool = False
    ) -> Encounter | None:
        statement = (
            select(Encounter)
            .options(
                joinedload(Encounter.patient),
                joinedload(Encounter.doctor),
                joinedload(Encounter.department),
            )
            .where(Encounter.id == encounter_id)
        )
        if not include_deleted:
            statement = statement.where(Encounter.deleted_at.is_(None))
        return self.db.scalar(statement)

    def get_by_encounter_no(self, encounter_no: str) -> Encounter | None:
        return self.db.scalar(
            select(Encounter).where(
                Encounter.encounter_no == encounter_no,
                Encounter.deleted_at.is_(None),
            )
        )

    def list(
        self,
        params: EncounterSearchParams,
        *,
        access_filter: ColumnElement[bool],
    ) -> tuple[list[Encounter], int]:
        filters: list[ColumnElement[bool]] = [
            Encounter.deleted_at.is_(None),
            access_filter,
        ]
        if params.keyword:
            escaped = self._escape_like(params.keyword.strip())
            pattern = f"%{escaped}%"
            filters.append(
                or_(
                    Encounter.encounter_no.ilike(pattern, escape="\\"),
                    Patient.patient_no.ilike(pattern, escape="\\"),
                    Patient.name.ilike(pattern, escape="\\"),
                )
            )
        if params.encounter_no:
            filters.append(Encounter.encounter_no == params.encounter_no.strip())
        if params.patient_id:
            filters.append(Encounter.patient_id == params.patient_id)
        if params.patient_name:
            filters.append(Patient.name == params.patient_name.strip())
        if params.doctor_id:
            filters.append(Encounter.doctor_id == params.doctor_id)
        if params.department_id:
            filters.append(Encounter.department_id == params.department_id)
        if params.encounter_type:
            filters.append(Encounter.encounter_type == params.encounter_type)
        if params.status:
            filters.append(Encounter.status == params.status)
        if params.start_date:
            filters.append(Encounter.visit_time >= self._day_start(params.start_date))
        if params.end_date:
            filters.append(
                Encounter.visit_time < self._day_start(params.end_date + timedelta(days=1))
            )

        base = select(Encounter).join(Encounter.patient).where(*filters)
        total = self.db.scalar(
            select(func.count()).select_from(base.subquery())
        ) or 0
        statement = (
            base.options(
                joinedload(Encounter.patient),
                joinedload(Encounter.doctor),
                joinedload(Encounter.department),
            )
            .order_by(Encounter.visit_time.desc(), Encounter.id.desc())
            .offset((params.page - 1) * params.page_size)
            .limit(params.page_size)
        )
        return list(self.db.scalars(statement).unique().all()), total

    def search(
        self,
        params: EncounterSearchParams,
        *,
        access_filter: ColumnElement[bool],
    ) -> tuple[list[Encounter], int]:
        return self.list(params, access_filter=access_filter)

    def list_by_patient(
        self, patient_id: int, *, access_filter: ColumnElement[bool]
    ) -> list[Encounter]:
        statement = (
            select(Encounter)
            .options(
                joinedload(Encounter.patient),
                joinedload(Encounter.doctor),
                joinedload(Encounter.department),
            )
            .where(
                Encounter.patient_id == patient_id,
                Encounter.deleted_at.is_(None),
                access_filter,
            )
            .order_by(Encounter.visit_time.desc(), Encounter.id.desc())
        )
        return list(self.db.scalars(statement).unique().all())

    def update(self, encounter: Encounter) -> Encounter:
        self.db.flush()
        return encounter

    def soft_delete(self, encounter: Encounter, deleted_at: datetime) -> None:
        encounter.deleted_at = deleted_at
        self.db.flush()

    def exists(self, encounter_id: int) -> bool:
        return bool(
            self.db.scalar(
                select(func.count(Encounter.id)).where(
                    Encounter.id == encounter_id,
                    Encounter.deleted_at.is_(None),
                )
            )
        )

    def exists_by_patient(self, patient_id: int) -> bool:
        return bool(
            self.db.scalar(
                select(func.count(Encounter.id)).where(
                    Encounter.patient_id == patient_id,
                    Encounter.deleted_at.is_(None),
                )
            )
        )

    def next_sequence_value(self, sequence_date: date) -> int:
        statement = (
            update(EncounterSequence)
            .where(EncounterSequence.sequence_date == sequence_date)
            .values(current_value=EncounterSequence.current_value + 1)
            .returning(EncounterSequence.current_value)
        )
        current_value = self.db.scalar(statement)
        if current_value is not None:
            return current_value
        try:
            with self.db.begin_nested():
                self.db.add(
                    EncounterSequence(
                        sequence_date=sequence_date, current_value=1
                    )
                )
                self.db.flush()
            return 1
        except IntegrityError:
            current_value = self.db.scalar(statement)
            if current_value is None:
                raise
            return current_value

    @staticmethod
    def _escape_like(value: str) -> str:
        return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")

    @staticmethod
    def _day_start(value: date) -> datetime:
        local = datetime.combine(value, time.min, tzinfo=LOCAL_TIMEZONE)
        return local.astimezone(timezone.utc)

