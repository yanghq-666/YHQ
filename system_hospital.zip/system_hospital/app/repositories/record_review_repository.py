"""病历审核时间线和审核人任务数据访问。"""

from datetime import datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

from sqlalchemy import func, select
from sqlalchemy.orm import Session, joinedload

from app.models.medical_record import MedicalRecord
from app.models.record_review import RecordReview
from app.schemas.record_review import MyReviewSearchParams

LOCAL_TIMEZONE = ZoneInfo("Asia/Shanghai")


class RecordReviewRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create(self, review: RecordReview) -> RecordReview:
        self.db.add(review)
        self.db.flush()
        return review

    def list_by_record(self, record_id: int) -> list[RecordReview]:
        statement = (
            select(RecordReview)
            .options(joinedload(RecordReview.reviewer))
            .where(RecordReview.record_id == record_id)
            .order_by(RecordReview.created_at, RecordReview.id)
        )
        return list(self.db.scalars(statement).all())

    def get_latest(self, record_id: int) -> RecordReview | None:
        return self.db.scalar(
            select(RecordReview)
            .options(joinedload(RecordReview.reviewer))
            .where(RecordReview.record_id == record_id)
            .order_by(RecordReview.created_at.desc(), RecordReview.id.desc())
            .limit(1)
        )

    def get_latest_rejection(self, record_id: int) -> RecordReview | None:
        from app.models.enums import ReviewAction

        return self.db.scalar(
            select(RecordReview)
            .options(joinedload(RecordReview.reviewer))
            .where(
                RecordReview.record_id == record_id,
                RecordReview.action == ReviewAction.REJECT,
            )
            .order_by(RecordReview.created_at.desc(), RecordReview.id.desc())
            .limit(1)
        )

    def latest_round(self, record_id: int) -> int:
        return self.db.scalar(
            select(func.max(RecordReview.review_round)).where(
                RecordReview.record_id == record_id
            )
        ) or 0

    def list_by_reviewer(
        self,
        reviewer_id: int,
        params: MyReviewSearchParams,
    ) -> tuple[list[RecordReview], int]:
        filters = [RecordReview.reviewer_id == reviewer_id]
        if params.action:
            filters.append(RecordReview.action == params.action)
        if params.status:
            filters.append(MedicalRecord.status == params.status)
        if params.start_date:
            filters.append(
                RecordReview.created_at >= self._day_start(params.start_date)
            )
        if params.end_date:
            filters.append(
                RecordReview.created_at
                < self._day_start(params.end_date + timedelta(days=1))
            )
        base = (
            select(RecordReview)
            .join(RecordReview.record)
            .where(*filters)
        )
        total = self.db.scalar(
            select(func.count()).select_from(base.subquery())
        ) or 0
        statement = (
            base.options(
                joinedload(RecordReview.reviewer),
                joinedload(RecordReview.record),
            )
            .order_by(RecordReview.created_at.desc(), RecordReview.id.desc())
            .offset((params.page - 1) * params.page_size)
            .limit(params.page_size)
        )
        return list(self.db.scalars(statement).unique().all()), total

    @staticmethod
    def _day_start(value) -> datetime:
        local = datetime.combine(value, time.min, tzinfo=LOCAL_TIMEZONE)
        return local.astimezone(timezone.utc)
