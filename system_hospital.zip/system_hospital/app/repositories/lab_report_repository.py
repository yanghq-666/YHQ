"""检验报告及结果数据访问。"""

from datetime import datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.models.lab_report import LabReport, LabResult
from app.schemas.lab_report import LabReportFilter

LOCAL_TIMEZONE = ZoneInfo("Asia/Shanghai")


class LabReportRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create(self, report: LabReport) -> LabReport:
        self.db.add(report)
        self.db.flush()
        return report

    def get_by_id(self, report_id: int) -> LabReport | None:
        return self.db.scalar(select(LabReport).options(selectinload(LabReport.results)).where(LabReport.id == report_id, LabReport.deleted_at.is_(None)))

    def list_by_record(self, record_id: int, params: LabReportFilter | None = None) -> list[LabReport]:
        statement = select(LabReport).options(selectinload(LabReport.results)).where(LabReport.record_id == record_id, LabReport.deleted_at.is_(None))
        if params:
            if params.status:
                statement = statement.where(LabReport.status == params.status)
            if params.report_type:
                statement = statement.where(LabReport.report_type == params.report_type.strip())
            if params.start_date:
                statement = statement.where(LabReport.created_at >= self._day_start(params.start_date))
            if params.end_date:
                statement = statement.where(LabReport.created_at < self._day_start(params.end_date + timedelta(days=1)))
        return list(self.db.scalars(statement.order_by(LabReport.created_at.desc(), LabReport.id.desc())).all())

    @staticmethod
    def _day_start(value):
        return datetime.combine(value, time.min, tzinfo=LOCAL_TIMEZONE).astimezone(timezone.utc)


class LabResultRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create_many(self, results: list[LabResult]) -> list[LabResult]:
        self.db.add_all(results)
        self.db.flush()
        return results

    def get_by_id(self, result_id: int) -> LabResult | None:
        return self.db.get(LabResult, result_id)

    def list_by_report(self, report_id: int) -> list[LabResult]:
        return list(self.db.scalars(select(LabResult).where(LabResult.lab_report_id == report_id).order_by(LabResult.sort_order, LabResult.id)).all())
