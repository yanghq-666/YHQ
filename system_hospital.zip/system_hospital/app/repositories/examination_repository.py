"""检查报告数据访问。"""

from datetime import datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.examination import Examination
from app.schemas.examination import ExaminationFilter

LOCAL_TIMEZONE = ZoneInfo("Asia/Shanghai")


class ExaminationRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create(self, examination: Examination) -> Examination:
        self.db.add(examination)
        self.db.flush()
        return examination

    def get_by_id(self, examination_id: int) -> Examination | None:
        return self.db.scalar(select(Examination).where(Examination.id == examination_id, Examination.deleted_at.is_(None)))

    def list_by_record(self, record_id: int, params: ExaminationFilter | None = None) -> list[Examination]:
        statement = select(Examination).where(Examination.record_id == record_id, Examination.deleted_at.is_(None))
        if params:
            if params.examination_type:
                statement = statement.where(Examination.examination_type == params.examination_type)
            if params.status:
                statement = statement.where(Examination.status == params.status)
            if params.start_date:
                statement = statement.where(Examination.created_at >= self._day_start(params.start_date))
            if params.end_date:
                statement = statement.where(Examination.created_at < self._day_start(params.end_date + timedelta(days=1)))
        return list(self.db.scalars(statement.order_by(Examination.created_at.desc(), Examination.id.desc())).all())

    @staticmethod
    def _day_start(value):
        return datetime.combine(value, time.min, tzinfo=LOCAL_TIMEZONE).astimezone(timezone.utc)
