"""角色、权限和科室查询仓储。"""

from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from app.models.department import Department
from app.models.permission import Permission, RolePermission
from app.models.role import Role


class RoleRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def list_roles(self) -> list[Role]:
        return list(self.db.scalars(select(Role).order_by(Role.id)).all())

    def get_role(self, role_id: int) -> Role | None:
        return self.db.get(Role, role_id)

    def get_roles_by_ids(self, role_ids: set[int]) -> list[Role]:
        if not role_ids:
            return []
        return list(
            self.db.scalars(
                select(Role).where(Role.id.in_(role_ids)).order_by(Role.id)
            ).all()
        )

    def get_permission_codes(self, role_id: int) -> list[str]:
        statement = (
            select(Permission.code)
            .join(
                RolePermission,
                RolePermission.permission_id == Permission.id,
            )
            .where(RolePermission.role_id == role_id)
            .order_by(Permission.code)
        )
        return list(self.db.scalars(statement).all())

    def list_permissions(self) -> list[Permission]:
        return list(
            self.db.scalars(
                select(Permission).order_by(Permission.module, Permission.code)
            ).all()
        )

    def get_permissions_by_ids(
        self, permission_ids: set[int]
    ) -> list[Permission]:
        if not permission_ids:
            return []
        return list(
            self.db.scalars(
                select(Permission).where(Permission.id.in_(permission_ids))
            ).all()
        )

    def replace_role_permissions(
        self, role_id: int, permission_ids: set[int]
    ) -> None:
        self.db.execute(
            delete(RolePermission).where(RolePermission.role_id == role_id)
        )
        self.db.add_all(
            RolePermission(role_id=role_id, permission_id=permission_id)
            for permission_id in sorted(permission_ids)
        )

    def list_departments(self) -> list[Department]:
        return list(
            self.db.scalars(
                select(Department).order_by(Department.department_code)
            ).all()
        )

    def get_department(self, department_id: int) -> Department | None:
        return self.db.get(Department, department_id)

    def get_department_by_code(self, code: str) -> Department | None:
        return self.db.scalar(
            select(Department).where(Department.department_code == code)
        )
