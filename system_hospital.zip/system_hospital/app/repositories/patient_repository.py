"""患者持久化与条件查询。"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import func, or_, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.models.patient import Patient, PatientSequence
from app.schemas.patient import PatientSearchParams


class PatientRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create(self, patient: Patient) -> Patient:
        self.db.add(patient)
        self.db.flush()
        return patient

    def get_by_id(
        self, patient_id: int, *, include_deleted: bool = False
    ) -> Patient | None:
        statement = select(Patient).where(Patient.id == patient_id)
        if not include_deleted:
            statement = statement.where(Patient.deleted_at.is_(None))
        return self.db.scalar(statement)

    def get_by_patient_no(self, patient_no: str) -> Patient | None:
        return self.db.scalar(
            select(Patient).where(
                Patient.patient_no == patient_no,
                Patient.deleted_at.is_(None),
            )
        )

    def get_by_id_card(
        self, id_card: str, *, include_deleted: bool = True
    ) -> Patient | None:
        statement = select(Patient).where(Patient.id_card == id_card)
        if not include_deleted:
            statement = statement.where(Patient.deleted_at.is_(None))
        return self.db.scalar(statement)

    def list(self, params: PatientSearchParams) -> tuple[list[Patient], int]:
        filters = [Patient.deleted_at.is_(None)]
        if params.keyword:
            keyword = self._escape_like(params.keyword.strip())
            pattern = f"%{keyword}%"
            filters.append(
                or_(
                    Patient.patient_no.ilike(pattern, escape="\\"),
                    Patient.name.ilike(pattern, escape="\\"),
                    Patient.phone.ilike(pattern, escape="\\"),
                )
            )
        if params.patient_no:
            filters.append(Patient.patient_no == params.patient_no.strip())
        if params.name:
            filters.append(Patient.name == params.name.strip())
        if params.phone:
            filters.append(Patient.phone == params.phone.strip())
        if params.id_card:
            filters.append(Patient.id_card == params.id_card.strip().upper())
        if params.gender:
            filters.append(Patient.gender == params.gender)
        if params.blood_type:
            filters.append(Patient.blood_type == params.blood_type)

        total = self.db.scalar(
            select(func.count(Patient.id)).where(*filters)
        ) or 0
        statement = (
            select(Patient)
            .where(*filters)
            .order_by(Patient.created_at.desc(), Patient.id.desc())
            .offset((params.page - 1) * params.page_size)
            .limit(params.page_size)
        )
        return list(self.db.scalars(statement).all()), total

    def search(
        self, params: PatientSearchParams
    ) -> tuple[list[Patient], int]:
        return self.list(params)

    def update(self, patient: Patient) -> Patient:
        self.db.flush()
        return patient

    def soft_delete(self, patient: Patient, deleted_at: datetime) -> None:
        patient.deleted_at = deleted_at
        self.db.flush()

    def next_sequence_value(self, year: int) -> int:
        """原子递增年度流水；首次创建并发由主键和保存点兜底。"""
        statement = (
            update(PatientSequence)
            .where(PatientSequence.year == year)
            .values(current_value=PatientSequence.current_value + 1)
            .returning(PatientSequence.current_value)
        )
        current_value = self.db.scalar(statement)
        if current_value is not None:
            return current_value

        try:
            with self.db.begin_nested():
                self.db.add(PatientSequence(year=year, current_value=1))
                self.db.flush()
            return 1
        except IntegrityError:
            current_value = self.db.scalar(statement)
            if current_value is None:
                raise
            return current_value

    @staticmethod
    def _escape_like(value: str) -> str:
        return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
