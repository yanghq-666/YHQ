"""第十三阶段：归档、统计和剩余管理页面集成测试。"""

from sqlalchemy import select
from sqlalchemy.orm import Session
from fastapi.testclient import TestClient

from app.models.audit_log import AuditLog
from app.models.enums import MedicalRecordStatus
from app.models.medical_record import MedicalRecord
from app.models.user import User
from app.models.department import Department
from app.models.role import Role
from app.models.permission import RolePermission
from app.core.security import verify_password
from app.repositories.user_repository import UserRepository
from tests.test_clinical_records import _create_diagnosis
from tests.test_record_reviews import _headers, _setup as setup_review, _submit
from tests.test_reports_and_attachments import (
    _create_exam,
    _create_lab,
    _setup as setup_reports,
)
from tests.test_web import _create_role_user, _web_login


def test_archive_api_state_lock_and_audit(
    client: TestClient, seeded_db: Session
) -> None:
    context = setup_review(seeded_db)
    record = context["record"]
    _create_diagnosis(client, record, context["doctor"])
    assert _submit(client, context).status_code == 200
    assert client.post(
        f"/api/medical-records/{record.id}/review/start",
        headers=_headers(context["senior_a"]),
    ).status_code == 200
    assert client.post(
        f"/api/medical-records/{record.id}/review/approve",
        headers=_headers(context["senior_a"]),
        json={"comment": "审核通过，可以归档"},
    ).status_code == 200

    archived = client.post(
        f"/api/medical-records/{record.id}/archive",
        headers=_headers(context["admin"]),
    )
    assert archived.status_code == 200, archived.text
    assert archived.json()["data"]["status"] == "ARCHIVED"
    seeded_db.refresh(record)
    assert record.archived_by == context["admin"].id
    assert record.archived_at is not None
    assert client.patch(
        f"/api/medical-records/{record.id}",
        headers=_headers(context["doctor"]),
        json={"doctor_notes": "归档后篡改"},
    ).status_code == 409
    assert client.post(
        f"/api/medical-records/{record.id}/archive",
        headers=_headers(context["admin"]),
    ).status_code == 409
    assert "MEDICAL_RECORD_ARCHIVE" in set(
        seeded_db.scalars(select(AuditLog.action)).all()
    )


def test_only_archive_role_can_archive(
    client: TestClient, seeded_db: Session
) -> None:
    context = setup_review(seeded_db)
    record = context["record"]
    record.status = MedicalRecordStatus.APPROVED
    record.approved_version = 1
    seeded_db.commit()
    forbidden = client.post(
        f"/api/medical-records/{record.id}/archive",
        headers=_headers(context["doctor"]),
    )
    assert forbidden.status_code == 403


def test_statistics_api_uses_database_data(
    client: TestClient, seeded_db: Session
) -> None:
    context = setup_review(seeded_db)
    summary = client.get(
        "/api/statistics/summary", headers=_headers(context["admin"])
    )
    assert summary.status_code == 200
    assert summary.json()["data"]["patients"] >= 1
    endpoints = (
        "/api/statistics/patients/monthly",
        "/api/statistics/encounters/daily",
        "/api/statistics/encounters/types",
        "/api/statistics/departments",
        "/api/statistics/records/status",
        "/api/statistics/diagnoses/top",
    )
    for endpoint in endpoints:
        response = client.get(endpoint, headers=_headers(context["admin"]))
        assert response.status_code == 200, (endpoint, response.text)
        assert isinstance(response.json()["data"], list)
    assert client.get(
        "/api/statistics/summary", headers=_headers(context["doctor"])
    ).status_code == 403


def test_remaining_web_pages_are_real_and_role_protected(
    client: TestClient, seeded_db: Session
) -> None:
    context = setup_reports(seeded_db)
    lab = _create_lab(client, context)
    examination = _create_exam(client, context)
    _web_login(client)
    paths = (
        "/profile",
        "/attachments",
        "/records",
        "/statistics",
        "/admin/users",
        "/admin/departments",
        "/admin/roles",
        "/audit-logs",
        "/labs",
        f"/labs/{lab['id']}",
        "/examinations",
        f"/examinations/{examination['id']}",
    )
    for path in paths:
        response = client.get(path)
        assert response.status_code == 200, (path, response.text)
        assert "功能开发中" not in response.text

    client.post("/logout")
    _create_role_user(
        seeded_db, username="stage13-doctor", role_code="DOCTOR"
    )
    _web_login(client, "stage13-doctor", "Web@Test123")
    assert client.get("/statistics").status_code == 403
    assert client.get("/records").status_code == 403


def test_admin_can_create_user_department_and_manage_permissions(
    client: TestClient, seeded_db: Session
) -> None:
    _web_login(client)
    department = seeded_db.scalar(
        select(Department).where(Department.department_code == "INTERNAL")
    )
    doctor_role = seeded_db.scalar(select(Role).where(Role.code == "DOCTOR"))
    assert department is not None and doctor_role is not None
    created = client.post(
        "/admin/users/new",
        data={
            "username": "stage13-new-doctor",
            "password": "Stage13@Test123",
            "real_name": "新建演示医生",
            "employee_no": "S13D001",
            "department_id": str(department.id),
            "role_ids": str(doctor_role.id),
            "is_active": "on",
        },
        follow_redirects=False,
    )
    assert created.status_code == 303, created.text
    user = seeded_db.scalar(
        select(User).where(User.username == "stage13-new-doctor")
    )
    assert user is not None and user.password_hash != "Stage13@Test123"
    assert client.post(
        f"/admin/users/{user.id}/reset-password",
        data={"password": "Reset@Test123"},
        follow_redirects=False,
    ).status_code == 303
    seeded_db.refresh(user)
    assert verify_password("Reset@Test123", user.password_hash)

    senior_role = seeded_db.scalar(
        select(Role).where(Role.code == "SENIOR_DOCTOR")
    )
    assert senior_role is not None
    assert client.post(
        f"/admin/users/{user.id}/edit",
        data={
            "username": user.username,
            "real_name": "调整后的演示医生",
            "employee_no": user.employee_no,
            "department_id": str(department.id),
            "role_ids": str(senior_role.id),
            "is_active": "on",
        },
        follow_redirects=False,
    ).status_code == 303
    assert UserRepository(seeded_db).get_role_codes(user.id) == {"SENIOR_DOCTOR"}
    assert client.post(
        f"/admin/users/{user.id}/toggle", follow_redirects=False
    ).status_code == 303
    seeded_db.refresh(user)
    assert user.is_active is False

    assert client.post(
        "/admin/departments/new",
        data={
            "department_code": "STAGE13",
            "name": "演示科室",
            "description": "课程项目测试",
        },
        follow_redirects=False,
    ).status_code == 303
    new_department = seeded_db.scalar(
        select(Department).where(Department.department_code == "STAGE13")
    )
    assert new_department is not None
    assert client.post(
        f"/admin/departments/{new_department.id}/edit",
        data={"name": "演示科室（已停用）", "status": "INACTIVE"},
        follow_redirects=False,
    ).status_code == 303
    seeded_db.refresh(new_department)
    assert new_department.status.value == "INACTIVE"

    role_page = client.get(f"/admin/roles/{doctor_role.id}")
    assert role_page.status_code == 200 and "权限配置" in role_page.text
    permission_ids = list(
        seeded_db.scalars(
            select(RolePermission.permission_id).where(
                RolePermission.role_id == doctor_role.id
            )
        ).all()
    )
    saved = client.post(
        f"/admin/roles/{doctor_role.id}",
        data={"permission_ids": [str(item) for item in permission_ids]},
        follow_redirects=False,
    )
    assert saved.status_code == 303
