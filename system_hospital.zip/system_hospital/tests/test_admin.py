"""管理员用户、角色、权限与科室接口测试。"""

from fastapi.testclient import TestClient
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.security import verify_password
from app.models.department import Department
from app.models.permission import Permission, RolePermission
from app.models.role import Role
from app.models.user import User, UserRole


def _admin_headers(client: TestClient) -> dict[str, str]:
    response = client.post(
        "/api/auth/login",
        json={"username": "admin", "password": "Admin@Test123"},
    )
    token = response.json()["data"]["access_token"]
    return {"Authorization": f"Bearer {token}"}


def test_admin_can_list_initialized_resources(
    client: TestClient, seeded_db: Session
) -> None:
    headers = _admin_headers(client)

    roles = client.get("/api/admin/roles", headers=headers)
    permissions = client.get("/api/admin/permissions", headers=headers)
    departments = client.get("/api/admin/departments", headers=headers)

    assert roles.status_code == 200
    assert len(roles.json()["data"]) == 7
    assert permissions.status_code == 200
    assert len(permissions.json()["data"]) == 32
    assert departments.status_code == 200
    assert len(departments.json()["data"]) == 9
    assert "病案室" in {item["name"] for item in departments.json()["data"]}


def test_create_user_hashes_password_and_binds_role(
    client: TestClient, seeded_db: Session
) -> None:
    headers = _admin_headers(client)
    doctor_role = seeded_db.scalar(select(Role).where(Role.code == "DOCTOR"))
    department = seeded_db.scalar(
        select(Department).where(Department.department_code == "INTERNAL")
    )
    assert doctor_role is not None
    assert department is not None

    payload = {
        "username": "doctor01",
        "password": "Doctor@Test123",
        "real_name": "张医生",
        "employee_no": "D001",
        "email": "doctor01@example.test",
        "phone": "13800000000",
        "department_id": department.id,
        "role_ids": [doctor_role.id],
    }
    response = client.post("/api/admin/users", headers=headers, json=payload)

    assert response.status_code == 201
    body = response.json()["data"]
    assert body["username"] == "doctor01"
    assert body["real_name"] == "张医生"
    assert body["department"]["name"] == "内科"
    assert body["roles"] == ["DOCTOR"]
    assert "password_hash" not in body

    created = seeded_db.scalar(
        select(User).where(User.username == "doctor01")
    )
    assert created is not None
    assert created.password_hash != payload["password"]
    assert verify_password(payload["password"], created.password_hash)
    assert seeded_db.scalar(
        select(func.count(UserRole.user_id)).where(
            UserRole.user_id == created.id,
            UserRole.role_id == doctor_role.id,
        )
    ) == 1


def test_duplicate_username_returns_conflict(
    client: TestClient, seeded_db: Session
) -> None:
    headers = _admin_headers(client)
    payload = {
        "username": "duplicate",
        "password": "Duplicate@Test123",
        "real_name": "重复用户",
        "role_ids": [],
    }
    first = client.post("/api/admin/users", headers=headers, json=payload)
    second = client.post("/api/admin/users", headers=headers, json=payload)

    assert first.status_code == 201
    assert second.status_code == 409
    assert second.json()["message"] == "用户名已存在"


def test_assign_roles_and_role_permission_links(
    client: TestClient, seeded_db: Session
) -> None:
    headers = _admin_headers(client)
    doctor_role = seeded_db.scalar(select(Role).where(Role.code == "DOCTOR"))
    assert doctor_role is not None
    create_response = client.post(
        "/api/admin/users",
        headers=headers,
        json={
            "username": "role-test",
            "password": "Role@Test123",
            "real_name": "角色测试",
            "role_ids": [],
        },
    )
    user_id = create_response.json()["data"]["id"]

    response = client.post(
        f"/api/admin/users/{user_id}/roles",
        headers=headers,
        json={"role_ids": [doctor_role.id]},
    )

    assert response.status_code == 200
    assert response.json()["data"]["roles"] == ["DOCTOR"]
    patient_view = seeded_db.scalar(
        select(Permission).where(Permission.code == "patient:view")
    )
    assert patient_view is not None
    assert seeded_db.scalar(
        select(func.count(RolePermission.role_id)).where(
            RolePermission.role_id == doctor_role.id,
            RolePermission.permission_id == patient_view.id,
        )
    ) == 1


def test_admin_can_create_department(
    client: TestClient, seeded_db: Session
) -> None:
    response = client.post(
        "/api/admin/departments",
        headers=_admin_headers(client),
        json={
            "department_code": "neurology",
            "name": "神经内科",
            "description": "测试科室",
        },
    )
    assert response.status_code == 201
    assert response.json()["data"]["department_code"] == "NEUROLOGY"
