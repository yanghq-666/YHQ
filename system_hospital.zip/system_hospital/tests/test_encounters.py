"""就诊创建、查询、状态机、数据范围、软删除和审计测试。"""

import re
from datetime import datetime, timezone

from fastapi.testclient import TestClient
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.security import create_access_token, hash_password
from app.models.audit_log import AuditLog
from app.models.department import Department
from app.models.encounter import Encounter
from app.models.enums import EncounterStatus, Gender, UserStatus
from app.models.patient import Patient
from app.models.role import Role
from app.models.user import User, UserRole


def _headers(user: User) -> dict[str, str]:
    token = create_access_token(user.id, user.username)
    return {"Authorization": f"Bearer {token}"}


def _setup(db: Session) -> tuple[User, User, Department, Patient]:
    admin = db.scalar(select(User).where(User.username == "admin"))
    department = db.scalar(
        select(Department).where(Department.department_code == "INTERNAL")
    )
    doctor_role = db.scalar(select(Role).where(Role.code == "DOCTOR"))
    assert admin is not None
    assert department is not None
    assert doctor_role is not None
    doctor = User(
        username="encounter-doctor",
        password_hash=hash_password("Encounter@Test123"),
        real_name="就诊测试医生",
        employee_no="ED001",
        department_id=department.id,
        status=UserStatus.ACTIVE,
        is_active=True,
    )
    patient = Patient(
        patient_no="PTEST000001",
        name="就诊测试患者",
        gender=Gender.MALE,
    )
    db.add_all([doctor, patient])
    db.flush()
    db.add(UserRole(user_id=doctor.id, role_id=doctor_role.id))
    db.commit()
    return admin, doctor, department, patient


def _payload(
    doctor: User,
    department: Department,
    patient: Patient,
    **overrides: object,
) -> dict[str, object]:
    data: dict[str, object] = {
        "patient_id": patient.id,
        "doctor_id": doctor.id,
        "department_id": department.id,
        "encounter_type": "OUTPATIENT",
        "visit_time": "2026-09-05T10:30:00+08:00",
        "chief_complaint": "咳嗽、发热3天",
        "remark": "测试就诊",
    }
    data.update(overrides)
    return data


def _create(
    client: TestClient,
    headers: dict[str, str],
    doctor: User,
    department: Department,
    patient: Patient,
    **overrides: object,
) -> dict[str, object]:
    response = client.post(
        "/api/encounters",
        headers=headers,
        json=_payload(doctor, department, patient, **overrides),
    )
    assert response.status_code == 201, response.text
    return response.json()["data"]


def test_create_outpatient_and_generate_unique_numbers(
    client: TestClient, seeded_db: Session
) -> None:
    admin, doctor, department, patient = _setup(seeded_db)
    first = _create(client, _headers(admin), doctor, department, patient)
    second = _create(client, _headers(admin), doctor, department, patient)

    assert re.fullmatch(r"E\d{8}\d{6}", str(first["encounter_no"]))
    assert first["encounter_no"] != second["encounter_no"]
    assert first["status"] == "REGISTERED"
    assert first["encounter_type"] == "OUTPATIENT"


def test_create_rejects_missing_or_deleted_patient(
    client: TestClient, seeded_db: Session
) -> None:
    admin, doctor, department, patient = _setup(seeded_db)
    missing = client.post(
        "/api/encounters",
        headers=_headers(admin),
        json=_payload(doctor, department, patient, patient_id=99999),
    )
    patient.deleted_at = datetime.now(timezone.utc)
    seeded_db.commit()
    deleted = client.post(
        "/api/encounters",
        headers=_headers(admin),
        json=_payload(doctor, department, patient),
    )

    assert missing.status_code == 404
    assert deleted.status_code == 404


def test_non_doctor_and_missing_department_are_rejected(
    client: TestClient, seeded_db: Session
) -> None:
    admin, doctor, department, patient = _setup(seeded_db)
    nurse_role = seeded_db.scalar(select(Role).where(Role.code == "NURSE"))
    assert nurse_role is not None
    nurse = User(
        username="not-a-doctor",
        password_hash=hash_password("Encounter@Test123"),
        real_name="护士",
        department_id=department.id,
        status=UserStatus.ACTIVE,
        is_active=True,
    )
    seeded_db.add(nurse)
    seeded_db.flush()
    seeded_db.add(UserRole(user_id=nurse.id, role_id=nurse_role.id))
    seeded_db.commit()

    invalid_doctor = client.post(
        "/api/encounters",
        headers=_headers(admin),
        json=_payload(doctor, department, patient, doctor_id=nurse.id),
    )
    missing_department = client.post(
        "/api/encounters",
        headers=_headers(admin),
        json=_payload(doctor, department, patient, department_id=99999),
    )
    assert invalid_doctor.status_code == 400
    assert missing_department.status_code == 404


def test_list_pagination_keyword_and_patient_history(
    client: TestClient, seeded_db: Session
) -> None:
    admin, doctor, department, patient = _setup(seeded_db)
    headers = _headers(admin)
    first = _create(client, headers, doctor, department, patient)
    _create(client, headers, doctor, department, patient)
    _create(client, headers, doctor, department, patient)

    page = client.get("/api/encounters?page=1&page_size=2", headers=headers)
    search = client.get(
        f"/api/encounters?keyword={first['encounter_no']}", headers=headers
    )
    history = client.get(
        f"/api/patients/{patient.id}/encounters", headers=headers
    )

    assert page.status_code == 200
    assert page.json()["data"]["total"] == 3
    assert len(page.json()["data"]["items"]) == 2
    assert page.json()["data"]["pages"] == 2
    assert search.json()["data"]["total"] == 1
    assert len(history.json()["data"]) == 3


def test_detail_contains_brief_relations(
    client: TestClient, seeded_db: Session
) -> None:
    admin, doctor, department, patient = _setup(seeded_db)
    created = _create(
        client, _headers(admin), doctor, department, patient
    )
    response = client.get(
        f"/api/encounters/{created['id']}", headers=_headers(admin)
    )
    data = response.json()["data"]

    assert response.status_code == 200
    assert data["patient"]["patient_no"] == patient.patient_no
    assert data["doctor"]["real_name"] == doctor.real_name
    assert data["department"]["name"] == department.name


def test_update_complaint_and_forbid_patient_or_status_change(
    client: TestClient, seeded_db: Session
) -> None:
    admin, doctor, department, patient = _setup(seeded_db)
    headers = _headers(admin)
    created = _create(client, headers, doctor, department, patient)
    updated = client.patch(
        f"/api/encounters/{created['id']}",
        headers=headers,
        json={"chief_complaint": "症状已缓解"},
    )
    patient_change = client.patch(
        f"/api/encounters/{created['id']}",
        headers=headers,
        json={"patient_id": 999},
    )
    status_change = client.patch(
        f"/api/encounters/{created['id']}",
        headers=headers,
        json={"status": "COMPLETED"},
    )

    assert updated.status_code == 200
    assert updated.json()["data"]["chief_complaint"] == "症状已缓解"
    assert patient_change.status_code == 422
    assert status_change.status_code == 422


def test_registered_start_then_complete_and_illegal_transition(
    client: TestClient, seeded_db: Session
) -> None:
    admin, doctor, department, patient = _setup(seeded_db)
    headers = _headers(admin)
    created = _create(client, headers, doctor, department, patient)
    started = client.post(
        f"/api/encounters/{created['id']}/start", headers=headers
    )
    completed = client.post(
        f"/api/encounters/{created['id']}/complete", headers=headers
    )
    illegal = client.post(
        f"/api/encounters/{created['id']}/start", headers=headers
    )

    assert started.status_code == 200
    assert started.json()["data"]["old_status"] == "REGISTERED"
    assert started.json()["data"]["status"] == "IN_PROGRESS"
    assert completed.status_code == 200
    assert completed.json()["data"]["status"] == "COMPLETED"
    assert illegal.status_code == 409


def test_registered_can_be_cancelled_but_not_started_afterwards(
    client: TestClient, seeded_db: Session
) -> None:
    admin, doctor, department, patient = _setup(seeded_db)
    headers = _headers(admin)
    created = _create(client, headers, doctor, department, patient)
    cancelled = client.post(
        f"/api/encounters/{created['id']}/cancel", headers=headers
    )
    illegal = client.post(
        f"/api/encounters/{created['id']}/start", headers=headers
    )
    assert cancelled.status_code == 200
    assert cancelled.json()["data"]["status"] == "CANCELLED"
    assert illegal.status_code == 409


def test_without_permission_cannot_view_encounters(
    client: TestClient, seeded_db: Session
) -> None:
    user = User(
        username="no-encounter-permission",
        password_hash=hash_password("Encounter@Test123"),
        real_name="无权限用户",
        status=UserStatus.ACTIVE,
        is_active=True,
    )
    seeded_db.add(user)
    seeded_db.commit()
    response = client.get("/api/encounters", headers=_headers(user))
    assert response.status_code == 403


def test_soft_delete_and_completed_delete_conflict(
    client: TestClient, seeded_db: Session
) -> None:
    admin, doctor, department, patient = _setup(seeded_db)
    headers = _headers(admin)
    deletable = _create(client, headers, doctor, department, patient)
    deleted = client.delete(
        f"/api/encounters/{deletable['id']}", headers=headers
    )
    assert deleted.status_code == 200
    assert client.get(
        f"/api/encounters/{deletable['id']}", headers=headers
    ).status_code == 404

    completed = _create(client, headers, doctor, department, patient)
    client.post(f"/api/encounters/{completed['id']}/start", headers=headers)
    client.post(f"/api/encounters/{completed['id']}/complete", headers=headers)
    conflict = client.delete(
        f"/api/encounters/{completed['id']}", headers=headers
    )
    assert conflict.status_code == 409


def test_audit_logs_include_state_changes(
    client: TestClient, seeded_db: Session
) -> None:
    admin, doctor, department, patient = _setup(seeded_db)
    headers = _headers(admin)
    created = _create(client, headers, doctor, department, patient)
    client.patch(
        f"/api/encounters/{created['id']}",
        headers=headers,
        json={"remark": "已更新"},
    )
    client.post(f"/api/encounters/{created['id']}/start", headers=headers)
    client.post(f"/api/encounters/{created['id']}/complete", headers=headers)

    logs = list(
        seeded_db.scalars(
            select(AuditLog)
            .where(
                AuditLog.target_type == "encounter",
                AuditLog.target_id == created["id"],
            )
            .order_by(AuditLog.id)
        ).all()
    )
    assert [log.action for log in logs] == [
        "ENCOUNTER_CREATE",
        "ENCOUNTER_UPDATE",
        "ENCOUNTER_START",
        "ENCOUNTER_COMPLETE",
    ]
    assert logs[-1].old_value == {"status": "IN_PROGRESS"}
    assert logs[-1].new_value == {"status": "COMPLETED"}
    assert logs[-1].request_path == f"/api/encounters/{created['id']}/complete"


def test_patient_with_encounter_cannot_be_deleted(
    client: TestClient, seeded_db: Session
) -> None:
    admin, doctor, department, patient = _setup(seeded_db)
    headers = _headers(admin)
    _create(client, headers, doctor, department, patient)
    response = client.delete(f"/api/patients/{patient.id}", headers=headers)
    assert response.status_code == 409


def test_doctor_data_scope_is_limited_to_own_department(
    client: TestClient, seeded_db: Session
) -> None:
    admin, doctor, department, patient = _setup(seeded_db)
    headers = _headers(admin)
    _create(client, headers, doctor, department, patient)

    other_department = seeded_db.scalar(
        select(Department).where(Department.department_code == "SURGERY")
    )
    doctor_role = seeded_db.scalar(select(Role).where(Role.code == "DOCTOR"))
    assert other_department is not None and doctor_role is not None
    outsider = User(
        username="outside-doctor",
        password_hash=hash_password("Encounter@Test123"),
        real_name="外科医生",
        department_id=other_department.id,
        status=UserStatus.ACTIVE,
        is_active=True,
    )
    seeded_db.add(outsider)
    seeded_db.flush()
    seeded_db.add(UserRole(user_id=outsider.id, role_id=doctor_role.id))
    seeded_db.commit()

    result = client.get("/api/encounters", headers=_headers(outsider))
    assert result.status_code == 200
    assert result.json()["data"]["total"] == 0

