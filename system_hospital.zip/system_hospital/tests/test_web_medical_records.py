"""病历工作站与临床记录 Web 页面集成测试。"""

from datetime import datetime, timezone

from fastapi.testclient import TestClient
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.security import hash_password
from app.models.audit_log import AuditLog
from app.models.department import Department
from app.models.diagnosis import Diagnosis
from app.models.encounter import Encounter
from app.models.enums import (
    EncounterStatus,
    EncounterType,
    Gender,
    MedicalOrderStatus,
    MedicalRecordStatus,
    PrescriptionStatus,
    UserStatus,
)
from app.models.medical_order import MedicalOrder
from app.models.medical_record import MedicalRecord, MedicalRecordVersion
from app.models.patient import Patient
from app.models.prescription import Prescription, PrescriptionItem
from app.models.role import Role
from app.models.user import User, UserRole


PASSWORD = "RecordWeb@Test123"
COMPLETE_RECORD_FORM = {
    "chief_complaint": "咳嗽、发热三天",
    "present_illness": "受凉后出现咳嗽、发热，伴轻度乏力。",
    "past_history": "否认慢性病史",
    "personal_history": "无特殊",
    "family_history": "无特殊",
    "allergy_history": "无",
    "physical_exam": "体温 38.2℃，双肺呼吸音粗。",
    "auxiliary_exam": "血常规提示白细胞升高",
    "diagnosis_summary": "社区获得性肺炎",
    "treatment_plan": "抗感染及对症治疗",
    "doctor_notes": "注意复查体温",
}


def _login(client: TestClient, username: str, password: str = PASSWORD) -> None:
    response = client.post(
        "/login",
        data={"username": username, "password": password},
        follow_redirects=False,
    )
    assert response.status_code == 303


def _setup(db: Session) -> dict[str, object]:
    internal = db.scalar(
        select(Department).where(Department.department_code == "INTERNAL")
    )
    surgery = db.scalar(
        select(Department).where(Department.department_code == "SURGERY")
    )
    doctor_role = db.scalar(select(Role).where(Role.code == "DOCTOR"))
    nurse_role = db.scalar(select(Role).where(Role.code == "NURSE"))
    assert internal and surgery and doctor_role and nurse_role
    doctor = User(
        username="record-web-doctor",
        password_hash=hash_password(PASSWORD),
        real_name="病历页面医生",
        employee_no="RWD001",
        department_id=internal.id,
        status=UserStatus.ACTIVE,
        is_active=True,
    )
    outsider = User(
        username="record-web-outsider",
        password_hash=hash_password(PASSWORD),
        real_name="外科页面医生",
        employee_no="RWD002",
        department_id=surgery.id,
        status=UserStatus.ACTIVE,
        is_active=True,
    )
    nurse = User(
        username="record-web-nurse",
        password_hash=hash_password(PASSWORD),
        real_name="病历页面护士",
        employee_no="RWN001",
        department_id=internal.id,
        status=UserStatus.ACTIVE,
        is_active=True,
    )
    patient = Patient(
        patient_no="PWEBRECORD01",
        name="病历页面患者",
        gender=Gender.FEMALE,
    )
    db.add_all([doctor, outsider, nurse, patient])
    db.flush()
    db.add_all(
        [
            UserRole(user_id=doctor.id, role_id=doctor_role.id),
            UserRole(user_id=outsider.id, role_id=doctor_role.id),
            UserRole(user_id=nurse.id, role_id=nurse_role.id),
        ]
    )
    encounter = Encounter(
        encounter_no="EWEBRECORD01",
        patient_id=patient.id,
        doctor_id=doctor.id,
        department_id=internal.id,
        encounter_type=EncounterType.OUTPATIENT,
        visit_time=datetime.now(timezone.utc),
        status=EncounterStatus.IN_PROGRESS,
        chief_complaint="咳嗽、发热三天",
        created_by=doctor.id,
    )
    db.add(encounter)
    db.commit()
    return {
        "doctor": doctor,
        "outsider": outsider,
        "nurse": nurse,
        "encounter": encounter,
    }


def _create_record_from_web(
    client: TestClient, db: Session, encounter: Encounter
) -> MedicalRecord:
    response = client.post(
        f"/encounters/{encounter.id}/medical-record/new",
        data=COMPLETE_RECORD_FORM,
        follow_redirects=False,
    )
    assert response.status_code == 303, response.text
    record = db.scalar(
        select(MedicalRecord).where(
            MedicalRecord.encounter_id == encounter.id,
            MedicalRecord.deleted_at.is_(None),
        )
    )
    assert record is not None
    return record


def test_record_pages_require_authentication(client: TestClient) -> None:
    for path in ("/medical-records", "/medical-records/my", "/medical-records/drafts"):
        response = client.get(path, follow_redirects=False)
        assert response.status_code == 303
        assert response.headers["location"] == "/login"


def test_record_web_create_edit_and_data_scope(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    encounter = context["encounter"]
    assert isinstance(encounter, Encounter)
    _login(client, "record-web-doctor")

    create_page = client.get(
        f"/encounters/{encounter.id}/medical-record/new"
    )
    assert create_page.status_code == 200
    assert "创建病历草稿" in create_page.text
    record = _create_record_from_web(client, seeded_db, encounter)
    assert record.record_no.startswith("MR")
    assert record.status == MedicalRecordStatus.DRAFT

    workspace = client.get(f"/medical-records/{record.id}")
    assert workspace.status_code == 200
    assert "病历工作站" in workspace.text
    assert "病历页面患者" in workspace.text
    assert "抗感染及对症治疗" in workspace.text
    assert client.get("/medical-records/drafts").status_code == 200
    assert record.record_no in client.get("/medical-records/my").text

    edited = COMPLETE_RECORD_FORM | {"doctor_notes": "复查血常规和胸片"}
    update = client.post(
        f"/medical-records/{record.id}/edit",
        data=edited,
        follow_redirects=False,
    )
    assert update.status_code == 303
    seeded_db.refresh(record)
    assert record.doctor_notes == "复查血常规和胸片"

    client.post("/logout", follow_redirects=False)
    _login(client, "record-web-outsider")
    assert client.get(f"/medical-records/{record.id}").status_code == 403


def test_record_web_clinical_workstation_and_submit(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    encounter = context["encounter"]
    assert isinstance(encounter, Encounter)
    _login(client, "record-web-doctor")
    record = _create_record_from_web(client, seeded_db, encounter)

    diagnosis = client.post(
        f"/medical-records/{record.id}/diagnoses/new",
        data={
            "diagnosis_name": "社区获得性肺炎",
            "diagnosis_code": "J18.9",
            "diagnosis_type": "PRELIMINARY",
            "description": "结合症状考虑",
            "sort_order": "0",
            "is_primary": "on",
        },
        follow_redirects=False,
    )
    assert diagnosis.status_code == 303
    diagnosis_model = seeded_db.scalar(
        select(Diagnosis).where(Diagnosis.record_id == record.id)
    )
    assert diagnosis_model is not None and diagnosis_model.is_primary

    order = client.post(
        f"/medical-records/{record.id}/orders/new",
        data={
            "order_type": "MEDICATION",
            "order_content": "阿莫西林胶囊",
            "dosage": "0.5",
            "dosage_unit": "g",
            "frequency": "TID",
            "route": "PO",
            "start_time": "2026-09-06T10:00",
            "end_time": "",
            "remark": "饭后服用",
        },
        follow_redirects=False,
    )
    assert order.status_code == 303, order.text
    order_model = seeded_db.scalar(
        select(MedicalOrder).where(MedicalOrder.record_id == record.id)
    )
    assert order_model is not None

    prescription_response = client.post(
        f"/medical-records/{record.id}/prescriptions/new",
        data={"prescription_type": "OUTPATIENT", "notes": "门诊处方"},
        follow_redirects=False,
    )
    assert prescription_response.status_code == 303
    prescription = seeded_db.scalar(
        select(Prescription).where(Prescription.record_id == record.id)
    )
    assert prescription is not None
    item_response = client.post(
        f"/medical-records/{record.id}/prescriptions/{prescription.id}/items/new",
        data={
            "drug_name": "阿莫西林胶囊",
            "specification": "0.25g",
            "dosage": "0.5",
            "dosage_unit": "g",
            "frequency": "TID",
            "route": "PO",
            "duration": "5",
            "duration_unit": "天",
            "quantity": "30",
            "quantity_unit": "粒",
            "usage_instruction": "饭后口服",
            "sort_order": "0",
        },
        follow_redirects=False,
    )
    assert item_response.status_code == 303, item_response.text
    assert seeded_db.scalar(
        select(PrescriptionItem).where(
            PrescriptionItem.prescription_id == prescription.id
        )
    ) is not None

    issue = client.post(
        f"/medical-records/{record.id}/prescriptions/{prescription.id}/issue",
        follow_redirects=False,
    )
    assert issue.status_code == 303
    seeded_db.refresh(prescription)
    assert prescription.status == PrescriptionStatus.ISSUED

    submit = client.post(
        f"/medical-records/{record.id}/submit", follow_redirects=False
    )
    assert submit.status_code == 303
    seeded_db.refresh(record)
    assert record.status == MedicalRecordStatus.SUBMITTED
    version = seeded_db.scalar(
        select(MedicalRecordVersion).where(
            MedicalRecordVersion.record_id == record.id
        )
    )
    assert version is not None and version.version == 1
    snapshot = version.snapshot_data
    assert snapshot["diagnoses"][0]["diagnosis_name"] == "社区获得性肺炎"
    assert snapshot["medical_orders"][0]["order_content"] == "阿莫西林胶囊"
    assert snapshot["prescriptions"][0]["items"][0]["drug_name"] == "阿莫西林胶囊"

    locked = client.get(f"/medical-records/{record.id}/edit")
    assert locked.status_code == 409
    workspace = client.get(f"/medical-records/{record.id}")
    assert workspace.status_code == 200
    assert "待审核" in workspace.text
    versions = client.get(f"/medical-records/{record.id}/versions")
    assert versions.status_code == 200
    assert "V1" in versions.text
    assert client.get(f"/medical-records/{record.id}/versions/1").status_code == 200


def test_submit_validation_and_clinical_status_actions(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    encounter = context["encounter"]
    assert isinstance(encounter, Encounter)
    _login(client, "record-web-doctor")
    record = _create_record_from_web(client, seeded_db, encounter)

    failed = client.post(
        f"/medical-records/{record.id}/submit", follow_redirects=False
    )
    assert failed.status_code == 303
    message_page = client.get(failed.headers["location"])
    assert "diagnoses" in message_page.text
    seeded_db.refresh(record)
    assert record.status == MedicalRecordStatus.DRAFT

    client.post(
        f"/medical-records/{record.id}/orders/new",
        data={
            "order_type": "TREATMENT",
            "order_content": "雾化吸入",
            "start_time": "",
            "end_time": "",
        },
        follow_redirects=False,
    )
    order = seeded_db.scalar(
        select(MedicalOrder).where(MedicalOrder.record_id == record.id)
    )
    assert order is not None
    stopped = client.post(
        f"/medical-records/{record.id}/orders/{order.id}/stop",
        follow_redirects=False,
    )
    assert stopped.status_code == 303
    seeded_db.refresh(order)
    assert order.status == MedicalOrderStatus.STOPPED

    repeated = client.post(
        f"/medical-records/{record.id}/orders/{order.id}/complete",
        follow_redirects=False,
    )
    assert repeated.status_code == 303
    page = client.get(repeated.headers["location"])
    assert "医嘱状态不能" in page.text


def test_nurse_cannot_open_record_write_pages(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    encounter = context["encounter"]
    assert isinstance(encounter, Encounter)
    _login(client, "record-web-nurse")

    assert client.get("/medical-records").status_code == 200
    assert (
        client.get(f"/encounters/{encounter.id}/medical-record/new").status_code
        == 403
    )
    assert client.get("/medical-records/1/diagnoses/new").status_code == 403
    assert client.get("/medical-records/1/orders/new").status_code == 403
    assert client.get("/medical-records/1/prescriptions/new").status_code == 403


def test_draft_delete_and_duplicate_create_entry(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    encounter = context["encounter"]
    assert isinstance(encounter, Encounter)
    _login(client, "record-web-doctor")
    record = _create_record_from_web(client, seeded_db, encounter)

    duplicate_page = client.get(
        f"/encounters/{encounter.id}/medical-record/new",
        follow_redirects=False,
    )
    assert duplicate_page.status_code == 303
    assert duplicate_page.headers["location"] == f"/medical-records/{record.id}"

    deleted = client.post(
        f"/medical-records/{record.id}/delete",
        follow_redirects=False,
    )
    assert deleted.status_code == 303
    seeded_db.refresh(record)
    assert record.deleted_at is not None
    assert client.get(f"/medical-records/{record.id}").status_code == 404


def test_workstation_actions_write_audit_log(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    encounter = context["encounter"]
    assert isinstance(encounter, Encounter)
    _login(client, "record-web-doctor")
    record = _create_record_from_web(client, seeded_db, encounter)
    client.post(
        f"/medical-records/{record.id}/diagnoses/new",
        data={
            "diagnosis_name": "上呼吸道感染",
            "diagnosis_type": "PRELIMINARY",
            "sort_order": "0",
            "is_primary": "on",
        },
        follow_redirects=False,
    )
    client.post(
        f"/medical-records/{record.id}/orders/new",
        data={
            "order_type": "TREATMENT",
            "order_content": "对症治疗",
            "start_time": "",
            "end_time": "",
        },
        follow_redirects=False,
    )
    actions = set(seeded_db.scalars(select(AuditLog.action)).all())
    assert {
        "MEDICAL_RECORD_CREATE",
        "DIAGNOSIS_CREATE",
        "MEDICAL_ORDER_CREATE",
    } <= actions


def test_clinical_record_web_update_delete_and_cancel(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    encounter = context["encounter"]
    assert isinstance(encounter, Encounter)
    _login(client, "record-web-doctor")
    record = _create_record_from_web(client, seeded_db, encounter)

    client.post(
        f"/medical-records/{record.id}/diagnoses/new",
        data={
            "diagnosis_name": "待修改诊断",
            "diagnosis_type": "PRELIMINARY",
            "sort_order": "0",
        },
        follow_redirects=False,
    )
    diagnosis = seeded_db.scalar(
        select(Diagnosis).where(Diagnosis.record_id == record.id)
    )
    assert diagnosis is not None
    assert (
        client.get(
            f"/medical-records/{record.id}/diagnoses/{diagnosis.id}/edit"
        ).status_code
        == 200
    )
    updated_diagnosis = client.post(
        f"/medical-records/{record.id}/diagnoses/{diagnosis.id}/edit",
        data={
            "diagnosis_name": "已修改诊断",
            "diagnosis_type": "FINAL",
            "sort_order": "1",
            "is_primary": "on",
        },
        follow_redirects=False,
    )
    assert updated_diagnosis.status_code == 303
    seeded_db.refresh(diagnosis)
    assert diagnosis.diagnosis_name == "已修改诊断"
    assert diagnosis.is_primary is True
    deleted_diagnosis = client.post(
        f"/medical-records/{record.id}/diagnoses/{diagnosis.id}/delete",
        follow_redirects=False,
    )
    assert deleted_diagnosis.status_code == 303
    seeded_db.refresh(diagnosis)
    assert diagnosis.deleted_at is not None

    client.post(
        f"/medical-records/{record.id}/orders/new",
        data={
            "order_type": "TREATMENT",
            "order_content": "原医嘱",
            "start_time": "",
            "end_time": "",
        },
        follow_redirects=False,
    )
    order = seeded_db.scalar(
        select(MedicalOrder).where(MedicalOrder.record_id == record.id)
    )
    assert order is not None
    assert (
        client.get(
            f"/medical-records/{record.id}/orders/{order.id}/edit"
        ).status_code
        == 200
    )
    updated_order = client.post(
        f"/medical-records/{record.id}/orders/{order.id}/edit",
        data={
            "order_type": "TREATMENT",
            "order_content": "已修改医嘱",
            "start_time": "",
            "end_time": "",
        },
        follow_redirects=False,
    )
    assert updated_order.status_code == 303
    seeded_db.refresh(order)
    assert order.order_content == "已修改医嘱"
    deleted_order = client.post(
        f"/medical-records/{record.id}/orders/{order.id}/delete",
        follow_redirects=False,
    )
    assert deleted_order.status_code == 303
    seeded_db.refresh(order)
    assert order.deleted_at is not None

    client.post(
        f"/medical-records/{record.id}/prescriptions/new",
        data={"prescription_type": "OUTPATIENT", "notes": "原备注"},
        follow_redirects=False,
    )
    prescription = seeded_db.scalar(
        select(Prescription).where(Prescription.record_id == record.id)
    )
    assert prescription is not None
    changed_prescription = client.post(
        f"/medical-records/{record.id}/prescriptions/{prescription.id}/edit",
        data={"prescription_type": "OUTPATIENT", "notes": "已修改备注"},
        follow_redirects=False,
    )
    assert changed_prescription.status_code == 303
    seeded_db.refresh(prescription)
    assert prescription.notes == "已修改备注"

    client.post(
        f"/medical-records/{record.id}/prescriptions/{prescription.id}/items/new",
        data={
            "drug_name": "原药品",
            "dosage": "1",
            "frequency": "QD",
            "quantity": "2",
            "sort_order": "0",
        },
        follow_redirects=False,
    )
    item = seeded_db.scalar(
        select(PrescriptionItem).where(
            PrescriptionItem.prescription_id == prescription.id
        )
    )
    assert item is not None
    assert (
        client.get(
            f"/medical-records/{record.id}/prescriptions/"
            f"{prescription.id}/items/{item.id}/edit"
        ).status_code
        == 200
    )
    changed_item = client.post(
        f"/medical-records/{record.id}/prescriptions/"
        f"{prescription.id}/items/{item.id}/edit",
        data={
            "drug_name": "已修改药品",
            "dosage": "1",
            "frequency": "BID",
            "quantity": "4",
            "sort_order": "0",
        },
        follow_redirects=False,
    )
    assert changed_item.status_code == 303
    seeded_db.refresh(item)
    assert item.drug_name == "已修改药品"
    assert item.frequency == "BID"

    removed_item = client.post(
        f"/medical-records/{record.id}/prescriptions/"
        f"{prescription.id}/items/{item.id}/delete",
        follow_redirects=False,
    )
    assert removed_item.status_code == 303
    seeded_db.refresh(item)
    assert item.deleted_at is not None
    workspace = client.get(f"/medical-records/{record.id}")
    assert workspace.status_code == 200
    assert "已修改药品" not in workspace.text
    cancelled = client.post(
        f"/medical-records/{record.id}/prescriptions/{prescription.id}/cancel",
        data={"reason": "患者治疗方案调整"},
        follow_redirects=False,
    )
    assert cancelled.status_code == 303
    seeded_db.refresh(prescription)
    assert prescription.status == PrescriptionStatus.CANCELLED
