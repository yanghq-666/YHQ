"""审核工作站 Web 页面、操作、权限与受保护附件集成测试。"""

from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.models.enums import MedicalRecordStatus
from app.models.medical_record import MedicalRecord
from tests.test_clinical_records import _create_diagnosis
from tests.test_record_reviews import _headers, _setup, _submit


def _login(
    client: TestClient,
    username: str,
    password: str = "Review@Test123",
) -> None:
    response = client.post(
        "/login",
        data={"username": username, "password": password},
        follow_redirects=False,
    )
    assert response.status_code == 303


def _submitted(
    client: TestClient, db: Session
) -> tuple[dict[str, object], MedicalRecord]:
    context = _setup(db)
    record = context["record"]
    assert isinstance(record, MedicalRecord)
    _create_diagnosis(client, record, context["doctor"])
    response = _submit(client, context)
    assert response.status_code == 200
    return context, record


def _start(
    client: TestClient,
    context: dict[str, object],
    record: MedicalRecord,
) -> None:
    response = client.post(
        f"/api/medical-records/{record.id}/review/start",
        headers=_headers(context["senior_a"]),
    )
    assert response.status_code == 200


def test_review_pages_require_login(client: TestClient) -> None:
    for path in ("/reviews/pending", "/reviews/reviewing", "/reviews/mine"):
        response = client.get(path, follow_redirects=False)
        assert response.status_code == 303
        assert response.headers["location"] == "/login"


def test_doctor_cannot_open_review_workstation(
    client: TestClient, seeded_db: Session
) -> None:
    _setup(seeded_db)
    _login(client, "review-doctor")
    assert client.get("/reviews/pending").status_code == 403


def test_pending_page_filters_and_opens_read_only_detail(
    client: TestClient, seeded_db: Session
) -> None:
    context, record = _submitted(client, seeded_db)
    _login(client, "review-senior-a")
    response = client.get(
        "/reviews/pending",
        params={
            "patient_name": "审核测试",
            "record_no": "MRREVIEW",
            "department_name": "内科",
            "doctor_name": "经治医生",
        },
    )
    assert response.status_code == 200
    assert record.record_no in response.text
    detail = client.get(f"/reviews/{record.id}")
    assert detail.status_code == 200
    assert "审核工作站仅提供只读查看" in detail.text
    assert "病历正文" in detail.text and "审核历史" in detail.text


def test_start_review_from_web_acquires_lock(
    client: TestClient, seeded_db: Session
) -> None:
    _context, record = _submitted(client, seeded_db)
    _login(client, "review-senior-a")
    response = client.post(
        f"/reviews/{record.id}/start", follow_redirects=False
    )
    assert response.status_code == 303
    seeded_db.refresh(record)
    assert record.status == MedicalRecordStatus.REVIEWING
    detail = client.get(f"/reviews/{record.id}")
    assert "您已取得审核锁" in detail.text
    assert "审核通过" in detail.text and "退回修改" in detail.text


def test_reject_requires_valid_comment(
    client: TestClient, seeded_db: Session
) -> None:
    context, record = _submitted(client, seeded_db)
    _start(client, context, record)
    _login(client, "review-senior-a")
    response = client.post(
        f"/reviews/{record.id}/reject",
        data={"comment": "短"},
        follow_redirects=False,
    )
    assert response.status_code == 303
    seeded_db.refresh(record)
    assert record.status == MedicalRecordStatus.REVIEWING


def test_rejected_record_shows_reason_reviewer_and_edit_action(
    client: TestClient, seeded_db: Session
) -> None:
    context, record = _submitted(client, seeded_db)
    _start(client, context, record)
    _login(client, "review-senior-a")
    response = client.post(
        f"/reviews/{record.id}/reject",
        data={"comment": "请补充现病史和治疗方案"},
        follow_redirects=False,
    )
    assert response.status_code == 303
    client.post("/logout", follow_redirects=False)
    _login(client, "review-doctor")
    detail = client.get(f"/medical-records/{record.id}")
    assert detail.status_code == 200
    assert "请补充现病史和治疗方案" in detail.text
    assert "审核主任甲" in detail.text
    assert "编辑病历" in detail.text and "重新提交" in detail.text


def test_rejected_record_can_be_edited_and_resubmitted_as_v2(
    client: TestClient, seeded_db: Session
) -> None:
    context, record = _submitted(client, seeded_db)
    _start(client, context, record)
    reject = client.post(
        f"/api/medical-records/{record.id}/review/reject",
        headers=_headers(context["senior_a"]),
        json={"comment": "请补充更完整的现病史"},
    )
    assert reject.status_code == 200
    changed = client.patch(
        f"/api/medical-records/{record.id}",
        headers=_headers(context["doctor"]),
        json={"present_illness": "已补充现病史及鉴别诊断"},
    )
    assert changed.status_code == 200
    _login(client, "review-doctor")
    response = client.post(
        f"/medical-records/{record.id}/submit",
        data={"change_reason": "根据审核意见补充现病史"},
        follow_redirects=False,
    )
    assert response.status_code == 303
    versions = client.get(f"/medical-records/{record.id}/versions")
    assert "V2" in versions.text


def test_second_reviewer_cannot_take_existing_review_lock(
    client: TestClient, seeded_db: Session
) -> None:
    context, record = _submitted(client, seeded_db)
    _start(client, context, record)
    _login(client, "review-senior-b")
    detail = client.get(f"/reviews/{record.id}")
    assert "正在由其他审核医生处理" in detail.text
    response = client.post(
        f"/reviews/{record.id}/start", follow_redirects=True
    )
    assert response.status_code == 200
    assert "该病历正在由其他审核医生处理" in response.text


def test_approve_updates_mine_page_and_review_timeline(
    client: TestClient, seeded_db: Session
) -> None:
    context, record = _submitted(client, seeded_db)
    _start(client, context, record)
    _login(client, "review-senior-a")
    response = client.post(
        f"/reviews/{record.id}/approve",
        data={"comment": "内容完整，同意通过"},
        follow_redirects=False,
    )
    assert response.status_code == 303
    seeded_db.refresh(record)
    assert record.status == MedicalRecordStatus.APPROVED
    assert record.approved_version == 1
    mine = client.get("/reviews/mine", params={"action": "APPROVE"})
    assert record.record_no in mine.text and "内容完整，同意通过" in mine.text
    detail = client.get(f"/reviews/{record.id}")
    assert "开始审核" in detail.text and "审核通过" in detail.text


def test_review_version_and_attachment_use_protected_web_routes(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    record = context["record"]
    assert isinstance(record, MedicalRecord)
    _create_diagnosis(client, record, context["doctor"])
    uploaded = client.post(
        f"/api/medical-records/{record.id}/attachments",
        headers=_headers(context["doctor"]),
        data={"category": "MEDICAL_RECORD", "description": "审核附件"},
        files={"file": ("report.pdf", b"%PDF-1.4\nreview", "application/pdf")},
    )
    assert uploaded.status_code == 201
    attachment_id = uploaded.json()["data"]["id"]
    assert _submit(client, context).status_code == 200
    _login(client, "review-senior-a")
    detail = client.get(f"/reviews/{record.id}")
    assert f"/attachments/{attachment_id}/content" in detail.text
    version = client.get(f"/reviews/{record.id}/versions/1")
    assert version.status_code == 200 and "不可变" in version.text
    content = client.get(f"/attachments/{attachment_id}/content")
    assert content.status_code == 200
    assert content.headers["content-type"].startswith("application/pdf")


def test_review_navigation_legacy_route_and_existing_pages(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    record = context["record"]
    assert isinstance(record, MedicalRecord)
    _login(client, "review-senior-a")
    legacy = client.get("/reviews/my", follow_redirects=False)
    assert legacy.status_code == 308
    assert legacy.headers["location"] == "/reviews/mine"
    for path in (
        "/reviews/pending",
        "/reviews/reviewing",
        "/reviews/mine",
        "/patients",
        "/encounters",
        "/medical-records/my",
        "/docs",
    ):
        assert client.get(path).status_code == 200, path
