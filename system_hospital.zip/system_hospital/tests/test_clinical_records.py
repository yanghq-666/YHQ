"""诊断、医嘱、处方、完整快照和临床锁定测试。"""

import re
from datetime import datetime, timezone

from fastapi.testclient import TestClient
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.security import create_access_token, hash_password
from app.models.audit_log import AuditLog
from app.models.department import Department
from app.models.diagnosis import Diagnosis
from app.models.encounter import Encounter
from app.models.enums import (
    EncounterStatus,
    EncounterType,
    Gender,
    MedicalRecordStatus,
    UserStatus,
)
from app.models.medical_record import MedicalRecord
from app.models.patient import Patient
from app.models.prescription import Prescription
from app.models.role import Role
from app.models.user import User, UserRole


def _headers(user: User) -> dict[str, str]:
    token = create_access_token(user.id, user.username)
    return {"Authorization": f"Bearer {token}"}


def _setup(db: Session) -> dict[str, object]:
    admin = db.scalar(select(User).where(User.username == "admin"))
    internal = db.scalar(
        select(Department).where(Department.department_code == "INTERNAL")
    )
    surgery = db.scalar(
        select(Department).where(Department.department_code == "SURGERY")
    )
    doctor_role = db.scalar(select(Role).where(Role.code == "DOCTOR"))
    nurse_role = db.scalar(select(Role).where(Role.code == "NURSE"))
    assert admin and internal and surgery and doctor_role and nurse_role
    doctor = User(
        username="clinical-doctor",
        password_hash=hash_password("Clinical@Test123"),
        real_name="临床测试医生",
        employee_no="CD001",
        department_id=internal.id,
        status=UserStatus.ACTIVE,
        is_active=True,
    )
    outsider = User(
        username="clinical-outsider",
        password_hash=hash_password("Clinical@Test123"),
        real_name="外科测试医生",
        employee_no="CD002",
        department_id=surgery.id,
        status=UserStatus.ACTIVE,
        is_active=True,
    )
    nurse = User(
        username="clinical-nurse",
        password_hash=hash_password("Clinical@Test123"),
        real_name="临床测试护士",
        employee_no="CN001",
        department_id=internal.id,
        status=UserStatus.ACTIVE,
        is_active=True,
    )
    patient = Patient(
        patient_no="PCLINICAL001",
        name="临床测试患者",
        gender=Gender.MALE,
    )
    db.add_all([doctor, outsider, nurse, patient])
    db.flush()
    db.add_all(
        [
            UserRole(user_id=doctor.id, role_id=doctor_role.id),
            UserRole(user_id=outsider.id, role_id=doctor_role.id),
            UserRole(user_id=nurse.id, role_id=nurse_role.id),
        ]
    )
    encounter = Encounter(
        encounter_no="ECLINICAL001",
        patient_id=patient.id,
        doctor_id=doctor.id,
        department_id=internal.id,
        encounter_type=EncounterType.OUTPATIENT,
        visit_time=datetime.now(timezone.utc),
        status=EncounterStatus.IN_PROGRESS,
        created_by=doctor.id,
    )
    db.add(encounter)
    db.flush()
    record = MedicalRecord(
        record_no="MRCLINICAL001",
        encounter_id=encounter.id,
        chief_complaint="发热、咳嗽",
        present_illness="发热咳嗽三天",
        physical_exam="体温38℃，呼吸音粗",
        diagnosis_summary="呼吸道感染",
        treatment_plan="对症治疗",
        status=MedicalRecordStatus.DRAFT,
        created_by=doctor.id,
        updated_by=doctor.id,
    )
    db.add(record)
    db.commit()
    return {
        "admin": admin,
        "doctor": doctor,
        "outsider": outsider,
        "nurse": nurse,
        "patient": patient,
        "encounter": encounter,
        "record": record,
    }


def _diagnosis_payload(**overrides: object) -> dict[str, object]:
    payload: dict[str, object] = {
        "diagnosis_name": "社区获得性肺炎",
        "diagnosis_code": "J18.9",
        "diagnosis_type": "PRELIMINARY",
        "description": "结合症状考虑",
        "is_primary": True,
        "sort_order": 0,
    }
    payload.update(overrides)
    return payload


def _order_payload(**overrides: object) -> dict[str, object]:
    payload: dict[str, object] = {
        "order_type": "MEDICATION",
        "order_content": "阿莫西林胶囊",
        "dosage": "0.5",
        "dosage_unit": "g",
        "frequency": "TID",
        "route": "PO",
        "start_time": "2026-09-06T10:00:00+08:00",
    }
    payload.update(overrides)
    return payload


def _item_payload(**overrides: object) -> dict[str, object]:
    payload: dict[str, object] = {
        "drug_name": "阿莫西林胶囊",
        "specification": "0.25g",
        "dosage": "0.5",
        "dosage_unit": "g",
        "frequency": "TID",
        "route": "PO",
        "duration": 5,
        "duration_unit": "day",
        "quantity": 30,
        "quantity_unit": "粒",
        "usage_instruction": "饭后口服",
    }
    payload.update(overrides)
    return payload


def _create_diagnosis(
    client: TestClient, record: MedicalRecord, user: User, **overrides: object
) -> dict[str, object]:
    response = client.post(
        f"/api/medical-records/{record.id}/diagnoses",
        headers=_headers(user),
        json=_diagnosis_payload(**overrides),
    )
    assert response.status_code == 201, response.text
    return response.json()["data"]


def _create_order(
    client: TestClient, record: MedicalRecord, user: User, **overrides: object
) -> dict[str, object]:
    response = client.post(
        f"/api/medical-records/{record.id}/orders",
        headers=_headers(user),
        json=_order_payload(**overrides),
    )
    assert response.status_code == 201, response.text
    return response.json()["data"]


def _create_prescription(
    client: TestClient,
    record: MedicalRecord,
    user: User,
    *,
    items: list[dict[str, object]] | None = None,
) -> dict[str, object]:
    response = client.post(
        f"/api/medical-records/{record.id}/prescriptions",
        headers=_headers(user),
        json={
            "prescription_type": "OUTPATIENT",
            "notes": "测试处方",
            "items": items or [],
        },
    )
    assert response.status_code == 201, response.text
    return response.json()["data"]


def test_diagnosis_crud_and_same_type_primary_is_replaced(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    doctor = context["doctor"]
    record = context["record"]
    assert isinstance(doctor, User) and isinstance(record, MedicalRecord)
    first = _create_diagnosis(client, record, doctor)
    second = _create_diagnosis(
        client, record, doctor, diagnosis_name="细菌性肺炎", sort_order=1
    )
    listed = client.get(
        f"/api/medical-records/{record.id}/diagnoses",
        headers=_headers(doctor),
    )
    first_stored = seeded_db.get(Diagnosis, first["id"])
    assert first_stored is not None and first_stored.is_primary is False
    assert listed.json()["data"][0]["id"] == second["id"]

    updated = client.patch(
        f"/api/diagnoses/{second['id']}",
        headers=_headers(doctor),
        json={"diagnosis_name": "细菌性肺炎（修订）"},
    )
    deleted = client.delete(
        f"/api/diagnoses/{first['id']}", headers=_headers(doctor)
    )
    assert updated.status_code == 200
    assert deleted.status_code == 200
    assert len(
        client.get(
            f"/api/medical-records/{record.id}/diagnoses",
            headers=_headers(doctor),
        ).json()["data"]
    ) == 1


def test_diagnosis_permission_and_submitted_lock(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    doctor = context["doctor"]
    nurse = context["nurse"]
    record = context["record"]
    assert isinstance(doctor, User) and isinstance(nurse, User)
    assert isinstance(record, MedicalRecord)
    denied = client.post(
        f"/api/medical-records/{record.id}/diagnoses",
        headers=_headers(nurse),
        json=_diagnosis_payload(),
    )
    record.status = MedicalRecordStatus.SUBMITTED
    seeded_db.commit()
    locked = client.post(
        f"/api/medical-records/{record.id}/diagnoses",
        headers=_headers(doctor),
        json=_diagnosis_payload(),
    )
    assert denied.status_code == 403
    assert locked.status_code == 409


def test_medical_order_number_update_stop_and_filters(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    doctor = context["doctor"]
    record = context["record"]
    assert isinstance(doctor, User) and isinstance(record, MedicalRecord)
    first = _create_order(client, record, doctor)
    second = _create_order(
        client, record, doctor, order_type="LAB", order_content="血常规"
    )
    assert re.fullmatch(r"MO\d{8}\d{6}", str(first["order_no"]))
    assert first["order_no"] != second["order_no"]
    updated = client.patch(
        f"/api/orders/{first['id']}",
        headers=_headers(doctor),
        json={"dosage": "0.75"},
    )
    stopped = client.post(
        f"/api/orders/{first['id']}/stop", headers=_headers(doctor)
    )
    repeated = client.post(
        f"/api/orders/{first['id']}/stop", headers=_headers(doctor)
    )
    cannot_delete = client.delete(
        f"/api/orders/{first['id']}", headers=_headers(doctor)
    )
    filtered = client.get(
        f"/api/medical-records/{record.id}/orders?order_type=LAB",
        headers=_headers(doctor),
    )
    assert updated.json()["data"]["dosage"] == "0.75"
    assert stopped.json()["data"]["status"] == "STOPPED"
    assert stopped.json()["data"]["stopped_at"] is not None
    assert repeated.status_code == 409
    assert cannot_delete.status_code == 409
    assert [item["id"] for item in filtered.json()["data"]] == [second["id"]]


def test_medical_order_complete_delete_permission_and_record_lock(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    doctor = context["doctor"]
    nurse = context["nurse"]
    record = context["record"]
    assert isinstance(doctor, User) and isinstance(nurse, User)
    assert isinstance(record, MedicalRecord)
    order = _create_order(client, record, doctor)
    no_permission = client.patch(
        f"/api/orders/{order['id']}",
        headers=_headers(nurse),
        json={"remark": "护士修改"},
    )
    completed = client.post(
        f"/api/orders/{order['id']}/complete", headers=_headers(doctor)
    )
    active = _create_order(client, record, doctor, order_content="可删除医嘱")
    deleted = client.delete(
        f"/api/orders/{active['id']}", headers=_headers(doctor)
    )
    locked_order = _create_order(client, record, doctor, order_content="锁定医嘱")
    record.status = MedicalRecordStatus.SUBMITTED
    seeded_db.commit()
    locked = client.patch(
        f"/api/orders/{locked_order['id']}",
        headers=_headers(doctor),
        json={"remark": "不允许"},
    )
    assert no_permission.status_code == 403
    assert completed.json()["data"]["status"] == "COMPLETED"
    assert deleted.status_code == 200
    assert locked.status_code == 409


def test_prescription_transaction_numbers_and_item_crud(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    doctor = context["doctor"]
    record = context["record"]
    assert isinstance(doctor, User) and isinstance(record, MedicalRecord)
    invalid = client.post(
        f"/api/medical-records/{record.id}/prescriptions",
        headers=_headers(doctor),
        json={
            "prescription_type": "OUTPATIENT",
            "items": [_item_payload(), {"frequency": "BID"}],
        },
    )
    assert invalid.status_code == 422
    assert seeded_db.scalar(select(func.count(Prescription.id))) == 0

    first = _create_prescription(
        client, record, doctor, items=[_item_payload(), _item_payload(drug_name="布洛芬")]
    )
    second = _create_prescription(client, record, doctor)
    assert re.fullmatch(r"RX\d{8}\d{6}", str(first["prescription_no"]))
    assert first["prescription_no"] != second["prescription_no"]
    assert len(first["items"]) == 2

    added = client.post(
        f"/api/prescriptions/{first['id']}/items",
        headers=_headers(doctor),
        json=_item_payload(drug_name="氯雷他定", sort_order=3),
    )
    item_id = added.json()["data"]["id"]
    updated = client.patch(
        f"/api/prescription-items/{item_id}",
        headers=_headers(doctor),
        json={"quantity": 20},
    )
    deleted = client.delete(
        f"/api/prescription-items/{item_id}", headers=_headers(doctor)
    )
    detail = client.get(
        f"/api/prescriptions/{first['id']}", headers=_headers(doctor)
    )
    listed = client.get(
        f"/api/medical-records/{record.id}/prescriptions",
        headers=_headers(doctor),
    )
    assert updated.json()["data"]["quantity"] == "20.000"
    assert deleted.status_code == 200
    assert len(detail.json()["data"]["items"]) == 2
    assert listed.json()["data"][0]["item_count"] in {0, 2}


def test_prescription_issue_item_lock_cancel_and_permission(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    doctor = context["doctor"]
    nurse = context["nurse"]
    record = context["record"]
    assert isinstance(doctor, User) and isinstance(nurse, User)
    assert isinstance(record, MedicalRecord)
    prescription = _create_prescription(client, record, doctor)
    empty_issue = client.post(
        f"/api/prescriptions/{prescription['id']}/issue",
        headers=_headers(doctor),
    )
    added = client.post(
        f"/api/prescriptions/{prescription['id']}/items",
        headers=_headers(doctor),
        json=_item_payload(),
    ).json()["data"]
    denied = client.post(
        f"/api/prescriptions/{prescription['id']}/issue",
        headers=_headers(nurse),
    )
    issued = client.post(
        f"/api/prescriptions/{prescription['id']}/issue",
        headers=_headers(doctor),
    )
    item_locked = client.patch(
        f"/api/prescription-items/{added['id']}",
        headers=_headers(doctor),
        json={"quantity": 10},
    )
    cancelled = client.post(
        f"/api/prescriptions/{prescription['id']}/cancel",
        headers=_headers(doctor),
        json={"reason": "患者药物过敏"},
    )
    assert empty_issue.status_code == 400
    assert denied.status_code == 403
    assert issued.json()["data"]["status"] == "ISSUED"
    assert item_locked.status_code == 409
    assert cancelled.json()["data"]["status"] == "CANCELLED"
    assert cancelled.json()["data"]["cancel_reason"] == "患者药物过敏"


def test_submit_requires_diagnosis_and_primary_diagnosis(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    doctor = context["doctor"]
    record = context["record"]
    assert isinstance(doctor, User) and isinstance(record, MedicalRecord)
    no_diagnosis = client.post(
        f"/api/medical-records/{record.id}/submit", headers=_headers(doctor)
    )
    diagnosis = _create_diagnosis(client, record, doctor, is_primary=False)
    no_primary = client.post(
        f"/api/medical-records/{record.id}/submit", headers=_headers(doctor)
    )
    client.patch(
        f"/api/diagnoses/{diagnosis['id']}",
        headers=_headers(doctor),
        json={"is_primary": True},
    )
    submitted = client.post(
        f"/api/medical-records/{record.id}/submit", headers=_headers(doctor)
    )
    assert no_diagnosis.status_code == 422
    assert no_diagnosis.json()["data"]["missing_fields"] == ["diagnoses"]
    assert no_primary.json()["data"]["missing_fields"] == [
        "primary_diagnosis"
    ]
    assert submitted.json()["data"]["status"] == "SUBMITTED"


def test_submission_snapshot_contains_all_clinical_data_and_locks_children(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    doctor = context["doctor"]
    record = context["record"]
    assert isinstance(doctor, User) and isinstance(record, MedicalRecord)
    diagnosis = _create_diagnosis(client, record, doctor)
    order = _create_order(client, record, doctor)
    prescription = _create_prescription(
        client, record, doctor, items=[_item_payload()]
    )
    client.post(
        f"/api/prescriptions/{prescription['id']}/issue",
        headers=_headers(doctor),
    )
    submitted = client.post(
        f"/api/medical-records/{record.id}/submit", headers=_headers(doctor)
    )
    version = client.get(
        f"/api/medical-records/{record.id}/versions/1",
        headers=_headers(doctor),
    ).json()["data"]["snapshot_data"]
    assert submitted.status_code == 200
    assert version["medical_record"]["status"] == "DRAFT"
    assert version["diagnoses"][0]["id"] == diagnosis["id"]
    assert version["medical_orders"][0]["id"] == order["id"]
    assert version["prescriptions"][0]["prescription"]["id"] == prescription["id"]
    assert len(version["prescriptions"][0]["items"]) == 1

    diagnosis_locked = client.patch(
        f"/api/diagnoses/{diagnosis['id']}",
        headers=_headers(doctor),
        json={"description": "不允许修改"},
    )
    order_locked = client.patch(
        f"/api/orders/{order['id']}",
        headers=_headers(doctor),
        json={"remark": "不允许修改"},
    )
    prescription_locked = client.patch(
        f"/api/prescriptions/{prescription['id']}",
        headers=_headers(doctor),
        json={"notes": "不允许修改"},
    )
    assert diagnosis_locked.status_code == 409
    assert order_locked.status_code == 409
    assert prescription_locked.status_code == 409


def test_key_operations_create_audit_logs(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    doctor = context["doctor"]
    record = context["record"]
    assert isinstance(doctor, User) and isinstance(record, MedicalRecord)
    diagnosis = _create_diagnosis(client, record, doctor)
    client.patch(
        f"/api/diagnoses/{diagnosis['id']}",
        headers=_headers(doctor),
        json={"sort_order": 2},
    )
    client.delete(
        f"/api/diagnoses/{diagnosis['id']}", headers=_headers(doctor)
    )
    order = _create_order(client, record, doctor)
    client.patch(
        f"/api/orders/{order['id']}",
        headers=_headers(doctor),
        json={"remark": "更新"},
    )
    client.post(f"/api/orders/{order['id']}/stop", headers=_headers(doctor))
    prescription = _create_prescription(
        client, record, doctor, items=[_item_payload()]
    )
    client.patch(
        f"/api/prescriptions/{prescription['id']}",
        headers=_headers(doctor),
        json={"notes": "更新"},
    )
    added = client.post(
        f"/api/prescriptions/{prescription['id']}/items",
        headers=_headers(doctor),
        json=_item_payload(drug_name="布洛芬"),
    ).json()["data"]
    client.patch(
        f"/api/prescription-items/{added['id']}",
        headers=_headers(doctor),
        json={"sort_order": 2},
    )
    client.delete(
        f"/api/prescription-items/{added['id']}", headers=_headers(doctor)
    )
    client.post(
        f"/api/prescriptions/{prescription['id']}/issue",
        headers=_headers(doctor),
    )
    client.post(
        f"/api/prescriptions/{prescription['id']}/cancel",
        headers=_headers(doctor),
        json={"reason": "测试取消"},
    )
    actions = set(seeded_db.scalars(select(AuditLog.action)).all())
    assert {
        "DIAGNOSIS_CREATE",
        "DIAGNOSIS_UPDATE",
        "DIAGNOSIS_DELETE",
        "MEDICAL_ORDER_CREATE",
        "MEDICAL_ORDER_UPDATE",
        "MEDICAL_ORDER_STOP",
        "PRESCRIPTION_CREATE",
        "PRESCRIPTION_UPDATE",
        "PRESCRIPTION_ITEM_CREATE",
        "PRESCRIPTION_ITEM_UPDATE",
        "PRESCRIPTION_ITEM_DELETE",
        "PRESCRIPTION_ISSUE",
        "PRESCRIPTION_CANCEL",
    } <= actions
