"""测试数据库和 API 客户端夹具。"""

import os
from collections.abc import Generator
from typing import Annotated

import pytest
from fastapi import Depends, FastAPI
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import StaticPool

os.environ["SECRET_KEY"] = "test-secret-key-with-at-least-32-characters"
os.environ["DATABASE_URL"] = "sqlite+pysqlite:///:memory:"
os.environ["APP_DEBUG"] = "false"
os.environ["MAX_UPLOAD_SIZE_MB"] = "1"

import app.models  # noqa: E402, F401
from app.core.database import Base, get_db  # noqa: E402
from app.core.permissions import require_permissions  # noqa: E402
from app.main import create_app  # noqa: E402
from app.api.deps import get_storage_service  # noqa: E402
from app.models.user import User  # noqa: E402
from app.services.bootstrap_service import (  # noqa: E402
    initialize_system_data,
)
from app.services.storage_service import LocalStorageService  # noqa: E402


@pytest.fixture
def db_session() -> Generator[Session, None, None]:
    engine = create_engine(
        "sqlite+pysqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    testing_session = sessionmaker(
        bind=engine,
        autoflush=False,
        expire_on_commit=False,
    )
    Base.metadata.create_all(engine)
    with testing_session() as session:
        yield session
    Base.metadata.drop_all(engine)
    engine.dispose()


@pytest.fixture
def seeded_db(db_session: Session) -> Session:
    initialize_system_data(
        db_session,
        admin_username="admin",
        admin_password="Admin@Test123",
        admin_real_name="测试管理员",
    )
    return db_session


@pytest.fixture
def app_instance(db_session: Session, tmp_path) -> FastAPI:
    application = create_app()

    def override_get_db() -> Generator[Session, None, None]:
        yield db_session

    application.dependency_overrides[get_db] = override_get_db
    application.dependency_overrides[get_storage_service] = lambda: LocalStorageService(
        tmp_path / "storage"
    )

    @application.get("/_test/admin-only", include_in_schema=False)
    def admin_only(
        _user: Annotated[
            User, Depends(require_permissions("admin:user"))
        ],
    ) -> dict[str, bool]:
        return {"allowed": True}

    return application


@pytest.fixture
def client(app_instance: FastAPI) -> Generator[TestClient, None, None]:
    with TestClient(app_instance) as test_client:
        yield test_client
