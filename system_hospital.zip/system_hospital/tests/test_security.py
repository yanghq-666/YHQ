"""密码和 JWT 安全测试。"""

from datetime import timedelta

import pytest

from app.core.exceptions import AuthenticationError
from app.core.security import (
    create_access_token,
    decode_access_token,
    hash_password,
    verify_password,
)


def test_password_is_hashed_and_can_be_verified() -> None:
    password = "Secure@Test123"
    password_hash = hash_password(password)

    assert password_hash != password
    assert password_hash.startswith("$2")
    assert verify_password(password, password_hash)
    assert not verify_password("wrong-password", password_hash)


def test_password_length_is_limited_for_bcrypt() -> None:
    with pytest.raises(ValueError):
        hash_password("short")
    with pytest.raises(ValueError):
        hash_password("x" * 73)


def test_access_token_round_trip() -> None:
    token = create_access_token(42, "doctor")
    payload = decode_access_token(token)

    assert payload["sub"] == "42"
    assert payload["username"] == "doctor"
    assert payload["token_type"] == "access"


def test_expired_access_token_is_rejected() -> None:
    token = create_access_token(
        42,
        "doctor",
        expires_delta=timedelta(seconds=-1),
    )

    with pytest.raises(AuthenticationError):
        decode_access_token(token)
