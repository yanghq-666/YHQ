"""检验、检查、附件、完整病历及快照集成测试。"""

import hashlib
import io
import re
from datetime import datetime, timezone
from pathlib import Path

from fastapi.testclient import TestClient
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.security import create_access_token, hash_password
from app.models.attachment import Attachment
from app.models.audit_log import AuditLog
from app.models.department import Department
from app.models.encounter import Encounter
from app.models.enums import EncounterStatus, EncounterType, Gender, MedicalRecordStatus, UserStatus
from app.models.lab_report import LabResult
from app.models.medical_record import MedicalRecord
from app.models.patient import Patient
from app.models.role import Role
from app.models.user import User, UserRole


def _headers(user: User) -> dict[str, str]:
    return {"Authorization": f"Bearer {create_access_token(user.id, user.username)}"}


def _login_headers(client: TestClient, username: str) -> dict[str, str]:
    response = client.post(
        "/api/auth/login",
        json={"username": username, "password": "Stage7@Test123"},
    )
    assert response.status_code == 200, response.text
    return {"Authorization": f"Bearer {response.json()['data']['access_token']}"}


def _setup(db: Session) -> dict[str, object]:
    roles = {code: db.scalar(select(Role).where(Role.code == code)) for code in ("DOCTOR", "LAB_TECHNICIAN", "RADIOLOGY_TECHNICIAN")}
    department = db.scalar(select(Department).where(Department.department_code == "INTERNAL"))
    other_department = db.scalar(select(Department).where(Department.department_code == "SURGERY"))
    admin = db.scalar(select(User).where(User.username == "admin"))
    assert all(roles.values()) and department and other_department and admin
    doctor = User(username="stage7-doctor", password_hash=hash_password("Stage7@Test123"), real_name="阶段七医生", employee_no="S7D001", department_id=department.id, status=UserStatus.ACTIVE, is_active=True)
    outsider = User(username="stage7-outsider", password_hash=hash_password("Stage7@Test123"), real_name="外科医生", employee_no="S7D002", department_id=other_department.id, status=UserStatus.ACTIVE, is_active=True)
    lab = User(username="stage7-lab", password_hash=hash_password("Stage7@Test123"), real_name="检验人员", employee_no="S7L001", department_id=department.id, status=UserStatus.ACTIVE, is_active=True)
    radio = User(username="stage7-radio", password_hash=hash_password("Stage7@Test123"), real_name="影像人员", employee_no="S7R001", department_id=department.id, status=UserStatus.ACTIVE, is_active=True)
    patient = Patient(patient_no="PS7000001", name="阶段七患者", gender=Gender.FEMALE)
    db.add_all([doctor, outsider, lab, radio, patient])
    db.flush()
    db.add_all([
        UserRole(user_id=doctor.id, role_id=roles["DOCTOR"].id),
        UserRole(user_id=outsider.id, role_id=roles["DOCTOR"].id),
        UserRole(user_id=lab.id, role_id=roles["LAB_TECHNICIAN"].id),
        UserRole(user_id=radio.id, role_id=roles["RADIOLOGY_TECHNICIAN"].id),
    ])
    encounter = Encounter(encounter_no="ES7000001", patient_id=patient.id, doctor_id=doctor.id, department_id=department.id, encounter_type=EncounterType.OUTPATIENT, visit_time=datetime.now(timezone.utc), status=EncounterStatus.IN_PROGRESS, created_by=doctor.id)
    db.add(encounter)
    db.flush()
    record = MedicalRecord(record_no="MRS7000001", encounter_id=encounter.id, chief_complaint="发热", present_illness="发热三天", physical_exam="体温升高", diagnosis_summary="待查", treatment_plan="完善检查", status=MedicalRecordStatus.DRAFT, created_by=doctor.id, updated_by=doctor.id)
    db.add(record)
    db.commit()
    return {"admin": admin, "doctor": doctor, "outsider": outsider, "lab": lab, "radio": radio, "patient": patient, "encounter": encounter, "record": record}


def _create_lab(client: TestClient, context: dict[str, object]):
    record, doctor = context["record"], context["doctor"]
    response = client.post(f"/api/medical-records/{record.id}/lab-reports", headers=_headers(doctor), json={"report_name": "血常规", "report_type": "HEMATOLOGY", "specimen_type": "全血"})
    assert response.status_code == 201, response.text
    return response.json()["data"]


def _create_exam(client: TestClient, context: dict[str, object]):
    record, doctor = context["record"], context["doctor"]
    response = client.post(f"/api/medical-records/{record.id}/examinations", headers=_headers(doctor), json={"examination_type": "CT", "examination_name": "胸部CT", "body_part": "胸部", "clinical_indication": "排除肺部感染"})
    assert response.status_code == 201, response.text
    return response.json()["data"]


def _upload(client: TestClient, record: MedicalRecord, user: User, name: str, content: bytes, content_type: str):
    return client.post(f"/api/medical-records/{record.id}/attachments", headers=_headers(user), data={"category": "MEDICAL_RECORD", "description": "报告附件"}, files={"file": (name, content, content_type)})


def test_lab_report_state_machine_results_permissions_and_audit(client: TestClient, seeded_db: Session) -> None:
    context = _setup(seeded_db)
    report = _create_lab(client, context)
    patient = context["patient"]
    assert re.fullmatch(r"LAB\d{14}", report["report_no"])
    assert report["patient_id"] == patient.id and report["status"] == "PENDING"
    assert client.post(f"/api/medical-records/{context['record'].id}/lab-reports", headers=_headers(context["doctor"]), json={"report_name": "伪造", "report_type": "OTHER", "patient_id": 999}).status_code == 422
    assert client.post(f"/api/medical-records/{context['record'].id}/lab-reports", headers=_headers(context["outsider"]), json={"report_name": "越权", "report_type": "OTHER"}).status_code == 403
    assert _create_lab(client, context)["report_no"] != report["report_no"]
    assert client.post(f"/api/lab-reports/{report['id']}/start", headers=_headers(context["doctor"])).status_code == 403
    started = client.post(f"/api/lab-reports/{report['id']}/start", headers=_headers(context["lab"]))
    assert started.status_code == 200 and started.json()["data"]["status"] == "IN_PROGRESS"
    empty_complete = client.post(f"/api/lab-reports/{report['id']}/complete", headers=_headers(context["lab"]), json={"result_summary": "异常", "conclusion": "感染"})
    assert empty_complete.status_code == 409
    invalid_batch = client.post(f"/api/lab-reports/{report['id']}/results", headers=_headers(context["lab"]), json={"results": [{"item_name": "WBC", "result_value": "12.5"}, {"item_name": ""}]})
    assert invalid_batch.status_code == 422
    assert seeded_db.scalar(select(func.count(LabResult.id)).where(LabResult.lab_report_id == report["id"])) == 0
    added = client.post(f"/api/lab-reports/{report['id']}/results", headers=_headers(context["lab"]), json={"results": [{"item_code": "WBC", "item_name": "白细胞", "result_value": "12.5", "unit": "10^9/L", "reference_range": "3.5-9.5", "abnormal_flag": "HIGH"}, {"item_code": "RBC", "item_name": "红细胞", "result_value": "4.6", "abnormal_flag": "NORMAL"}]})
    assert added.status_code == 201 and len(added.json()["data"]) == 2
    result_id = added.json()["data"][0]["id"]
    assert client.patch(f"/api/lab-results/{result_id}", headers=_headers(context["lab"]), json={"remark": "复核"}).status_code == 200
    completed = client.post(f"/api/lab-reports/{report['id']}/complete", headers=_headers(context["lab"]), json={"result_summary": "白细胞升高", "conclusion": "提示感染"})
    assert completed.status_code == 200 and completed.json()["data"]["reported_at"]
    assert client.get(f"/api/lab-reports/{report['id']}", headers=_headers(context["doctor"])).json()["data"]["results"][0]["item_code"] == "WBC"
    filtered = client.get(f"/api/medical-records/{context['record'].id}/lab-reports?status=COMPLETED&report_type=HEMATOLOGY", headers=_headers(context["doctor"]))
    assert filtered.status_code == 200 and [item["id"] for item in filtered.json()["data"]] == [report["id"]]
    assert client.patch(f"/api/lab-results/{result_id}", headers=_headers(context["lab"]), json={"result_value": "9"}).status_code == 409
    actions = set(seeded_db.scalars(select(AuditLog.action)).all())
    assert {"LAB_REPORT_CREATE", "LAB_REPORT_START", "LAB_RESULT_CREATE", "LAB_RESULT_UPDATE", "LAB_REPORT_COMPLETE"} <= actions


def test_examination_state_machine_and_role_isolation(client: TestClient, seeded_db: Session) -> None:
    context = _setup(seeded_db)
    item = _create_exam(client, context)
    assert re.fullmatch(r"EX\d{14}", item["examination_no"])
    assert _create_exam(client, context)["examination_no"] != item["examination_no"]
    assert client.post(f"/api/examinations/{item['id']}/start", headers=_headers(context["lab"])).status_code == 403
    started = client.post(f"/api/examinations/{item['id']}/start", headers=_headers(context["radio"]))
    assert started.status_code == 200 and started.json()["data"]["status"] == "IN_PROGRESS"
    completed = client.post(f"/api/examinations/{item['id']}/complete", headers=_headers(context["radio"]), json={"findings": "右下肺片状高密度影", "conclusion": "考虑右下肺感染"})
    assert completed.status_code == 200 and completed.json()["data"]["status"] == "COMPLETED"
    assert completed.json()["data"]["performed_at"] and completed.json()["data"]["reported_at"]
    assert client.get(f"/api/medical-records/{context['record'].id}/examinations?examination_type=CT&status=COMPLETED", headers=_headers(context["doctor"])).json()["data"][0]["id"] == item["id"]
    actions = set(seeded_db.scalars(select(AuditLog.action)).all())
    assert {"EXAMINATION_CREATE", "EXAMINATION_START", "EXAMINATION_COMPLETE"} <= actions


def test_attachment_validation_storage_hash_download_and_delete(client: TestClient, seeded_db: Session, tmp_path: Path) -> None:
    context = _setup(seeded_db)
    record, doctor = context["record"], context["doctor"]
    pdf = b"%PDF-1.4\nbody\n%%EOF"
    uploaded = _upload(client, record, doctor, "report.pdf", pdf, "application/pdf")
    assert uploaded.status_code == 201, uploaded.text
    data = uploaded.json()["data"]
    assert data["file_hash"] == hashlib.sha256(pdf).hexdigest()
    assert data["file_size"] == len(pdf) and data["storage_provider"] == "local"
    assert "report.pdf" not in data["object_key"]
    assert (tmp_path / "storage" / data["object_key"]).is_file()
    jpeg = _upload(client, record, doctor, "image.jpg", b"\xff\xd8\xff\xe0JPEG", "image/jpeg")
    assert jpeg.status_code == 201
    assert _upload(client, record, doctor, "evil.exe", b"MZ", "application/octet-stream").status_code == 400
    assert _upload(client, record, doctor, "fake.pdf", b"MZ executable", "application/pdf").status_code == 400
    for name in ("../../../abc.pdf", "....\\abc.pdf", "%2e%2e%2fabc.pdf", "..%5c..%5cabc.pdf"):
        assert _upload(client, record, doctor, name, pdf, "application/pdf").status_code == 400
    too_large = _upload(client, record, doctor, "large.pdf", b"%PDF-" + b"x" * (1024 * 1024), "application/pdf")
    assert too_large.status_code == 413
    downloaded = client.get(f"/api/attachments/{data['id']}/download", headers=_headers(doctor))
    assert downloaded.status_code == 200 and downloaded.content == pdf
    assert client.get(f"/api/attachments/{data['id']}/content", headers=_headers(doctor)).headers["content-type"].startswith("application/pdf")
    assert client.get(f"/api/attachments/{data['id']}/download", headers=_headers(context["outsider"])).status_code == 403
    deleted = client.delete(f"/api/attachments/{data['id']}", headers=_headers(doctor))
    assert deleted.status_code == 200
    assert seeded_db.get(Attachment, data["id"]).deleted_at is not None
    actions = list(seeded_db.scalars(select(AuditLog.action)))
    assert "ATTACHMENT_UPLOAD" in actions and "ATTACHMENT_DOWNLOAD" in actions and "ATTACHMENT_DELETE" in actions


def test_attachment_link_consistency_and_locked_delete(client: TestClient, seeded_db: Session) -> None:
    context = _setup(seeded_db)
    record, doctor = context["record"], context["doctor"]
    lab = _create_lab(client, context)
    bad = client.post(f"/api/medical-records/{record.id}/attachments", headers=_headers(doctor), data={"category": "LAB_REPORT", "lab_report_id": lab["id"] + 999}, files={"file": ("report.pdf", b"%PDF-1.4\n%%EOF", "application/pdf")})
    assert bad.status_code == 400
    uploaded = _upload(client, record, doctor, "report.pdf", b"%PDF-1.4\n%%EOF", "application/pdf").json()["data"]
    record.status = MedicalRecordStatus.SUBMITTED
    seeded_db.commit()
    assert client.delete(f"/api/attachments/{uploaded['id']}", headers=_headers(doctor)).status_code == 403


def test_full_record_and_version_snapshot_include_new_modules(client: TestClient, seeded_db: Session) -> None:
    context = _setup(seeded_db)
    record, doctor, lab_user, radio = context["record"], context["doctor"], context["lab"], context["radio"]
    lab = _create_lab(client, context)
    client.post(f"/api/lab-reports/{lab['id']}/start", headers=_headers(lab_user))
    client.post(f"/api/lab-reports/{lab['id']}/results", headers=_headers(lab_user), json={"results": [{"item_code": "WBC", "item_name": "白细胞", "result_value": "12.5", "abnormal_flag": "HIGH"}]})
    client.post(f"/api/lab-reports/{lab['id']}/complete", headers=_headers(lab_user), json={"result_summary": "升高", "conclusion": "感染"})
    exam = _create_exam(client, context)
    client.post(f"/api/examinations/{exam['id']}/start", headers=_headers(radio))
    client.post(f"/api/examinations/{exam['id']}/complete", headers=_headers(radio), json={"findings": "高密度影", "conclusion": "肺感染"})
    attachment = _upload(client, record, doctor, "report.pdf", b"%PDF-1.4\n%%EOF", "application/pdf").json()["data"]
    full = client.get(f"/api/medical-records/{record.id}/full", headers=_headers(doctor))
    assert full.status_code == 200, full.text
    aggregate = full.json()["data"]
    assert aggregate["lab_reports"][0]["results"][0]["item_code"] == "WBC"
    assert aggregate["examinations"][0]["conclusion"] == "肺感染"
    assert aggregate["attachments"][0]["id"] == attachment["id"]
    diagnosis = client.post(f"/api/medical-records/{record.id}/diagnoses", headers=_headers(doctor), json={"diagnosis_name": "肺部感染", "diagnosis_type": "PRELIMINARY", "is_primary": True})
    assert diagnosis.status_code == 201
    submitted = client.post(f"/api/medical-records/{record.id}/submit", headers=_headers(doctor))
    assert submitted.status_code == 200, submitted.text
    version = client.get(f"/api/medical-records/{record.id}/versions/1", headers=_headers(doctor)).json()["data"]["snapshot_data"]
    assert version["lab_reports"][0]["id"] == lab["id"]
    assert version["lab_results"][0]["item_code"] == "WBC"
    assert version["examinations"][0]["id"] == exam["id"]
    assert version["attachments_metadata"][0]["file_hash"] == attachment["file_hash"]
    assert "object_key" not in version["attachments_metadata"][0]
    assert "content" not in version["attachments_metadata"][0]


def test_results_can_complete_after_record_submission(client: TestClient, seeded_db: Session) -> None:
    context = _setup(seeded_db)
    report = _create_lab(client, context)
    exam = _create_exam(client, context)
    context["record"].status = MedicalRecordStatus.SUBMITTED
    seeded_db.commit()
    lab_headers = _login_headers(client, "stage7-lab")
    radio_headers = _login_headers(client, "stage7-radio")
    assert client.post(f"/api/lab-reports/{report['id']}/start", headers=lab_headers).status_code == 200
    assert client.post(f"/api/lab-reports/{report['id']}/results", headers=lab_headers, json={"results": [{"item_name": "CRP", "result_value": "20"}]}).status_code == 201
    assert client.post(f"/api/lab-reports/{report['id']}/complete", headers=lab_headers, json={"result_summary": "升高", "conclusion": "炎症"}).status_code == 200
    assert client.post(f"/api/examinations/{exam['id']}/start", headers=radio_headers).status_code == 200
    assert client.post(f"/api/examinations/{exam['id']}/complete", headers=radio_headers, json={"findings": "异常", "conclusion": "复查"}).status_code == 200


def test_pending_reports_can_cancel_only_once(client: TestClient, seeded_db: Session) -> None:
    context = _setup(seeded_db)
    lab = _create_lab(client, context)
    exam = _create_exam(client, context)
    lab_cancel = client.post(f"/api/lab-reports/{lab['id']}/cancel", headers=_headers(context["lab"]), json={"reason": "标本不合格"})
    exam_cancel = client.post(f"/api/examinations/{exam['id']}/cancel", headers=_headers(context["radio"]), json={"reason": "患者取消"})
    assert lab_cancel.status_code == 200 and lab_cancel.json()["data"]["status"] == "CANCELLED"
    assert exam_cancel.status_code == 200 and exam_cancel.json()["data"]["status"] == "CANCELLED"
    assert client.post(f"/api/lab-reports/{lab['id']}/start", headers=_headers(context["lab"])).status_code == 409
    assert client.post(f"/api/examinations/{exam['id']}/start", headers=_headers(context["radio"])).status_code == 409
