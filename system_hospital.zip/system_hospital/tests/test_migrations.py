"""Alembic 迁移升级、模型一致性和回滚测试。"""

from pathlib import Path

from alembic import command
from alembic.config import Config
from sqlalchemy import create_engine, inspect


def test_initial_migration_upgrade_check_and_downgrade(
    tmp_path: Path,
) -> None:
    database_path = tmp_path / "migration_test.db"
    database_url = f"sqlite:///{database_path.as_posix()}"
    config = Config("alembic.ini")
    config.attributes["database_url"] = database_url

    command.upgrade(config, "head")
    engine = create_engine(database_url)
    expected_tables = {
        "alembic_version",
        "audit_logs",
        "attachments",
        "business_sequences",
        "departments",
        "diagnoses",
        "encounter_sequences",
        "encounters",
        "examinations",
        "lab_reports",
        "lab_results",
        "medical_record_sequences",
        "medical_record_versions",
        "medical_records",
        "medical_orders",
        "patient_sequences",
        "patients",
        "permissions",
        "prescription_items",
        "prescriptions",
        "record_reviews",
        "role_permissions",
        "roles",
        "user_roles",
        "users",
    }
    assert set(inspect(engine).get_table_names()) == expected_tables

    command.check(config)
    command.downgrade(config, "base")
    assert set(inspect(engine).get_table_names()) == {"alembic_version"}
    engine.dispose()
