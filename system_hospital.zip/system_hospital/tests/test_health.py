"""第一阶段的应用启动冒烟测试。"""

import os

os.environ.setdefault(
    "SECRET_KEY", "test-only-secret-with-at-least-32-characters"
)
os.environ.setdefault("DATABASE_URL", "sqlite+pysqlite:///:memory:")
os.environ.setdefault("APP_DEBUG", "false")

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402


def test_health_check() -> None:
    """健康检查必须返回约定的固定结构。"""
    with TestClient(app) as client:
        response = client.get("/health")

    assert response.status_code == 200
    assert response.json() == {"status": "ok"}
