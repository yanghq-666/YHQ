"""患者与就诊 Web 页面端到端测试。"""

from fastapi.testclient import TestClient
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.security import hash_password
from app.models.audit_log import AuditLog
from app.models.department import Department
from app.models.encounter import Encounter
from app.models.enums import BloodType, EncounterStatus, Gender, UserStatus
from app.models.patient import Patient
from app.models.role import Role
from app.models.user import User, UserRole


def _login(client: TestClient, username: str, password: str) -> None:
    response = client.post(
        "/login",
        data={"username": username, "password": password},
        follow_redirects=False,
    )
    assert response.status_code == 303


def _create_user(
    db: Session,
    *,
    username: str,
    role_code: str,
    password: str = "WebPage@Test123",
) -> User:
    role = db.scalar(select(Role).where(Role.code == role_code))
    department = db.scalar(
        select(Department).where(Department.department_code == "INTERNAL")
    )
    assert role is not None
    assert department is not None
    user = User(
        username=username,
        password_hash=hash_password(password),
        real_name=f"{role_code}页面测试",
        employee_no=f"PAGE-{username}",
        department_id=department.id,
        status=UserStatus.ACTIVE,
        is_active=True,
    )
    db.add(user)
    db.flush()
    db.add(UserRole(user_id=user.id, role_id=role.id))
    db.commit()
    return user


def _patient_form(name: str, id_card: str) -> dict[str, str]:
    return {
        "name": name,
        "gender": "FEMALE",
        "birthday": "1990-05-20",
        "id_card": id_card,
        "phone": "13800001234",
        "address": "测试地址",
        "blood_type": "A",
        "allergy_history": "无",
        "emergency_contact": "联系人",
        "emergency_phone": "13900001234",
        "remark": "Web 页面测试",
    }


def test_patient_web_create_search_detail_edit_and_delete(
    client: TestClient, seeded_db: Session
) -> None:
    _login(client, "admin", "Admin@Test123")

    create = client.post(
        "/patients/new",
        data=_patient_form("网页患者", "110101199005201234"),
        follow_redirects=False,
    )
    assert create.status_code == 303
    assert create.headers["location"].startswith("/patients/")

    patient = seeded_db.scalar(
        select(Patient).where(Patient.name == "网页患者")
    )
    assert patient is not None
    detail = client.get(f"/patients/{patient.id}")
    assert detail.status_code == 200
    assert patient.patient_no in detail.text
    assert "就诊历史" in detail.text

    search = client.get("/patients", params={"keyword": patient.patient_no})
    assert search.status_code == 200
    assert "网页患者" in search.text
    empty_filters = client.get(
        "/patients?keyword=&gender=&blood_type="
    )
    assert empty_filters.status_code == 200

    updated_form = _patient_form("网页患者已更新", "110101199005201234")
    update = client.post(
        f"/patients/{patient.id}/edit",
        data=updated_form,
        follow_redirects=False,
    )
    assert update.status_code == 303
    seeded_db.refresh(patient)
    assert patient.name == "网页患者已更新"

    delete = client.post(
        f"/patients/{patient.id}/delete", follow_redirects=False
    )
    assert delete.status_code == 303
    seeded_db.refresh(patient)
    assert patient.deleted_at is not None
    actions = set(seeded_db.scalars(select(AuditLog.action)).all())
    assert {"PATIENT_CREATE", "PATIENT_UPDATE", "PATIENT_DELETE"} <= actions


def test_patient_web_validation_error_keeps_form(
    client: TestClient, seeded_db: Session
) -> None:
    _login(client, "admin", "Admin@Test123")
    response = client.post(
        "/patients/new",
        data=_patient_form("校验患者", "invalid-id-card"),
    )

    assert response.status_code == 422
    assert "身份证号格式不正确" in response.text
    assert "校验患者" in response.text


def test_encounter_web_create_search_detail_and_transitions(
    client: TestClient, seeded_db: Session
) -> None:
    doctor = _create_user(
        seeded_db, username="encounter-web-doctor", role_code="DOCTOR"
    )
    department = doctor.department
    patient = Patient(
        patient_no="P2026999001",
        name="就诊页面患者",
        gender=Gender.MALE,
        blood_type=BloodType.UNKNOWN,
    )
    seeded_db.add(patient)
    seeded_db.commit()
    _login(client, "admin", "Admin@Test123")

    form = {
        "patient_id": str(patient.id),
        "doctor_id": str(doctor.id),
        "department_id": str(department.id),
        "encounter_type": "OUTPATIENT",
        "visit_time": "2026-09-06T10:30",
        "chief_complaint": "发热三天",
        "admission_time": "",
        "discharge_time": "",
        "room_no": "",
        "bed_no": "",
        "remark": "Web 就诊测试",
    }
    create = client.post(
        "/encounters/new", data=form, follow_redirects=False
    )
    assert create.status_code == 303

    encounter = seeded_db.scalar(
        select(Encounter).where(Encounter.patient_id == patient.id)
    )
    assert encounter is not None
    assert encounter.status == EncounterStatus.REGISTERED
    detail = client.get(f"/encounters/{encounter.id}")
    assert detail.status_code == 200
    assert encounter.encounter_no in detail.text
    assert "发热三天" in detail.text

    search = client.get(
        "/encounters", params={"keyword": "就诊页面患者"}
    )
    assert search.status_code == 200
    assert encounter.encounter_no in search.text
    empty_filters = client.get(
        "/encounters?keyword=&encounter_type=&status=&department_id="
    )
    assert empty_filters.status_code == 200

    form["chief_complaint"] = "发热伴咳嗽三天"
    form.pop("patient_id")
    form.pop("encounter_type")
    update = client.post(
        f"/encounters/{encounter.id}/edit",
        data=form,
        follow_redirects=False,
    )
    assert update.status_code == 303
    seeded_db.refresh(encounter)
    assert encounter.chief_complaint == "发热伴咳嗽三天"

    start = client.post(
        f"/encounters/{encounter.id}/start", follow_redirects=False
    )
    assert start.status_code == 303
    seeded_db.refresh(encounter)
    assert encounter.status == EncounterStatus.IN_PROGRESS

    complete = client.post(
        f"/encounters/{encounter.id}/complete", follow_redirects=False
    )
    assert complete.status_code == 303
    seeded_db.refresh(encounter)
    assert encounter.status == EncounterStatus.COMPLETED


def test_web_patient_and_encounter_write_permissions(
    client: TestClient, seeded_db: Session
) -> None:
    _create_user(seeded_db, username="web-nurse", role_code="NURSE")
    _login(client, "web-nurse", "WebPage@Test123")

    assert client.get("/patients").status_code == 200
    assert client.get("/encounters").status_code == 200
    patient_create = client.get("/patients/new")
    encounter_create = client.get("/encounters/new")
    assert patient_create.status_code == 403
    assert encounter_create.status_code == 403
    assert "无权访问" in patient_create.text


def test_non_admin_edit_does_not_overwrite_masked_patient_fields(
    client: TestClient, seeded_db: Session
) -> None:
    _create_user(seeded_db, username="privacy-doctor", role_code="DOCTOR")
    patient = Patient(
        patient_no="P2026999002",
        name="隐私字段患者",
        gender=Gender.FEMALE,
        blood_type=BloodType.A,
        id_card="110101199005201234",
        phone="13800001234",
        emergency_phone="13900001234",
    )
    seeded_db.add(patient)
    seeded_db.commit()
    _login(client, "privacy-doctor", "WebPage@Test123")

    edit_page = client.get(f"/patients/{patient.id}/edit")
    assert edit_page.status_code == 200
    assert "仅管理员可在此页面修改" in edit_page.text
    assert "110101199005201234" not in edit_page.text

    form = _patient_form("隐私字段患者已更新", "")
    form.pop("id_card")
    form.pop("phone")
    form.pop("emergency_phone")
    response = client.post(
        f"/patients/{patient.id}/edit",
        data=form,
        follow_redirects=False,
    )
    assert response.status_code == 303
    seeded_db.refresh(patient)
    assert patient.name == "隐私字段患者已更新"
    assert patient.id_card == "110101199005201234"
    assert patient.phone == "13800001234"
    assert patient.emergency_phone == "13900001234"
