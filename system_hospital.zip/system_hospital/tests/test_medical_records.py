"""病历草稿、提交、版本、权限、软删除和审计测试。"""

import re
from datetime import datetime, timezone

from fastapi.testclient import TestClient
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.security import create_access_token, hash_password
from app.models.audit_log import AuditLog
from app.models.department import Department
from app.models.encounter import Encounter
from app.models.enums import (
    EncounterStatus,
    EncounterType,
    Gender,
    UserStatus,
)
from app.models.medical_record import MedicalRecord, MedicalRecordVersion
from app.models.patient import Patient
from app.models.role import Role
from app.models.user import User, UserRole


COMPLETE_RECORD = {
    "chief_complaint": "咳嗽、发热3天",
    "present_illness": "三天前受凉后出现咳嗽和发热。",
    "physical_exam": "体温38.2℃，双肺呼吸音粗。",
    "diagnosis_summary": "急性上呼吸道感染",
    "treatment_plan": "对症治疗，复查血常规。",
}


def _headers(user: User) -> dict[str, str]:
    token = create_access_token(user.id, user.username)
    return {"Authorization": f"Bearer {token}"}


def _setup(db: Session) -> dict[str, object]:
    admin = db.scalar(select(User).where(User.username == "admin"))
    department = db.scalar(
        select(Department).where(Department.department_code == "INTERNAL")
    )
    other_department = db.scalar(
        select(Department).where(Department.department_code == "SURGERY")
    )
    doctor_role = db.scalar(select(Role).where(Role.code == "DOCTOR"))
    nurse_role = db.scalar(select(Role).where(Role.code == "NURSE"))
    assert admin and department and other_department and doctor_role and nurse_role

    doctor = User(
        username="record-doctor",
        password_hash=hash_password("Record@Test123"),
        real_name="病历测试医生",
        employee_no="MRD001",
        department_id=department.id,
        status=UserStatus.ACTIVE,
        is_active=True,
    )
    outsider = User(
        username="record-outsider",
        password_hash=hash_password("Record@Test123"),
        real_name="外科医生",
        employee_no="MRD002",
        department_id=other_department.id,
        status=UserStatus.ACTIVE,
        is_active=True,
    )
    nurse = User(
        username="record-nurse",
        password_hash=hash_password("Record@Test123"),
        real_name="病历测试护士",
        employee_no="MRN001",
        department_id=department.id,
        status=UserStatus.ACTIVE,
        is_active=True,
    )
    patient = Patient(
        patient_no="PMR000001",
        name="病历测试患者",
        gender=Gender.FEMALE,
    )
    db.add_all([doctor, outsider, nurse, patient])
    db.flush()
    db.add_all(
        [
            UserRole(user_id=doctor.id, role_id=doctor_role.id),
            UserRole(user_id=outsider.id, role_id=doctor_role.id),
            UserRole(user_id=nurse.id, role_id=nurse_role.id),
        ]
    )
    db.commit()
    return {
        "admin": admin,
        "doctor": doctor,
        "outsider": outsider,
        "nurse": nurse,
        "department": department,
        "other_department": other_department,
        "patient": patient,
    }


def _encounter(
    db: Session,
    context: dict[str, object],
    *,
    suffix: int = 1,
    status: EncounterStatus = EncounterStatus.IN_PROGRESS,
) -> Encounter:
    doctor = context["doctor"]
    department = context["department"]
    patient = context["patient"]
    assert isinstance(doctor, User)
    assert isinstance(department, Department)
    assert isinstance(patient, Patient)
    encounter = Encounter(
        encounter_no=f"ETEST{suffix:06d}",
        patient_id=patient.id,
        doctor_id=doctor.id,
        department_id=department.id,
        encounter_type=EncounterType.OUTPATIENT,
        visit_time=datetime.now(timezone.utc),
        status=status,
        created_by=doctor.id,
    )
    db.add(encounter)
    db.commit()
    return encounter


def _create_record(
    client: TestClient,
    encounter: Encounter,
    user: User,
    payload: dict[str, object] | None = None,
) -> dict[str, object]:
    response = client.post(
        f"/api/encounters/{encounter.id}/medical-record",
        headers=_headers(user),
        json=payload or {},
    )
    assert response.status_code == 201, response.text
    return response.json()["data"]


def _create_primary_diagnosis(
    client: TestClient, record_id: int, user: User
) -> dict[str, object]:
    response = client.post(
        f"/api/medical-records/{record_id}/diagnoses",
        headers=_headers(user),
        json={
            "diagnosis_name": "急性上呼吸道感染",
            "diagnosis_type": "PRELIMINARY",
            "is_primary": True,
        },
    )
    assert response.status_code == 201, response.text
    return response.json()["data"]


def test_create_record_generates_number_and_prevents_duplicate(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    doctor = context["doctor"]
    assert isinstance(doctor, User)
    first_encounter = _encounter(seeded_db, context)
    second_encounter = _encounter(seeded_db, context, suffix=2)
    first = _create_record(client, first_encounter, doctor)
    second = _create_record(client, second_encounter, doctor)
    duplicate = client.post(
        f"/api/encounters/{first_encounter.id}/medical-record",
        headers=_headers(doctor),
        json={},
    )

    assert re.fullmatch(r"MR\d{8}\d{6}", str(first["record_no"]))
    assert first["record_no"] != second["record_no"]
    assert first["status"] == "DRAFT"
    assert duplicate.status_code == 409


def test_cancelled_and_non_responsible_doctor_cannot_create(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    doctor = context["doctor"]
    outsider = context["outsider"]
    assert isinstance(doctor, User) and isinstance(outsider, User)
    cancelled = _encounter(
        seeded_db, context, status=EncounterStatus.CANCELLED
    )
    active = _encounter(seeded_db, context, suffix=2)

    cancelled_response = client.post(
        f"/api/encounters/{cancelled.id}/medical-record",
        headers=_headers(doctor),
        json={},
    )
    outsider_response = client.post(
        f"/api/encounters/{active.id}/medical-record",
        headers=_headers(outsider),
        json={},
    )
    assert cancelled_response.status_code == 409
    assert outsider_response.status_code == 403


def test_admin_can_supplement_completed_encounter(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    admin = context["admin"]
    assert isinstance(admin, User)
    completed = _encounter(
        seeded_db, context, status=EncounterStatus.COMPLETED
    )
    response = client.post(
        f"/api/encounters/{completed.id}/medical-record",
        headers=_headers(admin),
        json={},
    )
    assert response.status_code == 201


def test_detail_encounter_lookup_list_and_keyword_search(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    admin = context["admin"]
    doctor = context["doctor"]
    patient = context["patient"]
    assert isinstance(admin, User) and isinstance(doctor, User)
    assert isinstance(patient, Patient)
    first_encounter = _encounter(seeded_db, context)
    second_encounter = _encounter(seeded_db, context, suffix=2)
    first = _create_record(client, first_encounter, doctor, COMPLETE_RECORD)
    _create_record(client, second_encounter, doctor)

    detail = client.get(
        f"/api/medical-records/{first['id']}", headers=_headers(admin)
    )
    by_encounter = client.get(
        f"/api/encounters/{first_encounter.id}/medical-record",
        headers=_headers(admin),
    )
    page = client.get(
        "/api/medical-records?page=1&page_size=1", headers=_headers(admin)
    )
    search = client.get(
        f"/api/medical-records?keyword={patient.patient_no}",
        headers=_headers(admin),
    )

    assert detail.status_code == 200
    assert detail.json()["data"]["encounter"]["patient"]["name"] == patient.name
    assert detail.json()["data"]["encounter"]["doctor"]["id"] == doctor.id
    assert by_encounter.json()["data"]["id"] == first["id"]
    assert page.json()["data"]["total"] == 2
    assert len(page.json()["data"]["items"]) == 1
    assert search.json()["data"]["total"] == 2


def test_missing_record_by_encounter_returns_404(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    admin = context["admin"]
    assert isinstance(admin, User)
    encounter = _encounter(seeded_db, context)
    response = client.get(
        f"/api/encounters/{encounter.id}/medical-record",
        headers=_headers(admin),
    )
    assert response.status_code == 404


def test_my_records_and_drafts_are_scoped(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    doctor = context["doctor"]
    outsider = context["outsider"]
    assert isinstance(doctor, User) and isinstance(outsider, User)
    encounter = _encounter(seeded_db, context)
    created = _create_record(client, encounter, doctor, COMPLETE_RECORD)

    mine = client.get("/api/medical-records/my", headers=_headers(doctor))
    drafts = client.get(
        "/api/medical-records/my/drafts", headers=_headers(doctor)
    )
    outside = client.get(
        "/api/medical-records/my", headers=_headers(outsider)
    )
    assert mine.json()["data"]["total"] == 1
    assert drafts.json()["data"]["items"][0]["id"] == created["id"]
    assert outside.json()["data"]["total"] == 0


def test_draft_partial_update_and_system_fields_forbidden(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    doctor = context["doctor"]
    assert isinstance(doctor, User)
    encounter = _encounter(seeded_db, context)
    created = _create_record(client, encounter, doctor)
    updated = client.patch(
        f"/api/medical-records/{created['id']}",
        headers=_headers(doctor),
        json={"chief_complaint": "咳嗽、发热3天"},
    )
    assert updated.status_code == 200
    assert updated.json()["data"]["chief_complaint"] == "咳嗽、发热3天"

    for field, value in (
        ("record_no", "MANUAL"),
        ("encounter_id", 999),
        ("patient_id", 999),
        ("status", "SUBMITTED"),
    ):
        response = client.patch(
            f"/api/medical-records/{created['id']}",
            headers=_headers(doctor),
            json={field: value},
        )
        assert response.status_code == 422


def test_incomplete_submit_returns_missing_fields(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    doctor = context["doctor"]
    assert isinstance(doctor, User)
    encounter = _encounter(seeded_db, context)
    created = _create_record(
        client, encounter, doctor, {"chief_complaint": "咳嗽"}
    )
    response = client.post(
        f"/api/medical-records/{created['id']}/submit",
        headers=_headers(doctor),
    )
    assert response.status_code == 422
    assert response.json()["data"]["missing_fields"] == [
        "present_illness",
        "physical_exam",
        "diagnosis_summary",
        "treatment_plan",
        "diagnoses",
    ]


def test_submit_sets_fields_and_creates_version(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    doctor = context["doctor"]
    assert isinstance(doctor, User)
    encounter = _encounter(seeded_db, context)
    created = _create_record(client, encounter, doctor, COMPLETE_RECORD)
    _create_primary_diagnosis(client, created["id"], doctor)
    submitted = client.post(
        f"/api/medical-records/{created['id']}/submit",
        headers=_headers(doctor),
    )
    versions = client.get(
        f"/api/medical-records/{created['id']}/versions",
        headers=_headers(doctor),
    )
    version = client.get(
        f"/api/medical-records/{created['id']}/versions/1",
        headers=_headers(doctor),
    )

    assert submitted.status_code == 200
    assert submitted.json()["data"]["status"] == "SUBMITTED"
    assert submitted.json()["data"]["submitted_at"] is not None
    assert submitted.json()["data"]["version"] == 1
    assert len(versions.json()["data"]) == 1
    snapshot = version.json()["data"]["snapshot_data"]
    assert snapshot["medical_record"]["status"] == "DRAFT"
    assert snapshot["medical_record"]["diagnosis_summary"]
    assert snapshot["diagnoses"][0]["is_primary"] is True
    assert seeded_db.scalar(select(MedicalRecordVersion)) is not None


def test_submitted_record_cannot_update_or_delete(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    doctor = context["doctor"]
    assert isinstance(doctor, User)
    encounter = _encounter(seeded_db, context)
    created = _create_record(client, encounter, doctor, COMPLETE_RECORD)
    _create_primary_diagnosis(client, created["id"], doctor)
    client.post(
        f"/api/medical-records/{created['id']}/submit",
        headers=_headers(doctor),
    )
    updated = client.patch(
        f"/api/medical-records/{created['id']}",
        headers=_headers(doctor),
        json={"doctor_notes": "不应成功"},
    )
    deleted = client.delete(
        f"/api/medical-records/{created['id']}", headers=_headers(doctor)
    )
    assert updated.status_code == 409
    assert deleted.status_code == 409


def test_draft_can_be_soft_deleted_and_encounter_cannot_be_deleted(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    doctor = context["doctor"]
    assert isinstance(doctor, User)
    encounter = _encounter(seeded_db, context)
    created = _create_record(client, encounter, doctor)
    encounter_delete = client.delete(
        f"/api/encounters/{encounter.id}", headers=_headers(doctor)
    )
    deleted = client.delete(
        f"/api/medical-records/{created['id']}", headers=_headers(doctor)
    )
    missing = client.get(
        f"/api/medical-records/{created['id']}", headers=_headers(doctor)
    )
    assert encounter_delete.status_code == 409
    assert deleted.status_code == 200
    assert missing.status_code == 404
    stored = seeded_db.get(MedicalRecord, created["id"])
    assert stored is not None and stored.deleted_at is not None


def test_nurse_cannot_create_or_update_main_record(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    doctor = context["doctor"]
    nurse = context["nurse"]
    assert isinstance(doctor, User) and isinstance(nurse, User)
    encounter = _encounter(seeded_db, context)
    no_create = client.post(
        f"/api/encounters/{encounter.id}/medical-record",
        headers=_headers(nurse),
        json={},
    )
    created = _create_record(client, encounter, doctor)
    no_update = client.patch(
        f"/api/medical-records/{created['id']}",
        headers=_headers(nurse),
        json={"doctor_notes": "护士修改"},
    )
    assert no_create.status_code == 403
    assert no_update.status_code == 403


def test_user_without_record_permission_is_rejected(
    client: TestClient, seeded_db: Session
) -> None:
    user = User(
        username="no-record-permission",
        password_hash=hash_password("Record@Test123"),
        real_name="无病历权限用户",
        status=UserStatus.ACTIVE,
        is_active=True,
    )
    seeded_db.add(user)
    seeded_db.commit()
    assert client.get(
        "/api/medical-records", headers=_headers(user)
    ).status_code == 403


def test_audit_log_records_safe_changes_submit_version_and_delete(
    client: TestClient, seeded_db: Session
) -> None:
    context = _setup(seeded_db)
    doctor = context["doctor"]
    assert isinstance(doctor, User)
    encounter = _encounter(seeded_db, context)
    created = _create_record(client, encounter, doctor)
    client.patch(
        f"/api/medical-records/{created['id']}",
        headers=_headers(doctor),
        json=COMPLETE_RECORD,
    )
    _create_primary_diagnosis(client, created["id"], doctor)
    client.post(
        f"/api/medical-records/{created['id']}/submit",
        headers=_headers(doctor),
    )
    logs = list(
        seeded_db.scalars(
            select(AuditLog)
            .where(
                AuditLog.target_type == "medical_record",
                AuditLog.target_id == created["id"],
            )
            .order_by(AuditLog.id)
        )
    )
    assert [item.action for item in logs] == [
        "MEDICAL_RECORD_CREATE",
        "MEDICAL_RECORD_UPDATE",
        "MEDICAL_RECORD_VERSION_CREATE",
        "MEDICAL_RECORD_SUBMIT",
    ]
    assert logs[1].new_value["changed_fields"] == sorted(COMPLETE_RECORD)
    assert "咳嗽、发热3天" not in str(logs[1].new_value)
    assert logs[-1].request_path.endswith("/submit")

    second = _encounter(seeded_db, context, suffix=2)
    draft = _create_record(client, second, doctor)
    client.delete(
        f"/api/medical-records/{draft['id']}", headers=_headers(doctor)
    )
    delete_log = seeded_db.scalar(
        select(AuditLog).where(
            AuditLog.action == "MEDICAL_RECORD_DELETE",
            AuditLog.target_id == draft["id"],
        )
    )
    assert delete_log is not None
