"""Web 登录、布局、菜单权限和错误页测试。"""

from fastapi import FastAPI
from fastapi.testclient import TestClient
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.security import hash_password
from app.models.department import Department
from app.models.enums import UserStatus
from app.models.role import Role
from app.models.user import User, UserRole


def _create_role_user(
    db: Session,
    *,
    username: str,
    role_code: str,
    department_code: str = "INTERNAL",
    active: bool = True,
) -> User:
    role = db.scalar(select(Role).where(Role.code == role_code))
    department = db.scalar(
        select(Department).where(
            Department.department_code == department_code
        )
    )
    assert role is not None
    assert department is not None
    user = User(
        username=username,
        password_hash=hash_password("Web@Test123"),
        real_name=f"{role_code}测试用户",
        employee_no=f"WEB-{username}",
        department_id=department.id,
        status=UserStatus.ACTIVE if active else UserStatus.INACTIVE,
        is_active=active,
    )
    db.add(user)
    db.flush()
    db.add(UserRole(user_id=user.id, role_id=role.id))
    db.commit()
    return user


def _web_login(
    client: TestClient,
    username: str = "admin",
    password: str = "Admin@Test123",
):
    return client.post(
        "/login",
        data={"username": username, "password": password},
        follow_redirects=False,
    )


def test_root_and_anonymous_dashboard_redirect(client: TestClient) -> None:
    root = client.get("/", follow_redirects=False)
    dashboard = client.get("/dashboard", follow_redirects=False)

    assert root.status_code == 303
    assert root.headers["location"] == "/login"
    assert dashboard.status_code == 303
    assert dashboard.headers["location"] == "/login"


def test_login_page_and_static_asset(client: TestClient) -> None:
    response = client.get("/login")
    css = client.get("/static/css/app.css")

    assert response.status_code == 200
    assert "医院病历管理系统" in response.text
    assert 'name="username"' in response.text
    assert 'name="password"' in response.text
    assert css.status_code == 200


def test_admin_login_cookie_dashboard_and_logout(
    client: TestClient, seeded_db: Session
) -> None:
    login = _web_login(client)

    assert login.status_code == 303
    assert login.headers["location"] == "/dashboard"
    cookie_header = login.headers["set-cookie"]
    assert "access_token=" in cookie_header
    assert "HttpOnly" in cookie_header
    assert "SameSite=lax" in cookie_header

    dashboard = client.get("/dashboard")
    assert dashboard.status_code == 200
    assert "测试管理员" in dashboard.text
    assert "患者总数" in dashboard.text
    assert "用户管理" in dashboard.text
    assert "操作日志" in dashboard.text

    logout = client.post("/logout", follow_redirects=False)
    assert logout.status_code == 303
    assert logout.headers["location"] == "/login"
    assert client.get("/dashboard", follow_redirects=False).status_code == 303


def test_invalid_and_disabled_web_login(
    client: TestClient, seeded_db: Session
) -> None:
    invalid = _web_login(client, password="wrong-password")
    _create_role_user(
        seeded_db,
        username="disabled-web",
        role_code="DOCTOR",
        active=False,
    )
    disabled = _web_login(client, "disabled-web", "Web@Test123")

    assert invalid.status_code == 401
    assert "用户名或密码错误" in invalid.text
    assert disabled.status_code == 401
    assert "用户名或密码错误" in disabled.text


def test_doctor_and_senior_doctor_permission_menus(
    client: TestClient, seeded_db: Session
) -> None:
    _create_role_user(seeded_db, username="web-doctor", role_code="DOCTOR")
    _create_role_user(
        seeded_db,
        username="web-senior",
        role_code="SENIOR_DOCTOR",
    )

    _web_login(client, "web-doctor", "Web@Test123")
    doctor_page = client.get("/dashboard")
    assert doctor_page.status_code == 200
    assert "我的草稿病历" in doctor_page.text
    assert "待审核病历" not in doctor_page.text
    assert "用户管理" not in doctor_page.text

    client.post("/logout")
    _web_login(client, "web-senior", "Web@Test123")
    senior_page = client.get("/dashboard")
    assert senior_page.status_code == 200
    assert "待审核病历" in senior_page.text
    assert "我的审核" in senior_page.text
    assert "用户管理" not in senior_page.text


def test_web_rbac_403_and_unknown_page_404(
    client: TestClient, seeded_db: Session
) -> None:
    _create_role_user(seeded_db, username="limited-doctor", role_code="DOCTOR")
    _web_login(client, "limited-doctor", "Web@Test123")

    forbidden = client.get("/admin/users")
    missing = client.get("/not-a-real-page")

    assert forbidden.status_code == 403
    assert "无权访问" in forbidden.text
    assert "您没有权限访问该页面" in forbidden.text
    assert missing.status_code == 404
    assert "页面不存在" in missing.text


def test_docs_and_api_login_remain_available(
    client: TestClient, seeded_db: Session
) -> None:
    docs = client.get("/docs")
    api_login = client.post(
        "/api/auth/login",
        json={"username": "admin", "password": "Admin@Test123"},
    )

    assert docs.status_code == 200
    assert "Swagger UI" in docs.text
    assert api_login.status_code == 200
    assert api_login.json()["data"]["token_type"] == "bearer"


def test_unexpected_web_error_uses_safe_500_page(
    app_instance: FastAPI,
) -> None:
    @app_instance.get("/_test/web-500", include_in_schema=False)
    def raise_web_error() -> None:
        raise RuntimeError("internal detail must not be rendered")

    with TestClient(app_instance, raise_server_exceptions=False) as test_client:
        response = test_client.get("/_test/web-500")

    assert response.status_code == 500
    assert "系统发生错误" in response.text
    assert "请稍后重试" in response.text
    assert "internal detail" not in response.text
