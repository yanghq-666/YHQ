"""病历审核锁、退回重提、版本和数据权限测试。"""

from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

from fastapi.testclient import TestClient
from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session, sessionmaker

import app.models  # noqa: F401
from app.core.database import Base
from app.core.security import create_access_token, hash_password
from app.models.audit_log import AuditLog
from app.models.department import Department
from app.models.encounter import Encounter
from app.models.enums import EncounterStatus, EncounterType, Gender, MedicalRecordStatus, UserStatus
from app.models.medical_record import MedicalRecord
from app.models.patient import Patient
from app.models.record_review import RecordReview
from app.models.role import Role
from app.models.user import User, UserRole
from app.repositories.medical_record_repository import MedicalRecordRepository
from tests.test_clinical_records import _create_diagnosis, _create_order, _create_prescription, _item_payload


def _headers(user: User) -> dict[str, str]:
    token = create_access_token(user.id, user.username)
    return {"Authorization": f"Bearer {token}"}


def _setup(db: Session) -> dict[str, object]:
    internal = db.scalar(select(Department).where(Department.department_code == "INTERNAL"))
    surgery = db.scalar(select(Department).where(Department.department_code == "SURGERY"))
    admin = db.scalar(select(User).where(User.username == "admin"))
    roles = {code: db.scalar(select(Role).where(Role.code == code)) for code in ("DOCTOR", "SENIOR_DOCTOR", "LAB_TECHNICIAN", "RADIOLOGY_TECHNICIAN")}
    assert internal and surgery and admin and all(roles.values())
    users = [
        User(username="review-doctor", password_hash=hash_password("Review@Test123"), real_name="经治医生", employee_no="RVD001", department_id=internal.id, status=UserStatus.ACTIVE, is_active=True),
        User(username="review-senior-a", password_hash=hash_password("Review@Test123"), real_name="审核主任甲", employee_no="RVS001", department_id=internal.id, status=UserStatus.ACTIVE, is_active=True),
        User(username="review-senior-b", password_hash=hash_password("Review@Test123"), real_name="审核主任乙", employee_no="RVS002", department_id=internal.id, status=UserStatus.ACTIVE, is_active=True),
        User(username="review-cross", password_hash=hash_password("Review@Test123"), real_name="外科主任", employee_no="RVS003", department_id=surgery.id, status=UserStatus.ACTIVE, is_active=True),
        User(username="review-lab", password_hash=hash_password("Review@Test123"), real_name="检验人员", employee_no="RVL001", department_id=internal.id, status=UserStatus.ACTIVE, is_active=True),
        User(username="review-radio", password_hash=hash_password("Review@Test123"), real_name="影像人员", employee_no="RVR001", department_id=internal.id, status=UserStatus.ACTIVE, is_active=True),
    ]
    db.add_all(users)
    db.flush()
    role_codes = ["DOCTOR", "SENIOR_DOCTOR", "SENIOR_DOCTOR", "SENIOR_DOCTOR", "LAB_TECHNICIAN", "RADIOLOGY_TECHNICIAN"]
    db.add_all(UserRole(user_id=user.id, role_id=roles[code].id) for user, code in zip(users, role_codes, strict=True))
    patient = Patient(patient_no="PREVIEW001", name="审核测试患者", gender=Gender.FEMALE)
    db.add(patient)
    db.flush()
    encounter = Encounter(encounter_no="EREVIEW001", patient_id=patient.id, doctor_id=users[0].id, department_id=internal.id, encounter_type=EncounterType.OUTPATIENT, visit_time=datetime.now(timezone.utc), status=EncounterStatus.IN_PROGRESS, created_by=users[0].id)
    db.add(encounter)
    db.flush()
    record = MedicalRecord(record_no="MRREVIEW001", encounter_id=encounter.id, chief_complaint="发热咳嗽", present_illness="发热咳嗽三天", physical_exam="体温38度", diagnosis_summary="肺部感染", treatment_plan="抗感染治疗", status=MedicalRecordStatus.DRAFT, created_by=users[0].id, updated_by=users[0].id)
    db.add(record)
    db.commit()
    return {"admin": admin, "doctor": users[0], "senior_a": users[1], "senior_b": users[2], "cross": users[3], "lab": users[4], "radio": users[5], "patient": patient, "encounter": encounter, "record": record}


def _submit(client: TestClient, context: dict[str, object], reason: str | None = None):
    record, doctor = context["record"], context["doctor"]
    kwargs = {"json": {"change_reason": reason}} if reason else {}
    return client.post(f"/api/medical-records/{record.id}/submit", headers=_headers(doctor), **kwargs)


def test_complete_reject_resubmit_approve_workflow(client: TestClient, seeded_db: Session) -> None:
    context = _setup(seeded_db)
    record, doctor, senior = context["record"], context["doctor"], context["senior_a"]
    diagnosis = _create_diagnosis(client, record, doctor)
    _create_order(client, record, doctor)
    _create_prescription(client, record, doctor, items=[_item_payload()])
    lab = client.post(f"/api/medical-records/{record.id}/lab-reports", headers=_headers(doctor), json={"report_name": "血常规", "report_type": "HEMATOLOGY"}).json()["data"]
    exam = client.post(f"/api/medical-records/{record.id}/examinations", headers=_headers(doctor), json={"examination_type": "CT", "examination_name": "胸部CT"}).json()["data"]
    first = _submit(client, context)
    assert first.status_code == 200 and first.json()["data"]["version"] == 1
    pending = client.get("/api/medical-records/pending-review", headers=_headers(senior))
    assert pending.status_code == 200 and pending.json()["data"]["items"][0]["current_version"] == 1
    started = client.post(f"/api/medical-records/{record.id}/review/start", headers=_headers(senior))
    assert started.status_code == 200 and started.json()["data"]["status"] == "REVIEWING"
    assert client.patch(f"/api/medical-records/{record.id}", headers=_headers(doctor), json={"present_illness": "审核中篡改"}).status_code == 409
    rejected = client.post(f"/api/medical-records/{record.id}/review/reject", headers=_headers(senior), json={"comment": "补充现病史及治疗计划"})
    assert rejected.status_code == 200, rejected.text
    assert rejected.json()["data"]["status"] == "REJECTED"
    seeded_db.refresh(record)
    assert record.current_reviewer_id is None
    latest = client.get(f"/api/medical-records/{record.id}/latest-review", headers=_headers(doctor))
    assert latest.json()["data"]["comment"] == "补充现病史及治疗计划"
    assert client.get("/api/medical-records/my/rejected", headers=_headers(doctor)).json()["data"]["total"] == 1
    changed = client.patch(f"/api/medical-records/{record.id}", headers=_headers(doctor), json={"present_illness": "补充后的现病史和影像鉴别诊断"})
    assert changed.status_code == 200
    second = _submit(client, context, "根据审核意见补充现病史及治疗计划")
    assert second.status_code == 200 and second.json()["data"]["version"] == 2
    v1 = client.get(f"/api/medical-records/{record.id}/versions/1/full", headers=_headers(doctor)).json()["data"]
    v2 = client.get(f"/api/medical-records/{record.id}/versions/2/full", headers=_headers(doctor)).json()["data"]
    assert v1["medical_record"]["present_illness"] == "发热咳嗽三天"
    assert v2["medical_record"]["present_illness"] == "补充后的现病史和影像鉴别诊断"
    assert v2["diagnoses"][0]["id"] == diagnosis["id"] and v2["lab_reports"][0]["id"] == lab["id"] and v2["examinations"][0]["id"] == exam["id"]
    client.post(f"/api/medical-records/{record.id}/review/start", headers=_headers(senior))
    approved = client.post(f"/api/medical-records/{record.id}/review/approve", headers=_headers(senior), json={"comment": "病历内容完整，审核通过"})
    assert approved.status_code == 200 and approved.json()["data"]["approved_version"] == 2
    seeded_db.refresh(record)
    assert record.status == MedicalRecordStatus.APPROVED and record.reviewed_by == senior.id and record.reviewed_at is not None and record.current_reviewer_id is None
    history = client.get(f"/api/medical-records/{record.id}/reviews", headers=_headers(doctor)).json()["data"]
    assert [item["action"] for item in history] == ["SUBMIT", "START_REVIEW", "REJECT", "RESUBMIT", "START_REVIEW", "APPROVE"]
    assert [item["record_version"] for item in history] == [1, 1, 1, 2, 2, 2]
    full = client.get(f"/api/medical-records/{record.id}/full", headers=_headers(senior)).json()["data"]
    assert len(full["versions"]) == 2 and len(full["review_history"]) == 6
    assert client.get("/api/medical-records/my-reviews", headers=_headers(senior)).json()["data"]["total"] == 4
    actions = set(seeded_db.scalars(select(AuditLog.action)).all())
    assert {"MEDICAL_RECORD_REVIEW_START", "MEDICAL_RECORD_REJECT", "MEDICAL_RECORD_RESUBMIT", "MEDICAL_RECORD_APPROVE"} <= actions


def test_review_permissions_self_review_and_department_scope(client: TestClient, seeded_db: Session) -> None:
    context = _setup(seeded_db)
    record, doctor = context["record"], context["doctor"]
    _create_diagnosis(client, record, doctor)
    assert client.post(f"/api/medical-records/{record.id}/review/approve", headers=_headers(context["senior_a"]), json={}).status_code == 409
    _submit(client, context)
    assert client.post(f"/api/medical-records/{record.id}/review/start", headers=_headers(doctor)).status_code == 403
    assert client.post(f"/api/medical-records/{record.id}/review/start", headers=_headers(context["cross"])).status_code == 403
    assert client.get("/api/medical-records/pending-review", headers=_headers(context["cross"])).json()["data"]["total"] == 0
    assert client.post(f"/api/medical-records/{record.id}/review/start", headers=_headers(context["admin"])).status_code == 200

    senior = context["senior_a"]
    encounter = context["encounter"]
    self_record = MedicalRecord(record_no="MRREVIEWSELF", encounter_id=encounter.id + 1000, chief_complaint="完整主诉", present_illness="完整现病史", physical_exam="完整查体", diagnosis_summary="诊断", treatment_plan="计划", status=MedicalRecordStatus.SUBMITTED, created_by=senior.id, updated_by=senior.id, submitted_by=senior.id, submitted_at=datetime.now(timezone.utc))
    # 使用独立就诊满足一对一约束。
    self_encounter = Encounter(id=encounter.id + 1000, encounter_no="EREVIEWSELF", patient_id=context["patient"].id, doctor_id=senior.id, department_id=senior.department_id, encounter_type=EncounterType.OUTPATIENT, visit_time=datetime.now(timezone.utc), status=EncounterStatus.IN_PROGRESS, created_by=senior.id)
    seeded_db.add_all([self_encounter, self_record])
    seeded_db.commit()
    from app.models.medical_record import MedicalRecordVersion
    seeded_db.add(MedicalRecordVersion(record_id=self_record.id, version=1, snapshot_data={"medical_record": {}}, change_reason="首次提交", created_by=senior.id))
    seeded_db.commit()
    assert client.post(f"/api/medical-records/{self_record.id}/review/start", headers=_headers(senior)).status_code == 403


def test_review_lock_and_reject_validation(client: TestClient, seeded_db: Session) -> None:
    context = _setup(seeded_db)
    record, doctor, first, second = context["record"], context["doctor"], context["senior_a"], context["senior_b"]
    _create_diagnosis(client, record, doctor)
    _submit(client, context)
    assert client.post(f"/api/medical-records/{record.id}/review/start", headers=_headers(first)).status_code == 200
    assert client.post(f"/api/medical-records/{record.id}/review/start", headers=_headers(second)).status_code == 409
    assert client.post(f"/api/medical-records/{record.id}/review/approve", headers=_headers(second), json={}).status_code == 409
    assert client.post(f"/api/medical-records/{record.id}/review/reject", headers=_headers(first), json={"comment": "不通过"}).status_code == 422
    assert client.post(f"/api/medical-records/{record.id}/review/approve", headers=_headers(first), json={}).status_code == 200
    assert client.patch(f"/api/medical-records/{record.id}", headers=_headers(doctor), json={"doctor_notes": "不允许"}).status_code == 409
    assert _submit(client, context).status_code == 409


def test_resubmit_requires_reason(client: TestClient, seeded_db: Session) -> None:
    context = _setup(seeded_db)
    record, doctor, senior = context["record"], context["doctor"], context["senior_a"]
    _create_diagnosis(client, record, doctor)
    _submit(client, context)
    client.post(f"/api/medical-records/{record.id}/review/start", headers=_headers(senior))
    client.post(f"/api/medical-records/{record.id}/review/reject", headers=_headers(senior), json={"comment": "需要补充完整记录"})
    assert _submit(client, context).status_code == 400
    assert _submit(client, context, "短").status_code == 400


def test_conditional_review_lock_allows_only_one_winner(tmp_path: Path) -> None:
    engine = create_engine(f"sqlite:///{(tmp_path / 'review-lock.db').as_posix()}", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine, expire_on_commit=False)
    with factory() as db:
        department = Department(department_code="LOCK", name="锁测试")
        patient = Patient(patient_no="PLOCK001", name="并发患者", gender=Gender.UNKNOWN)
        first = User(username="lock-a", password_hash="x", real_name="甲", status=UserStatus.ACTIVE, is_active=True)
        second = User(username="lock-b", password_hash="x", real_name="乙", status=UserStatus.ACTIVE, is_active=True)
        db.add_all([department, patient, first, second]); db.flush()
        encounter = Encounter(encounter_no="ELOCK001", patient_id=patient.id, doctor_id=first.id, department_id=department.id, encounter_type=EncounterType.OUTPATIENT, visit_time=datetime.now(timezone.utc), status=EncounterStatus.IN_PROGRESS, created_by=first.id)
        db.add(encounter); db.flush()
        record = MedicalRecord(record_no="MRLOCK001", encounter_id=encounter.id, status=MedicalRecordStatus.SUBMITTED, created_by=first.id, updated_by=first.id)
        db.add(record); db.commit()
        record_id, reviewer_ids = record.id, (first.id, second.id)

    def claim(reviewer_id: int) -> bool:
        with factory() as db:
            won = MedicalRecordRepository(db).conditional_start_review(record_id, reviewer_id)
            db.commit()
            return won

    with ThreadPoolExecutor(max_workers=2) as pool:
        outcomes = list(pool.map(claim, reviewer_ids))
    assert sorted(outcomes) == [False, True]
    with factory() as db:
        stored = db.get(MedicalRecord, record_id)
        assert stored.status == MedicalRecordStatus.REVIEWING and stored.current_reviewer_id in reviewer_ids
    engine.dispose()
