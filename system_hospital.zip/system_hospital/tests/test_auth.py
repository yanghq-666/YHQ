"""登录、当前用户和 RBAC 接口测试。"""

from fastapi.testclient import TestClient
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.security import hash_password
from app.models.enums import UserStatus
from app.models.role import Role
from app.models.user import User, UserRole


def _login(client: TestClient, username: str, password: str) -> str:
    response = client.post(
        "/api/auth/login",
        json={"username": username, "password": password},
    )
    assert response.status_code == 200
    return response.json()["data"]["access_token"]


def test_login_and_get_current_user(
    client: TestClient, seeded_db: Session
) -> None:
    token = _login(client, "admin", "Admin@Test123")
    response = client.get(
        "/api/auth/me",
        headers={"Authorization": f"Bearer {token}"},
    )

    assert response.status_code == 200
    body = response.json()
    assert body["success"] is True
    assert body["data"]["username"] == "admin"
    assert body["data"]["real_name"] == "测试管理员"
    assert body["data"]["roles"] == ["ADMIN"]
    assert "admin:user" in body["data"]["permissions"]
    assert "password_hash" not in body["data"]


def test_login_failure_uses_unified_response(
    client: TestClient, seeded_db: Session
) -> None:
    response = client.post(
        "/api/auth/login",
        json={"username": "admin", "password": "wrong-password"},
    )

    assert response.status_code == 401
    assert response.json() == {
        "success": False,
        "code": 401,
        "message": "用户名或密码错误",
        "data": None,
    }


def test_me_requires_bearer_token(client: TestClient) -> None:
    response = client.get("/api/auth/me")

    assert response.status_code == 401
    assert response.json()["message"] == "请先登录"


def test_rbac_allows_admin_and_denies_doctor(
    client: TestClient, seeded_db: Session
) -> None:
    admin_token = _login(client, "admin", "Admin@Test123")
    allowed = client.get(
        "/api/admin/users",
        headers={"Authorization": f"Bearer {admin_token}"},
    )
    assert allowed.status_code == 200
    assert allowed.json()["success"] is True

    doctor_role = seeded_db.scalar(select(Role).where(Role.code == "DOCTOR"))
    assert doctor_role is not None
    doctor = User(
        username="doctor",
        password_hash=hash_password("Doctor@Test123"),
        real_name="测试医生",
        status=UserStatus.ACTIVE,
    )
    seeded_db.add(doctor)
    seeded_db.flush()
    seeded_db.add(UserRole(user_id=doctor.id, role_id=doctor_role.id))
    seeded_db.commit()

    doctor_token = _login(client, "doctor", "Doctor@Test123")
    denied = client.get(
        "/api/admin/users",
        headers={"Authorization": f"Bearer {doctor_token}"},
    )
    assert denied.status_code == 403
    assert denied.json()["message"] == "缺少权限：admin:user"


def test_unknown_user_login_uses_same_error(
    client: TestClient, seeded_db: Session
) -> None:
    response = client.post(
        "/api/auth/login",
        json={"username": "missing", "password": "wrong-password"},
    )
    assert response.status_code == 401
    assert response.json()["message"] == "用户名或密码错误"


def test_invalid_token_is_rejected(client: TestClient) -> None:
    response = client.get(
        "/api/auth/me",
        headers={"Authorization": "Bearer invalid-token"},
    )
    assert response.status_code == 401


def test_disabled_user_token_returns_403(
    client: TestClient, seeded_db: Session
) -> None:
    token = _login(client, "admin", "Admin@Test123")
    admin = seeded_db.scalar(select(User).where(User.username == "admin"))
    assert admin is not None
    admin.is_active = False
    admin.status = UserStatus.INACTIVE
    seeded_db.commit()

    response = client.get(
        "/api/auth/me",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 403
    assert response.json()["message"] == "账号已被禁用"


def test_login_response_contains_user(
    client: TestClient, seeded_db: Session
) -> None:
    response = client.post(
        "/api/auth/login",
        json={"username": "admin", "password": "Admin@Test123"},
    )
    assert response.status_code == 200
    assert response.json()["data"]["user"]["username"] == "admin"
