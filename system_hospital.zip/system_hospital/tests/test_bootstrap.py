"""系统基础数据初始化测试。"""

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.security import verify_password
from app.models.department import Department
from app.models.permission import Permission, RolePermission
from app.models.role import Role
from app.models.user import User, UserRole
from app.services.bootstrap_service import (
    DEPARTMENTS,
    PERMISSIONS,
    ROLES,
    initialize_system_data,
)


def test_bootstrap_is_complete_and_idempotent(db_session: Session) -> None:
    first = initialize_system_data(
        db_session,
        admin_username="admin",
        admin_password="Initial@Test123",
        admin_real_name="管理员",
    )
    admin = db_session.scalar(select(User).where(User.username == "admin"))
    assert admin is not None
    initial_hash = admin.password_hash

    second = initialize_system_data(
        db_session,
        admin_username="admin",
        admin_password="Different@Test123",
        admin_real_name="管理员",
    )

    assert first == second
    assert db_session.scalar(select(func.count(Role.id))) == len(ROLES)
    assert db_session.scalar(select(func.count(Permission.id))) == len(PERMISSIONS)
    assert db_session.scalar(select(func.count(Department.id))) == len(DEPARTMENTS)
    assert len(DEPARTMENTS) == 9
    assert db_session.scalar(select(func.count(User.id))) == 1
    assert db_session.scalar(select(func.count(UserRole.user_id))) == 1
    assert db_session.scalar(select(func.count(RolePermission.role_id))) > 0

    db_session.refresh(admin)
    assert admin.password_hash == initial_hash
    assert verify_password("Initial@Test123", admin.password_hash)
    assert not verify_password("Different@Test123", admin.password_hash)
