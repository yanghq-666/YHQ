"""患者建档、查询、权限、脱敏、软删除和审计测试。"""

from datetime import datetime, timezone

from fastapi.testclient import TestClient
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.security import create_access_token, hash_password
from app.models.audit_log import AuditLog
from app.models.enums import UserStatus
from app.models.patient import Patient
from app.models.role import Role
from app.models.user import User, UserRole


def _headers_for(user: User) -> dict[str, str]:
    return {
        "Authorization": f"Bearer {create_access_token(user.id, user.username)}"
    }


def _admin_headers(db: Session) -> dict[str, str]:
    admin = db.scalar(select(User).where(User.username == "admin"))
    assert admin is not None
    return _headers_for(admin)


def _create_role_user(db: Session, username: str, role_code: str) -> User:
    role = db.scalar(select(Role).where(Role.code == role_code))
    assert role is not None
    user = User(
        username=username,
        password_hash=hash_password("Patient@Test123"),
        real_name=f"{role_code}测试用户",
        status=UserStatus.ACTIVE,
        is_active=True,
    )
    db.add(user)
    db.flush()
    db.add(UserRole(user_id=user.id, role_id=role.id))
    db.commit()
    return user


def _patient_payload(**overrides: object) -> dict[str, object]:
    payload: dict[str, object] = {
        "name": "张三",
        "gender": "MALE",
        "birthday": "1985-06-12",
        "id_card": "110101198506121234",
        "phone": "13800000000",
        "address": "北京市",
        "blood_type": "A",
        "allergy_history": "青霉素过敏",
        "emergency_contact": "李四",
        "emergency_phone": "13900000000",
        "remark": "测试患者",
    }
    payload.update(overrides)
    return payload


def _create_patient(
    client: TestClient,
    headers: dict[str, str],
    **overrides: object,
) -> dict[str, object]:
    response = client.post(
        "/api/patients",
        headers=headers,
        json=_patient_payload(**overrides),
    )
    assert response.status_code == 201, response.text
    return response.json()["data"]


def test_create_patient_generates_unique_patient_number(
    client: TestClient, seeded_db: Session
) -> None:
    headers = _admin_headers(seeded_db)
    first = _create_patient(client, headers)
    second = _create_patient(
        client,
        headers,
        name="李四",
        id_card="110101198701011235",
    )

    current_year = datetime.now(timezone.utc).year
    assert first["patient_no"] == f"P{current_year}000001"
    assert second["patient_no"] == f"P{current_year}000002"
    assert first["patient_no"] != second["patient_no"]
    assert seeded_db.scalar(select(func.count(Patient.id))) == 2


def test_duplicate_id_card_is_rejected(
    client: TestClient, seeded_db: Session
) -> None:
    headers = _admin_headers(seeded_db)
    _create_patient(client, headers)
    response = client.post(
        "/api/patients",
        headers=headers,
        json=_patient_payload(name="同身份证患者"),
    )

    assert response.status_code == 409
    assert response.json()["message"] == "该身份证号已存在患者档案"


def test_same_name_with_different_identity_is_allowed(
    client: TestClient, seeded_db: Session
) -> None:
    headers = _admin_headers(seeded_db)
    _create_patient(client, headers)
    second = _create_patient(
        client, headers, id_card="110101199001011236", phone="13700000000"
    )
    assert second["name"] == "张三"


def test_user_without_create_permission_gets_403(
    client: TestClient, seeded_db: Session
) -> None:
    nurse = _create_role_user(seeded_db, "nurse01", "NURSE")
    response = client.post(
        "/api/patients",
        headers=_headers_for(nurse),
        json=_patient_payload(),
    )
    assert response.status_code == 403
    assert "patient:create" in response.json()["message"]


def test_patient_list_pagination_and_keyword_search(
    client: TestClient, seeded_db: Session
) -> None:
    headers = _admin_headers(seeded_db)
    _create_patient(client, headers, name="张一", id_card="110101198501011231")
    _create_patient(client, headers, name="张二", id_card="110101198501011232")
    _create_patient(client, headers, name="王三", id_card="110101198501011233")

    page = client.get("/api/patients?page=1&page_size=2", headers=headers)
    searched = client.get(
        "/api/patients?keyword=张&page=1&page_size=20", headers=headers
    )

    assert page.status_code == 200
    assert len(page.json()["data"]["items"]) == 2
    assert page.json()["data"]["total"] == 3
    assert page.json()["data"]["pages"] == 2
    assert searched.json()["data"]["total"] == 2


def test_search_by_patient_number(
    client: TestClient, seeded_db: Session
) -> None:
    headers = _admin_headers(seeded_db)
    patient = _create_patient(client, headers)
    response = client.get(
        f"/api/patients?patient_no={patient['patient_no']}",
        headers=headers,
    )
    assert response.status_code == 200
    assert response.json()["data"]["items"][0]["id"] == patient["id"]


def test_get_patient_detail_and_not_found(
    client: TestClient, seeded_db: Session
) -> None:
    headers = _admin_headers(seeded_db)
    patient = _create_patient(client, headers)
    found = client.get(f"/api/patients/{patient['id']}", headers=headers)
    missing = client.get("/api/patients/99999", headers=headers)

    assert found.status_code == 200
    assert found.json()["data"]["patient_no"] == patient["patient_no"]
    assert missing.status_code == 404


def test_update_patient_and_forbid_patient_number_change(
    client: TestClient, seeded_db: Session
) -> None:
    headers = _admin_headers(seeded_db)
    patient = _create_patient(client, headers)
    response = client.put(
        f"/api/patients/{patient['id']}",
        headers=headers,
        json={"name": "张三（更新）", "phone": "13600000000"},
    )
    forbidden = client.put(
        f"/api/patients/{patient['id']}",
        headers=headers,
        json={"patient_no": "MANUAL001"},
    )

    assert response.status_code == 200
    assert response.json()["data"]["name"] == "张三（更新）"
    assert response.json()["data"]["patient_no"] == patient["patient_no"]
    assert forbidden.status_code == 422


def test_soft_delete_hides_patient_and_writes_audit(
    client: TestClient, seeded_db: Session
) -> None:
    headers = _admin_headers(seeded_db)
    patient = _create_patient(client, headers)
    response = client.delete(f"/api/patients/{patient['id']}", headers=headers)
    detail = client.get(f"/api/patients/{patient['id']}", headers=headers)

    assert response.status_code == 200
    assert detail.status_code == 404
    deleted = seeded_db.get(Patient, patient["id"])
    assert deleted is not None and deleted.deleted_at is not None
    actions = set(
        seeded_db.scalars(
            select(AuditLog.action).where(AuditLog.target_id == patient["id"])
        ).all()
    )
    assert {"PATIENT_CREATE", "PATIENT_DELETE"} <= actions


def test_create_and_update_audit_contains_request_context(
    client: TestClient, seeded_db: Session
) -> None:
    headers = _admin_headers(seeded_db)
    patient = _create_patient(client, headers)
    client.put(
        f"/api/patients/{patient['id']}",
        headers=headers,
        json={"remark": "已复诊"},
    )
    update_log = seeded_db.scalar(
        select(AuditLog).where(
            AuditLog.target_id == patient["id"],
            AuditLog.action == "PATIENT_UPDATE",
        )
    )
    assert update_log is not None
    assert update_log.user_id is not None
    assert update_log.request_method == "PUT"
    assert update_log.request_path == f"/api/patients/{patient['id']}"
    assert update_log.old_value is not None
    assert update_log.new_value is not None
    assert "********" in update_log.new_value["id_card"]


def test_non_admin_is_masked_while_admin_sees_full_values(
    client: TestClient, seeded_db: Session
) -> None:
    admin_headers = _admin_headers(seeded_db)
    patient = _create_patient(client, admin_headers)
    doctor = _create_role_user(seeded_db, "doctor-patient", "DOCTOR")

    admin_detail = client.get(
        f"/api/patients/{patient['id']}", headers=admin_headers
    )
    doctor_detail = client.get(
        f"/api/patients/{patient['id']}", headers=_headers_for(doctor)
    )

    assert admin_detail.json()["data"]["id_card"] == "110101198506121234"
    assert admin_detail.json()["data"]["phone"] == "13800000000"
    assert doctor_detail.json()["data"]["id_card"] == "110101********1234"
    assert doctor_detail.json()["data"]["phone"] == "138****0000"


def test_admin_can_restore_soft_deleted_patient(
    client: TestClient, seeded_db: Session
) -> None:
    headers = _admin_headers(seeded_db)
    patient = _create_patient(client, headers)
    client.delete(f"/api/patients/{patient['id']}", headers=headers)
    restored = client.post(
        f"/api/patients/{patient['id']}/restore", headers=headers
    )

    assert restored.status_code == 200
    assert restored.json()["data"]["id"] == patient["id"]
    assert client.get(
        f"/api/patients/{patient['id']}", headers=headers
    ).status_code == 200
    assert seeded_db.scalar(
        select(func.count(AuditLog.id)).where(
            AuditLog.target_id == patient["id"],
            AuditLog.action == "PATIENT_RESTORE",
        )
    ) == 1

